# prototype/demo/social_dialogue.json

**$.phone.call[0].title**

```text
自动续费侦探
```

**$.phone.call[0].lines[0]**

```text
>我刚翻账单，发现有个会员一直在扣钱。
```

**$.phone.call[0].lines[1]**

```text
哪个？
```

**$.phone.call[0].lines[2]**

```text
>一个好久没打开的软件，连密码都忘了。
```

**$.phone.call[0].lines[3]**

```text
赶紧关了吧。我也去看看我的。
```

**$.phone.call[1].title**

```text
购物车减负
```

**$.phone.call[1].lines[0]**

```text
>我把购物车删了一半。
```

**$.phone.call[1].lines[1]**

```text
买完了？
```

**$.phone.call[1].lines[2]**

```text
>没买，越看越觉得用不上。
```

**$.phone.call[1].lines[3]**

```text
那挺好啊，省下钱吃顿好的。
```

**$.phone.call[2].title**

```text
路边的空椅子
```

**$.phone.call[2].lines[0]**

```text
>我路上找了张椅子坐，结果不太想起来了。
```

**$.phone.call[2].lines[1]**

```text
累啦？
```

**$.phone.call[2].lines[2]**

```text
>有点。本来还想去另一家店。
```

**$.phone.call[2].lines[3]**

```text
下回再去呗，店又不跑。
```

**$.phone.call[3].title**

```text
袋子里的袋子
```

**$.phone.call[3].lines[0]**

```text
>我家怎么能翻出这么多袋子啊。
```

**$.phone.call[3].lines[1]**

```text
我家也是，一抽屉。
```

**$.phone.call[3].lines[2]**

```text
>这到底留到什么时候用？
```

**$.phone.call[3].lines[3]**

```text
挑几个结实的，剩下的扔了吧。
```

**$.phone.call[4].title**

```text
发错的语音
```

**$.phone.call[4].lines[0]**

```text
>我给自己发了条语音。
```

**$.phone.call[4].lines[1]**

```text
提醒自己拿钥匙？
```

**$.phone.call[4].lines[2]**

```text
>对，结果听见自己的声音又不想点开。
```

**$.phone.call[4].lines[3]**

```text
哈哈，钥匙拿了就行。
```

**$.phone.call[5].title**

```text
冰箱磁铁
```

**$.phone.call[5].lines[0]**

```text
>我贴了个少吃零食的冰箱贴。
```

**$.phone.call[5].lines[1]**

```text
然后呢？
```

**$.phone.call[5].lines[2]**

```text
>拿零食的时候顺手把它扶正了。
```

**$.phone.call[5].lines[3]**

```text
你还挺照顾它面子的。
```

**$.phone.call[6].title**

```text
导航的脾气
```

**$.phone.call[6].lines[0]**

```text
>我没听导航的，多绕了好一段。
```

**$.phone.call[6].lines[1]**

```text
又想抄近路？
```

**$.phone.call[6].lines[2]**

```text
>嗯，觉得自己认得。
```

**$.phone.call[6].lines[3]**

```text
下次先看看路，别光觉得。
```

**$.phone.call[7].title**

```text
袜子失踪案
```

**$.phone.call[7].lines[0]**

```text
>我一只袜子又找不着了。
```

**$.phone.call[7].lines[1]**

```text
床底看了没？
```

**$.phone.call[7].lines[2]**

```text
>看了，翻出另外两只。
```

**$.phone.call[7].lines[3]**

```text
行，至少找袜子这事没白忙。
```

**$.phone.call[8].title**

```text
安静的快递
```

**$.phone.call[8].lines[0]**

```text
>买了一颗纽扣，寄来个挺大的盒子。
```

**$.phone.call[8].lines[1]**

```text
里面垫满纸？
```

**$.phone.call[8].lines[2]**

```text
>对，拆了好几层才看见。
```

**$.phone.call[8].lines[3]**

```text
别顺手把纽扣和纸一起扔了啊。
```

**$.phone.call[9].title**

```text
地图收藏夹
```

**$.phone.call[9].lines[0]**

```text
>我收藏了好多店，基本没去过。
```

**$.phone.call[9].lines[1]**

```text
挑一家近的先去啊。
```

**$.phone.call[9].lines[2]**

```text
>看着都想去，就选不出来。
```

**$.phone.call[9].lines[3]**

```text
先发两家给我，我帮你纠结。
```

**$.phone.call[10].title**

```text
学会拒绝
```

**$.phone.call[10].lines[0]**

```text
>有件事我不想帮，刚才终于说了。
```

**$.phone.call[10].lines[1]**

```text
对方怎么回？
```

**$.phone.call[10].lines[2]**

```text
>说没事，找别人了。
```

**$.phone.call[10].lines[3]**

```text
那不挺好，我还以为要扯半天。
```

**$.phone.call[11].title**

```text
盆栽新叶
```

**$.phone.call[11].lines[0]**

```text
>我那盆绿植长新叶子了。
```

**$.phone.call[11].lines[1]**

```text
拍我看看。
```

**$.phone.call[11].lines[2]**

```text
>等会儿啊，挺小一片的。
```

**$.phone.call[11].lines[3]**

```text
看见了，还真长出来了。
```

**$.phone.call[12].title**

```text
相册清理
```

**$.phone.call[12].lines[0]**

```text
>我本来想删照片，看着看着忘删了。
```

**$.phone.call[12].lines[1]**

```text
又翻以前出去玩的照片了吧。
```

**$.phone.call[12].lines[2]**

```text
>嗯，一下看了好久。
```

**$.phone.call[12].lines[3]**

```text
那先留着呗，下次别拍那么多重样的。
```

**$.phone.call[13].title**

```text
门口的鞋
```

**$.phone.call[13].lines[0]**

```text
>我差点穿两只不一样的鞋出门。
```

**$.phone.call[13].lines[1]**

```text
哈哈哈，真穿出去了？
```

**$.phone.call[13].lines[2]**

```text
>走到门口才发现。
```

**$.phone.call[13].lines[3]**

```text
还好，还来得及假装没这回事。
```

**$.phone.call[14].title**

```text
纸质地图
```

**$.phone.call[14].lines[0]**

```text
>我翻出张旧地图，好多地方都变了。
```

**$.phone.call[14].lines[1]**

```text
哪里来的？
```

**$.phone.call[14].lines[2]**

```text
>以前随手拿的，夹在一本书里。
```

**$.phone.call[14].lines[3]**

```text
先别扔，拍张给我看看。
```

**$.phone.call[15].title**

```text
新买的笔
```

**$.phone.call[15].lines[0]**

```text
>我新买的笔还挺好写。
```

**$.phone.call[15].lines[1]**

```text
什么笔？
```

**$.phone.call[15].lines[2]**

```text
>一支普通的，就是不怎么断墨。
```

**$.phone.call[15].lines[3]**

```text
链接发我，我那支写着写着就没了。
```

**$.phone.call[16].title**

```text
薄荷的野心
```

**$.phone.call[16].lines[0]**

```text
>我的薄荷快挤满花盆了。
```

**$.phone.call[16].lines[1]**

```text
那剪一点啊。
```

**$.phone.call[16].lines[2]**

```text
>怕我下手重了。
```

**$.phone.call[16].lines[3]**

```text
先剪一小撮，别整盆端走就行。
```

**$.phone.call[17].title**

```text
冷笑话存档
```

**$.phone.call[17].lines[0]**

```text
>你上次那个冷笑话，我后来讲给别人听了。
```

**$.phone.call[17].lines[1]**

```text
有人笑吗？
```

**$.phone.call[17].lines[2]**

```text
>有一个，说没听懂。
```

**$.phone.call[17].lines[3]**

```text
那跟你当时反应差不多。
```

**$.phone.call[18].title**

```text
数字断舍离
```

**$.phone.call[18].lines[0]**

```text
>我退了几个好久不说话的群。
```

**$.phone.call[18].lines[1]**

```text
是不是清净点了？
```

**$.phone.call[18].lines[2]**

```text
>嗯，不过有个群又把我拉回去了。
```

**$.phone.call[18].lines[3]**

```text
哈哈，看来他们还挺舍不得你。
```

**$.phone.call[19].title**

```text
透明手机壳
```

**$.phone.call[19].lines[0]**

```text
>我手机壳里那张票都褪色了。
```

**$.phone.call[19].lines[1]**

```text
还夹着啊？
```

**$.phone.call[19].lines[2]**

```text
>嗯，懒得换，看着也习惯了。
```

**$.phone.call[19].lines[3]**

```text
你先擦擦壳吧，边都发黄了。
```

**$.phone.call[20].title**

```text
电梯里的镜子
```

**$.phone.call[20].lines[0]**

```text
>我在电梯里才发现衣领翻着。
```

**$.phone.call[20].lines[1]**

```text
翻多久了？
```

**$.phone.call[20].lines[2]**

```text
>不知道，已经在外面走一圈了。
```

**$.phone.call[20].lines[3]**

```text
没事，应该没人盯着你衣领看。
```

**$.phone.call[21].title**

```text
旧书签
```

**$.phone.call[21].lines[0]**

```text
>书里掉出一张纸，写着下次从这里看。
```

**$.phone.call[21].lines[1]**

```text
然后你看过这页没？
```

**$.phone.call[21].lines[2]**

```text
>完全没印象。
```

**$.phone.call[21].lines[3]**

```text
行，那这回真从这里看。
```

**$.phone.call[22].title**

```text
存下的表情
```

**$.phone.call[22].lines[0]**

```text
>我存了个表情，但一直没机会发。
```

**$.phone.call[22].lines[1]**

```text
先发我看看。
```

**$.phone.call[22].lines[2]**

```text
>发了。
```

**$.phone.call[22].lines[3]**

```text
哈哈哈，这个你留着，下回肯定用得上。
```

**$.phone.call[23].title**

```text
剪胶带的技巧
```

**$.phone.call[23].lines[0]**

```text
>我终于想起用完胶带折个角了。
```

**$.phone.call[23].lines[1]**

```text
你以前是不是每次都找半天？
```

**$.phone.call[23].lines[2]**

```text
>对，抠得我手指疼。
```

**$.phone.call[23].lines[3]**

```text
我也老忘，得贴张纸提醒一下。
```

**$.phone.call[24].title**

```text
耳机的左右
```

**$.phone.call[24].lines[0]**

```text
>我耳机好像一直戴反了。
```

**$.phone.call[24].lines[1]**

```text
你耳朵没觉得别扭？
```

**$.phone.call[24].lines[2]**

```text
>有一点，以为它就长这样。
```

**$.phone.call[24].lines[3]**

```text
你也太能凑合了吧。
```

**$.phone.call[25].title**

```text
忘带会员卡
```

**$.phone.call[25].lines[0]**

```text
>买完东西才想起能积分。
```

**$.phone.call[25].lines[1]**

```text
能补吗？
```

**$.phone.call[25].lines[2]**

```text
>问了，说下次记得。
```

**$.phone.call[25].lines[3]**

```text
那算了，别为了两分再跑回去。
```

**$.phone.call[26].title**

```text
一根充电线
```

**$.phone.call[26].lines[0]**

```text
>我找到那根能用的线了。
```

**$.phone.call[26].lines[1]**

```text
在哪儿？
```

**$.phone.call[26].lines[2]**

```text
>在一堆坏线里面。
```

**$.phone.call[26].lines[3]**

```text
坏的扔掉几根吧，不然还得再找。
```

**$.phone.call[27].title**

```text
自动更正
```

**$.phone.call[27].lines[0]**

```text
>输入法把我一句正经话改得乱七八糟。
```

**$.phone.call[27].lines[1]**

```text
发出去了？
```

**$.phone.call[27].lines[2]**

```text
>发了，对方回了我三个问号。
```

**$.phone.call[27].lines[3]**

```text
哈哈，先解释一下吧。
```

**$.phone.call[28].title**

```text
口袋里的硬币
```

**$.phone.call[28].lines[0]**

```text
>我口袋里摸出一块钱。
```

**$.phone.call[28].lines[1]**

```text
那你先收好。
```

**$.phone.call[28].lines[2]**

```text
>我还以为早就花了。
```

**$.phone.call[28].lines[3]**

```text
说不定你还有别的衣服没翻呢。
```

**$.phone.call[29].title**

```text
新鲜的夸奖
```

**$.phone.call[29].lines[0]**

```text
>有人夸我做得仔细，我一下不知道怎么回。
```

**$.phone.call[29].lines[1]**

```text
说谢谢啊。
```

**$.phone.call[29].lines[2]**

```text
>说了，但有点不习惯。
```

**$.phone.call[29].lines[3]**

```text
多收几次就习惯啦。
```

**$.phone.call[30].title**

```text
二手书的字
```

**$.phone.call[30].lines[0]**

```text
>我买的旧书上有人写批注。
```

**$.phone.call[30].lines[1]**

```text
写什么了？
```

**$.phone.call[30].lines[2]**

```text
>这一段没看懂。刚好，我也没懂。
```

**$.phone.call[30].lines[3]**

```text
哈哈，那你看看后面有没有答案。
```

**$.phone.call[31].title**

```text
小店的招牌
```

**$.phone.call[31].lines[0]**

```text
>路边那家店招牌有个字写歪了。
```

**$.phone.call[31].lines[1]**

```text
哪家？
```

**$.phone.call[31].lines[2]**

```text
>转角那家，小小的那个。
```

**$.phone.call[31].lines[3]**

```text
我下次路过也看看，我之前都没注意。
```

**$.phone.call[32].title**

```text
关掉的闹钟
```

**$.phone.call[32].lines[0]**

```text
>我删了一个早就不用的闹钟。
```

**$.phone.call[32].lines[1]**

```text
还一直响呢？
```

**$.phone.call[32].lines[2]**

```text
>没响，但老看见它就觉得有事。
```

**$.phone.call[32].lines[3]**

```text
删了好，真要用再定呗。
```

**$.phone.call[33].title**

```text
钥匙的标签
```

**$.phone.call[33].lines[0]**

```text
>我给钥匙贴标签，贴完还是分不清。
```

**$.phone.call[33].lines[1]**

```text
你写了啥？
```

**$.phone.call[33].lines[2]**

```text
>都写的家里。
```

**$.phone.call[33].lines[3]**

```text
你倒是写上开哪扇门啊。
```

**$.phone.call[34].title**

```text
试用装大集合
```

**$.phone.call[34].lines[0]**

```text
>我翻出一堆没用的试用装。
```

**$.phone.call[34].lines[1]**

```text
先看看过期没。
```

**$.phone.call[34].lines[2]**

```text
>有几袋字太小了，看不清。
```

**$.phone.call[34].lines[3]**

```text
凑灯底下看看，别放着放着又忘了。
```

**$.phone.call[35].title**

```text
路牌的新发现
```

**$.phone.call[35].lines[0]**

```text
>我才知道那条小路叫什么。
```

**$.phone.call[35].lines[1]**

```text
你不是经常走吗？
```

**$.phone.call[35].lines[2]**

```text
>我只记得旁边有家卖吃的。
```

**$.phone.call[35].lines[3]**

```text
也行，你认得地方就行。
```

**$.phone.call[36].title**

```text
记住一件好事
```

**$.phone.call[36].lines[0]**

```text
>刚才有人帮我扶了一下快掉的袋子。
```

**$.phone.call[36].lines[1]**

```text
东西没撒吧？
```

**$.phone.call[36].lines[2]**

```text
>没，吓我一跳，手里提太多了。
```

**$.phone.call[36].lines[3]**

```text
下次分两趟，别一口气全拎着。
```

**$.phone.call[37].title**

```text
拒绝无效比较
```

**$.phone.call[37].lines[0]**

```text
>我刚才又看别人进度，看得有点烦。
```

**$.phone.call[37].lines[1]**

```text
那先别看了呗。
```

**$.phone.call[37].lines[2]**

```text
>嗯，我这边其实也在做。
```

**$.phone.call[37].lines[3]**

```text
做你自己的，弄完再给我看看。
```

**$.phone.call[38].title**

```text
水杯的刻度
```

**$.phone.call[38].lines[0]**

```text
>我在杯子上画了两条线。
```

**$.phone.call[38].lines[1]**

```text
提醒喝水？
```

**$.phone.call[38].lines[2]**

```text
>对，现在一看还没喝到那儿。
```

**$.phone.call[38].lines[3]**

```text
那你先喝两口啊。
```

**$.phone.call[39].title**

```text
听错的歌词
```

**$.phone.call[39].lines[0]**

```text
>有句歌词我唱了好几年，居然是错的。
```

**$.phone.call[39].lines[1]**

```text
你唱成啥了？
```

**$.phone.call[39].lines[2]**

```text
>等下，我有点不想说。
```

**$.phone.call[39].lines[3]**

```text
哈哈，快说，我保证先不笑。
```

**$.phone.call[40].title**

```text
便签的便签
```

**$.phone.call[40].lines[0]**

```text
>我贴了张纸，提醒自己看另一张纸。
```

**$.phone.call[40].lines[1]**

```text
你这是绕了几层？
```

**$.phone.call[40].lines[2]**

```text
>贴完也觉得有点多余。
```

**$.phone.call[40].lines[3]**

```text
把第一张的事直接办了吧。
```

**$.phone.call[41].title**

```text
拼图缺一块
```

**$.phone.call[41].lines[0]**

```text
>拼图缺的那块找到了。
```

**$.phone.call[41].lines[1]**

```text
藏哪儿了？
```

**$.phone.call[41].lines[2]**

```text
>我手里，拿着找了半天。
```

**$.phone.call[41].lines[3]**

```text
哈哈哈，你先把手摊开这招记住。
```

**$.phone.call[42].title**

```text
地毯上的线头
```

**$.phone.call[42].lines[0]**

```text
>刚才以为地上有虫，吓我一跳。
```

**$.phone.call[42].lines[1]**

```text
真有啊？
```

**$.phone.call[42].lines[2]**

```text
>没，是一段线头。
```

**$.phone.call[42].lines[3]**

```text
哦，那你赶紧扫了，省得再吓一遍。
```

**$.phone.call[43].title**

```text
允许自己歇会儿
```

**$.phone.call[43].lines[0]**

```text
>我刚才坐着发了会儿呆。
```

**$.phone.call[43].lines[1]**

```text
舒服吧？
```

**$.phone.call[43].lines[2]**

```text
>嗯，啥也没干，倒没那么累了。
```

**$.phone.call[43].lines[3]**

```text
那再坐会儿，反正这会儿不急。
```

**$.phone.call[44].title**

```text
菜单上的小字
```

**$.phone.call[44].lines[0]**

```text
>菜上来了，和图片长得不太一样。
```

**$.phone.call[44].lines[1]**

```text
差很多吗？
```

**$.phone.call[44].lines[2]**

```text
>也还行，就是没那么满。
```

**$.phone.call[44].lines[3]**

```text
先尝尝吧，好吃就行。
```

**$.phone.call[45].title**

```text
找不到的文件
```

**$.phone.call[45].lines[0]**

```text
>我那个文件又不知道哪个是最后一版了。
```

**$.phone.call[45].lines[1]**

```text
你不是改名了吗？
```

**$.phone.call[45].lines[2]**

```text
>改了，好几个都叫最终。
```

**$.phone.call[45].lines[3]**

```text
先按时间排一下，再慢慢看。
```

**$.phone.call[46].title**

```text
袋里的小饼干
```

**$.phone.call[46].lines[0]**

```text
>包里居然还有一块完整饼干。
```

**$.phone.call[46].lines[1]**

```text
这次没碎啊？
```

**$.phone.call[46].lines[2]**

```text
>嗯，我都有点舍不得吃。
```

**$.phone.call[46].lines[3]**

```text
留太久也会碎，趁现在吃呗。
```

**$.phone.call[47].title**

```text
给未来留字
```

**$.phone.call[47].lines[0]**

```text
>我写了张纸条，想过阵子再看。
```

**$.phone.call[47].lines[1]**

```text
写什么了？
```

**$.phone.call[47].lines[2]**

```text
>提醒自己别乱藏东西。
```

**$.phone.call[47].lines[3]**

```text
那你别把这张纸条也藏起来。
```

**$.phone.call[48].title**

```text
说话不必有结论
```

**$.phone.call[48].lines[0]**

```text
>我是不是光顾着说了，你那边在忙吗？
```

**$.phone.call[48].lines[1]**

```text
还好，你接着说。
```

**$.phone.call[48].lines[2]**

```text
>嗯，也没什么大事，就闲扯两句。
```

**$.phone.call[48].lines[3]**

```text
挺好的，我这会儿也没别的事。
```

**$.phone.call[49].title**

```text
小心愿收集
```

**$.phone.call[49].lines[0]**

```text
>我想找条没走过的路逛逛。
```

**$.phone.call[49].lines[1]**

```text
去啊，别走太远就行。
```

**$.phone.call[49].lines[2]**

```text
>怕绕出去回不来了。
```

**$.phone.call[49].lines[3]**

```text
你开着地图嘛，真不行再问人。
```

**$.phone.video[0].title**

```text
镜头前·自动续费侦探
```

**$.phone.video[0].lines[0]**

```text
>我刚翻账单，发现有个会员一直在扣钱。
```

**$.phone.video[0].lines[1]**

```text
哪个？
```

**$.phone.video[0].lines[2]**

```text
>一个好久没打开的软件，连密码都忘了。
```

**$.phone.video[0].lines[3]**

```text
赶紧关了吧。我也去看看我的。
```

**$.phone.video[1].title**

```text
镜头前·购物车减负
```

**$.phone.video[1].lines[0]**

```text
>我把购物车删了一半。
```

**$.phone.video[1].lines[1]**

```text
买完了？
```

**$.phone.video[1].lines[2]**

```text
>没买，越看越觉得用不上。
```

**$.phone.video[1].lines[3]**

```text
那挺好啊，省下钱吃顿好的。
```

**$.phone.video[2].title**

```text
镜头前·路边的空椅子
```

**$.phone.video[2].lines[0]**

```text
>我路上找了张椅子坐，结果不太想起来了。
```

**$.phone.video[2].lines[1]**

```text
累啦？
```

**$.phone.video[2].lines[2]**

```text
>有点。本来还想去另一家店。
```

**$.phone.video[2].lines[3]**

```text
下回再去呗，店又不跑。
```

**$.phone.video[3].title**

```text
镜头前·袋子里的袋子
```

**$.phone.video[3].lines[0]**

```text
>我家怎么能翻出这么多袋子啊。
```

**$.phone.video[3].lines[1]**

```text
我家也是，一抽屉。
```

**$.phone.video[3].lines[2]**

```text
>这到底留到什么时候用？
```

**$.phone.video[3].lines[3]**

```text
挑几个结实的，剩下的扔了吧。
```

**$.phone.video[4].title**

```text
镜头前·发错的语音
```

**$.phone.video[4].lines[0]**

```text
>我给自己发了条语音。
```

**$.phone.video[4].lines[1]**

```text
提醒自己拿钥匙？
```

**$.phone.video[4].lines[2]**

```text
>对，结果听见自己的声音又不想点开。
```

**$.phone.video[4].lines[3]**

```text
哈哈，钥匙拿了就行。
```

**$.phone.video[5].title**

```text
镜头前·冰箱磁铁
```

**$.phone.video[5].lines[0]**

```text
>我贴了个少吃零食的冰箱贴。
```

**$.phone.video[5].lines[1]**

```text
然后呢？
```

**$.phone.video[5].lines[2]**

```text
>拿零食的时候顺手把它扶正了。
```

**$.phone.video[5].lines[3]**

```text
你还挺照顾它面子的。
```

**$.phone.video[6].title**

```text
镜头前·导航的脾气
```

**$.phone.video[6].lines[0]**

```text
>我没听导航的，多绕了好一段。
```

**$.phone.video[6].lines[1]**

```text
又想抄近路？
```

**$.phone.video[6].lines[2]**

```text
>嗯，觉得自己认得。
```

**$.phone.video[6].lines[3]**

```text
下次先看看路，别光觉得。
```

**$.phone.video[7].title**

```text
镜头前·袜子失踪案
```

**$.phone.video[7].lines[0]**

```text
>我一只袜子又找不着了。
```

**$.phone.video[7].lines[1]**

```text
床底看了没？
```

**$.phone.video[7].lines[2]**

```text
>看了，翻出另外两只。
```

**$.phone.video[7].lines[3]**

```text
行，至少找袜子这事没白忙。
```

**$.phone.video[8].title**

```text
镜头前·安静的快递
```

**$.phone.video[8].lines[0]**

```text
>买了一颗纽扣，寄来个挺大的盒子。
```

**$.phone.video[8].lines[1]**

```text
里面垫满纸？
```

**$.phone.video[8].lines[2]**

```text
>对，拆了好几层才看见。
```

**$.phone.video[8].lines[3]**

```text
别顺手把纽扣和纸一起扔了啊。
```

**$.phone.video[9].title**

```text
镜头前·地图收藏夹
```

**$.phone.video[9].lines[0]**

```text
>我收藏了好多店，基本没去过。
```

**$.phone.video[9].lines[1]**

```text
挑一家近的先去啊。
```

**$.phone.video[9].lines[2]**

```text
>看着都想去，就选不出来。
```

**$.phone.video[9].lines[3]**

```text
先发两家给我，我帮你纠结。
```

**$.phone.video[10].title**

```text
镜头前·学会拒绝
```

**$.phone.video[10].lines[0]**

```text
>有件事我不想帮，刚才终于说了。
```

**$.phone.video[10].lines[1]**

```text
对方怎么回？
```

**$.phone.video[10].lines[2]**

```text
>说没事，找别人了。
```

**$.phone.video[10].lines[3]**

```text
那不挺好，我还以为要扯半天。
```

**$.phone.video[11].title**

```text
镜头前·盆栽新叶
```

**$.phone.video[11].lines[0]**

```text
>我那盆绿植长新叶子了。
```

**$.phone.video[11].lines[1]**

```text
拍我看看。
```

**$.phone.video[11].lines[2]**

```text
>等会儿啊，挺小一片的。
```

**$.phone.video[11].lines[3]**

```text
看见了，还真长出来了。
```

**$.phone.video[12].title**

```text
镜头前·相册清理
```

**$.phone.video[12].lines[0]**

```text
>我本来想删照片，看着看着忘删了。
```

**$.phone.video[12].lines[1]**

```text
又翻以前出去玩的照片了吧。
```

**$.phone.video[12].lines[2]**

```text
>嗯，一下看了好久。
```

**$.phone.video[12].lines[3]**

```text
那先留着呗，下次别拍那么多重样的。
```

**$.phone.video[13].title**

```text
镜头前·门口的鞋
```

**$.phone.video[13].lines[0]**

```text
>我差点穿两只不一样的鞋出门。
```

**$.phone.video[13].lines[1]**

```text
哈哈哈，真穿出去了？
```

**$.phone.video[13].lines[2]**

```text
>走到门口才发现。
```

**$.phone.video[13].lines[3]**

```text
还好，还来得及假装没这回事。
```

**$.phone.video[14].title**

```text
镜头前·纸质地图
```

**$.phone.video[14].lines[0]**

```text
>我翻出张旧地图，好多地方都变了。
```

**$.phone.video[14].lines[1]**

```text
哪里来的？
```

**$.phone.video[14].lines[2]**

```text
>以前随手拿的，夹在一本书里。
```

**$.phone.video[14].lines[3]**

```text
先别扔，拍张给我看看。
```

**$.phone.video[15].title**

```text
镜头前·新买的笔
```

**$.phone.video[15].lines[0]**

```text
>我新买的笔还挺好写。
```

**$.phone.video[15].lines[1]**

```text
什么笔？
```

**$.phone.video[15].lines[2]**

```text
>一支普通的，就是不怎么断墨。
```

**$.phone.video[15].lines[3]**

```text
链接发我，我那支写着写着就没了。
```

**$.phone.video[16].title**

```text
镜头前·薄荷的野心
```

**$.phone.video[16].lines[0]**

```text
>我的薄荷快挤满花盆了。
```

**$.phone.video[16].lines[1]**

```text
那剪一点啊。
```

**$.phone.video[16].lines[2]**

```text
>怕我下手重了。
```

**$.phone.video[16].lines[3]**

```text
先剪一小撮，别整盆端走就行。
```

**$.phone.video[17].title**

```text
镜头前·冷笑话存档
```

**$.phone.video[17].lines[0]**

```text
>你上次那个冷笑话，我后来讲给别人听了。
```

**$.phone.video[17].lines[1]**

```text
有人笑吗？
```

**$.phone.video[17].lines[2]**

```text
>有一个，说没听懂。
```

**$.phone.video[17].lines[3]**

```text
那跟你当时反应差不多。
```

**$.phone.video[18].title**

```text
镜头前·数字断舍离
```

**$.phone.video[18].lines[0]**

```text
>我退了几个好久不说话的群。
```

**$.phone.video[18].lines[1]**

```text
是不是清净点了？
```

**$.phone.video[18].lines[2]**

```text
>嗯，不过有个群又把我拉回去了。
```

**$.phone.video[18].lines[3]**

```text
哈哈，看来他们还挺舍不得你。
```

**$.phone.video[19].title**

```text
镜头前·透明手机壳
```

**$.phone.video[19].lines[0]**

```text
>我手机壳里那张票都褪色了。
```

**$.phone.video[19].lines[1]**

```text
还夹着啊？
```

**$.phone.video[19].lines[2]**

```text
>嗯，懒得换，看着也习惯了。
```

**$.phone.video[19].lines[3]**

```text
你先擦擦壳吧，边都发黄了。
```

**$.phone.video[20].title**

```text
镜头前·电梯里的镜子
```

**$.phone.video[20].lines[0]**

```text
>我在电梯里才发现衣领翻着。
```

**$.phone.video[20].lines[1]**

```text
翻多久了？
```

**$.phone.video[20].lines[2]**

```text
>不知道，已经在外面走一圈了。
```

**$.phone.video[20].lines[3]**

```text
没事，应该没人盯着你衣领看。
```

**$.phone.video[21].title**

```text
镜头前·旧书签
```

**$.phone.video[21].lines[0]**

```text
>书里掉出一张纸，写着下次从这里看。
```

**$.phone.video[21].lines[1]**

```text
然后你看过这页没？
```

**$.phone.video[21].lines[2]**

```text
>完全没印象。
```

**$.phone.video[21].lines[3]**

```text
行，那这回真从这里看。
```

**$.phone.video[22].title**

```text
镜头前·存下的表情
```

**$.phone.video[22].lines[0]**

```text
>我存了个表情，但一直没机会发。
```

**$.phone.video[22].lines[1]**

```text
先发我看看。
```

**$.phone.video[22].lines[2]**

```text
>发了。
```

**$.phone.video[22].lines[3]**

```text
哈哈哈，这个你留着，下回肯定用得上。
```

**$.phone.video[23].title**

```text
镜头前·剪胶带的技巧
```

**$.phone.video[23].lines[0]**

```text
>我终于想起用完胶带折个角了。
```

**$.phone.video[23].lines[1]**

```text
你以前是不是每次都找半天？
```

**$.phone.video[23].lines[2]**

```text
>对，抠得我手指疼。
```

**$.phone.video[23].lines[3]**

```text
我也老忘，得贴张纸提醒一下。
```

**$.phone.video[24].title**

```text
镜头前·耳机的左右
```

**$.phone.video[24].lines[0]**

```text
>我耳机好像一直戴反了。
```

**$.phone.video[24].lines[1]**

```text
你耳朵没觉得别扭？
```

**$.phone.video[24].lines[2]**

```text
>有一点，以为它就长这样。
```

**$.phone.video[24].lines[3]**

```text
你也太能凑合了吧。
```

**$.phone.video[25].title**

```text
镜头前·忘带会员卡
```

**$.phone.video[25].lines[0]**

```text
>买完东西才想起能积分。
```

**$.phone.video[25].lines[1]**

```text
能补吗？
```

**$.phone.video[25].lines[2]**

```text
>问了，说下次记得。
```

**$.phone.video[25].lines[3]**

```text
那算了，别为了两分再跑回去。
```

**$.phone.video[26].title**

```text
镜头前·一根充电线
```

**$.phone.video[26].lines[0]**

```text
>我找到那根能用的线了。
```

**$.phone.video[26].lines[1]**

```text
在哪儿？
```

**$.phone.video[26].lines[2]**

```text
>在一堆坏线里面。
```

**$.phone.video[26].lines[3]**

```text
坏的扔掉几根吧，不然还得再找。
```

**$.phone.video[27].title**

```text
镜头前·自动更正
```

**$.phone.video[27].lines[0]**

```text
>输入法把我一句正经话改得乱七八糟。
```

**$.phone.video[27].lines[1]**

```text
发出去了？
```

**$.phone.video[27].lines[2]**

```text
>发了，对方回了我三个问号。
```

**$.phone.video[27].lines[3]**

```text
哈哈，先解释一下吧。
```

**$.phone.video[28].title**

```text
镜头前·口袋里的硬币
```

**$.phone.video[28].lines[0]**

```text
>我口袋里摸出一块钱。
```

**$.phone.video[28].lines[1]**

```text
那你先收好。
```

**$.phone.video[28].lines[2]**

```text
>我还以为早就花了。
```

**$.phone.video[28].lines[3]**

```text
说不定你还有别的衣服没翻呢。
```

**$.phone.video[29].title**

```text
镜头前·新鲜的夸奖
```

**$.phone.video[29].lines[0]**

```text
>有人夸我做得仔细，我一下不知道怎么回。
```

**$.phone.video[29].lines[1]**

```text
说谢谢啊。
```

**$.phone.video[29].lines[2]**

```text
>说了，但有点不习惯。
```

**$.phone.video[29].lines[3]**

```text
多收几次就习惯啦。
```

**$.phone.video[30].title**

```text
镜头前·二手书的字
```

**$.phone.video[30].lines[0]**

```text
>我买的旧书上有人写批注。
```

**$.phone.video[30].lines[1]**

```text
写什么了？
```

**$.phone.video[30].lines[2]**

```text
>这一段没看懂。刚好，我也没懂。
```

**$.phone.video[30].lines[3]**

```text
哈哈，那你看看后面有没有答案。
```

**$.phone.video[31].title**

```text
镜头前·小店的招牌
```

**$.phone.video[31].lines[0]**

```text
>路边那家店招牌有个字写歪了。
```

**$.phone.video[31].lines[1]**

```text
哪家？
```

**$.phone.video[31].lines[2]**

```text
>转角那家，小小的那个。
```

**$.phone.video[31].lines[3]**

```text
我下次路过也看看，我之前都没注意。
```

**$.phone.video[32].title**

```text
镜头前·关掉的闹钟
```

**$.phone.video[32].lines[0]**

```text
>我删了一个早就不用的闹钟。
```

**$.phone.video[32].lines[1]**

```text
还一直响呢？
```

**$.phone.video[32].lines[2]**

```text
>没响，但老看见它就觉得有事。
```

**$.phone.video[32].lines[3]**

```text
删了好，真要用再定呗。
```

**$.phone.video[33].title**

```text
镜头前·钥匙的标签
```

**$.phone.video[33].lines[0]**

```text
>我给钥匙贴标签，贴完还是分不清。
```

**$.phone.video[33].lines[1]**

```text
你写了啥？
```

**$.phone.video[33].lines[2]**

```text
>都写的家里。
```

**$.phone.video[33].lines[3]**

```text
你倒是写上开哪扇门啊。
```

**$.phone.video[34].title**

```text
镜头前·试用装大集合
```

**$.phone.video[34].lines[0]**

```text
>我翻出一堆没用的试用装。
```

**$.phone.video[34].lines[1]**

```text
先看看过期没。
```

**$.phone.video[34].lines[2]**

```text
>有几袋字太小了，看不清。
```

**$.phone.video[34].lines[3]**

```text
凑灯底下看看，别放着放着又忘了。
```

**$.phone.video[35].title**

```text
镜头前·路牌的新发现
```

**$.phone.video[35].lines[0]**

```text
>我才知道那条小路叫什么。
```

**$.phone.video[35].lines[1]**

```text
你不是经常走吗？
```

**$.phone.video[35].lines[2]**

```text
>我只记得旁边有家卖吃的。
```

**$.phone.video[35].lines[3]**

```text
也行，你认得地方就行。
```

**$.phone.video[36].title**

```text
镜头前·记住一件好事
```

**$.phone.video[36].lines[0]**

```text
>刚才有人帮我扶了一下快掉的袋子。
```

**$.phone.video[36].lines[1]**

```text
东西没撒吧？
```

**$.phone.video[36].lines[2]**

```text
>没，吓我一跳，手里提太多了。
```

**$.phone.video[36].lines[3]**

```text
下次分两趟，别一口气全拎着。
```

**$.phone.video[37].title**

```text
镜头前·拒绝无效比较
```

**$.phone.video[37].lines[0]**

```text
>我刚才又看别人进度，看得有点烦。
```

**$.phone.video[37].lines[1]**

```text
那先别看了呗。
```

**$.phone.video[37].lines[2]**

```text
>嗯，我这边其实也在做。
```

**$.phone.video[37].lines[3]**

```text
做你自己的，弄完再给我看看。
```

**$.phone.video[38].title**

```text
镜头前·水杯的刻度
```

**$.phone.video[38].lines[0]**

```text
>我在杯子上画了两条线。
```

**$.phone.video[38].lines[1]**

```text
提醒喝水？
```

**$.phone.video[38].lines[2]**

```text
>对，现在一看还没喝到那儿。
```

**$.phone.video[38].lines[3]**

```text
那你先喝两口啊。
```

**$.phone.video[39].title**

```text
镜头前·听错的歌词
```

**$.phone.video[39].lines[0]**

```text
>有句歌词我唱了好几年，居然是错的。
```

**$.phone.video[39].lines[1]**

```text
你唱成啥了？
```

**$.phone.video[39].lines[2]**

```text
>等下，我有点不想说。
```

**$.phone.video[39].lines[3]**

```text
哈哈，快说，我保证先不笑。
```

**$.phone.video[40].title**

```text
镜头前·便签的便签
```

**$.phone.video[40].lines[0]**

```text
>我贴了张纸，提醒自己看另一张纸。
```

**$.phone.video[40].lines[1]**

```text
你这是绕了几层？
```

**$.phone.video[40].lines[2]**

```text
>贴完也觉得有点多余。
```

**$.phone.video[40].lines[3]**

```text
把第一张的事直接办了吧。
```

**$.phone.video[41].title**

```text
镜头前·拼图缺一块
```

**$.phone.video[41].lines[0]**

```text
>拼图缺的那块找到了。
```

**$.phone.video[41].lines[1]**

```text
藏哪儿了？
```

**$.phone.video[41].lines[2]**

```text
>我手里，拿着找了半天。
```

**$.phone.video[41].lines[3]**

```text
哈哈哈，你先把手摊开这招记住。
```

**$.phone.video[42].title**

```text
镜头前·地毯上的线头
```

**$.phone.video[42].lines[0]**

```text
>刚才以为地上有虫，吓我一跳。
```

**$.phone.video[42].lines[1]**

```text
真有啊？
```

**$.phone.video[42].lines[2]**

```text
>没，是一段线头。
```

**$.phone.video[42].lines[3]**

```text
哦，那你赶紧扫了，省得再吓一遍。
```

**$.phone.video[43].title**

```text
镜头前·允许自己歇会儿
```

**$.phone.video[43].lines[0]**

```text
>我刚才坐着发了会儿呆。
```

**$.phone.video[43].lines[1]**

```text
舒服吧？
```

**$.phone.video[43].lines[2]**

```text
>嗯，啥也没干，倒没那么累了。
```

**$.phone.video[43].lines[3]**

```text
那再坐会儿，反正这会儿不急。
```

**$.phone.video[44].title**

```text
镜头前·菜单上的小字
```

**$.phone.video[44].lines[0]**

```text
>菜上来了，和图片长得不太一样。
```

**$.phone.video[44].lines[1]**

```text
差很多吗？
```

**$.phone.video[44].lines[2]**

```text
>也还行，就是没那么满。
```

**$.phone.video[44].lines[3]**

```text
先尝尝吧，好吃就行。
```

**$.phone.video[45].title**

```text
镜头前·找不到的文件
```

**$.phone.video[45].lines[0]**

```text
>我那个文件又不知道哪个是最后一版了。
```

**$.phone.video[45].lines[1]**

```text
你不是改名了吗？
```

**$.phone.video[45].lines[2]**

```text
>改了，好几个都叫最终。
```

**$.phone.video[45].lines[3]**

```text
先按时间排一下，再慢慢看。
```

**$.phone.video[46].title**

```text
镜头前·袋里的小饼干
```

**$.phone.video[46].lines[0]**

```text
>包里居然还有一块完整饼干。
```

**$.phone.video[46].lines[1]**

```text
这次没碎啊？
```

**$.phone.video[46].lines[2]**

```text
>嗯，我都有点舍不得吃。
```

**$.phone.video[46].lines[3]**

```text
留太久也会碎，趁现在吃呗。
```

**$.phone.video[47].title**

```text
镜头前·给未来留字
```

**$.phone.video[47].lines[0]**

```text
>我写了张纸条，想过阵子再看。
```

**$.phone.video[47].lines[1]**

```text
写什么了？
```

**$.phone.video[47].lines[2]**

```text
>提醒自己别乱藏东西。
```

**$.phone.video[47].lines[3]**

```text
那你别把这张纸条也藏起来。
```

**$.phone.video[48].title**

```text
镜头前·说话不必有结论
```

**$.phone.video[48].lines[0]**

```text
>我是不是光顾着说了，你那边在忙吗？
```

**$.phone.video[48].lines[1]**

```text
还好，你接着说。
```

**$.phone.video[48].lines[2]**

```text
>嗯，也没什么大事，就闲扯两句。
```

**$.phone.video[48].lines[3]**

```text
挺好的，我这会儿也没别的事。
```

**$.phone.video[49].title**

```text
镜头前·小心愿收集
```

**$.phone.video[49].lines[0]**

```text
>我想找条没走过的路逛逛。
```

**$.phone.video[49].lines[1]**

```text
去啊，别走太远就行。
```

**$.phone.video[49].lines[2]**

```text
>怕绕出去回不来了。
```

**$.phone.video[49].lines[3]**

```text
你开着地图嘛，真不行再问人。
```

**$.relationship.familiar[0][0]**

```text
再聊·初识·短短的近况
```

**$.relationship.familiar[0][1]**

```text
>最近怎么样？
```

**$.relationship.familiar[0][2]**

```text
还行，你呢？
```

**$.relationship.familiar[0][3]**

```text
>也差不多。
```

**$.relationship.familiar[0][4]**

```text
嗯，没什么新鲜事。
```

**$.relationship.familiar[1][0]**

```text
再聊·初识·共同的话题
```

**$.relationship.familiar[1][1]**

```text
>也没什么事，就是问个好。
```

**$.relationship.familiar[1][2]**

```text
你好啊。
```

**$.relationship.familiar[1][3]**

```text
>那我先去忙了。
```

**$.relationship.familiar[1][4]**

```text
好，回头聊。
```

**$.relationship.familiar[2][0]**

```text
再聊·初识·刚加上的人
```

**$.relationship.familiar[2][1]**

```text
>你好，我是{朋友}。
```

**$.relationship.familiar[2][2]**

```text
你好，刚给你备注上。
```

**$.relationship.familiar[2][3]**

```text
>好嘞，那我先去忙了。
```

**$.relationship.familiar[2][4]**

```text
嗯，回头聊。
```

**$.relationship.familiar[3][0]**

```text
再聊·初识·下次再聊
```

**$.relationship.familiar[3][1]**

```text
>我先去弄点事。
```

**$.relationship.familiar[3][2]**

```text
好，你忙。
```

**$.relationship.familiar[3][3]**

```text
>回头再聊。
```

**$.relationship.familiar[3][4]**

```text
嗯，拜拜。
```

**$.relationship.familiar[4][0]**

```text
再聊·初识·声音认出来了
```

**$.relationship.familiar[4][1]**

```text
>喂，我是{朋友}，刚才加的。
```

**$.relationship.familiar[4][2]**

```text
听出来了，你好。
```

**$.relationship.familiar[4][3]**

```text
>我还怕你没存号码。
```

**$.relationship.familiar[4][4]**

```text
存了，刚看见名字。
```

**$.relationship.familiar[5][0]**

```text
再聊·初识·先问方便
```

**$.relationship.familiar[5][1]**

```text
>现在方便说话吗？
```

**$.relationship.familiar[5][2]**

```text
方便，你说。
```

**$.relationship.familiar[5][3]**

```text
>我就问两句。
```

**$.relationship.familiar[5][4]**

```text
嗯。
```

**$.relationship.familiar[6][0]**

```text
再聊·初识·第一次拨通
```

**$.relationship.familiar[6][1]**

```text
>喂，能听见吧？
```

**$.relationship.familiar[6][2]**

```text
能，挺清楚的。
```

**$.relationship.familiar[6][3]**

```text
>好，我刚还以为没拨出去。
```

**$.relationship.familiar[6][4]**

```text
接到了。
```

**$.relationship.familiar[7][0]**

```text
再聊·初识·不是急事
```

**$.relationship.familiar[7][1]**

```text
>没急事，打个招呼。
```

**$.relationship.familiar[7][2]**

```text
嗯，你好。
```

**$.relationship.familiar[7][3]**

```text
>突然打过来，没打扰吧？
```

**$.relationship.familiar[7][4]**

```text
没有，刚好有空。
```

**$.relationship.familiar[8][0]**

```text
再聊·初识·确认那个地方
```

**$.relationship.familiar[8][1]**

```text
>刚说那个地方怎么走来着？
```

**$.relationship.familiar[8][2]**

```text
我找找地图，发给你吧。
```

**$.relationship.familiar[8][3]**

```text
>好，我光听方向有点记不住。
```

**$.relationship.familiar[8][4]**

```text
嗯，等一下。
```

**$.relationship.familiar[9][0]**

```text
再聊·初识·声音有点小
```

**$.relationship.familiar[9][1]**

```text
>你刚才那句没听清。
```

**$.relationship.familiar[9][2]**

```text
我大点声，这样呢？
```

**$.relationship.familiar[9][3]**

```text
>这回听见了。
```

**$.relationship.familiar[9][4]**

```text
你刚问什么来着？
```

**$.relationship.familiar[10][0]**

```text
再聊·初识·一下安静
```

**$.relationship.familiar[10][1]**

```text
>喂？
```

**$.relationship.familiar[10][2]**

```text
嗯？
```

**$.relationship.familiar[10][3]**

```text
>我还以为断了。
```

**$.relationship.familiar[10][4]**

```text
没断，我刚也没说话。
```

**$.relationship.familiar[11][0]**

```text
再聊·初识·叫名字有点生
```

**$.relationship.familiar[11][1]**

```text
>你名字最后那个字，我没叫错吧？
```

**$.relationship.familiar[11][2]**

```text
没错，就是那个音。
```

**$.relationship.familiar[11][3]**

```text
>好，我还怕念错。
```

**$.relationship.familiar[11][4]**

```text
没事。
```

**$.relationship.familiar[12][0]**

```text
再聊·初识·短短的问候
```

**$.relationship.familiar[12][1]**

```text
>后来没耽误你吧？
```

**$.relationship.familiar[12][2]**

```text
没有，赶上了。
```

**$.relationship.familiar[12][3]**

```text
>那就好，我刚想起来。
```

**$.relationship.familiar[12][4]**

```text
嗯，谢谢啊。
```

**$.relationship.familiar[13][0]**

```text
再聊·初识·手上在忙
```

**$.relationship.familiar[13][1]**

```text
>你那边什么声音？
```

**$.relationship.familiar[13][2]**

```text
手上在收点东西。
```

**$.relationship.familiar[13][3]**

```text
>那你先忙，不急。
```

**$.relationship.familiar[13][4]**

```text
没事，你说就行。
```

**$.relationship.familiar[14][0]**

```text
再聊·初识·不用站着接
```

**$.relationship.familiar[14][1]**

```text
>我一接电话就爱站起来。
```

**$.relationship.familiar[14][2]**

```text
你刚在走路？
```

**$.relationship.familiar[14][3]**

```text
>没有，在屋里转。
```

**$.relationship.familiar[14][4]**

```text
怪不得听着有脚步声。
```

**$.relationship.familiar[15][0]**

```text
再聊·初识·没准备话题
```

**$.relationship.familiar[15][1]**

```text
>我打过来才忘了想问什么。
```

**$.relationship.familiar[15][2]**

```text
想起来再说也行。
```

**$.relationship.familiar[15][3]**

```text
>等会儿……哦，想起来了。
```

**$.relationship.familiar[15][4]**

```text
什么？
```

**$.relationship.friend[0][0]**

```text
薄荷的野心
```

**$.relationship.friend[0][1]**

```text
>我的薄荷快挤满花盆了。
```

**$.relationship.friend[0][2]**

```text
那剪一点啊。
```

**$.relationship.friend[0][3]**

```text
>怕我下手重了。
```

**$.relationship.friend[0][4]**

```text
先剪一小撮，别整盆端走就行。
```

**$.relationship.friend[1][0]**

```text
冷笑话存档
```

**$.relationship.friend[1][1]**

```text
>你上次那个冷笑话，我后来讲给别人听了。
```

**$.relationship.friend[1][2]**

```text
有人笑吗？
```

**$.relationship.friend[1][3]**

```text
>有一个，说没听懂。
```

**$.relationship.friend[1][4]**

```text
那跟你当时反应差不多。
```

**$.relationship.friend[2][0]**

```text
数字断舍离
```

**$.relationship.friend[2][1]**

```text
>我退了几个好久不说话的群。
```

**$.relationship.friend[2][2]**

```text
是不是清净点了？
```

**$.relationship.friend[2][3]**

```text
>嗯，不过有个群又把我拉回去了。
```

**$.relationship.friend[2][4]**

```text
哈哈，看来他们还挺舍不得你。
```

**$.relationship.friend[3][0]**

```text
透明手机壳
```

**$.relationship.friend[3][1]**

```text
>我手机壳里那张票都褪色了。
```

**$.relationship.friend[3][2]**

```text
还夹着啊？
```

**$.relationship.friend[3][3]**

```text
>嗯，懒得换，看着也习惯了。
```

**$.relationship.friend[3][4]**

```text
你先擦擦壳吧，边都发黄了。
```

**$.relationship.friend[4][0]**

```text
电梯里的镜子
```

**$.relationship.friend[4][1]**

```text
>我在电梯里才发现衣领翻着。
```

**$.relationship.friend[4][2]**

```text
翻多久了？
```

**$.relationship.friend[4][3]**

```text
>不知道，已经在外面走一圈了。
```

**$.relationship.friend[4][4]**

```text
没事，应该没人盯着你衣领看。
```

**$.relationship.friend[5][0]**

```text
旧书签
```

**$.relationship.friend[5][1]**

```text
>书里掉出一张纸，写着下次从这里看。
```

**$.relationship.friend[5][2]**

```text
然后你看过这页没？
```

**$.relationship.friend[5][3]**

```text
>完全没印象。
```

**$.relationship.friend[5][4]**

```text
行，那这回真从这里看。
```

**$.relationship.friend[6][0]**

```text
存下的表情
```

**$.relationship.friend[6][1]**

```text
>我存了个表情，但一直没机会发。
```

**$.relationship.friend[6][2]**

```text
先发我看看。
```

**$.relationship.friend[6][3]**

```text
>发了。
```

**$.relationship.friend[6][4]**

```text
哈哈哈，这个你留着，下回肯定用得上。
```

**$.relationship.friend[7][0]**

```text
剪胶带的技巧
```

**$.relationship.friend[7][1]**

```text
>我终于想起用完胶带折个角了。
```

**$.relationship.friend[7][2]**

```text
你以前是不是每次都找半天？
```

**$.relationship.friend[7][3]**

```text
>对，抠得我手指疼。
```

**$.relationship.friend[7][4]**

```text
我也老忘，得贴张纸提醒一下。
```

**$.relationship.friend[8][0]**

```text
耳机的左右
```

**$.relationship.friend[8][1]**

```text
>我耳机好像一直戴反了。
```

**$.relationship.friend[8][2]**

```text
你耳朵没觉得别扭？
```

**$.relationship.friend[8][3]**

```text
>有一点，以为它就长这样。
```

**$.relationship.friend[8][4]**

```text
你也太能凑合了吧。
```

**$.relationship.friend[9][0]**

```text
忘带会员卡
```

**$.relationship.friend[9][1]**

```text
>买完东西才想起能积分。
```

**$.relationship.friend[9][2]**

```text
能补吗？
```

**$.relationship.friend[9][3]**

```text
>问了，说下次记得。
```

**$.relationship.friend[9][4]**

```text
那算了，别为了两分再跑回去。
```

**$.relationship.friend[10][0]**

```text
一根充电线
```

**$.relationship.friend[10][1]**

```text
>我找到那根能用的线了。
```

**$.relationship.friend[10][2]**

```text
在哪儿？
```

**$.relationship.friend[10][3]**

```text
>在一堆坏线里面。
```

**$.relationship.friend[10][4]**

```text
坏的扔掉几根吧，不然还得再找。
```

**$.relationship.friend[11][0]**

```text
自动更正
```

**$.relationship.friend[11][1]**

```text
>输入法把我一句正经话改得乱七八糟。
```

**$.relationship.friend[11][2]**

```text
发出去了？
```

**$.relationship.friend[11][3]**

```text
>发了，对方回了我三个问号。
```

**$.relationship.friend[11][4]**

```text
哈哈，先解释一下吧。
```

**$.relationship.friend[12][0]**

```text
口袋里的硬币
```

**$.relationship.friend[12][1]**

```text
>我口袋里摸出一块钱。
```

**$.relationship.friend[12][2]**

```text
那你先收好。
```

**$.relationship.friend[12][3]**

```text
>我还以为早就花了。
```

**$.relationship.friend[12][4]**

```text
说不定你还有别的衣服没翻呢。
```

**$.relationship.friend[13][0]**

```text
新鲜的夸奖
```

**$.relationship.friend[13][1]**

```text
>有人夸我做得仔细，我一下不知道怎么回。
```

**$.relationship.friend[13][2]**

```text
说谢谢啊。
```

**$.relationship.friend[13][3]**

```text
>说了，但有点不习惯。
```

**$.relationship.friend[13][4]**

```text
多收几次就习惯啦。
```

**$.relationship.friend[14][0]**

```text
二手书的字
```

**$.relationship.friend[14][1]**

```text
>我买的旧书上有人写批注。
```

**$.relationship.friend[14][2]**

```text
写什么了？
```

**$.relationship.friend[14][3]**

```text
>这一段没看懂。刚好，我也没懂。
```

**$.relationship.friend[14][4]**

```text
哈哈，那你看看后面有没有答案。
```

**$.relationship.friend[15][0]**

```text
小店的招牌
```

**$.relationship.friend[15][1]**

```text
>路边那家店招牌有个字写歪了。
```

**$.relationship.friend[15][2]**

```text
哪家？
```

**$.relationship.friend[15][3]**

```text
>转角那家，小小的那个。
```

**$.relationship.friend[15][4]**

```text
我下次路过也看看，我之前都没注意。
```

**$.relationship.close[0][0]**

```text
耳机的左右
```

**$.relationship.close[0][1]**

```text
>我耳机好像一直戴反了。
```

**$.relationship.close[0][2]**

```text
你耳朵没觉得别扭？
```

**$.relationship.close[0][3]**

```text
>有一点，以为它就长这样。
```

**$.relationship.close[0][4]**

```text
你也太能凑合了吧。
```

**$.relationship.close[1][0]**

```text
忘带会员卡
```

**$.relationship.close[1][1]**

```text
>买完东西才想起能积分。
```

**$.relationship.close[1][2]**

```text
能补吗？
```

**$.relationship.close[1][3]**

```text
>问了，说下次记得。
```

**$.relationship.close[1][4]**

```text
那算了，别为了两分再跑回去。
```

**$.relationship.close[2][0]**

```text
一根充电线
```

**$.relationship.close[2][1]**

```text
>我找到那根能用的线了。
```

**$.relationship.close[2][2]**

```text
在哪儿？
```

**$.relationship.close[2][3]**

```text
>在一堆坏线里面。
```

**$.relationship.close[2][4]**

```text
坏的扔掉几根吧，不然还得再找。
```

**$.relationship.close[3][0]**

```text
自动更正
```

**$.relationship.close[3][1]**

```text
>输入法把我一句正经话改得乱七八糟。
```

**$.relationship.close[3][2]**

```text
发出去了？
```

**$.relationship.close[3][3]**

```text
>发了，对方回了我三个问号。
```

**$.relationship.close[3][4]**

```text
哈哈，先解释一下吧。
```

**$.relationship.close[4][0]**

```text
口袋里的硬币
```

**$.relationship.close[4][1]**

```text
>我口袋里摸出一块钱。
```

**$.relationship.close[4][2]**

```text
那你先收好。
```

**$.relationship.close[4][3]**

```text
>我还以为早就花了。
```

**$.relationship.close[4][4]**

```text
说不定你还有别的衣服没翻呢。
```

**$.relationship.close[5][0]**

```text
新鲜的夸奖
```

**$.relationship.close[5][1]**

```text
>有人夸我做得仔细，我一下不知道怎么回。
```

**$.relationship.close[5][2]**

```text
说谢谢啊。
```

**$.relationship.close[5][3]**

```text
>说了，但有点不习惯。
```

**$.relationship.close[5][4]**

```text
多收几次就习惯啦。
```

**$.relationship.close[6][0]**

```text
二手书的字
```

**$.relationship.close[6][1]**

```text
>我买的旧书上有人写批注。
```

**$.relationship.close[6][2]**

```text
写什么了？
```

**$.relationship.close[6][3]**

```text
>这一段没看懂。刚好，我也没懂。
```

**$.relationship.close[6][4]**

```text
哈哈，那你看看后面有没有答案。
```

**$.relationship.close[7][0]**

```text
小店的招牌
```

**$.relationship.close[7][1]**

```text
>路边那家店招牌有个字写歪了。
```

**$.relationship.close[7][2]**

```text
哪家？
```

**$.relationship.close[7][3]**

```text
>转角那家，小小的那个。
```

**$.relationship.close[7][4]**

```text
我下次路过也看看，我之前都没注意。
```

**$.relationship.close[8][0]**

```text
关掉的闹钟
```

**$.relationship.close[8][1]**

```text
>我删了一个早就不用的闹钟。
```

**$.relationship.close[8][2]**

```text
还一直响呢？
```

**$.relationship.close[8][3]**

```text
>没响，但老看见它就觉得有事。
```

**$.relationship.close[8][4]**

```text
删了好，真要用再定呗。
```

**$.relationship.close[9][0]**

```text
钥匙的标签
```

**$.relationship.close[9][1]**

```text
>我给钥匙贴标签，贴完还是分不清。
```

**$.relationship.close[9][2]**

```text
你写了啥？
```

**$.relationship.close[9][3]**

```text
>都写的家里。
```

**$.relationship.close[9][4]**

```text
你倒是写上开哪扇门啊。
```

**$.relationship.close[10][0]**

```text
试用装大集合
```

**$.relationship.close[10][1]**

```text
>我翻出一堆没用的试用装。
```

**$.relationship.close[10][2]**

```text
先看看过期没。
```

**$.relationship.close[10][3]**

```text
>有几袋字太小了，看不清。
```

**$.relationship.close[10][4]**

```text
凑灯底下看看，别放着放着又忘了。
```

**$.relationship.close[11][0]**

```text
路牌的新发现
```

**$.relationship.close[11][1]**

```text
>我才知道那条小路叫什么。
```

**$.relationship.close[11][2]**

```text
你不是经常走吗？
```

**$.relationship.close[11][3]**

```text
>我只记得旁边有家卖吃的。
```

**$.relationship.close[11][4]**

```text
也行，你认得地方就行。
```

**$.relationship.close[12][0]**

```text
记住一件好事
```

**$.relationship.close[12][1]**

```text
>刚才有人帮我扶了一下快掉的袋子。
```

**$.relationship.close[12][2]**

```text
东西没撒吧？
```

**$.relationship.close[12][3]**

```text
>没，吓我一跳，手里提太多了。
```

**$.relationship.close[12][4]**

```text
下次分两趟，别一口气全拎着。
```

**$.relationship.close[13][0]**

```text
拒绝无效比较
```

**$.relationship.close[13][1]**

```text
>我刚才又看别人进度，看得有点烦。
```

**$.relationship.close[13][2]**

```text
那先别看了呗。
```

**$.relationship.close[13][3]**

```text
>嗯，我这边其实也在做。
```

**$.relationship.close[13][4]**

```text
做你自己的，弄完再给我看看。
```

**$.relationship.close[14][0]**

```text
水杯的刻度
```

**$.relationship.close[14][1]**

```text
>我在杯子上画了两条线。
```

**$.relationship.close[14][2]**

```text
提醒喝水？
```

**$.relationship.close[14][3]**

```text
>对，现在一看还没喝到那儿。
```

**$.relationship.close[14][4]**

```text
那你先喝两口啊。
```

**$.relationship.close[15][0]**

```text
听错的歌词
```

**$.relationship.close[15][1]**

```text
>有句歌词我唱了好几年，居然是错的。
```

**$.relationship.close[15][2]**

```text
你唱成啥了？
```

**$.relationship.close[15][3]**

```text
>等下，我有点不想说。
```

**$.relationship.close[15][4]**

```text
哈哈，快说，我保证先不笑。
```

**$.relationship.best[0][0]**

```text
试用装大集合
```

**$.relationship.best[0][1]**

```text
>我翻出一堆没用的试用装。
```

**$.relationship.best[0][2]**

```text
先看看过期没。
```

**$.relationship.best[0][3]**

```text
>有几袋字太小了，看不清。
```

**$.relationship.best[0][4]**

```text
凑灯底下看看，别放着放着又忘了。
```

**$.relationship.best[1][0]**

```text
路牌的新发现
```

**$.relationship.best[1][1]**

```text
>我才知道那条小路叫什么。
```

**$.relationship.best[1][2]**

```text
你不是经常走吗？
```

**$.relationship.best[1][3]**

```text
>我只记得旁边有家卖吃的。
```

**$.relationship.best[1][4]**

```text
也行，你认得地方就行。
```

**$.relationship.best[2][0]**

```text
记住一件好事
```

**$.relationship.best[2][1]**

```text
>刚才有人帮我扶了一下快掉的袋子。
```

**$.relationship.best[2][2]**

```text
东西没撒吧？
```

**$.relationship.best[2][3]**

```text
>没，吓我一跳，手里提太多了。
```

**$.relationship.best[2][4]**

```text
下次分两趟，别一口气全拎着。
```

**$.relationship.best[3][0]**

```text
拒绝无效比较
```

**$.relationship.best[3][1]**

```text
>我刚才又看别人进度，看得有点烦。
```

**$.relationship.best[3][2]**

```text
那先别看了呗。
```

**$.relationship.best[3][3]**

```text
>嗯，我这边其实也在做。
```

**$.relationship.best[3][4]**

```text
做你自己的，弄完再给我看看。
```

**$.relationship.best[4][0]**

```text
水杯的刻度
```

**$.relationship.best[4][1]**

```text
>我在杯子上画了两条线。
```

**$.relationship.best[4][2]**

```text
提醒喝水？
```

**$.relationship.best[4][3]**

```text
>对，现在一看还没喝到那儿。
```

**$.relationship.best[4][4]**

```text
那你先喝两口啊。
```

**$.relationship.best[5][0]**

```text
听错的歌词
```

**$.relationship.best[5][1]**

```text
>有句歌词我唱了好几年，居然是错的。
```

**$.relationship.best[5][2]**

```text
你唱成啥了？
```

**$.relationship.best[5][3]**

```text
>等下，我有点不想说。
```

**$.relationship.best[5][4]**

```text
哈哈，快说，我保证先不笑。
```

**$.relationship.best[6][0]**

```text
便签的便签
```

**$.relationship.best[6][1]**

```text
>我贴了张纸，提醒自己看另一张纸。
```

**$.relationship.best[6][2]**

```text
你这是绕了几层？
```

**$.relationship.best[6][3]**

```text
>贴完也觉得有点多余。
```

**$.relationship.best[6][4]**

```text
把第一张的事直接办了吧。
```

**$.relationship.best[7][0]**

```text
拼图缺一块
```

**$.relationship.best[7][1]**

```text
>拼图缺的那块找到了。
```

**$.relationship.best[7][2]**

```text
藏哪儿了？
```

**$.relationship.best[7][3]**

```text
>我手里，拿着找了半天。
```

**$.relationship.best[7][4]**

```text
哈哈哈，你先把手摊开这招记住。
```

**$.relationship.best[8][0]**

```text
地毯上的线头
```

**$.relationship.best[8][1]**

```text
>刚才以为地上有虫，吓我一跳。
```

**$.relationship.best[8][2]**

```text
真有啊？
```

**$.relationship.best[8][3]**

```text
>没，是一段线头。
```

**$.relationship.best[8][4]**

```text
哦，那你赶紧扫了，省得再吓一遍。
```

**$.relationship.best[9][0]**

```text
允许自己歇会儿
```

**$.relationship.best[9][1]**

```text
>我刚才坐着发了会儿呆。
```

**$.relationship.best[9][2]**

```text
舒服吧？
```

**$.relationship.best[9][3]**

```text
>嗯，啥也没干，倒没那么累了。
```

**$.relationship.best[9][4]**

```text
那再坐会儿，反正这会儿不急。
```

**$.relationship.best[10][0]**

```text
菜单上的小字
```

**$.relationship.best[10][1]**

```text
>菜上来了，和图片长得不太一样。
```

**$.relationship.best[10][2]**

```text
差很多吗？
```

**$.relationship.best[10][3]**

```text
>也还行，就是没那么满。
```

**$.relationship.best[10][4]**

```text
先尝尝吧，好吃就行。
```

**$.relationship.best[11][0]**

```text
找不到的文件
```

**$.relationship.best[11][1]**

```text
>我那个文件又不知道哪个是最后一版了。
```

**$.relationship.best[11][2]**

```text
你不是改名了吗？
```

**$.relationship.best[11][3]**

```text
>改了，好几个都叫最终。
```

**$.relationship.best[11][4]**

```text
先按时间排一下，再慢慢看。
```

**$.relationship.best[12][0]**

```text
袋里的小饼干
```

**$.relationship.best[12][1]**

```text
>包里居然还有一块完整饼干。
```

**$.relationship.best[12][2]**

```text
这次没碎啊？
```

**$.relationship.best[12][3]**

```text
>嗯，我都有点舍不得吃。
```

**$.relationship.best[12][4]**

```text
留太久也会碎，趁现在吃呗。
```

**$.relationship.best[13][0]**

```text
给未来留字
```

**$.relationship.best[13][1]**

```text
>我写了张纸条，想过阵子再看。
```

**$.relationship.best[13][2]**

```text
写什么了？
```

**$.relationship.best[13][3]**

```text
>提醒自己别乱藏东西。
```

**$.relationship.best[13][4]**

```text
那你别把这张纸条也藏起来。
```

**$.relationship.best[14][0]**

```text
说话不必有结论
```

**$.relationship.best[14][1]**

```text
>我是不是光顾着说了，你那边在忙吗？
```

**$.relationship.best[14][2]**

```text
还好，你接着说。
```

**$.relationship.best[14][3]**

```text
>嗯，也没什么大事，就闲扯两句。
```

**$.relationship.best[14][4]**

```text
挺好的，我这会儿也没别的事。
```

**$.relationship.best[15][0]**

```text
小心愿收集
```

**$.relationship.best[15][1]**

```text
>我想找条没走过的路逛逛。
```

**$.relationship.best[15][2]**

```text
去啊，别走太远就行。
```

**$.relationship.best[15][3]**

```text
>怕绕出去回不来了。
```

**$.relationship.best[15][4]**

```text
你开着地图嘛，真不行再问人。
```

**$.visit.common[0][0]**

```text
杯垫的岗位
```

**$.visit.common[0][1]**

```text
>这杯垫能用吗？
```

**$.visit.common[0][2]**

```text
能啊，怎么了？
```

**$.visit.common[0][3]**

```text
>杯子底下有水，我刚滴你桌上了。
```

**$.visit.common[1][0]**

```text
沙发的记忆
```

**$.visit.common[1][1]**

```text
>你平时就坐这边？
```

**$.visit.common[1][2]**

```text
嗯，这块坐垫都坐软了。
```

**$.visit.common[1][3]**

```text
>那我坐旁边，给你留着。
```

**$.visit.common[2][0]**

```text
遥控器失踪
```

**$.visit.common[2][1]**

```text
>遥控器呢？
```

**$.visit.common[2][2]**

```text
你看看坐垫底下。
```

**$.visit.common[2][3]**

```text
>还真在这儿，差点压着它坐。
```

**$.visit.common[3][0]**

```text
靠枕的名字
```

**$.visit.common[3][1]**

```text
>这个靠枕借我靠一下。
```

**$.visit.common[3][2]**

```text
拿吧，腰后面垫着舒服点。
```

**$.visit.common[3][3]**

```text
>嗯，比刚才好多了。
```

**$.visit.common[4][0]**

```text
门垫的礼貌
```

**$.visit.common[4][1]**

```text
>刚才我鞋底蹭半天，还是有点灰。
```

**$.visit.common[4][2]**

```text
没事，门垫就是擦鞋的。
```

**$.visit.common[4][3]**

```text
>那我把鞋放门边。
```

**$.visit.common[5][0]**

```text
纸巾的方向
```

**$.visit.common[5][1]**

```text
>这纸巾一抽就出来好几张。
```

**$.visit.common[5][2]**

```text
快用完了就这样。
```

**$.visit.common[5][3]**

```text
>我先放旁边，别浪费了。
```

**$.visit.common[6][0]**

```text
茶几的边界
```

**$.visit.common[6][1]**

```text
>东西放这儿行吗？
```

**$.visit.common[6][2]**

```text
行，杯子往边上挪一点。
```

**$.visit.common[6][3]**

```text
>好，这下放得开了。
```

**$.visit.common[7][0]**

```text
墙上那幅画
```

**$.visit.common[7][1]**

```text
>墙上这幅画哪儿买的？
```

**$.visit.common[7][2]**

```text
买东西顺便带回来的。
```

**$.visit.common[7][3]**

```text
>还挺好看，我也想找一幅。
```

**$.visit.common[8][0]**

```text
不配套的杯子
```

**$.visit.common[8][1]**

```text
>我拿哪个杯子？
```

**$.visit.common[8][2]**

```text
都干净的，挑个顺手的。
```

**$.visit.common[8][3]**

```text
>那我拿有把手的这个。
```

**$.visit.common[9][0]**

```text
抱枕占座
```

**$.visit.common[9][1]**

```text
>这靠枕能挪一下吗？
```

**$.visit.common[9][2]**

```text
能，放我这边吧。
```

**$.visit.common[9][3]**

```text
>好，我刚才坐到一半才发现。
```

**$.visit.common[10][0]**

```text
空白便签
```

**$.visit.common[10][1]**

```text
>你这儿怎么贴了张空便签？
```

**$.visit.common[10][2]**

```text
本来要记个事，拿到笔就忘了。
```

**$.visit.common[10][3]**

```text
>那先别撕，没准一会儿想起来。
```

**$.visit.common[11][0]**

```text
书脊的颜色
```

**$.visit.common[11][1]**

```text
>这些书你都看完了？
```

**$.visit.common[11][2]**

```text
没有，有些还没拆封呢。
```

**$.visit.common[11][3]**

```text
>我也是，买的时候觉得自己特别有空。
```

**$.visit.common[12][0]**

```text
抽屉里的线
```

**$.visit.common[12][1]**

```text
>你有没有一抽屉不知道干什么的线？
```

**$.visit.common[12][2]**

```text
有，不敢扔，怕哪天派上用场。
```

**$.visit.common[12][3]**

```text
>我家也有，找充电线的时候全倒出来。
```

**$.visit.common[13][0]**

```text
手边的零钱
```

**$.visit.common[13][1]**

```text
>桌上这几枚零钱要收起来吗？
```

**$.visit.common[13][2]**

```text
先放着吧，我一直忘拿。
```

**$.visit.common[13][3]**

```text
>我钱包里倒是一个硬币都找不着了。
```

**$.visit.common[14][0]**

```text
被遗忘的袋子
```

**$.visit.common[14][1]**

```text
>袋子里怎么还有袋子？
```

**$.visit.common[14][2]**

```text
买东西留下的，装垃圾能用。
```

**$.visit.common[14][3]**

```text
>我家也是，越攒越多。
```

**$.visit.common[15][0]**

```text
纸盒改造
```

**$.visit.common[15][1]**

```text
>这盒子你还要吗？
```

**$.visit.common[15][2]**

```text
要，装些零碎东西。
```

**$.visit.common[15][3]**

```text
>那我把盖子也给你放上。
```

**$.visit.common[16][0]**

```text
备用按钮
```

**$.visit.common[16][1]**

```text
>衣服送的备用扣子你留吗？
```

**$.visit.common[16][2]**

```text
留着，不过找不到是哪件衣服的了。
```

**$.visit.common[16][3]**

```text
>我都放一起，下次找更麻烦。
```

**$.visit.common[17][0]**

```text
窗台的位置
```

**$.visit.common[17][1]**

```text
>这盆东西放窗边多久了？
```

**$.visit.common[17][2]**

```text
前阵子挪过来的。
```

**$.visit.common[17][3]**

```text
>比放柜子上看着亮堂。
```

**$.visit.common[18][0]**

```text
钥匙的声音
```

**$.visit.common[18][1]**

```text
>刚才在门口找了半天钥匙。
```

**$.visit.common[18][2]**

```text
最后找到了？
```

**$.visit.common[18][3]**

```text
>在最外面那个袋里，我一直翻里面。
```

**$.visit.common[19][0]**

```text
安静的挂钟
```

**$.visit.common[19][1]**

```text
>你这钟怎么没声音？
```

**$.visit.common[19][2]**

```text
有，凑近才听得见。
```

**$.visit.common[19][3]**

```text
>挺好，我那个夜里听着特别响。
```

**$.visit.common[20][0]**

```text
地板的木纹
```

**$.visit.common[20][1]**

```text
>你家这地板好擦吗？
```

**$.visit.common[20][2]**

```text
还行，水别拖太多。
```

**$.visit.common[20][3]**

```text
>我上回拖完半天不干，差点滑一下。
```

**$.visit.common[21][0]**

```text
空位的用途
```

**$.visit.common[21][1]**

```text
>这块空地你打算放什么？
```

**$.visit.common[21][2]**

```text
还没想好，先空着。
```

**$.visit.common[21][3]**

```text
>空着也挺好，走路不用绕。
```

**$.visit.common[22][0]**

```text
布袋与口袋
```

**$.visit.common[22][1]**

```text
>这布袋里面还有个小袋啊。
```

**$.visit.common[22][2]**

```text
嗯，放钥匙方便。
```

**$.visit.common[22][3]**

```text
>这个好，我每次都得把整袋翻一遍。
```

**$.visit.common[23][0]**

```text
杯柄朝哪边
```

**$.visit.common[23][1]**

```text
>这杯柄朝着我，拿着倒方便。
```

**$.visit.common[23][2]**

```text
我刚转过来的。
```

**$.visit.common[23][3]**

```text
>谢谢啊，我一只手还拿着东西呢。
```

**$.visit.common[24][0]**

```text
有故事的划痕
```

**$.visit.common[24][1]**

```text
>桌上这道印怎么弄的？
```

**$.visit.common[24][2]**

```text
做手工时没垫东西，划的。
```

**$.visit.common[24][3]**

```text
>不仔细看看不出来。
```

**$.visit.common[25][0]**

```text
小票当书签
```

**$.visit.common[25][1]**

```text
>你用小票当书签啊？
```

**$.visit.common[25][2]**

```text
嗯，手边正好有。
```

**$.visit.common[25][3]**

```text
>别夹久了字印书上，我试过。
```

**$.visit.common[26][0]**

```text
台灯的角度
```

**$.visit.common[26][1]**

```text
>这个灯能往这边转吗？
```

**$.visit.common[26][2]**

```text
可以，你轻点掰。
```

**$.visit.common[26][3]**

```text
>好了，这下不晃眼了。
```

**$.visit.common[27][0]**

```text
柜门的小声响
```

**$.visit.common[27][1]**

```text
>柜门关好了没？
```

**$.visit.common[27][2]**

```text
再推一下，听见咔哒就好了。
```

**$.visit.common[27][3]**

```text
>嗯，这回关上了。
```

**$.visit.common[28][0]**

```text
多出来的勺子
```

**$.visit.common[28][1]**

```text
>勺子放哪个抽屉？
```

**$.visit.common[28][2]**

```text
左边那个，小心别夹手。
```

**$.visit.common[28][3]**

```text
>找到了，刚才一直看右边。
```

**$.visit.common[29][0]**

```text
难得的空桌面
```

**$.visit.common[29][1]**

```text
>今天桌上挺干净啊。
```

**$.visit.common[29][2]**

```text
刚收拾的，你来得巧。
```

**$.visit.common[29][3]**

```text
>那我东西放边上，别又弄乱了。
```

**$.visit.common[30][0]**

```text
袜子的远行
```

**$.visit.common[30][1]**

```text
>出门前找袜子找了半天。
```

**$.visit.common[30][2]**

```text
最后在哪？
```

**$.visit.common[30][3]**

```text
>鞋里面。我还翻了一遍洗衣篮。
```

**$.visit.common[31][0]**

```text
出门前检查
```

**$.visit.common[31][1]**

```text
>出门你也会反复摸钥匙吗？
```

**$.visit.common[31][2]**

```text
会，门关上还要再摸一下。
```

**$.visit.common[31][3]**

```text
>对对，就怕锁里面了。
```

**$.visit.common[32][0]**

```text
绕路的收获
```

**$.visit.common[32][1]**

```text
>我刚才绕了点路。
```

**$.visit.common[32][2]**

```text
走错了？
```

**$.visit.common[32][3]**

```text
>看见一家小店，进去转了一圈。
```

**$.visit.common[33][0]**

```text
路口的习惯
```

**$.visit.common[33][1]**

```text
>刚才差点拐回自己家。
```

**$.visit.common[33][2]**

```text
不是都走到这边了吗？
```

**$.visit.common[33][3]**

```text
>走惯了，没看路。
```

**$.visit.common[34][0]**

```text
忘带的东西
```

**$.visit.common[34][1]**

```text
>我就说忘了什么。
```

**$.visit.common[34][2]**

```text
想起来了？
```

**$.visit.common[34][3]**

```text
>买的点心忘带了，还在桌上。
```

**$.visit.common[35][0]**

```text
袋子很轻
```

**$.visit.common[35][1]**

```text
>这次我没带什么东西。
```

**$.visit.common[35][2]**

```text
来坐坐还带什么。
```

**$.visit.common[35][3]**

```text
>上回拎太多，回去手都酸了。
```

**$.visit.common[36][0]**

```text
没按发送
```

**$.visit.common[36][1]**

```text
>我刚才给你发消息了。
```

**$.visit.common[36][2]**

```text
没看到啊。
```

**$.visit.common[36][3]**

```text
>哎，没按发送。现在不用发了。
```

**$.visit.common[37][0]**

```text
敲门的节奏
```

**$.visit.common[37][1]**

```text
>我刚敲门你听到了吧？
```

**$.visit.common[37][2]**

```text
听见了，手上拿着东西。
```

**$.visit.common[37][3]**

```text
>哦，我还以为敲轻了。
```

**$.visit.common[38][0]**

```text
找门牌
```

**$.visit.common[38][1]**

```text
>门牌我看了两遍才敢敲。
```

**$.visit.common[38][2]**

```text
怕走错？
```

**$.visit.common[38][3]**

```text
>嗯，我有回敲错了，还问人家饭做好没。
```

**$.visit.common[39][0]**

```text
楼梯的计数
```

**$.visit.common[39][1]**

```text
>我来的时候数了下台阶。
```

**$.visit.common[39][2]**

```text
多少级？
```

**$.visit.common[39][3]**

```text
>数一半忘了，算了。
```

**$.visit.common[40][0]**

```text
伞的临时座位
```

**$.visit.common[40][1]**

```text
>伞放哪里？
```

**$.visit.common[40][2]**

```text
靠门边吧，下面有垫子。
```

**$.visit.common[40][3]**

```text
>好，伞尖还有点湿。
```

**$.visit.common[41][0]**

```text
同路的陌生人
```

**$.visit.common[41][1]**

```text
>刚才有个人一直跟我同路。
```

**$.visit.common[41][2]**

```text
住附近的？
```

**$.visit.common[41][3]**

```text
>不知道，后来他问我路，我也不认识。
```

**$.visit.common[42][0]**

```text
拐角的招牌
```

**$.visit.common[42][1]**

```text
>拐角那家店换招牌了。
```

**$.visit.common[42][2]**

```text
我就觉得哪儿不太一样。
```

**$.visit.common[42][3]**

```text
>字大多了，这回能看清了。
```

**$.visit.common[43][0]**

```text
路边的小狗
```

**$.visit.common[43][1]**

```text
>路上有只狗一直看我。
```

**$.visit.common[43][2]**

```text
你手上拿吃的了？
```

**$.visit.common[43][3]**

```text
>没啊，可能闻到袋子的味儿了。
```

**$.visit.common[44][0]**

```text
等电梯的哲学
```

**$.visit.common[44][1]**

```text
>我来的时候电梯等了好久。
```

**$.visit.common[44][2]**

```text
是不是刚上去？
```

**$.visit.common[44][3]**

```text
>嗯，到了又在别的层停，干脆走楼梯了。
```

**$.visit.common[45][0]**

```text
衣服的新口袋
```

**$.visit.common[45][1]**

```text
>我才发现衣服有个内袋。
```

**$.visit.common[45][2]**

```text
都穿多久了？
```

**$.visit.common[45][3]**

```text
>好久了，洗的时候也没摸出来。
```

**$.visit.common[46][0]**

```text
两只手的分工
```

**$.visit.common[46][1]**

```text
>下回不能两只手都拎东西。
```

**$.visit.common[46][2]**

```text
怎么了？
```

**$.visit.common[46][3]**

```text
>找钥匙腾不出手，在门口折腾半天。
```

**$.visit.common[47][0]**

```text
路上的小花
```

**$.visit.common[47][1]**

```text
>墙缝里长了朵小花。
```

**$.visit.common[47][2]**

```text
开了？我只见过叶子。
```

**$.visit.common[47][3]**

```text
>开了，下回路过你看一眼。
```

**$.visit.common[48][0]**

```text
慢一点进门
```

**$.visit.common[48][1]**

```text
>走快了，还有点喘。
```

**$.visit.common[48][2]**

```text
坐一会儿，要水吗？
```

**$.visit.common[48][3]**

```text
>要，少倒一点就行。
```

**$.visit.common[49][0]**

```text
没有迟到
```

**$.visit.common[49][1]**

```text
>没来早吧？
```

**$.visit.common[49][2]**

```text
没有，我刚忙完。
```

**$.visit.common[49][3]**

```text
>那就好，刚还想在外面等会儿。
```

**$.visit.common[50][0]**

```text
没头没尾的故事
```

**$.visit.common[50][1]**

```text
>我突然想起件事，开头有点忘了。
```

**$.visit.common[50][2]**

```text
你先说，我听听。
```

**$.visit.common[50][3]**

```text
>等会儿，好像是昨天买东西的时候。
```

**$.visit.common[51][0]**

```text
说到一半跑题
```

**$.visit.common[51][1]**

```text
>我们刚说到哪了？
```

**$.visit.common[51][2]**

```text
你问杯子在哪买的。
```

**$.visit.common[51][3]**

```text
>哦对，差点忘了这茬。
```

**$.visit.common[52][0]**

```text
停顿不用填满
```

**$.visit.common[52][1]**

```text
>我刚才没说话，你别在意啊。
```

**$.visit.common[52][2]**

```text
我也在走神。
```

**$.visit.common[52][3]**

```text
>好，那我再坐会儿。
```

**$.visit.common[53][0]**

```text
同一句话
```

**$.visit.common[53][1]**

```text
>咱俩刚说一块去了。
```

**$.visit.common[53][2]**

```text
你先讲吧。
```

**$.visit.common[53][3]**

```text
>没事，我就想说这个。
```

**$.visit.common[54][0]**

```text
笑点延迟
```

**$.visit.common[54][1]**

```text
>哎，我才反应过来你刚才那个笑话。
```

**$.visit.common[54][2]**

```text
我都快忘了讲的什么了。
```

**$.visit.common[54][3]**

```text
>就前面那句，越想越好笑。
```

**$.visit.common[55][0]**

```text
讲故事的手势
```

**$.visit.common[55][1]**

```text
>你先把杯子放下再比画。
```

**$.visit.common[55][2]**

```text
怎么？
```

**$.visit.common[55][3]**

```text
>我怕你一激动把水甩出来。
```

**$.visit.common[56][0]**

```text
忘记的人名
```

**$.visit.common[56][1]**

```text
>那个人叫什么来着？
```

**$.visit.common[56][2]**

```text
哪个人？
```

**$.visit.common[56][3]**

```text
>就上次那个……算了，回头想起来再说。
```

**$.visit.common[57][0]**

```text
说错一个字
```

**$.visit.common[57][1]**

```text
>刚才那个词我是不是说反了？
```

**$.visit.common[57][2]**

```text
有点，但能听懂。
```

**$.visit.common[57][3]**

```text
>那就好，我说完自己都愣了一下。
```

**$.visit.common[58][0]**

```text
一件无聊小事
```

**$.visit.common[58][1]**

```text
>我跟你说个特别小的事。
```

**$.visit.common[58][2]**

```text
什么事？
```

**$.visit.common[58][3]**

```text
>我今天找了半天耳机，原来就在耳朵上。
```

**$.visit.common[59][0]**

```text
不用总结
```

**$.visit.common[59][1]**

```text
>说半天也没说出什么。
```

**$.visit.common[59][2]**

```text
又不是开会，要什么结论。
```

**$.visit.common[59][3]**

```text
>也是。对了，你刚才说那个店呢？
```

**$.visit.common[60][0]**

```text
想起来的歌
```

**$.visit.common[60][1]**

```text
>你这句让我想起首歌。
```

**$.visit.common[60][2]**

```text
哪首？
```

**$.visit.common[60][3]**

```text
>名字想不起来，我哼一下你听听。
```

**$.visit.common[61][0]**

```text
接住一句话
```

**$.visit.common[61][1]**

```text
>我还没说完你就猜到了。
```

**$.visit.common[61][2]**

```text
我猜对了？
```

**$.visit.common[61][3]**

```text
>对，就是那个意思。
```

**$.visit.common[62][0]**

```text
夸奖的练习
```

**$.visit.common[62][1]**

```text
>今天有人夸我，我愣住了。
```

**$.visit.common[62][2]**

```text
怎么不说谢谢？
```

**$.visit.common[62][3]**

```text
>后来补上了，前面光顾着摆手。
```

**$.visit.common[63][0]**

```text
认真听完
```

**$.visit.common[63][1]**

```text
>我刚才是不是说太久了？
```

**$.visit.common[63][2]**

```text
没有，后来怎么弄的？
```

**$.visit.common[63][3]**

```text
>后来去问了，才知道不用那么麻烦。
```

**$.visit.common[64][0]**

```text
不同的记忆
```

**$.visit.common[64][1]**

```text
>这件事你记得和我不一样。
```

**$.visit.common[64][2]**

```text
我记得那天特别冷。
```

**$.visit.common[64][3]**

```text
>我就记得没带钥匙，在门口等了好久。
```

**$.visit.common[65][0]**

```text
小声的吐槽
```

**$.visit.common[65][1]**

```text
>有件事越想越气。
```

**$.visit.common[65][2]**

```text
怎么了？
```

**$.visit.common[65][3]**

```text
>先说好，你听我讲完，别急着笑。
```

**$.visit.common[66][0]**

```text
不抢着安慰
```

**$.visit.common[66][1]**

```text
>你先说，我听着。
```

**$.visit.common[66][2]**

```text
其实也没什么，就是有点烦。
```

**$.visit.common[66][3]**

```text
>哪件事？刚才说的那个？
```

**$.visit.common[67][0]**

```text
突然冒出的词
```

**$.visit.common[67][1]**

```text
>你刚用的那个词挺逗。
```

**$.visit.common[67][2]**

```text
随口说的。
```

**$.visit.common[67][3]**

```text
>我学一下，下回也这么说。
```

**$.visit.common[68][0]**

```text
故事的版本
```

**$.visit.common[68][1]**

```text
>这事你好像说过。
```

**$.visit.common[68][2]**

```text
后面还有，你听我讲。
```

**$.visit.common[68][3]**

```text
>行，我先不插嘴。
```

**$.visit.common[69][0]**

```text
不用假装精神
```

**$.visit.common[69][1]**

```text
>我今天可能话少点。
```

**$.visit.common[69][2]**

```text
累了？
```

**$.visit.common[69][3]**

```text
>有点，坐会儿就好。
```

**$.visit.common[70][0]**

```text
没有大新闻
```

**$.visit.common[70][1]**

```text
>最近真没什么新鲜事。
```

**$.visit.common[70][2]**

```text
我也是，每天差不多。
```

**$.visit.common[70][3]**

```text
>哦，倒是换了个洗衣液，味儿太重了。
```

**$.visit.common[71][0]**

```text
慢慢组织语言
```

**$.visit.common[71][1]**

```text
>等会儿，我捋一下。
```

**$.visit.common[71][2]**

```text
好，你说。
```

**$.visit.common[71][3]**

```text
>不对，应该先说前面那件事。
```

**$.visit.common[72][0]**

```text
话题的小岔路
```

**$.visit.common[72][1]**

```text
>我是不是又跑题了？
```

**$.visit.common[72][2]**

```text
有点，不过你接着说。
```

**$.visit.common[72][3]**

```text
>我先记一下，省得原来那个也忘了。
```

**$.visit.common[73][0]**

```text
把笑声补上
```

**$.visit.common[73][1]**

```text
>刚才不是不好笑。
```

**$.visit.common[73][2]**

```text
那你憋着干什么？
```

**$.visit.common[73][3]**

```text
>嘴里有水啊，差点呛着。
```

**$.visit.common[74][0]**

```text
各说各的重点
```

**$.visit.common[74][1]**

```text
>上次那地方你还记得吗？
```

**$.visit.common[74][2]**

```text
记得，那儿的点心不错。
```

**$.visit.common[74][3]**

```text
>我想问风景呢。点心确实也不错。
```

**$.visit.common[75][0]**

```text
想收藏的瞬间
```

**$.visit.common[75][1]**

```text
>有时候就想多坐一会儿。
```

**$.visit.common[75][2]**

```text
那就坐着，别急。
```

**$.visit.common[75][3]**

```text
>嗯，我晚点再走。
```

**$.visit.common[76][0]**

```text
不必拍照
```

**$.visit.common[76][1]**

```text
>咱们今天没拍照。
```

**$.visit.common[76][2]**

```text
要拍一张吗？
```

**$.visit.common[76][3]**

```text
>不用了吧，下回再拍。
```

**$.visit.common[77][0]**

```text
熟悉的声音
```

**$.visit.common[77][1]**

```text
>你刚一开门我就知道找对了。
```

**$.visit.common[77][2]**

```text
还能找错？
```

**$.visit.common[77][3]**

```text
>我刚才在楼下真犹豫了一下。
```

**$.visit.common[78][0]**

```text
被记住的小事
```

**$.visit.common[78][1]**

```text
>你还记得我不喝太烫的啊。
```

**$.visit.common[78][2]**

```text
上次你吹了半天才喝。
```

**$.visit.common[78][3]**

```text
>这次正好，谢谢。
```

**$.visit.common[79][0]**

```text
客气的尽头
```

**$.visit.common[79][1]**

```text
>我是不是太不客气了？
```

**$.visit.common[79][2]**

```text
靠枕都抱走了，现在才问。
```

**$.visit.common[79][3]**

```text
>那我再借一会儿。
```

**$.visit.common[80][0]**

```text
饼干的完整度
```

**$.visit.common[80][1]**

```text
>这饼干是不是碎了？
```

**$.visit.common[80][2]**

```text
底下接着点。
```

**$.visit.common[80][3]**

```text
>嗯，掉了一手，得拿张纸。
```

**$.visit.common[81][0]**

```text
果皮的形状
```

**$.visit.common[81][1]**

```text
>这果皮削得挺长。
```

**$.visit.common[81][2]**

```text
快断了，别碰我手。
```

**$.visit.common[81][3]**

```text
>行行，我不动。
```

**$.visit.common[82][0]**

```text
零食的分量
```

**$.visit.common[82][1]**

```text
>袋子挺大，里面没多少。
```

**$.visit.common[82][2]**

```text
买之前看着还挺划算。
```

**$.visit.common[82][3]**

```text
>下回先看看克数吧。
```

**$.visit.common[83][0]**

```text
点心的先后
```

**$.visit.common[83][1]**

```text
>先吃哪个？
```

**$.visit.common[83][2]**

```text
这块吧，拆开了容易放软。
```

**$.visit.common[83][3]**

```text
>好，那先吃这个。
```

**$.visit.common[84][0]**

```text
甜咸之争
```

**$.visit.common[84][1]**

```text
>你吃甜的还是咸的？
```

**$.visit.common[84][2]**

```text
现在想吃咸的。
```

**$.visit.common[84][3]**

```text
>那甜的先放着。
```

**$.visit.common[85][0]**

```text
最后一小块
```

**$.visit.common[85][1]**

```text
>最后一块怎么办？
```

**$.visit.common[85][2]**

```text
掰开吧。
```

**$.visit.common[85][3]**

```text
>你掰，我一掰就碎。
```

**$.visit.common[86][0]**

```text
包装袋的声音
```

**$.visit.common[86][1]**

```text
>这袋子怎么这么难拆。
```

**$.visit.common[86][2]**

```text
从上面那个口撕。
```

**$.visit.common[86][3]**

```text
>找到了，刚一直撕反了。
```

**$.visit.common[87][0]**

```text
坚果很难剥
```

**$.visit.common[87][1]**

```text
>这颗剥不开。
```

**$.visit.common[87][2]**

```text
拿夹子试试。
```

**$.visit.common[87][3]**

```text
>你这儿有吗？我怕崩到牙。
```

**$.visit.common[88][0]**

```text
不熟的水果
```

**$.visit.common[88][1]**

```text
>这水果我没吃过。
```

**$.visit.common[88][2]**

```text
我也第一次买。
```

**$.visit.common[88][3]**

```text
>那一人尝一点，不好吃就别硬吃。
```

**$.visit.common[89][0]**

```text
点心的名字
```

**$.visit.common[89][1]**

```text
>这点心叫什么？
```

**$.visit.common[89][2]**

```text
包装还在，你看看。
```

**$.visit.common[89][3]**

```text
>等下，我先把这口咽了。
```

**$.visit.common[90][0]**

```text
香味先到
```

**$.visit.common[90][1]**

```text
>闻着挺香。
```

**$.visit.common[90][2]**

```text
你尝尝，小心烫。
```

**$.visit.common[90][3]**

```text
>等会儿，我拿个勺。
```

**$.visit.common[91][0]**

```text
手里的杯子
```

**$.visit.common[91][1]**

```text
>我捧着杯子，手就不乱动了。
```

**$.visit.common[91][2]**

```text
那喝一口啊。
```

**$.visit.common[91][3]**

```text
>还真忘了，光顾着说话。
```

**$.visit.common[92][0]**

```text
水温刚好
```

**$.visit.common[92][1]**

```text
>这水不烫，正好。
```

**$.visit.common[92][2]**

```text
兑了点凉的。
```

**$.visit.common[92][3]**

```text
>再给我倒半杯吧。
```

**$.visit.common[93][0]**

```text
不小心洒一点
```

**$.visit.common[93][1]**

```text
>哎，水洒了。
```

**$.visit.common[93][2]**

```text
没事，纸在旁边。
```

**$.visit.common[93][3]**

```text
>我擦一下，没洒多少。
```

**$.visit.common[94][0]**

```text
水果核的队伍
```

**$.visit.common[94][1]**

```text
>你把核摆这么齐干什么？
```

**$.visit.common[94][2]**

```text
顺手的，没注意。
```

**$.visit.common[94][3]**

```text
>我这几个也放过去吧。
```

**$.visit.common[95][0]**

```text
薄荷糖的勇气
```

**$.visit.common[95][1]**

```text
>这薄荷糖是不是特别凉？
```

**$.visit.common[95][2]**

```text
嗯，你先别一口咬碎。
```

**$.visit.common[95][3]**

```text
>幸好问了，我正准备咬。
```

**$.visit.common[96][0]**

```text
好看的糖纸
```

**$.visit.common[96][1]**

```text
>这糖纸颜色挺好看。
```

**$.visit.common[96][2]**

```text
你想留着？
```

**$.visit.common[96][3]**

```text
>嗯，夹本子里。
```

**$.visit.common[97][0]**

```text
分一半的仪式
```

**$.visit.common[97][1]**

```text
>你那半块好吃吗？
```

**$.visit.common[97][2]**

```text
不都一块掰的？
```

**$.visit.common[97][3]**

```text
>我知道，就是看着你的大一点。
```

**$.visit.common[98][0]**

```text
空盘子的证据
```

**$.visit.common[98][1]**

```text
>这么快就吃完了。
```

**$.visit.common[98][2]**

```text
还有吗？
```

**$.visit.common[98][3]**

```text
>袋子里看看，应该还有一点碎的。
```

**$.visit.common[99][0]**

```text
点心带走
```

**$.visit.common[99][1]**

```text
>剩下的要不要带回去？
```

**$.visit.common[99][2]**

```text
我带一点，你也留点。
```

**$.visit.common[99][3]**

```text
>行，我找个袋子。
```

**$.visit.common[100][0]**

```text
没读完的书
```

**$.visit.common[100][1]**

```text
>有本书我看了一半就放下了。
```

**$.visit.common[100][2]**

```text
不好看？
```

**$.visit.common[100][3]**

```text
>也不是，隔久了前面又忘了。
```

**$.visit.common[101][0]**

```text
电影的结尾
```

**$.visit.common[101][1]**

```text
>这个结尾你看懂没？
```

**$.visit.common[101][2]**

```text
没太懂，前面是不是漏了什么？
```

**$.visit.common[101][3]**

```text
>我也想倒回去看一遍。
```

**$.visit.common[102][0]**

```text
重复听的歌
```

**$.visit.common[102][1]**

```text
>我最近老听同一首歌。
```

**$.visit.common[102][2]**

```text
没听腻？
```

**$.visit.common[102][3]**

```text
>暂时没有，可能再听几天就换了。
```

**$.visit.common[103][0]**

```text
画歪的线
```

**$.visit.common[103][1]**

```text
>这线怎么越画越歪。
```

**$.visit.common[103][2]**

```text
你纸都没放平。
```

**$.visit.common[103][3]**

```text
>难怪，我还怪笔不好用。
```

**$.visit.common[104][0]**

```text
新的小兴趣
```

**$.visit.common[104][1]**

```text
>想找个不用买一堆东西的爱好。
```

**$.visit.common[104][2]**

```text
画画呢？先拿普通纸试试。
```

**$.visit.common[104][3]**

```text
>行，我家应该还有铅笔。
```

**$.visit.common[105][0]**

```text
拼图的耐心
```

**$.visit.common[105][1]**

```text
>拼图拼得我眼睛都花了。
```

**$.visit.common[105][2]**

```text
多大的？
```

**$.visit.common[105][3]**

```text
>买大了，桌子差点放不下。
```

**$.visit.common[106][0]**

```text
书里夹的叶子
```

**$.visit.common[106][1]**

```text
>这叶子在书里夹好久了。
```

**$.visit.common[106][2]**

```text
都压平了。
```

**$.visit.common[106][3]**

```text
>嗯，拿的时候得轻点，边上有点脆。
```

**$.visit.common[107][0]**

```text
旋律记错
```

**$.visit.common[107][1]**

```text
>我哼个调，你听听是什么歌。
```

**$.visit.common[107][2]**

```text
你哼。
```

**$.visit.common[107][3]**

```text
>先别笑啊，我可能记错了。
```

**$.visit.common[108][0]**

```text
看不懂也行
```

**$.visit.common[108][1]**

```text
>没怎么看懂，但是还想再看。
```

**$.visit.common[108][2]**

```text
那就再看一遍。
```

**$.visit.common[108][3]**

```text
>等我找个空点的时候。
```

**$.visit.common[109][0]**

```text
一个词的分量
```

**$.visit.common[109][1]**

```text
>书里有个词我不认识。
```

**$.visit.common[109][2]**

```text
哪个？
```

**$.visit.common[109][3]**

```text
>我拍给你看，打不出来。
```

**$.visit.common[110][0]**

```text
做一点手工
```

**$.visit.common[110][1]**

```text
>我想做点手工。
```

**$.visit.common[110][2]**

```text
先别买一大套材料。
```

**$.visit.common[110][3]**

```text
>嗯，先拿家里的纸试试。
```

**$.visit.common[111][0]**

```text
故事里的配角
```

**$.visit.common[111][1]**

```text
>我反倒记住那个配角了。
```

**$.visit.common[111][2]**

```text
哪个？
```

**$.visit.common[111][3]**

```text
>老坐在门口那个，没几句台词。
```

**$.visit.common[112][0]**

```text
不强求爱好
```

**$.visit.common[112][1]**

```text
>买的工具都没用几次。
```

**$.visit.common[112][2]**

```text
先收好呗，别又买新的。
```

**$.visit.common[112][3]**

```text
>是，先把这点用明白。
```

**$.visit.common[113][0]**

```text
书单越变越长
```

**$.visit.common[113][1]**

```text
>想看的书越存越多。
```

**$.visit.common[113][2]**

```text
已经存多少了？
```

**$.visit.common[113][3]**

```text
>不敢数，反正比看完的多。
```

**$.visit.common[114][0]**

```text
老照片的角度
```

**$.visit.common[114][1]**

```text
>以前拍照怎么都这个角度。
```

**$.visit.common[114][2]**

```text
当时觉得好看吧。
```

**$.visit.common[114][3]**

```text
>可能吧，现在看脸都变形了。
```

**$.visit.common[115][0]**

```text
电影配乐
```

**$.visit.common[115][1]**

```text
>这部电影的音乐我还记得。
```

**$.visit.common[115][2]**

```text
剧情呢？
```

**$.visit.common[115][3]**

```text
>只记得一点了，歌倒是会哼。
```

**$.visit.common[116][0]**

```text
只看一小段
```

**$.visit.common[116][1]**

```text
>今天本来想多弄点，结果就做了一点。
```

**$.visit.common[116][2]**

```text
卡住了？
```

**$.visit.common[116][3]**

```text
>没有，收拾材料花太久了。
```

**$.visit.common[117][0]**

```text
看过的地方
```

**$.visit.common[117][1]**

```text
>电影里那个地方我去过。
```

**$.visit.common[117][2]**

```text
真有那么好看？
```

**$.visit.common[117][3]**

```text
>拍得比我自己拍的好看多了。
```

**$.visit.common[118][0]**

```text
手写的字
```

**$.visit.common[118][1]**

```text
>这字写的什么？我自己都不认识了。
```

**$.visit.common[118][2]**

```text
你前后读一下。
```

**$.visit.common[118][3]**

```text
>还是猜不出来，下回慢点写。
```

**$.visit.common[119][0]**

```text
留一点空白
```

**$.visit.common[119][1]**

```text
>这页先空着吧。
```

**$.visit.common[119][2]**

```text
还没想好写什么？
```

**$.visit.common[119][3]**

```text
>嗯，写满了又不好改。
```

**$.visit.common[120][0]**

```text
一次没做成
```

**$.visit.common[120][1]**

```text
>那件事没弄成。
```

**$.visit.common[120][2]**

```text
卡哪儿了？
```

**$.visit.common[120][3]**

```text
>还差一份材料，得再跑一趟。
```

**$.visit.common[121][0]**

```text
普通的成就
```

**$.visit.common[121][1]**

```text
>拖了好久那件事，我总算办了。
```

**$.visit.common[121][2]**

```text
来回跑了几趟？
```

**$.visit.common[121][3]**

```text
>两趟，早知道上次就问清楚。
```

**$.visit.common[122][0]**

```text
不急着比较
```

**$.visit.common[122][1]**

```text
>看别人弄那么快，我也跟着急。
```

**$.visit.common[122][2]**

```text
你又不跟人家交同一份作业。
```

**$.visit.common[122][3]**

```text
>也是，我先弄完自己的。
```

**$.visit.common[123][0]**

```text
允许慢半拍
```

**$.visit.common[123][1]**

```text
>刚才人家说完我才反应过来。
```

**$.visit.common[123][2]**

```text
后来补上了没？
```

**$.visit.common[123][3]**

```text
>补上了，就是慢了点。
```

**$.visit.common[124][0]**

```text
学着说不
```

**$.visit.common[124][1]**

```text
>刚拒绝一件事，还有点过意不去。
```

**$.visit.common[124][2]**

```text
你不是确实没空吗？
```

**$.visit.common[124][3]**

```text
>嗯，去不了就早点说吧。
```

**$.visit.common[125][0]**

```text
计划的余地
```

**$.visit.common[125][1]**

```text
>我把事情排太满了。
```

**$.visit.common[125][2]**

```text
哪些能往后挪？
```

**$.visit.common[125][3]**

```text
>这个不急，我先划掉。
```

**$.visit.common[126][0]**

```text
短暂走神
```

**$.visit.common[126][1]**

```text
>等下，你上一句说什么？
```

**$.visit.common[126][2]**

```text
刚才没听见？
```

**$.visit.common[126][3]**

```text
>走神了，你再说一遍。
```

**$.visit.common[127][0]**

```text
找回自己的节奏
```

**$.visit.common[127][1]**

```text
>最近总觉得时间不够。
```

**$.visit.common[127][2]**

```text
是不是接的事太多？
```

**$.visit.common[127][3]**

```text
>有点，我得少揽两件。
```

**$.visit.common[128][0]**

```text
不算白忙
```

**$.visit.common[128][1]**

```text
>收拾了半天，还没收完。
```

**$.visit.common[128][2]**

```text
先歇会儿？
```

**$.visit.common[128][3]**

```text
>嗯，越翻出来越多。
```

**$.visit.common[129][0]**

```text
把事情拆开
```

**$.visit.common[129][1]**

```text
>一想到还有一堆事，就不想动了。
```

**$.visit.common[129][2]**

```text
先做最急的那个。
```

**$.visit.common[129][3]**

```text
>那我先把东西找出来。
```

**$.visit.common[130][0]**

```text
自己的标准
```

**$.visit.common[130][1]**

```text
>我是不是又太较真了？
```

**$.visit.common[130][2]**

```text
你看这地方，平时也看不见。
```

**$.visit.common[130][3]**

```text
>也是，别折腾了。
```

**$.visit.common[131][0]**

```text
小小的进步
```

**$.visit.common[131][1]**

```text
>这回比上回好一点。
```

**$.visit.common[131][2]**

```text
哪里？
```

**$.visit.common[131][3]**

```text
>至少没装反，能用了。
```

**$.visit.common[132][0]**

```text
情绪的名字
```

**$.visit.common[132][1]**

```text
>刚才烦半天，都不知道烦什么。
```

**$.visit.common[132][2]**

```text
饿了还是困了？
```

**$.visit.common[132][3]**

```text
>可能是累了，坐下好多了。
```

**$.visit.common[133][0]**

```text
不用马上振作
```

**$.visit.common[133][1]**

```text
>今天不太想说话。
```

**$.visit.common[133][2]**

```text
那歇会儿，要水吗？
```

**$.visit.common[133][3]**

```text
>要，谢谢。
```

**$.visit.common[134][0]**

```text
借一点勇气
```

**$.visit.common[134][1]**

```text
>有件事想试，又怕弄坏。
```

**$.visit.common[134][2]**

```text
先拿不用的练一下。
```

**$.visit.common[134][3]**

```text
>对，我找点旧的。
```

**$.visit.common[135][0]**

```text
不完美的开始
```

**$.visit.common[135][1]**

```text
>要不要再准备一下？
```

**$.visit.common[135][2]**

```text
缺什么？
```

**$.visit.common[135][3]**

```text
>好像也没缺，就是不敢开始。
```

**$.visit.common[136][0]**

```text
把担心放旁边
```

**$.visit.common[136][1]**

```text
>我怕一会儿又忘。
```

**$.visit.common[136][2]**

```text
写下来啊。
```

**$.visit.common[136][3]**

```text
>笔呢？刚才还拿着的。
```

**$.visit.common[137][0]**

```text
不拿休息换内疚
```

**$.visit.common[137][1]**

```text
>休息一会儿又惦记着没干完的事。
```

**$.visit.common[137][2]**

```text
那你先定个时间，到了再做。
```

**$.visit.common[137][3]**

```text
>行，再坐十分钟。
```

**$.visit.common[138][0]**

```text
夸自己一句
```

**$.visit.common[138][1]**

```text
>今天居然没拖到最后。
```

**$.visit.common[138][2]**

```text
难得啊。
```

**$.visit.common[138][3]**

```text
>是啊，我自己也挺意外。
```

**$.visit.common[139][0]**

```text
先照顾自己
```

**$.visit.common[139][1]**

```text
>光顾着给别人拿，自己的忘了。
```

**$.visit.common[139][2]**

```text
你那份还在里面。
```

**$.visit.common[139][3]**

```text
>哦，那就好，我去拿。
```

**$.visit.common[140][0]**

```text
植物的沉默
```

**$.visit.common[140][1]**

```text
>你也会跟植物说话？
```

**$.visit.common[140][2]**

```text
浇水时随口念两句。
```

**$.visit.common[140][3]**

```text
>我一般问它怎么又黄了。
```

**$.visit.common[141][0]**

```text
杯子的选择题
```

**$.visit.common[141][1]**

```text
>你怎么总用这个杯子？
```

**$.visit.common[141][2]**

```text
顺手，而且别的太小。
```

**$.visit.common[141][3]**

```text
>确实，这个不用老添水。
```

**$.visit.common[142][0]**

```text
把门轻轻关上
```

**$.visit.common[142][1]**

```text
>刚才关门是不是太响了？
```

**$.visit.common[142][2]**

```text
还好，没什么。
```

**$.visit.common[142][3]**

```text
>我以为得使劲，没想到一下就关上了。
```

**$.visit.common[143][0]**

```text
靠着还是坐直
```

**$.visit.common[143][1]**

```text
>我能往后靠点吗？
```

**$.visit.common[143][2]**

```text
靠啊，后面有靠枕。
```

**$.visit.common[143][3]**

```text
>好，刚才坐得腰有点酸。
```

**$.visit.common[144][0]**

```text
小物件的去留
```

**$.visit.common[144][1]**

```text
>这个没什么用，我还舍不得扔。
```

**$.visit.common[144][2]**

```text
不占地方就留着呗。
```

**$.visit.common[144][3]**

```text
>嗯，放盒子里也行。
```

**$.visit.common[145][0]**

```text
发现一个角落
```

**$.visit.common[145][1]**

```text
>这角落是不是换过东西？
```

**$.visit.common[145][2]**

```text
我把那盆挪走了。
```

**$.visit.common[145][3]**

```text
>怪不得觉得宽敞了。
```

**$.visit.common[146][0]**

```text
椅子的声音
```

**$.visit.common[146][1]**

```text
>椅子是不是有点响？
```

**$.visit.common[146][2]**

```text
往后挪就这样。
```

**$.visit.common[146][3]**

```text
>我轻点，别把地板划了。
```

**$.visit.common[147][0]**

```text
顺手收一下
```

**$.visit.common[147][1]**

```text
>这两样我放一起了啊。
```

**$.visit.common[147][2]**

```text
好，你别忙着收拾了。
```

**$.visit.common[147][3]**

```text
>顺手的，这就坐下。
```

**$.visit.common[148][0]**

```text
歪一点也好
```

**$.visit.common[148][1]**

```text
>这摆件是不是歪了？
```

**$.visit.common[148][2]**

```text
底下垫了张纸，没垫平。
```

**$.visit.common[148][3]**

```text
>我给你扶一下。
```

**$.visit.common[149][0]**

```text
书上的折角
```

**$.visit.common[149][1]**

```text
>你会给书折角吗？
```

**$.visit.common[149][2]**

```text
没书签的时候会。
```

**$.visit.common[149][3]**

```text
>我也是，但折多了整本鼓起来。
```

**$.visit.common[150][0]**

```text
相同的毛病
```

**$.visit.common[150][1]**

```text
>刚放下又找不到了。
```

**$.visit.common[150][2]**

```text
看看你手边。
```

**$.visit.common[150][3]**

```text
>哦，压在袖子底下了。
```

**$.visit.common[151][0]**

```text
回忆的细节
```

**$.visit.common[151][1]**

```text
>那回的事我就记得鞋湿了。
```

**$.visit.common[151][2]**

```text
雨下那么大，能不湿吗。
```

**$.visit.common[151][3]**

```text
>回去塞了一晚上的纸。
```

**$.visit.common[152][0]**

```text
小时候的想象
```

**$.visit.common[152][1]**

```text
>小时候老想看看柜子后面有什么。
```

**$.visit.common[152][2]**

```text
后来挪开过吗？
```

**$.visit.common[152][3]**

```text
>挪过，掉了一堆灰，还有一支笔。
```

**$.visit.common[153][0]**

```text
长大的证据
```

**$.visit.common[153][1]**

```text
>现在买纸巾都要比一下。
```

**$.visit.common[153][2]**

```text
以前呢？
```

**$.visit.common[153][3]**

```text
>以前拿了就走，没觉得还有区别。
```

**$.visit.common[154][0]**

```text
奇怪的收藏
```

**$.visit.common[154][1]**

```text
>我攒了一盒小纸片。
```

**$.visit.common[154][2]**

```text
票根什么的？
```

**$.visit.common[154][3]**

```text
>嗯，还有些好看的包装。
```

**$.visit.common[155][0]**

```text
遗忘的好处
```

**$.visit.common[155][1]**

```text
>有件糗事我到现在还记着。
```

**$.visit.common[155][2]**

```text
别人估计早忘了。
```

**$.visit.common[155][3]**

```text
>希望吧，我每次想起来都想捂脸。
```

**$.visit.common[156][0]**

```text
熟悉后的随意
```

**$.visit.common[156][1]**

```text
>第一次来我都不敢往后靠。
```

**$.visit.common[156][2]**

```text
现在呢？
```

**$.visit.common[156][3]**

```text
>现在这个靠枕我都抱半天了。
```

**$.visit.common[157][0]**

```text
没有变的小习惯
```

**$.visit.common[157][1]**

```text
>你想事情还是爱摸杯子边。
```

**$.visit.common[157][2]**

```text
我有吗？
```

**$.visit.common[157][3]**

```text
>有啊，你刚才就一直摸。
```

**$.visit.common[158][0]**

```text
记得谁说过
```

**$.visit.common[158][1]**

```text
>这句话好像谁跟我说过。
```

**$.visit.common[158][2]**

```text
想不起来了？
```

**$.visit.common[158][3]**

```text
>嗯，只记得当时觉得挺对。
```

**$.visit.common[159][0]**

```text
共同的普通
```

**$.visit.common[159][1]**

```text
>咱们好像也没干过什么大事。
```

**$.visit.common[159][2]**

```text
不就是吃饭、坐着聊天吗。
```

**$.visit.common[159][3]**

```text
>还真是，下回也这样吧。
```

**$.visit.common[160][0]**

```text
先喝一口水
```

**$.visit.common[160][1]**

```text
>等会儿，我先喝口水。
```

**$.visit.common[160][2]**

```text
刚才说太快了吧。
```

**$.visit.common[160][3]**

```text
>有点，嘴都干了。
```

**$.visit.common[161][0]**

```text
把手机扣下
```

**$.visit.common[161][1]**

```text
>我把手机扣过来，老亮。
```

**$.visit.common[161][2]**

```text
是不是群消息？
```

**$.visit.common[161][3]**

```text
>嗯，晚点再看。
```

**$.visit.common[162][0]**

```text
不用招待太周到
```

**$.visit.common[162][1]**

```text
>你别老起来拿东西了。
```

**$.visit.common[162][2]**

```text
怕你没得吃。
```

**$.visit.common[162][3]**

```text
>够了够了，我都还没吃完。
```

**$.visit.common[163][0]**

```text
不急着走
```

**$.visit.common[163][1]**

```text
>我还不急着走。
```

**$.visit.common[163][2]**

```text
那再坐会儿。
```

**$.visit.common[163][3]**

```text
>行，反正也没别的事。
```

**$.visit.common[164][0]**

```text
一张小凳子
```

**$.visit.common[164][1]**

```text
>这小凳子你平时用吗？
```

**$.visit.common[164][2]**

```text
够不着柜子上面的时候用。
```

**$.visit.common[164][3]**

```text
>我也想买个，站椅子上不稳。
```

**$.visit.common[165][0]**

```text
收好随身物
```

**$.visit.common[165][1]**

```text
>包放这里挡路吗？
```

**$.visit.common[165][2]**

```text
往里推一点就行。
```

**$.visit.common[165][3]**

```text
>这样呢？好，我放好了。
```

**$.visit.common[166][0]**

```text
没带礼物
```

**$.visit.common[166][1]**

```text
>来得急，什么都没带。
```

**$.visit.common[166][2]**

```text
不用带，下次也别拎一堆。
```

**$.visit.common[166][3]**

```text
>行，那我就不客气了。
```

**$.visit.common[167][0]**

```text
不同的坐法
```

**$.visit.common[167][1]**

```text
>你平时都坐这儿？
```

**$.visit.common[167][2]**

```text
差不多。
```

**$.visit.common[167][3]**

```text
>难怪遥控器和纸都在旁边。
```

**$.visit.common[168][0]**

```text
闲聊的长度
```

**$.visit.common[168][1]**

```text
>都聊这么久了？
```

**$.visit.common[168][2]**

```text
你刚说要走的时候就过去一会儿了。
```

**$.visit.common[168][3]**

```text
>我再坐五分钟，真的。
```

**$.visit.common[169][0]**

```text
地毯的小边角
```

**$.visit.common[169][1]**

```text
>这地毯角又翘起来了。
```

**$.visit.common[169][2]**

```text
压了好几次也不行。
```

**$.visit.common[169][3]**

```text
>小心别绊着，拿东西压一下？
```

**$.visit.common[170][0]**

```text
笑着停一下
```

**$.visit.common[170][1]**

```text
>等会儿，我先笑完。
```

**$.visit.common[170][2]**

```text
还没笑够？
```

**$.visit.common[170][3]**

```text
>别催，你一说我又想笑了。
```

**$.visit.common[171][0]**

```text
小声的谢谢
```

**$.visit.common[171][1]**

```text
>今天麻烦你招待了。
```

**$.visit.common[171][2]**

```text
麻烦什么，下回再来。
```

**$.visit.common[171][3]**

```text
>好，我走之前帮你收个杯子。
```

**$.visit.common[172][0]**

```text
短短的关心
```

**$.visit.common[172][1]**

```text
>最近吃饭还规律吗？
```

**$.visit.common[172][2]**

```text
还行，有时懒得做。
```

**$.visit.common[172][3]**

```text
>你别又拿饼干凑一顿。
```

**$.visit.common[173][0]**

```text
生活的小改动
```

**$.visit.common[173][1]**

```text
>我把常用的东西都挪近了。
```

**$.visit.common[173][2]**

```text
这回不用老找了吧？
```

**$.visit.common[173][3]**

```text
>好一点，就是总伸手去原来那儿拿。
```

**$.visit.common[174][0]**

```text
意外的共识
```

**$.visit.common[174][1]**

```text
>原来你也这么想。
```

**$.visit.common[174][2]**

```text
我以为就我呢。
```

**$.visit.common[174][3]**

```text
>早知道前面就问你了。
```

**$.visit.common[175][0]**

```text
不同也能聊
```

**$.visit.common[175][1]**

```text
>这件事我想的跟你不一样。
```

**$.visit.common[175][2]**

```text
哪里不一样？
```

**$.visit.common[175][3]**

```text
>等下，我从前面说。
```

**$.visit.common[176][0]**

```text
给建议前先问
```

**$.visit.common[176][1]**

```text
>你先说完，我再帮你想。
```

**$.visit.common[176][2]**

```text
我就是想吐槽一下。
```

**$.visit.common[176][3]**

```text
>行，那我先听着。
```

**$.visit.common[177][0]**

```text
不抢最后一句
```

**$.visit.common[177][1]**

```text
>咱俩先别争了。
```

**$.visit.common[177][2]**

```text
行，反正这会儿也没法试。
```

**$.visit.common[177][3]**

```text
>下回试试就知道了。
```

**$.visit.common[178][0]**

```text
被允许的沉默
```

**$.visit.common[178][1]**

```text
>你刚才怎么半天没出声？
```

**$.visit.common[178][2]**

```text
在听你讲啊。
```

**$.visit.common[178][3]**

```text
>哦，我还以为你困了。
```

**$.visit.common[179][0]**

```text
一样的笨拙
```

**$.visit.common[179][1]**

```text
>我刚差点拿错杯子。
```

**$.visit.common[179][2]**

```text
你的在这边。
```

**$.visit.common[179][3]**

```text
>看见了，两个颜色太像了。
```

**$.visit.common[180][0]**

```text
分享一个发现
```

**$.visit.common[180][1]**

```text
>跟你说完，我倒是想清楚了。
```

**$.visit.common[180][2]**

```text
那你准备怎么办？
```

**$.visit.common[180][3]**

```text
>先去问问，别自己瞎猜了。
```

**$.visit.common[181][0]**

```text
彼此的余地
```

**$.visit.common[181][1]**

```text
>我有时候回消息挺慢的。
```

**$.visit.common[181][2]**

```text
忙就忙你的，急事我会打电话。
```

**$.visit.common[181][3]**

```text
>好，我看到会回。
```

**$.visit.common[182][0]**

```text
温柔的提醒
```

**$.visit.common[182][1]**

```text
>我是不是又催你休息了？
```

**$.visit.common[182][2]**

```text
是，但我确实该停一会儿了。
```

**$.visit.common[182][3]**

```text
>那你先别忙了，坐下。
```

**$.visit.common[183][0]**

```text
坦然承认忘记
```

**$.visit.common[183][1]**

```text
>上回那件事我忘了一点。
```

**$.visit.common[183][2]**

```text
哪一段？
```

**$.visit.common[183][3]**

```text
>就你后来去找谁了？
```

**$.visit.common[184][0]**

```text
记得一个约定
```

**$.visit.common[184][1]**

```text
>咱们是不是说过一起散步？
```

**$.visit.common[184][2]**

```text
是啊，还没挑时间。
```

**$.visit.common[184][3]**

```text
>你哪天有空再说吧。
```

**$.visit.common[185][0]**

```text
不需要精彩
```

**$.visit.common[185][1]**

```text
>这事是不是有点没意思？
```

**$.visit.common[185][2]**

```text
你先说，我还不知道呢。
```

**$.visit.common[185][3]**

```text
>其实就是买菜多找了我一块钱。
```

**$.visit.common[186][0]**

```text
各有一点忙
```

**$.visit.common[186][1]**

```text
>好久没坐着聊这么久了。
```

**$.visit.common[186][2]**

```text
你最近忙什么呢？
```

**$.visit.common[186][3]**

```text
>都是杂事，一天一下就过去了。
```

**$.visit.common[187][0]**

```text
不必强撑热闹
```

**$.visit.common[187][1]**

```text
>累的话咱们歇会儿。
```

**$.visit.common[187][2]**

```text
嗯，我靠一下。
```

**$.visit.common[187][3]**

```text
>好，我也不想动了。
```

**$.visit.common[188][0]**

```text
礼貌与熟悉
```

**$.visit.common[188][1]**

```text
>你看我，都这么熟了还说谢谢。
```

**$.visit.common[188][2]**

```text
顺口的，没事。
```

**$.visit.common[188][3]**

```text
>那谢谢还是要说的。
```

**$.visit.common[189][0]**

```text
把烦恼放小
```

**$.visit.common[189][1]**

```text
>刚才说完感觉没那么烦了。
```

**$.visit.common[189][2]**

```text
那就先别想了。
```

**$.visit.common[189][3]**

```text
>嗯，回去再处理。
```

**$.visit.common[190][0]**

```text
结束之前
```

**$.visit.common[190][1]**

```text
>下次还这么坐会儿？
```

**$.visit.common[190][2]**

```text
好啊，来之前说一声就行。
```

**$.visit.common[190][3]**

```text
>行，我到时候找你。
```

**$.visit.common[191][0]**

```text
坐近一点点
```

**$.visit.common[191][1]**

```text
>我挪这边一点，刚才没听清。
```

**$.visit.common[191][2]**

```text
这边能听见吗？
```

**$.visit.common[191][3]**

```text
>能了，你接着说。
```

**$.visit.common[192][0]**

```text
同一个疑问
```

**$.visit.common[192][1]**

```text
>我刚也想问这个。
```

**$.visit.common[192][2]**

```text
你还有什么没弄懂的？
```

**$.visit.common[192][3]**

```text
>差不多了，你先说吧。
```

**$.visit.common[193][0]**

```text
捡起小东西
```

**$.visit.common[193][1]**

```text
>这是不是你掉的？
```

**$.visit.common[193][2]**

```text
对，我找半天了。
```

**$.visit.common[193][3]**

```text
>在椅子底下，刚好看见。
```

**$.visit.common[194][0]**

```text
记在脑子里
```

**$.visit.common[194][1]**

```text
>这个办法我记一下。
```

**$.visit.common[194][2]**

```text
你先试试，不一定每次都管用。
```

**$.visit.common[194][3]**

```text
>嗯，我回去试。
```

**$.visit.common[195][0]**

```text
不用找借口
```

**$.visit.common[195][1]**

```text
>其实也没什么事，就想来坐会儿。
```

**$.visit.common[195][2]**

```text
来呗，这还用找理由。
```

**$.visit.common[195][3]**

```text
>那我下回直接问你在不在家。
```

**$.visit.common[196][0]**

```text
一点点挪动
```

**$.visit.common[196][1]**

```text
>刚才怎么坐都不舒服。
```

**$.visit.common[196][2]**

```text
把靠垫往下挪点。
```

**$.visit.common[196][3]**

```text
>好了，还是你这个办法管用。
```

**$.visit.common[197][0]**

```text
先笑自己
```

**$.visit.common[197][1]**

```text
>刚才那个词我说错了吧？
```

**$.visit.common[197][2]**

```text
我听懂了，没事。
```

**$.visit.common[197][3]**

```text
>我越想越好笑，舌头没跟上。
```

**$.visit.common[198][0]**

```text
小屋的声音
```

**$.visit.common[198][1]**

```text
>你家刚才什么响了一声？
```

**$.visit.common[198][2]**

```text
柜子吧，偶尔会这样。
```

**$.visit.common[198][3]**

```text
>哦，我还以为掉东西了。
```

**$.visit.common[199][0]**

```text
留住这份自在
```

**$.visit.common[199][1]**

```text
>坐着坐着就不想走了。
```

**$.visit.common[199][2]**

```text
那下次早点来。
```

**$.visit.common[199][3]**

```text
>行，这次我真该回去了。
```

**$.visit.tv[0][0]**

```text
遥控器主持人
```

**$.visit.tv[0][1]**

```text
>看哪个台？
```

**$.visit.tv[0][2]**

```text
你先挑吧。
```

**$.visit.tv[0][3]**

```text
>那我换两个看看。
```

**$.visit.tv[1][0]**

```text
片头的熟悉感
```

**$.visit.tv[1][1]**

```text
>这片头我居然会唱。
```

**$.visit.tv[1][2]**

```text
以前看过吧。
```

**$.visit.tv[1][3]**

```text
>看过，就是剧情忘差不多了。
```

**$.visit.tv[2][0]**

```text
不剧透协议
```

**$.visit.tv[2][1]**

```text
>你看过这一集？
```

**$.visit.tv[2][2]**

```text
嗯，我不说后面。
```

**$.visit.tv[2][3]**

```text
>那你也别老看我反应啊。
```

**$.visit.tv[3][0]**

```text
广告时间
```

**$.visit.tv[3][1]**

```text
>怎么又广告了。
```

**$.visit.tv[3][2]**

```text
刚好喝口水。
```

**$.visit.tv[3][3]**

```text
>你别换台，我怕错过后面。
```

**$.visit.tv[4][0]**

```text
配角的名字
```

**$.visit.tv[4][1]**

```text
>那个人叫什么？
```

**$.visit.tv[4][2]**

```text
角色名还是演员？
```

**$.visit.tv[4][3]**

```text
>演员，别的剧里也见过。
```

**$.visit.tv[5][0]**

```text
声音调一点
```

**$.visit.tv[5][1]**

```text
>声音大不大？
```

**$.visit.tv[5][2]**

```text
小一点吧，听不清你讲话了。
```

**$.visit.tv[5][3]**

```text
>这样行吗？
```

**$.visit.tv[6][0]**

```text
悬念太认真
```

**$.visit.tv[6][1]**

```text
>他不会真进去吧？
```

**$.visit.tv[6][2]**

```text
你先看。
```

**$.visit.tv[6][3]**

```text
>哎，真进去了，门都没关。
```

**$.visit.tv[7][0]**

```text
一起笑半拍
```

**$.visit.tv[7][1]**

```text
>刚才有什么好笑的？
```

**$.visit.tv[7][2]**

```text
你没看见他后面那个人？
```

**$.visit.tv[7][3]**

```text
>没啊，倒回去一点。
```

**$.visit.tv[8][0]**

```text
片尾不急走
```

**$.visit.tv[8][1]**

```text
>片尾曲还挺好听。
```

**$.visit.tv[8][2]**

```text
要不要换台？
```

**$.visit.tv[8][3]**

```text
>先别，我听完这段。
```

**$.visit.tv[9][0]**

```text
吃播的力量
```

**$.visit.tv[9][1]**

```text
>看得我都饿了。
```

**$.visit.tv[9][2]**

```text
又在拍吃的。
```

**$.visit.tv[9][3]**

```text
>还拍这么近，太馋人了。
```

**$.visit.tv[10][0]**

```text
纪录片的小知识
```

**$.visit.tv[10][1]**

```text
>原来这个是这么做的。
```

**$.visit.tv[10][2]**

```text
以前我也不知道。
```

**$.visit.tv[10][3]**

```text
>难怪卖那么贵，得做这么久。
```

**$.visit.tv[11][0]**

```text
选台的循环
```

**$.visit.tv[11][1]**

```text
>怎么又换回这个台了。
```

**$.visit.tv[11][2]**

```text
你都转一圈了。
```

**$.visit.tv[11][3]**

```text
>算了，就看这个吧。
```

**$.visit.tv[12][0]**

```text
背景音的工作
```

**$.visit.tv[12][1]**

```text
>刚才讲到哪儿了？
```

**$.visit.tv[12][2]**

```text
我们光说话，没看。
```

**$.visit.tv[12][3]**

```text
>我说怎么接不上了。
```

**$.visit.tv[13][0]**

```text
猜错的反转
```

**$.visit.tv[13][1]**

```text
>我刚还说肯定是他。
```

**$.visit.tv[13][2]**

```text
结果猜错了吧。
```

**$.visit.tv[13][3]**

```text
>你别笑，你也没猜对。
```

**$.visit.tv[14][0]**

```text
暂停一下
```

**$.visit.tv[14][1]**

```text
>这句我没听清。
```

**$.visit.tv[14][2]**

```text
倒回去一点？
```

**$.visit.tv[14][3]**

```text
>好，就几秒。
```

**$.visit.tv[15][0]**

```text
主角的勇气
```

**$.visit.tv[15][1]**

```text
>这换我肯定不敢进去。
```

**$.visit.tv[15][2]**

```text
太黑了。
```

**$.visit.tv[15][3]**

```text
>而且明明知道里面有人。
```

**$.visit.tv[16][0]**

```text
布景观察员
```

**$.visit.tv[16][1]**

```text
>你看后面那盏灯，像不像你家的？
```

**$.visit.tv[16][2]**

```text
有点像。
```

**$.visit.tv[16][3]**

```text
>就是大一圈，样子真差不多。
```

**$.visit.tv[17][0]**

```text
特效的边界
```

**$.visit.tv[17][1]**

```text
>这个也飞得太远了吧。
```

**$.visit.tv[17][2]**

```text
是夸张了点。
```

**$.visit.tv[17][3]**

```text
>人还一点事都没有。
```

**$.visit.tv[18][0]**

```text
下一集的诱惑
```

**$.visit.tv[18][1]**

```text
>怎么偏偏在这儿停。
```

**$.visit.tv[18][2]**

```text
要看下一集吗？
```

**$.visit.tv[18][3]**

```text
>等下，看看还有多长。
```

**$.visit.tv[19][0]**

```text
一起看的不同
```

**$.visit.tv[19][1]**

```text
>自己看都没发现这个。
```

**$.visit.tv[19][2]**

```text
我也是看第二遍才注意到。
```

**$.visit.tv[19][3]**

```text
>难怪你刚才一直笑。
```

**$.visit.meal[0][0]**

```text
第一口温度
```

**$.visit.meal[0][1]**

```text
>先小口尝尝，别烫着。
```

**$.visit.meal[0][2]**

```text
嗯，我吹一吹。
```

**$.visit.meal[0][3]**

```text
>里面可能还热，慢一点。
```

**$.visit.meal[1][0]**

```text
认真尝味道
```

**$.visit.meal[1][1]**

```text
>这个挺好吃啊。
```

**$.visit.meal[1][2]**

```text
真的？我刚还怕味道淡。
```

**$.visit.meal[1][3]**

```text
>不淡，正合适。
```

**$.visit.meal[2][0]**

```text
饭香很公平
```

**$.visit.meal[2][1]**

```text
>刚才闻着就饿了。
```

**$.visit.meal[2][2]**

```text
现在多吃点。
```

**$.visit.meal[2][3]**

```text
>你也吃，别光给我夹。
```

**$.visit.meal[3][0]**

```text
筷子的节奏
```

**$.visit.meal[3][1]**

```text
>边说话边吃，半天没下去多少。
```

**$.visit.meal[3][2]**

```text
你先吃完这口。
```

**$.visit.meal[3][3]**

```text
>嗯，嘴里还有呢。
```

**$.visit.meal[4][0]**

```text
一口接一口
```

**$.visit.meal[4][1]**

```text
>等会儿，我先咽了再说。
```

**$.visit.meal[4][2]**

```text
吃你的，不急。
```

**$.visit.meal[4][3]**

```text
>刚想说什么，差点忘了。
```

**$.visit.meal[5][0]**

```text
挑哪一块
```

**$.visit.meal[5][1]**

```text
>这两块你想要哪个？
```

**$.visit.meal[5][2]**

```text
近的那块吧。
```

**$.visit.meal[5][3]**

```text
>好，另一块我夹走了。
```

**$.visit.meal[6][0]**

```text
家常的分量
```

**$.visit.meal[6][1]**

```text
>还是在家吃饭自在。
```

**$.visit.meal[6][2]**

```text
能慢慢吃，不用等位。
```

**$.visit.meal[6][3]**

```text
>对，吃完也不着急腾桌子。
```

**$.visit.meal[7][0]**

```text
盐的讨论
```

**$.visit.meal[7][1]**

```text
>味道咸不咸？
```

**$.visit.meal[7][2]**

```text
不咸，刚好。
```

**$.visit.meal[7][3]**

```text
>那就行，我刚没敢多放。
```

**$.visit.meal[8][0]**

```text
小碗的坚持
```

**$.visit.meal[8][1]**

```text
>我先少盛一点。
```

**$.visit.meal[8][2]**

```text
不够锅里还有。
```

**$.visit.meal[8][3]**

```text
>好，我怕盛多了吃不完。
```

**$.visit.meal[9][0]**

```text
把手机放旁边
```

**$.visit.meal[9][1]**

```text
>我把手机放一边，先吃。
```

**$.visit.meal[9][2]**

```text
怎么，有消息？
```

**$.visit.meal[9][3]**

```text
>群里一直响，没什么要紧的。
```

**$.visit.meal[10][0]**

```text
饭桌上的小事
```

**$.visit.meal[10][1]**

```text
>刚才那个吃完再说？
```

**$.visit.meal[10][2]**

```text
行，我这口还没咽下去。
```

**$.visit.meal[10][3]**

```text
>你慢点，别呛着。
```

**$.visit.meal[11][0]**

```text
汤别太急
```

**$.visit.meal[11][1]**

```text
>这碗汤有点满。
```

**$.visit.meal[11][2]**

```text
先放这儿，我挪一下。
```

**$.visit.meal[11][3]**

```text
>好了，差点晃出来。
```

**$.visit.meal[12][0]**

```text
做饭的耐心
```

**$.visit.meal[12][1]**

```text
>做了挺久吧？
```

**$.visit.meal[12][2]**

```text
准备东西花了点时间。
```

**$.visit.meal[12][3]**

```text
>我帮你把盘子收一下。
```

**$.visit.meal[13][0]**

```text
一菜两种看法
```

**$.visit.meal[13][1]**

```text
>这个边上脆，里面倒挺软。
```

**$.visit.meal[13][2]**

```text
我也是刚吃出来。
```

**$.visit.meal[13][3]**

```text
>趁热吃，凉了可能没这口感。
```

**$.visit.meal[14][0]**

```text
下次我来
```

**$.visit.meal[14][1]**

```text
>下回我做给你吃。
```

**$.visit.meal[14][2]**

```text
好，别弄太多。
```

**$.visit.meal[14][3]**

```text
>嗯，我先挑个会做的。
```

**$.visit.meal[15][0]**

```text
不抢着客气
```

**$.visit.meal[15][1]**

```text
>这块给你。
```

**$.visit.meal[15][2]**

```text
好，那你吃这块。
```

**$.visit.meal[15][3]**

```text
>行，赶紧吃吧。
```

**$.visit.meal[16][0]**

```text
饭后的计划
```

**$.visit.meal[16][1]**

```text
>吃完还干什么？
```

**$.visit.meal[16][2]**

```text
先坐会儿吧。
```

**$.visit.meal[16][3]**

```text
>同意，我现在不想动。
```

**$.visit.meal[17][0]**

```text
小小失误也香
```

**$.visit.meal[17][1]**

```text
>这块是不是有点焦？
```

**$.visit.meal[17][2]**

```text
嗯，刚才没看住火。
```

**$.visit.meal[17][3]**

```text
>还好，边上脆脆的。
```

**$.visit.meal[18][0]**

```text
留一点余地
```

**$.visit.meal[18][1]**

```text
>不添了，我饱了。
```

**$.visit.meal[18][2]**

```text
真饱了就别盛。
```

**$.visit.meal[18][3]**

```text
>嗯，再吃该撑了。
```

**$.visit.meal[19][0]**

```text
谢谢这一顿
```

**$.visit.meal[19][1]**

```text
>吃好了，谢谢你啊。
```

**$.visit.meal[19][2]**

```text
好吃就行。
```

**$.visit.meal[19][3]**

```text
>我来收碗，你先坐会儿。
```

**$.visit.rain[0][0]**

```text
雨声的底色
```

**$.visit.rain[0][1]**

```text
>听，雨是不是大了？
```

**$.visit.rain[0][2]**

```text
嗯，打窗户都听得见。
```

**$.visit.rain[0][3]**

```text
>刚才外面还没这么响。
```

**$.visit.rain[1][0]**

```text
伞放门边
```

**$.visit.rain[1][1]**

```text
>伞还在滴水。
```

**$.visit.rain[1][2]**

```text
下面有垫子，一会儿再收。
```

**$.visit.rain[1][3]**

```text
>好，我就先放那儿了。
```

**$.visit.rain[2][0]**

```text
窗上的小路
```

**$.visit.rain[2][1]**

```text
>这水一直往窗缝那儿流。
```

**$.visit.rain[2][2]**

```text
没流进来吧？
```

**$.visit.rain[2][3]**

```text
>没有，里面是干的。
```

**$.visit.rain[3][0]**

```text
不必赶路
```

**$.visit.rain[3][1]**

```text
>幸好已经进屋了。
```

**$.visit.rain[3][2]**

```text
刚才还担心你在路上。
```

**$.visit.rain[3][3]**

```text
>赶上了，就湿了点袖子。
```

**$.visit.rain[4][0]**

```text
雨把远处藏起来
```

**$.visit.rain[4][1]**

```text
>外面都看不清了。
```

**$.visit.rain[4][2]**

```text
雨挺密的。
```

**$.visit.rain[4][3]**

```text
>那我先别急着走。
```

**$.visit.rain[5][0]**

```text
鞋底先擦干
```

**$.visit.rain[5][1]**

```text
>我鞋底是不是把地踩湿了？
```

**$.visit.rain[5][2]**

```text
没有，门垫擦干了。
```

**$.visit.rain[5][3]**

```text
>好，刚在外面蹭了几下。
```

**$.visit.rain[6][0]**

```text
雨伞的花纹
```

**$.visit.rain[6][1]**

```text
>你的伞哪儿买的？
```

**$.visit.rain[6][2]**

```text
路边买的，原来那把坏了。
```

**$.visit.rain[6][3]**

```text
>这个花纹还挺好看。
```

**$.visit.rain[7][0]**

```text
雨天的呼吸
```

**$.visit.rain[7][1]**

```text
>好像有点潮。
```

**$.visit.rain[7][2]**

```text
窗边更明显。
```

**$.visit.rain[7][3]**

```text
>要不要把窗缝关小点？
```

**$.visit.rain[8][0]**

```text
水珠的比赛
```

**$.visit.rain[8][1]**

```text
>这两滴水要碰一起了。
```

**$.visit.rain[8][2]**

```text
哪儿？
```

**$.visit.rain[8][3]**

```text
>玻璃上，哎，已经滑下去了。
```

**$.visit.rain[9][0]**

```text
雨停再说
```

**$.visit.rain[9][1]**

```text
>我等雨小点再走。
```

**$.visit.rain[9][2]**

```text
行，你先坐着。
```

**$.visit.rain[9][3]**

```text
>要是一直不小，我再想办法。
```

**$.visit.rain[10][0]**

```text
雨声遮住杂音
```

**$.visit.rain[10][1]**

```text
>外面车声都听不见了。
```

**$.visit.rain[10][2]**

```text
雨太响了。
```

**$.visit.rain[10][3]**

```text
>你刚才那句我也差点没听到。
```

**$.visit.rain[11][0]**

```text
湿伞的重量
```

**$.visit.rain[11][1]**

```text
>这伞得晾一下。
```

**$.visit.rain[11][2]**

```text
靠门边撑开一点？
```

**$.visit.rain[11][3]**

```text
>行，别挡着门就好。
```

**$.visit.rain[12][0]**

```text
窗边看雨
```

**$.visit.rain[12][1]**

```text
>还是坐屋里看雨舒服。
```

**$.visit.rain[12][2]**

```text
刚才鞋有没有湿？
```

**$.visit.rain[12][3]**

```text
>还好，鞋尖有一点。
```

**$.visit.rain[13][0]**

```text
雨打叶子
```

**$.visit.rain[13][1]**

```text
>雨打树叶声音跟打窗上不一样。
```

**$.visit.rain[13][2]**

```text
树叶上轻一点。
```

**$.visit.rain[13][3]**

```text
>嗯，刚才风一吹又响了一阵。
```

**$.visit.rain[14][0]**

```text
多带一把伞
```

**$.visit.rain[14][1]**

```text
>下次得记得带伞。
```

**$.visit.rain[14][2]**

```text
包里塞一把小的吧。
```

**$.visit.rain[14][3]**

```text
>我有，就是老忘了放回去。
```

**$.visit.rain[15][0]**

```text
雨天的慢动作
```

**$.visit.rain[15][1]**

```text
>一下雨我就懒得出门。
```

**$.visit.rain[15][2]**

```text
尤其是鞋湿了以后。
```

**$.visit.rain[15][3]**

```text
>对，走一路都难受。
```

**$.visit.rain[16][0]**

```text
屋里的干燥
```

**$.visit.rain[16][1]**

```text
>还好衣服没怎么湿。
```

**$.visit.rain[16][2]**

```text
刚才淋到了？
```

**$.visit.rain[16][3]**

```text
>就从门口跑进来那一小段。
```

**$.visit.rain[17][0]**

```text
雨点敲门
```

**$.visit.rain[17][1]**

```text
>刚是不是有人敲门？
```

**$.visit.rain[17][2]**

```text
没有，雨打窗台。
```

**$.visit.rain[17][3]**

```text
>听岔了，还以为又来人了。
```

**$.visit.rain[18][0]**

```text
想听清楚
```

**$.visit.rain[18][1]**

```text
>刚才没听清，你说什么？
```

**$.visit.rain[18][2]**

```text
我说要不要再倒点水。
```

**$.visit.rain[18][3]**

```text
>要，半杯就行。
```

**$.visit.rain[19][0]**

```text
离开时的伞
```

**$.visit.rain[19][1]**

```text
>走的时候记得提醒我拿伞。
```

**$.visit.rain[19][2]**

```text
现在就放包旁边？
```

**$.visit.rain[19][3]**

```text
>好，不然真可能忘。
```

**$.visit.snow[0][0]**

```text
第一眼的白
```

**$.visit.snow[0][1]**

```text
>外面都白了。
```

**$.visit.snow[0][2]**

```text
刚才还没积这么多。
```

**$.visit.snow[0][3]**

```text
>一会儿出去得慢点。
```

**$.visit.snow[1][0]**

```text
雪花不着急
```

**$.visit.snow[1][1]**

```text
>这雪飘得挺慢。
```

**$.visit.snow[1][2]**

```text
风一吹又往回走。
```

**$.visit.snow[1][3]**

```text
>我盯半天了，还没落地。
```

**$.visit.snow[2][0]**

```text
暖手的杯子
```

**$.visit.snow[2][1]**

```text
>这杯子捧着挺暖和。
```

**$.visit.snow[2][2]**

```text
手还冷吗？
```

**$.visit.snow[2][3]**

```text
>好多了，刚才手指都僵了。
```

**$.visit.snow[3][0]**

```text
脚印的方向
```

**$.visit.snow[3][1]**

```text
>那串脚印是你的吗？
```

**$.visit.snow[3][2]**

```text
不是，我今天还没从那边走。
```

**$.visit.snow[3][3]**

```text
>哦，我还以为你出去过。
```

**$.visit.snow[4][0]**

```text
不急着开窗
```

**$.visit.snow[4][1]**

```text
>我想开窗看看。
```

**$.visit.snow[4][2]**

```text
别开太久，冷。
```

**$.visit.snow[4][3]**

```text
>嗯，看一眼就关。
```

**$.visit.snow[5][0]**

```text
雪的安静
```

**$.visit.snow[5][1]**

```text
>下雪以后好像安静了点。
```

**$.visit.snow[5][2]**

```text
路上人也少了。
```

**$.visit.snow[5][3]**

```text
>我刚来的时候就没碰上几个。
```

**$.visit.snow[6][0]**

```text
围巾的归宿
```

**$.visit.snow[6][1]**

```text
>围巾放这儿可以吗？
```

**$.visit.snow[6][2]**

```text
放吧，走的时候记得拿。
```

**$.visit.snow[6][3]**

```text
>嗯，和包放一起。
```

**$.visit.snow[7][0]**

```text
雪落在枝上
```

**$.visit.snow[7][1]**

```text
>树枝上积了一条雪。
```

**$.visit.snow[7][2]**

```text
细的那根都压弯了。
```

**$.visit.snow[7][3]**

```text
>会不会掉下来啊。
```

**$.visit.snow[8][0]**

```text
鞋印的证据
```

**$.visit.snow[8][1]**

```text
>门口那脚印是我踩的。
```

**$.visit.snow[8][2]**

```text
鞋上雪化了吗？
```

**$.visit.snow[8][3]**

```text
>化了，我再在垫子上蹭一下。
```

**$.visit.snow[9][0]**

```text
雪天的颜色
```

**$.visit.snow[9][1]**

```text
>一下雪，你家窗框看着都深了。
```

**$.visit.snow[9][2]**

```text
平时没这么明显。
```

**$.visit.snow[9][3]**

```text
>对，外面全白了。
```

**$.visit.snow[10][0]**

```text
手指慢慢回暖
```

**$.visit.snow[10][1]**

```text
>手总算暖过来了。
```

**$.visit.snow[10][2]**

```text
你刚才没戴手套？
```

**$.visit.snow[10][3]**

```text
>没带，光把手揣兜里了。
```

**$.visit.snow[11][0]**

```text
想象雪的形状
```

**$.visit.snow[11][1]**

```text
>雪花落手上就没了。
```

**$.visit.snow[11][2]**

```text
手热啊。
```

**$.visit.snow[11][3]**

```text
>我还没看清就化了。
```

**$.visit.snow[12][0]**

```text
帽子上的雪
```

**$.visit.snow[12][1]**

```text
>帽子上还有雪吗？
```

**$.visit.snow[12][2]**

```text
有一点，别弄领子里。
```

**$.visit.snow[12][3]**

```text
>帮我拍一下，谢谢。
```

**$.visit.snow[13][0]**

```text
暂时没出门
```

**$.visit.snow[13][1]**

```text
>又开始下了，我再坐会儿。
```

**$.visit.snow[13][2]**

```text
行，不赶就等等。
```

**$.visit.snow[13][3]**

```text
>嗯，刚才还以为要停了。
```

**$.visit.snow[14][0]**

```text
冷暖的分界
```

**$.visit.snow[14][1]**

```text
>隔着窗户看挺好，真不想出去。
```

**$.visit.snow[14][2]**

```text
外面风还大。
```

**$.visit.snow[14][3]**

```text
>等会儿把围巾再裹紧点。
```

**$.visit.snow[15][0]**

```text
一片雪的旅行
```

**$.visit.snow[15][1]**

```text
>那片雪刚快落地，又吹起来了。
```

**$.visit.snow[15][2]**

```text
风兜着呢。
```

**$.visit.snow[15][3]**

```text
>哦，现在落下去了。
```

**$.visit.snow[16][0]**

```text
雪人的计划
```

**$.visit.snow[16][1]**

```text
>雪再厚点能堆雪人了吧。
```

**$.visit.snow[16][2]**

```text
得看看能不能攥起来。
```

**$.visit.snow[16][3]**

```text
>太松也不行，我上回捏半天没捏住。
```

**$.visit.snow[17][0]**

```text
白色的屋檐
```

**$.visit.snow[17][1]**

```text
>屋檐上那块雪挺厚。
```

**$.visit.snow[17][2]**

```text
别站底下，怕掉。
```

**$.visit.snow[17][3]**

```text
>嗯，我回去绕开点。
```

**$.visit.snow[18][0]**

```text
慢慢走回去
```

**$.visit.snow[18][1]**

```text
>回去得慢点了。
```

**$.visit.snow[18][2]**

```text
路上滑，别看着雪走。
```

**$.visit.snow[18][3]**

```text
>知道，我先看看鞋底。
```

**$.visit.snow[19][0]**

```text
把雪景记住
```

**$.visit.snow[19][1]**

```text
>我想拍张雪景。
```

**$.visit.snow[19][2]**

```text
隔着窗玻璃有反光。
```

**$.visit.snow[19][3]**

```text
>那先这样拍一张，出去再拍。
```

**$.visit.spring[0][0]**

```text
春天的绿
```

**$.visit.spring[0][1]**

```text
>外面那树是不是长新叶了？
```

**$.visit.spring[0][2]**

```text
前几天还光着呢。
```

**$.visit.spring[0][3]**

```text
>今天仔细看才发现。
```

**$.visit.spring[1][0]**

```text
想种点什么
```

**$.visit.spring[1][1]**

```text
>我也想养盆小植物。
```

**$.visit.spring[1][2]**

```text
先养个好活的。
```

**$.visit.spring[1][3]**

```text
>嗯，别买回来几天就蔫了。
```

**$.visit.spring[2][0]**

```text
衣服的厚薄
```

**$.visit.spring[2][1]**

```text
>这天出门真不知道穿多少。
```

**$.visit.spring[2][2]**

```text
外套能脱就行。
```

**$.visit.spring[2][3]**

```text
>刚走着热，坐下又凉了。
```

**$.visit.spring[3][0]**

```text
花期的惦记
```

**$.visit.spring[3][1]**

```text
>最近想去看看花。
```

**$.visit.spring[3][2]**

```text
哪儿开了？
```

**$.visit.spring[3][3]**

```text
>我也还在问，看到照片了。
```

**$.visit.spring[4][0]**

```text
春天的整理
```

**$.visit.spring[4][1]**

```text
>天暖了就想收拾东西。
```

**$.visit.spring[4][2]**

```text
先从哪儿收？
```

**$.visit.spring[4][3]**

```text
>先把空盒子扔掉，太占地方了。
```

**$.visit.summer[0][0]**

```text
夏天的杯子
```

**$.visit.summer[0][1]**

```text
>最近水喝得特别快。
```

**$.visit.summer[0][2]**

```text
杯子放手边吧。
```

**$.visit.summer[0][3]**

```text
>嗯，不然总忘了倒。
```

**$.visit.summer[1][0]**

```text
慢一点的午后
```

**$.visit.summer[1][1]**

```text
>一热我就不想动。
```

**$.visit.summer[1][2]**

```text
出去走一会儿就出汗。
```

**$.visit.summer[1][3]**

```text
>对，回家还得再换衣服。
```

**$.visit.summer[2][0]**

```text
夏日小计划
```

**$.visit.summer[2][1]**

```text
>想出去走走，又怕晒。
```

**$.visit.summer[2][2]**

```text
等没那么热再去。
```

**$.visit.summer[2][3]**

```text
>行，看看晚点凉不凉快。
```

**$.visit.summer[3][0]**

```text
薄一点的衣料
```

**$.visit.summer[3][1]**

```text
>换薄衣服真轻快。
```

**$.visit.summer[3][2]**

```text
厚的都收了？
```

**$.visit.summer[3][3]**

```text
>还没，挑个空再洗。
```

**$.visit.summer[4][0]**

```text
冰与热的选择
```

**$.visit.summer[4][1]**

```text
>这么热你还喝热水？
```

**$.visit.summer[4][2]**

```text
不烫，放凉一点喝。
```

**$.visit.summer[4][3]**

```text
>哦，我以为刚烧开的。
```

**$.visit.autumn[0][0]**

```text
叶子的颜色
```

**$.visit.autumn[0][1]**

```text
>树叶开始黄了。
```

**$.visit.autumn[0][2]**

```text
昨天还没注意。
```

**$.visit.autumn[0][3]**

```text
>路边已经落了不少了。
```

**$.visit.autumn[1][0]**

```text
想留的叶子
```

**$.visit.autumn[1][1]**

```text
>刚捡了片挺好看的叶子。
```

**$.visit.autumn[1][2]**

```text
你要夹书里？
```

**$.visit.autumn[1][3]**

```text
>嗯，先擦干净。
```

**$.visit.autumn[2][0]**

```text
外套的口袋
```

**$.visit.autumn[2][1]**

```text
>终于能穿有大口袋的外套了。
```

**$.visit.autumn[2][2]**

```text
又装一堆东西？
```

**$.visit.autumn[2][3]**

```text
>可不是，回头洗的时候全得掏出来。
```

**$.visit.autumn[3][0]**

```text
温度的提醒
```

**$.visit.autumn[3][1]**

```text
>风一吹有点凉。
```

**$.visit.autumn[3][2]**

```text
出门带件外套吧。
```

**$.visit.autumn[3][3]**

```text
>嗯，刚才差点没拿。
```

**$.visit.autumn[4][0]**

```text
秋天的胃口
```

**$.visit.autumn[4][1]**

```text
>天凉了就想吃热的。
```

**$.visit.autumn[4][2]**

```text
汤面怎么样？
```

**$.visit.autumn[4][3]**

```text
>行，想想就饿了。
```

**$.visit.winter[0][0]**

```text
冬天的门口
```

**$.visit.winter[0][1]**

```text
>还是屋里暖和。
```

**$.visit.winter[0][2]**

```text
把门关好，风挺大。
```

**$.visit.winter[0][3]**

```text
>关好了，外面真冷。
```

**$.visit.winter[1][0]**

```text
毛衣的小静电
```

**$.visit.winter[1][1]**

```text
>哎，又被电了一下。
```

**$.visit.winter[1][2]**

```text
脱毛衣的时候？
```

**$.visit.winter[1][3]**

```text
>嗯，刚还听到啪一声。
```

**$.visit.winter[2][0]**

```text
暖一点的座位
```

**$.visit.winter[2][1]**

```text
>这靠垫我垫一下，有点凉。
```

**$.visit.winter[2][2]**

```text
拿吧，一会儿就暖了。
```

**$.visit.winter[2][3]**

```text
>好，我先坐这边。
```

**$.visit.winter[3][0]**

```text
把手收回来
```

**$.visit.winter[3][1]**

```text
>手一伸出来就冷。
```

**$.visit.winter[3][2]**

```text
放袖子里捂捂。
```

**$.visit.winter[3][3]**

```text
>嗯，我先暖一下再拿东西。
```

**$.visit.winter[4][0]**

```text
冬天的热气
```

**$.visit.winter[4][1]**

```text
>这水还冒热气呢。
```

**$.visit.winter[4][2]**

```text
刚倒的，别急着喝。
```

**$.visit.winter[4][3]**

```text
>好，先捧一会儿。
```

**$.visit.morning[0][0]**

```text
早上的问候
```

**$.visit.morning[0][1]**

```text
>早啊，没吵到你吧？
```

**$.visit.morning[0][2]**

```text
没有，起来一会儿了。
```

**$.visit.morning[0][3]**

```text
>那就好，我刚还怕来早了。
```

**$.visit.morning[1][0]**

```text
早餐别省
```

**$.visit.morning[1][1]**

```text
>早上吃东西没？
```

**$.visit.morning[1][2]**

```text
还没顾上，你呢？
```

**$.visit.morning[1][3]**

```text
>吃了点，你赶紧吃，别饿着。
```

**$.visit.morning[2][0]**

```text
刚开始的一天
```

**$.visit.morning[2][1]**

```text
>这会儿还早，路上没多少人。
```

**$.visit.morning[2][2]**

```text
你出门挺早啊。
```

**$.visit.morning[2][3]**

```text
>嗯，早点把事办完。
```

**$.visit.morning[3][0]**

```text
早上的清醒
```

**$.visit.morning[3][1]**

```text
>我脑子还有点迷糊。
```

**$.visit.morning[3][2]**

```text
没睡醒？
```

**$.visit.morning[3][3]**

```text
>有点，洗了脸好一些了。
```

**$.visit.noon[0][0]**

```text
中午的肚子
```

**$.visit.noon[0][1]**

```text
>到中午就不知道吃什么。
```

**$.visit.noon[0][2]**

```text
你现在想吃什么？
```

**$.visit.noon[0][3]**

```text
>都行，就是不想再凑合了。
```

**$.visit.noon[1][0]**

```text
午间的小歇
```

**$.visit.noon[1][1]**

```text
>坐下来就有点想打盹。
```

**$.visit.noon[1][2]**

```text
中午容易困。
```

**$.visit.noon[1][3]**

```text
>嗯，歇一小会儿再动。
```

**$.visit.noon[2][0]**

```text
一天的中场
```

**$.visit.noon[2][1]**

```text
>一上午怎么一下就没了。
```

**$.visit.noon[2][2]**

```text
忙完了？
```

**$.visit.noon[2][3]**

```text
>还差一点，歇会儿接着弄。
```

**$.visit.noon[3][0]**

```text
吃饱再打算
```

**$.visit.noon[3][1]**

```text
>先吃饭吧，我都饿了。
```

**$.visit.noon[3][2]**

```text
嗯，别等凉了。
```

**$.visit.noon[3][3]**

```text
>刚才顾着聊天忘看时间。
```

**$.visit.afternoon[0][0]**

```text
下午的松弛
```

**$.visit.afternoon[0][1]**

```text
>下午没事，就过来坐坐。
```

**$.visit.afternoon[0][2]**

```text
嗯，我也刚歇下来。
```

**$.visit.afternoon[0][3]**

```text
>来的时候还绕路看了家店。
```

**$.visit.afternoon[1][0]**

```text
小小的提神
```

**$.visit.afternoon[1][1]**

```text
>坐久了有点困。
```

**$.visit.afternoon[1][2]**

```text
起来活动一下？
```

**$.visit.afternoon[1][3]**

```text
>嗯，我伸伸腿。
```

**$.visit.afternoon[2][0]**

```text
慢慢挪的时间
```

**$.visit.afternoon[2][1]**

```text
>聊着聊着，都这个点了。
```

**$.visit.afternoon[2][2]**

```text
你有事要走？
```

**$.visit.afternoon[2][3]**

```text
>没有，就是看了一眼时间。
```

**$.visit.afternoon[3][0]**

```text
下午的小愿望
```

**$.visit.afternoon[3][1]**

```text
>今天下午不太想折腾了。
```

**$.visit.afternoon[3][2]**

```text
那就坐会儿。
```

**$.visit.afternoon[3][3]**

```text
>好，别给我拿东西了，够了。
```

**$.visit.evening[0][0]**

```text
晚些时候的问候
```

**$.visit.evening[0][1]**

```text
>外面天开始暗了。
```

**$.visit.evening[0][2]**

```text
我开个灯。
```

**$.visit.evening[0][3]**

```text
>嗯，刚才还没觉得。
```

**$.visit.evening[1][0]**

```text
晚饭的惦记
```

**$.visit.evening[1][1]**

```text
>差不多该想晚饭了。
```

**$.visit.evening[1][2]**

```text
你有什么想吃的？
```

**$.visit.evening[1][3]**

```text
>热乎点就行，今天想吃汤的。
```

**$.visit.evening[2][0]**

```text
今天的一件好事
```

**$.visit.evening[2][1]**

```text
>今天办了件挺顺的事。
```

**$.visit.evening[2][2]**

```text
什么事？
```

**$.visit.evening[2][3]**

```text
>本来以为得排队，去了就办上了。
```

**$.visit.evening[3][0]**

```text
晚一点的告别
```

**$.visit.evening[3][1]**

```text
>一会儿回去我走那条亮点的路。
```

**$.visit.evening[3][2]**

```text
好，别抄太暗的小道。
```

**$.visit.evening[3][3]**

```text
>嗯，没差几步。
```

**$.visit.night[0][0]**

```text
夜里轻声说
```

**$.visit.night[0][1]**

```text
>咱俩小点声吧，有点晚了。
```

**$.visit.night[0][2]**

```text
嗯，刚才说着忘了。
```

**$.visit.night[0][3]**

```text
>我把这句讲完就停。
```

**$.visit.night[1][0]**

```text
该道晚安了
```

**$.visit.night[1][1]**

```text
>不聊了吧，别耽误你睡。
```

**$.visit.night[1][2]**

```text
好，剩下明天说。
```

**$.visit.night[1][3]**

```text
>行，你早点休息。
```

**$.visit.night[2][0]**

```text
给明天留话
```

**$.visit.night[2][1]**

```text
>这事明天再说吧。
```

**$.visit.night[2][2]**

```text
好，记得提醒我。
```

**$.visit.night[2][3]**

```text
>我先记一下，明天问你。
```

**$.visit.night[3][0]**

```text
休息的提醒
```

**$.visit.night[3][1]**

```text
>你是不是困了？
```

**$.visit.night[3][2]**

```text
有点，刚打了个哈欠。
```

**$.visit.night[3][3]**

```text
>那别撑着了，赶紧去睡。
```

**$.discovery.慢热[0]**

```text
会先听别人说，再一点点讲自己的事
```

**$.discovery.慢热[1]**

```text
熟悉以后才更愿意主动分享，不是没话可说
```

**$.discovery.慢热[2]**

```text
需要留一点思考的空隙，说慢一点反倒更自在
```

**$.discovery.慢热[3]**

```text
安静的时候也会认真记住别人说的小事
```

**$.discovery.外向[0]**

```text
常会先打招呼，也愿意分享路上的小事
```

**$.discovery.外向[1]**

```text
看到有趣的东西，很自然就会想到找人聊聊
```

**$.discovery.外向[2]**

```text
聊天热闹时也会留意别人有没有接上话
```

**$.discovery.外向[3]**

```text
愿意先迈出一步，让生疏的见面轻松一些
```

**$.discovery.随性[0]**

```text
会给安排留点空白，也喜欢临时冒出的小主意
```

**$.discovery.随性[1]**

```text
有时先试试看，再慢慢调整方向
```

**$.discovery.随性[2]**

```text
不急着把相处排满，更喜欢留出自然发生的余地
```

**$.discovery.随性[3]**

```text
做事有自己的松弛节奏，但重要的约定也会认真听
```

**$.discovery.周到[0]**

```text
会提前问清是否方便，给别人留下选择的余地
```

**$.discovery.周到[1]**

```text
记得一些不起眼的小习惯，并悄悄照顾到
```

**$.discovery.周到[2]**

```text
安排事情时会多想一步，免得别人为难
```

**$.discovery.周到[3]**

```text
不只关心事情能不能做，也会关心别人舒不舒服
```

**$.discovery.沉稳[0]**

```text
会先理清事情，再决定怎样回应
```

**$.discovery.沉稳[1]**

```text
心里有感觉，也习惯慢慢消化后再说
```

**$.discovery.沉稳[2]**

```text
碰到不顺心时，往往先稳住自己再找办法
```

**$.discovery.沉稳[3]**

```text
看着不着急，其实会认真把话听完整
```

**$.discovery.敏感[0]**

```text
容易注意到语气和神色里的小变化
```

**$.discovery.敏感[1]**

```text
会被很小的好意打动，并把它记很久
```

**$.discovery.敏感[2]**

```text
感觉来得细，也越来越愿意把感受说清楚
```

**$.discovery.敏感[3]**

```text
能留意别人没说出口的不自在，也希望被温柔确认
```

**$.discovery.随和[0]**

```text
会在热闹和安静之间找舒服的节奏
```

**$.discovery.随和[1]**

```text
愿意主动接话，也不强迫每段沉默都被填满
```

**$.discovery.随和[2]**

```text
会看彼此的状态调整聊天方式
```

**$.discovery.随和[3]**

```text
既能一起热闹，也能安心地各待一会儿
```

**$.discovery.灵活[0]**

```text
既愿意提前商量，也能接受临时调整
```

**$.discovery.灵活[1]**

```text
会认真留住重要约定，不把每个细节都钉死
```

**$.discovery.灵活[2]**

```text
能在计划和变化之间找比较舒服的办法
```

**$.discovery.灵活[3]**

```text
做事不只照一种方式，会看眼前情况慢慢调整
```

**$.discovery.平和[0]**

```text
能感觉到情绪，也愿意给自己时间消化
```

**$.discovery.平和[1]**

```text
会表达在意，也能慢慢听别人的理由
```

**$.discovery.平和[2]**

```text
不急着压下感受，也不让每个感觉都替自己做决定
```

**$.discovery.平和[3]**

```text
遇到小波折时常会先停一下，再继续往前
```

**$.early.text[0].title**

```text
初识·名字对上了
```

**$.early.text[0].lines[0]**

```text
>你好，是刚才遇到的那位吗？
```

**$.early.text[0].lines[1]**

```text
对，是我。
```

**$.early.text[0].lines[2]**

```text
>好，没加错就行。
```

**$.early.text[0].lines[3]**

```text
嗯，我也存上了。
```

**$.early.text[1].title**

```text
初识·先留个备注
```

**$.early.text[1].lines[0]**

```text
>我把你名字存上了。
```

**$.early.text[1].lines[1]**

```text
我也刚存。
```

**$.early.text[1].lines[2]**

```text
>好，下次找你就方便了。
```

**$.early.text[1].lines[3]**

```text
嗯。
```

**$.early.text[2].title**

```text
初识·不知道怎么开头
```

**$.early.text[2].lines[0]**

```text
>你好啊。
```

**$.early.text[2].lines[1]**

```text
你好。
```

**$.early.text[2].lines[2]**

```text
>突然不知道说什么了。
```

**$.early.text[2].lines[3]**

```text
哈哈，那先打个招呼。
```

**$.early.text[3].title**

```text
初识·消息发出去
```

**$.early.text[3].lines[0]**

```text
>刚那条是不是没发出去？
```

**$.early.text[3].lines[1]**

```text
这条收到了。
```

**$.early.text[3].lines[2]**

```text
>哦，我还以为网断了。
```

**$.early.text[3].lines[3]**

```text
我刚没看手机。
```

**$.early.text[4].title**

```text
初识·简单问声好
```

**$.early.text[4].lines[0]**

```text
>在忙吗？
```

**$.early.text[4].lines[1]**

```text
这会儿还好，你呢？
```

**$.early.text[4].lines[2]**

```text
>也是，刚空下来。
```

**$.early.text[4].lines[3]**

```text
哦，你说。
```

**$.early.text[5].title**

```text
初识·不是群发
```

**$.early.text[5].lines[0]**

```text
>你好，这条不是群发啊。
```

**$.early.text[5].lines[1]**

```text
看出来了。
```

**$.early.text[5].lines[2]**

```text
>开头打得跟通知似的。
```

**$.early.text[5].lines[3]**

```text
哈哈，我差点回个收到。
```

**$.early.text[6].title**

```text
初识·头像认人
```

**$.early.text[6].lines[0]**

```text
>刚才差点没认出你头像。
```

**$.early.text[6].lines[1]**

```text
和本人差挺多？
```

**$.early.text[6].lines[2]**

```text
>有点，我又看了一眼名字。
```

**$.early.text[6].lines[3]**

```text
那我备注写清楚点。
```

**$.early.text[7].title**

```text
初识·字打慢一点
```

**$.early.text[7].lines[0]**

```text
>我打字慢一点啊。
```

**$.early.text[7].lines[1]**

```text
没事，不急。
```

**$.early.text[7].lines[2]**

```text
>刚才老按错。
```

**$.early.text[7].lines[3]**

```text
看得懂，你发吧。
```

**$.early.text[8].title**

```text
初识·想起刚才
```

**$.early.text[8].lines[0]**

```text
>刚说的那个地方叫什么来着？
```

**$.early.text[8].lines[1]**

```text
我发你看看。
```

**$.early.text[8].lines[2]**

```text
>谢谢，刚没记住。
```

**$.early.text[8].lines[3]**

```text
不客气。
```

**$.early.text[9].title**

```text
初识·不必立即回
```

**$.early.text[9].lines[0]**

```text
>你忙的话晚点回。
```

**$.early.text[9].lines[1]**

```text
好，我一会儿看。
```

**$.early.text[9].lines[2]**

```text
>嗯，不是什么急事。
```

**$.early.text[9].lines[3]**

```text
行。
```

**$.early.text[10].title**

```text
初识·打错的字
```

**$.early.text[10].lines[0]**

```text
>上面有个字打错了。
```

**$.early.text[10].lines[1]**

```text
看懂了。
```

**$.early.text[10].lines[2]**

```text
>好，懒得撤回了。
```

**$.early.text[10].lines[3]**

```text
嗯，没事。
```

**$.early.text[11].title**

```text
初识·谢谢提醒
```

**$.early.text[11].lines[0]**

```text
>刚才谢谢你提醒。
```

**$.early.text[11].lines[1]**

```text
没事，顺便的。
```

**$.early.text[11].lines[2]**

```text
>不然我真没看见。
```

**$.early.text[11].lines[3]**

```text
还好没掉。
```

**$.early.text[12].title**

```text
初识·聊过一点点
```

**$.early.text[12].lines[0]**

```text
>刚才都没顾上多说两句。
```

**$.early.text[12].lines[1]**

```text
嗯，有点赶。
```

**$.early.text[12].lines[2]**

```text
>下回碰见再聊。
```

**$.early.text[12].lines[3]**

```text
好啊。
```

**$.early.text[13].title**

```text
初识·表情的选择
```

**$.early.text[13].lines[0]**

```text
>本来想发个表情，挑半天。
```

**$.early.text[13].lines[1]**

```text
随便发一个就行。
```

**$.early.text[13].lines[2]**

```text
>结果越挑越不知道发哪个。
```

**$.early.text[13].lines[3]**

```text
哈哈，先不挑了。
```

**$.early.text[14].title**

```text
初识·有没有打扰
```

**$.early.text[14].lines[0]**

```text
>这会儿发消息没打扰吧？
```

**$.early.text[14].lines[1]**

```text
没有，你说。
```

**$.early.text[14].lines[2]**

```text
>好，我就问一下。
```

**$.early.text[14].lines[3]**

```text
嗯。
```

**$.early.text[15].title**

```text
初识·记性有限
```

**$.early.text[15].lines[0]**

```text
>我认人不太行，下回别见怪。
```

**$.early.text[15].lines[1]**

```text
没事，叫我一声就行。
```

**$.early.text[15].lines[2]**

```text
>嗯，名字记着了。
```

**$.early.text[15].lines[3]**

```text
好，下次见。
```

**$.early.text[16].title**

```text
初识·短短的近况
```

**$.early.text[16].lines[0]**

```text
>最近怎么样？
```

**$.early.text[16].lines[1]**

```text
还行，你呢？
```

**$.early.text[16].lines[2]**

```text
>也差不多。
```

**$.early.text[16].lines[3]**

```text
嗯，没什么新鲜事。
```

**$.early.text[17].title**

```text
初识·共同的话题
```

**$.early.text[17].lines[0]**

```text
>也没什么事，就是问个好。
```

**$.early.text[17].lines[1]**

```text
你好啊。
```

**$.early.text[17].lines[2]**

```text
>那我先去忙了。
```

**$.early.text[17].lines[3]**

```text
好，回头聊。
```

**$.early.text[18].title**

```text
初识·刚加上的人
```

**$.early.text[18].lines[0]**

```text
>你好，我是{朋友}。
```

**$.early.text[18].lines[1]**

```text
你好，刚给你备注上。
```

**$.early.text[18].lines[2]**

```text
>好嘞，那我先去忙了。
```

**$.early.text[18].lines[3]**

```text
嗯，回头聊。
```

**$.early.text[19].title**

```text
初识·下次再聊
```

**$.early.text[19].lines[0]**

```text
>我先去弄点事。
```

**$.early.text[19].lines[1]**

```text
好，你忙。
```

**$.early.text[19].lines[2]**

```text
>回头再聊。
```

**$.early.text[19].lines[3]**

```text
嗯，拜拜。
```

**$.early.call[0].title**

```text
初识·声音认出来了
```

**$.early.call[0].lines[0]**

```text
>喂，我是{朋友}，刚才加的。
```

**$.early.call[0].lines[1]**

```text
听出来了，你好。
```

**$.early.call[0].lines[2]**

```text
>我还怕你没存号码。
```

**$.early.call[0].lines[3]**

```text
存了，刚看见名字。
```

**$.early.call[1].title**

```text
初识·先问方便
```

**$.early.call[1].lines[0]**

```text
>现在方便说话吗？
```

**$.early.call[1].lines[1]**

```text
方便，你说。
```

**$.early.call[1].lines[2]**

```text
>我就问两句。
```

**$.early.call[1].lines[3]**

```text
嗯。
```

**$.early.call[2].title**

```text
初识·第一次拨通
```

**$.early.call[2].lines[0]**

```text
>喂，能听见吧？
```

**$.early.call[2].lines[1]**

```text
能，挺清楚的。
```

**$.early.call[2].lines[2]**

```text
>好，我刚还以为没拨出去。
```

**$.early.call[2].lines[3]**

```text
接到了。
```

**$.early.call[3].title**

```text
初识·不是急事
```

**$.early.call[3].lines[0]**

```text
>没急事，打个招呼。
```

**$.early.call[3].lines[1]**

```text
嗯，你好。
```

**$.early.call[3].lines[2]**

```text
>突然打过来，没打扰吧？
```

**$.early.call[3].lines[3]**

```text
没有，刚好有空。
```

**$.early.call[4].title**

```text
初识·确认那个地方
```

**$.early.call[4].lines[0]**

```text
>刚说那个地方怎么走来着？
```

**$.early.call[4].lines[1]**

```text
我找找地图，发给你吧。
```

**$.early.call[4].lines[2]**

```text
>好，我光听方向有点记不住。
```

**$.early.call[4].lines[3]**

```text
嗯，等一下。
```

**$.early.call[5].title**

```text
初识·声音有点小
```

**$.early.call[5].lines[0]**

```text
>你刚才那句没听清。
```

**$.early.call[5].lines[1]**

```text
我大点声，这样呢？
```

**$.early.call[5].lines[2]**

```text
>这回听见了。
```

**$.early.call[5].lines[3]**

```text
你刚问什么来着？
```

**$.early.call[6].title**

```text
初识·一下安静
```

**$.early.call[6].lines[0]**

```text
>喂？
```

**$.early.call[6].lines[1]**

```text
嗯？
```

**$.early.call[6].lines[2]**

```text
>我还以为断了。
```

**$.early.call[6].lines[3]**

```text
没断，我刚也没说话。
```

**$.early.call[7].title**

```text
初识·叫名字有点生
```

**$.early.call[7].lines[0]**

```text
>你名字最后那个字，我没叫错吧？
```

**$.early.call[7].lines[1]**

```text
没错，就是那个音。
```

**$.early.call[7].lines[2]**

```text
>好，我还怕念错。
```

**$.early.call[7].lines[3]**

```text
没事。
```

**$.early.call[8].title**

```text
初识·短短的问候
```

**$.early.call[8].lines[0]**

```text
>后来没耽误你吧？
```

**$.early.call[8].lines[1]**

```text
没有，赶上了。
```

**$.early.call[8].lines[2]**

```text
>那就好，我刚想起来。
```

**$.early.call[8].lines[3]**

```text
嗯，谢谢啊。
```

**$.early.call[9].title**

```text
初识·手上在忙
```

**$.early.call[9].lines[0]**

```text
>你那边什么声音？
```

**$.early.call[9].lines[1]**

```text
手上在收点东西。
```

**$.early.call[9].lines[2]**

```text
>那你先忙，不急。
```

**$.early.call[9].lines[3]**

```text
没事，你说就行。
```

**$.early.call[10].title**

```text
初识·不用站着接
```

**$.early.call[10].lines[0]**

```text
>我一接电话就爱站起来。
```

**$.early.call[10].lines[1]**

```text
你刚在走路？
```

**$.early.call[10].lines[2]**

```text
>没有，在屋里转。
```

**$.early.call[10].lines[3]**

```text
怪不得听着有脚步声。
```

**$.early.call[11].title**

```text
初识·没准备话题
```

**$.early.call[11].lines[0]**

```text
>我打过来才忘了想问什么。
```

**$.early.call[11].lines[1]**

```text
想起来再说也行。
```

**$.early.call[11].lines[2]**

```text
>等会儿……哦，想起来了。
```

**$.early.call[11].lines[3]**

```text
什么？
```

**$.early.call[12].title**

```text
初识·稍微客气
```

**$.early.call[12].lines[0]**

```text
>我是不是太客气了？
```

**$.early.call[12].lines[1]**

```text
还好。
```

**$.early.call[12].lines[2]**

```text
>每句都想加个不好意思。
```

**$.early.call[12].lines[3]**

```text
哈哈，不用每句都加。
```

**$.early.call[13].title**

```text
初识·怕认错人
```

**$.early.call[13].lines[0]**

```text
>我又看了眼号码才敢打。
```

**$.early.call[13].lines[1]**

```text
怕认错人？
```

**$.early.call[13].lines[2]**

```text
>嗯，还好没错。
```

**$.early.call[13].lines[3]**

```text
没错，是我。
```

**$.early.call[14].title**

```text
初识·一句感谢
```

**$.early.call[14].lines[0]**

```text
>刚才走得急，都没跟你说谢谢。
```

**$.early.call[14].lines[1]**

```text
没事，不用专门打来。
```

**$.early.call[14].lines[2]**

```text
>已经拨出去了，顺便说一句。
```

**$.early.call[14].lines[3]**

```text
好，收到了。
```

**$.early.call[15].title**

```text
初识·先聊小事
```

**$.early.call[15].lines[0]**

```text
>我想问个小事。
```

**$.early.call[15].lines[1]**

```text
你说。
```

**$.early.call[15].lines[2]**

```text
>你刚提那家店，贵不贵？
```

**$.early.call[15].lines[3]**

```text
我也是路过，下回看看。
```

**$.early.call[16].title**

```text
初识·停顿没关系
```

**$.early.call[16].lines[0]**

```text
>等一下，我刚没反应过来。
```

**$.early.call[16].lines[1]**

```text
嗯，我再说一遍？
```

**$.early.call[16].lines[2]**

```text
>好，麻烦你。
```

**$.early.call[16].lines[3]**

```text
没事。
```

**$.early.call[17].title**

```text
初识·留点下次的话
```

**$.early.call[17].lines[0]**

```text
>那我就先不多问了。
```

**$.early.call[17].lines[1]**

```text
好，下回再说。
```

**$.early.call[17].lines[2]**

```text
>嗯，有空碰见再聊。
```

**$.early.call[17].lines[3]**

```text
行。
```

**$.early.call[18].title**

```text
初识·开头比想象难
```

**$.early.call[18].lines[0]**

```text
>刚才拨号前想问的，突然忘了。
```

**$.early.call[18].lines[1]**

```text
要不你想起来再找我？
```

**$.early.call[18].lines[2]**

```text
>好，不占你时间了。
```

**$.early.call[18].lines[3]**

```text
嗯，回头聊。
```

**$.early.call[19].title**

```text
初识·短通话收尾
```

**$.early.call[19].lines[0]**

```text
>那先这样吧。
```

**$.early.call[19].lines[1]**

```text
好，我也去忙了。
```

**$.early.call[19].lines[2]**

```text
>下次有空再聊。
```

**$.early.call[19].lines[3]**

```text
嗯，拜拜。
```

**$.early.video[0].title**

```text
初识·镜头对上了
```

**$.early.video[0].lines[0]**

```text
>能看见我吗？
```

**$.early.video[0].lines[1]**

```text
能，看见了。
```

**$.early.video[0].lines[2]**

```text
>我先把手机放稳。
```

**$.early.video[0].lines[3]**

```text
好。
```

**$.early.video[1].title**

```text
初识·第一次开视频
```

**$.early.video[1].lines[0]**

```text
>我该看镜头还是看你啊？
```

**$.early.video[1].lines[1]**

```text
看屏幕就行。
```

**$.early.video[1].lines[2]**

```text
>哦，刚才老看自己。
```

**$.early.video[1].lines[3]**

```text
我也差点。
```

**$.early.video[2].title**

```text
初识·还没认熟
```

**$.early.video[2].lines[0]**

```text
>我又看了遍名字，怕认错。
```

**$.early.video[2].lines[1]**

```text
没错，是我。
```

**$.early.video[2].lines[2]**

```text
>好，画面有点小。
```

**$.early.video[2].lines[3]**

```text
现在能看清吗？
```

**$.early.video[3].title**

```text
初识·镜头太近
```

**$.early.video[3].lines[0]**

```text
>是不是离太近了？
```

**$.early.video[3].lines[1]**

```text
有点，现在这样正好。
```

**$.early.video[3].lines[2]**

```text
>刚只看见一只眼睛吧。
```

**$.early.video[3].lines[3]**

```text
差不多，吓我一跳。
```

**$.early.video[4].title**

```text
初识·手机要站稳
```

**$.early.video[4].lines[0]**

```text
>这手机老往下滑。
```

**$.early.video[4].lines[1]**

```text
后面垫个东西？
```

**$.early.video[4].lines[2]**

```text
>好了，这回不动了。
```

**$.early.video[4].lines[3]**

```text
嗯，看得清。
```

**$.early.video[5].title**

```text
初识·不用看屋子
```

**$.early.video[5].lines[0]**

```text
>我这边有点乱，不转镜头了。
```

**$.early.video[5].lines[1]**

```text
没事，不用转。
```

**$.early.video[5].lines[2]**

```text
>下回收拾完再说。
```

**$.early.video[5].lines[3]**

```text
嗯。
```

**$.early.video[6].title**

```text
初识·想问句好
```

**$.early.video[6].lines[0]**

```text
>就问个好，没别的事。
```

**$.early.video[6].lines[1]**

```text
你好啊。
```

**$.early.video[6].lines[2]**

```text
>突然视频是不是有点怪。
```

**$.early.video[6].lines[3]**

```text
没事，已经接了。
```

**$.early.video[7].title**

```text
初识·声音和画面
```

**$.early.video[7].lines[0]**

```text
>刚看见人还有点不习惯。
```

**$.early.video[7].lines[1]**

```text
你刚好半天没看镜头。
```

**$.early.video[7].lines[2]**

```text
>是，我在看画面卡没卡。
```

**$.early.video[7].lines[3]**

```text
没卡，挺清楚。
```

**$.early.video[8].title**

```text
初识·先别问太多
```

**$.early.video[8].lines[0]**

```text
>刚才想问你个事。
```

**$.early.video[8].lines[1]**

```text
什么？
```

**$.early.video[8].lines[2]**

```text
>等我把手机放好，拿着晃。
```

**$.early.video[8].lines[3]**

```text
好，我等下。
```

**$.early.video[9].title**

```text
初识·画面卡了一下
```

**$.early.video[9].lines[0]**

```text
>你刚才不动了。
```

**$.early.video[9].lines[1]**

```text
我本来就没动啊。
```

**$.early.video[9].lines[2]**

```text
>哦，我以为卡了。
```

**$.early.video[9].lines[3]**

```text
你那边我看着还挺顺。
```

**$.early.video[10].title**

```text
初识·和本人对上
```

**$.early.video[10].lines[0]**

```text
>这回名字和人总算对上了。
```

**$.early.video[10].lines[1]**

```text
下回认得出来吧？
```

**$.early.video[10].lines[2]**

```text
>应该吧，你再打个招呼。
```

**$.early.video[10].lines[3]**

```text
行。
```

**$.early.video[11].title**

```text
初识·镜头的角度
```

**$.early.video[11].lines[0]**

```text
>画面是不是有点歪？
```

**$.early.video[11].lines[1]**

```text
有一点，不过看得见。
```

**$.early.video[11].lines[2]**

```text
>我挪一下。好了？
```

**$.early.video[11].lines[3]**

```text
好了。
```

**$.early.video[12].title**

```text
初识·只聊一小会儿
```

**$.early.video[12].lines[0]**

```text
>我就聊一会儿啊。
```

**$.early.video[12].lines[1]**

```text
好，我也还有点事。
```

**$.early.video[12].lines[2]**

```text
>不用一直盯着屏幕。
```

**$.early.video[12].lines[3]**

```text
嗯，你说吧。
```

**$.early.video[13].title**

```text
初识·背景里有响声
```

**$.early.video[13].lines[0]**

```text
>你那儿刚什么响了一下？
```

**$.early.video[13].lines[1]**

```text
我放了个杯子。
```

**$.early.video[13].lines[2]**

```text
>哦，我以为有电话进来。
```

**$.early.video[13].lines[3]**

```text
没有，还连着呢。
```

**$.early.video[14].title**

```text
初识·互相有点生
```

**$.early.video[14].lines[0]**

```text
>视频比打字还不知道说什么。
```

**$.early.video[14].lines[1]**

```text
那先聊两句就挂？
```

**$.early.video[14].lines[2]**

```text
>也行，我先试试会不会用。
```

**$.early.video[14].lines[3]**

```text
声音画面都挺好的。
```

**$.early.video[15].title**

```text
初识·手机别拿累
```

**$.early.video[15].lines[0]**

```text
>举着手机累不累？
```

**$.early.video[15].lines[1]**

```text
有点，我找地方放一下。
```

**$.early.video[15].lines[2]**

```text
>嗯，我也靠在东西上了。
```

**$.early.video[15].lines[3]**

```text
好了。
```

**$.early.video[16].title**

```text
初识·比照片清楚
```

**$.early.video[16].lines[0]**

```text
>视频比头像清楚多了。
```

**$.early.video[16].lines[1]**

```text
头像太小了。
```

**$.early.video[16].lines[2]**

```text
>刚才看名字才认出是你。
```

**$.early.video[16].lines[3]**

```text
嗯，下次见面应该好认点。
```

**$.early.video[17].title**

```text
初识·打个招呼就好
```

**$.early.video[17].lines[0]**

```text
>没打扰你吧？
```

**$.early.video[17].lines[1]**

```text
这会儿没有。
```

**$.early.video[17].lines[2]**

```text
>那我就简单问两句。
```

**$.early.video[17].lines[3]**

```text
你说。
```

**$.early.video[18].title**

```text
初识·不习惯出镜
```

**$.early.video[18].lines[0]**

```text
>我平时不怎么开视频。
```

**$.early.video[18].lines[1]**

```text
那我声音听得清吗？
```

**$.early.video[18].lines[2]**

```text
>听得清，就是不知道手机往哪儿放。
```

**$.early.video[18].lines[3]**

```text
靠着放就行。
```

**$.early.video[19].title**

```text
初识·关镜头之前
```

**$.early.video[19].lines[0]**

```text
>那我先关啦。
```

**$.early.video[19].lines[1]**

```text
好，回头聊。
```

**$.early.video[19].lines[2]**

```text
>是点红的这个吧？
```

**$.early.video[19].lines[3]**

```text
对，挂断就行。
```

**$.earlyMeet.front[0][0]**

```text
路边的招呼
```

**$.earlyMeet.front[0][1]**

```text
>你好，经常从这边走吗？
```

**$.earlyMeet.front[0][2]**

```text
偶尔，你呢？
```

**$.earlyMeet.front[0][3]**

```text
>我也偶尔。那，路上慢点。
```

**$.earlyMeet.front[1][0]**

```text
门口认人
```

**$.earlyMeet.front[1][1]**

```text
>刚才好像在附近见过你。
```

**$.earlyMeet.front[1][2]**

```text
可能吧，我有时会路过。
```

**$.earlyMeet.front[1][3]**

```text
>哦，那我没完全认错。
```

**$.earlyMeet.front[2][0]**

```text
路边·简单问个路
```

**$.earlyMeet.front[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.front[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.front[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.front[3][0]**

```text
路边·没有挡着吧
```

**$.earlyMeet.front[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.front[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.front[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.front[4][0]**

```text
路边·想打个招呼
```

**$.earlyMeet.front[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.front[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.front[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.front[5][0]**

```text
路边·话有点少
```

**$.earlyMeet.front[5][1]**

```text
>你好啊。
```

**$.earlyMeet.front[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.front[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.front[6][0]**

```text
路边·先认个脸
```

**$.earlyMeet.front[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.front[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.front[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.front[7][0]**

```text
路边·有点生疏
```

**$.earlyMeet.front[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.front[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.front[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.front[8][0]**

```text
路边·不着急聊满
```

**$.earlyMeet.front[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.front[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.front[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.front[9][0]**

```text
路边·顺手提醒
```

**$.earlyMeet.front[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.front[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.front[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.front[10][0]**

```text
路边·先确认一下
```

**$.earlyMeet.front[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.front[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.front[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.front[11][0]**

```text
路边·把名字听清
```

**$.earlyMeet.front[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.front[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.front[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.front[12][0]**

```text
路边·有点认生
```

**$.earlyMeet.front[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.front[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.front[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.front[13][0]**

```text
路边·先看看周围
```

**$.earlyMeet.front[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.front[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.front[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.front[14][0]**

```text
路边·没听清一句
```

**$.earlyMeet.front[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.front[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.front[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.front[15][0]**

```text
路边·不想挡着你
```

**$.earlyMeet.front[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.front[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.front[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.front[16][0]**

```text
路边·把东西收好
```

**$.earlyMeet.front[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.front[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.front[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.front[17][0]**

```text
路边·说话有点轻
```

**$.earlyMeet.front[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.front[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.front[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.front[18][0]**

```text
路边·只是路过
```

**$.earlyMeet.front[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.front[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.front[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.front[19][0]**

```text
路边·不太会找话题
```

**$.earlyMeet.front[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.front[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.front[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.front[20][0]**

```text
路边·认一认方向
```

**$.earlyMeet.front[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.front[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.front[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.front[21][0]**

```text
路边·不急着问
```

**$.earlyMeet.front[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.front[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.front[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.front[22][0]**

```text
路边·名字先记着
```

**$.earlyMeet.front[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.front[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.front[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.front[23][0]**

```text
路边·开头忘词
```

**$.earlyMeet.front[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.front[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.front[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.front[24][0]**

```text
路边·眼神对上
```

**$.earlyMeet.front[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.front[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.front[24][3]**

```text
>你好啊。
```

**$.earlyMeet.front[25][0]**

```text
路边·差点碰到
```

**$.earlyMeet.front[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.front[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.front[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.front[26][0]**

```text
路边·站稳再聊
```

**$.earlyMeet.front[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.front[26][2]**

```text
好，不急。
```

**$.earlyMeet.front[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.front[27][0]**

```text
路边·没什么正事
```

**$.earlyMeet.front[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.front[27][2]**

```text
你好。
```

**$.earlyMeet.front[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.front[28][0]**

```text
路边·先不多打扰
```

**$.earlyMeet.front[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.front[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.front[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.front[29][0]**

```text
路边·留到下次
```

**$.earlyMeet.front[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.front[29][2]**

```text
好，下次见。
```

**$.earlyMeet.front[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.park_gazebo[0][0]**

```text
凉亭的空位
```

**$.earlyMeet.park_gazebo[0][1]**

```text
>这里还有人坐吗？
```

**$.earlyMeet.park_gazebo[0][2]**

```text
没有，你坐吧。
```

**$.earlyMeet.park_gazebo[0][3]**

```text
>谢谢，我就歇一会儿。
```

**$.earlyMeet.park_gazebo[1][0]**

```text
亭边问路
```

**$.earlyMeet.park_gazebo[1][1]**

```text
>你好，沿着这边能走到湖边吗？
```

**$.earlyMeet.park_gazebo[1][2]**

```text
应该能，我也是刚走过来。
```

**$.earlyMeet.park_gazebo[1][3]**

```text
>好，谢谢你。
```

**$.earlyMeet.park_gazebo[2][0]**

```text
凉亭·简单问个路
```

**$.earlyMeet.park_gazebo[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.park_gazebo[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.park_gazebo[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.park_gazebo[3][0]**

```text
凉亭·没有挡着吧
```

**$.earlyMeet.park_gazebo[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.park_gazebo[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.park_gazebo[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.park_gazebo[4][0]**

```text
凉亭·想打个招呼
```

**$.earlyMeet.park_gazebo[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.park_gazebo[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.park_gazebo[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.park_gazebo[5][0]**

```text
凉亭·话有点少
```

**$.earlyMeet.park_gazebo[5][1]**

```text
>你好啊。
```

**$.earlyMeet.park_gazebo[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.park_gazebo[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.park_gazebo[6][0]**

```text
凉亭·先认个脸
```

**$.earlyMeet.park_gazebo[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.park_gazebo[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.park_gazebo[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.park_gazebo[7][0]**

```text
凉亭·有点生疏
```

**$.earlyMeet.park_gazebo[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.park_gazebo[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.park_gazebo[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.park_gazebo[8][0]**

```text
凉亭·不着急聊满
```

**$.earlyMeet.park_gazebo[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.park_gazebo[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.park_gazebo[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.park_gazebo[9][0]**

```text
凉亭·顺手提醒
```

**$.earlyMeet.park_gazebo[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.park_gazebo[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.park_gazebo[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.park_gazebo[10][0]**

```text
凉亭·先确认一下
```

**$.earlyMeet.park_gazebo[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.park_gazebo[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.park_gazebo[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.park_gazebo[11][0]**

```text
凉亭·把名字听清
```

**$.earlyMeet.park_gazebo[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.park_gazebo[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.park_gazebo[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.park_gazebo[12][0]**

```text
凉亭·有点认生
```

**$.earlyMeet.park_gazebo[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.park_gazebo[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.park_gazebo[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.park_gazebo[13][0]**

```text
凉亭·先看看周围
```

**$.earlyMeet.park_gazebo[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.park_gazebo[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.park_gazebo[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.park_gazebo[14][0]**

```text
凉亭·没听清一句
```

**$.earlyMeet.park_gazebo[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.park_gazebo[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.park_gazebo[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.park_gazebo[15][0]**

```text
凉亭·不想挡着你
```

**$.earlyMeet.park_gazebo[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.park_gazebo[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.park_gazebo[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.park_gazebo[16][0]**

```text
凉亭·把东西收好
```

**$.earlyMeet.park_gazebo[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.park_gazebo[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.park_gazebo[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.park_gazebo[17][0]**

```text
凉亭·说话有点轻
```

**$.earlyMeet.park_gazebo[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.park_gazebo[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.park_gazebo[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.park_gazebo[18][0]**

```text
凉亭·只是路过
```

**$.earlyMeet.park_gazebo[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.park_gazebo[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.park_gazebo[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.park_gazebo[19][0]**

```text
凉亭·不太会找话题
```

**$.earlyMeet.park_gazebo[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.park_gazebo[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.park_gazebo[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.park_gazebo[20][0]**

```text
凉亭·认一认方向
```

**$.earlyMeet.park_gazebo[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.park_gazebo[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.park_gazebo[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.park_gazebo[21][0]**

```text
凉亭·不急着问
```

**$.earlyMeet.park_gazebo[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.park_gazebo[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.park_gazebo[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.park_gazebo[22][0]**

```text
凉亭·名字先记着
```

**$.earlyMeet.park_gazebo[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.park_gazebo[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.park_gazebo[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.park_gazebo[23][0]**

```text
凉亭·开头忘词
```

**$.earlyMeet.park_gazebo[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.park_gazebo[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.park_gazebo[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.park_gazebo[24][0]**

```text
凉亭·眼神对上
```

**$.earlyMeet.park_gazebo[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.park_gazebo[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.park_gazebo[24][3]**

```text
>你好啊。
```

**$.earlyMeet.park_gazebo[25][0]**

```text
凉亭·差点碰到
```

**$.earlyMeet.park_gazebo[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.park_gazebo[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.park_gazebo[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.park_gazebo[26][0]**

```text
凉亭·站稳再聊
```

**$.earlyMeet.park_gazebo[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.park_gazebo[26][2]**

```text
好，不急。
```

**$.earlyMeet.park_gazebo[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.park_gazebo[27][0]**

```text
凉亭·没什么正事
```

**$.earlyMeet.park_gazebo[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.park_gazebo[27][2]**

```text
你好。
```

**$.earlyMeet.park_gazebo[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.park_gazebo[28][0]**

```text
凉亭·先不多打扰
```

**$.earlyMeet.park_gazebo[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.park_gazebo[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.park_gazebo[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.park_gazebo[29][0]**

```text
凉亭·留到下次
```

**$.earlyMeet.park_gazebo[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.park_gazebo[29][2]**

```text
好，下次见。
```

**$.earlyMeet.park_gazebo[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.park_lakeside[0][0]**

```text
步道借过
```

**$.earlyMeet.park_lakeside[0][1]**

```text
>不好意思，从这边过去可以吗？
```

**$.earlyMeet.park_lakeside[0][2]**

```text
可以，我往旁边让点。
```

**$.earlyMeet.park_lakeside[0][3]**

```text
>谢谢。这里还挺好走的。
```

**$.earlyMeet.park_lakeside[1][0]**

```text
湖边搭话
```

**$.earlyMeet.park_lakeside[1][1]**

```text
>这里看水还挺清楚的。
```

**$.earlyMeet.park_lakeside[1][2]**

```text
嗯，站这边视野好一点。
```

**$.earlyMeet.park_lakeside[1][3]**

```text
>我刚发现。
```

**$.earlyMeet.park_lakeside[2][0]**

```text
湖边·简单问个路
```

**$.earlyMeet.park_lakeside[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.park_lakeside[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.park_lakeside[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.park_lakeside[3][0]**

```text
湖边·没有挡着吧
```

**$.earlyMeet.park_lakeside[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.park_lakeside[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.park_lakeside[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.park_lakeside[4][0]**

```text
湖边·想打个招呼
```

**$.earlyMeet.park_lakeside[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.park_lakeside[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.park_lakeside[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.park_lakeside[5][0]**

```text
湖边·话有点少
```

**$.earlyMeet.park_lakeside[5][1]**

```text
>你好啊。
```

**$.earlyMeet.park_lakeside[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.park_lakeside[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.park_lakeside[6][0]**

```text
湖边·先认个脸
```

**$.earlyMeet.park_lakeside[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.park_lakeside[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.park_lakeside[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.park_lakeside[7][0]**

```text
湖边·有点生疏
```

**$.earlyMeet.park_lakeside[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.park_lakeside[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.park_lakeside[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.park_lakeside[8][0]**

```text
湖边·不着急聊满
```

**$.earlyMeet.park_lakeside[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.park_lakeside[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.park_lakeside[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.park_lakeside[9][0]**

```text
湖边·顺手提醒
```

**$.earlyMeet.park_lakeside[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.park_lakeside[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.park_lakeside[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.park_lakeside[10][0]**

```text
湖边·先确认一下
```

**$.earlyMeet.park_lakeside[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.park_lakeside[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.park_lakeside[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.park_lakeside[11][0]**

```text
湖边·把名字听清
```

**$.earlyMeet.park_lakeside[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.park_lakeside[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.park_lakeside[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.park_lakeside[12][0]**

```text
湖边·有点认生
```

**$.earlyMeet.park_lakeside[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.park_lakeside[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.park_lakeside[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.park_lakeside[13][0]**

```text
湖边·先看看周围
```

**$.earlyMeet.park_lakeside[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.park_lakeside[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.park_lakeside[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.park_lakeside[14][0]**

```text
湖边·没听清一句
```

**$.earlyMeet.park_lakeside[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.park_lakeside[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.park_lakeside[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.park_lakeside[15][0]**

```text
湖边·不想挡着你
```

**$.earlyMeet.park_lakeside[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.park_lakeside[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.park_lakeside[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.park_lakeside[16][0]**

```text
湖边·把东西收好
```

**$.earlyMeet.park_lakeside[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.park_lakeside[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.park_lakeside[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.park_lakeside[17][0]**

```text
湖边·说话有点轻
```

**$.earlyMeet.park_lakeside[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.park_lakeside[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.park_lakeside[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.park_lakeside[18][0]**

```text
湖边·只是路过
```

**$.earlyMeet.park_lakeside[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.park_lakeside[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.park_lakeside[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.park_lakeside[19][0]**

```text
湖边·不太会找话题
```

**$.earlyMeet.park_lakeside[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.park_lakeside[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.park_lakeside[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.park_lakeside[20][0]**

```text
湖边·认一认方向
```

**$.earlyMeet.park_lakeside[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.park_lakeside[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.park_lakeside[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.park_lakeside[21][0]**

```text
湖边·不急着问
```

**$.earlyMeet.park_lakeside[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.park_lakeside[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.park_lakeside[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.park_lakeside[22][0]**

```text
湖边·名字先记着
```

**$.earlyMeet.park_lakeside[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.park_lakeside[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.park_lakeside[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.park_lakeside[23][0]**

```text
湖边·开头忘词
```

**$.earlyMeet.park_lakeside[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.park_lakeside[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.park_lakeside[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.park_lakeside[24][0]**

```text
湖边·眼神对上
```

**$.earlyMeet.park_lakeside[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.park_lakeside[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.park_lakeside[24][3]**

```text
>你好啊。
```

**$.earlyMeet.park_lakeside[25][0]**

```text
湖边·差点碰到
```

**$.earlyMeet.park_lakeside[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.park_lakeside[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.park_lakeside[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.park_lakeside[26][0]**

```text
湖边·站稳再聊
```

**$.earlyMeet.park_lakeside[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.park_lakeside[26][2]**

```text
好，不急。
```

**$.earlyMeet.park_lakeside[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.park_lakeside[27][0]**

```text
湖边·没什么正事
```

**$.earlyMeet.park_lakeside[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.park_lakeside[27][2]**

```text
你好。
```

**$.earlyMeet.park_lakeside[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.park_lakeside[28][0]**

```text
湖边·先不多打扰
```

**$.earlyMeet.park_lakeside[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.park_lakeside[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.park_lakeside[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.park_lakeside[29][0]**

```text
湖边·留到下次
```

**$.earlyMeet.park_lakeside[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.park_lakeside[29][2]**

```text
好，下次见。
```

**$.earlyMeet.park_lakeside[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.park_central[0][0]**

```text
草坪边初见
```

**$.earlyMeet.park_central[0][1]**

```text
>你好，这边能停一会儿吧？
```

**$.earlyMeet.park_central[0][2]**

```text
应该可以，我也在歇。
```

**$.earlyMeet.park_central[0][3]**

```text
>那就好。
```

**$.earlyMeet.park_central[1][0]**

```text
沿路认路
```

**$.earlyMeet.park_central[1][1]**

```text
>你知道回中央怎么走吗？
```

**$.earlyMeet.park_central[1][2]**

```text
往那边走，我刚从那儿来。
```

**$.earlyMeet.park_central[1][3]**

```text
>哦，好，谢谢。
```

**$.earlyMeet.park_central[2][0]**

```text
公园里·简单问个路
```

**$.earlyMeet.park_central[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.park_central[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.park_central[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.park_central[3][0]**

```text
公园里·没有挡着吧
```

**$.earlyMeet.park_central[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.park_central[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.park_central[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.park_central[4][0]**

```text
公园里·想打个招呼
```

**$.earlyMeet.park_central[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.park_central[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.park_central[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.park_central[5][0]**

```text
公园里·话有点少
```

**$.earlyMeet.park_central[5][1]**

```text
>你好啊。
```

**$.earlyMeet.park_central[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.park_central[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.park_central[6][0]**

```text
公园里·先认个脸
```

**$.earlyMeet.park_central[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.park_central[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.park_central[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.park_central[7][0]**

```text
公园里·有点生疏
```

**$.earlyMeet.park_central[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.park_central[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.park_central[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.park_central[8][0]**

```text
公园里·不着急聊满
```

**$.earlyMeet.park_central[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.park_central[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.park_central[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.park_central[9][0]**

```text
公园里·顺手提醒
```

**$.earlyMeet.park_central[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.park_central[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.park_central[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.park_central[10][0]**

```text
公园里·先确认一下
```

**$.earlyMeet.park_central[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.park_central[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.park_central[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.park_central[11][0]**

```text
公园里·把名字听清
```

**$.earlyMeet.park_central[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.park_central[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.park_central[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.park_central[12][0]**

```text
公园里·有点认生
```

**$.earlyMeet.park_central[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.park_central[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.park_central[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.park_central[13][0]**

```text
公园里·先看看周围
```

**$.earlyMeet.park_central[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.park_central[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.park_central[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.park_central[14][0]**

```text
公园里·没听清一句
```

**$.earlyMeet.park_central[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.park_central[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.park_central[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.park_central[15][0]**

```text
公园里·不想挡着你
```

**$.earlyMeet.park_central[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.park_central[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.park_central[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.park_central[16][0]**

```text
公园里·把东西收好
```

**$.earlyMeet.park_central[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.park_central[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.park_central[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.park_central[17][0]**

```text
公园里·说话有点轻
```

**$.earlyMeet.park_central[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.park_central[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.park_central[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.park_central[18][0]**

```text
公园里·只是路过
```

**$.earlyMeet.park_central[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.park_central[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.park_central[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.park_central[19][0]**

```text
公园里·不太会找话题
```

**$.earlyMeet.park_central[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.park_central[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.park_central[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.park_central[20][0]**

```text
公园里·认一认方向
```

**$.earlyMeet.park_central[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.park_central[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.park_central[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.park_central[21][0]**

```text
公园里·不急着问
```

**$.earlyMeet.park_central[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.park_central[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.park_central[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.park_central[22][0]**

```text
公园里·名字先记着
```

**$.earlyMeet.park_central[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.park_central[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.park_central[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.park_central[23][0]**

```text
公园里·开头忘词
```

**$.earlyMeet.park_central[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.park_central[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.park_central[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.park_central[24][0]**

```text
公园里·眼神对上
```

**$.earlyMeet.park_central[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.park_central[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.park_central[24][3]**

```text
>你好啊。
```

**$.earlyMeet.park_central[25][0]**

```text
公园里·差点碰到
```

**$.earlyMeet.park_central[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.park_central[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.park_central[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.park_central[26][0]**

```text
公园里·站稳再聊
```

**$.earlyMeet.park_central[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.park_central[26][2]**

```text
好，不急。
```

**$.earlyMeet.park_central[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.park_central[27][0]**

```text
公园里·没什么正事
```

**$.earlyMeet.park_central[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.park_central[27][2]**

```text
你好。
```

**$.earlyMeet.park_central[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.park_central[28][0]**

```text
公园里·先不多打扰
```

**$.earlyMeet.park_central[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.park_central[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.park_central[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.park_central[29][0]**

```text
公园里·留到下次
```

**$.earlyMeet.park_central[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.park_central[29][2]**

```text
好，下次见。
```

**$.earlyMeet.park_central[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.park_meadow[0][0]**

```text
草坪旁问候
```

**$.earlyMeet.park_meadow[0][1]**

```text
>这里坐着应该挺舒服。
```

**$.earlyMeet.park_meadow[0][2]**

```text
嗯，就是得挑个平一点的地方。
```

**$.earlyMeet.park_meadow[0][3]**

```text
>我先看看，谢谢。
```

**$.earlyMeet.park_meadow[1][0]**

```text
野餐区问路
```

**$.earlyMeet.park_meadow[1][1]**

```text
>不好意思，这边还有路过去吗？
```

**$.earlyMeet.park_meadow[1][2]**

```text
有，在那一侧。
```

**$.earlyMeet.park_meadow[1][3]**

```text
>看见了，谢谢你。
```

**$.earlyMeet.park_meadow[2][0]**

```text
草坪边·简单问个路
```

**$.earlyMeet.park_meadow[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.park_meadow[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.park_meadow[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.park_meadow[3][0]**

```text
草坪边·没有挡着吧
```

**$.earlyMeet.park_meadow[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.park_meadow[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.park_meadow[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.park_meadow[4][0]**

```text
草坪边·想打个招呼
```

**$.earlyMeet.park_meadow[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.park_meadow[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.park_meadow[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.park_meadow[5][0]**

```text
草坪边·话有点少
```

**$.earlyMeet.park_meadow[5][1]**

```text
>你好啊。
```

**$.earlyMeet.park_meadow[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.park_meadow[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.park_meadow[6][0]**

```text
草坪边·先认个脸
```

**$.earlyMeet.park_meadow[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.park_meadow[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.park_meadow[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.park_meadow[7][0]**

```text
草坪边·有点生疏
```

**$.earlyMeet.park_meadow[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.park_meadow[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.park_meadow[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.park_meadow[8][0]**

```text
草坪边·不着急聊满
```

**$.earlyMeet.park_meadow[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.park_meadow[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.park_meadow[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.park_meadow[9][0]**

```text
草坪边·顺手提醒
```

**$.earlyMeet.park_meadow[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.park_meadow[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.park_meadow[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.park_meadow[10][0]**

```text
草坪边·先确认一下
```

**$.earlyMeet.park_meadow[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.park_meadow[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.park_meadow[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.park_meadow[11][0]**

```text
草坪边·把名字听清
```

**$.earlyMeet.park_meadow[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.park_meadow[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.park_meadow[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.park_meadow[12][0]**

```text
草坪边·有点认生
```

**$.earlyMeet.park_meadow[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.park_meadow[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.park_meadow[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.park_meadow[13][0]**

```text
草坪边·先看看周围
```

**$.earlyMeet.park_meadow[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.park_meadow[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.park_meadow[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.park_meadow[14][0]**

```text
草坪边·没听清一句
```

**$.earlyMeet.park_meadow[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.park_meadow[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.park_meadow[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.park_meadow[15][0]**

```text
草坪边·不想挡着你
```

**$.earlyMeet.park_meadow[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.park_meadow[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.park_meadow[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.park_meadow[16][0]**

```text
草坪边·把东西收好
```

**$.earlyMeet.park_meadow[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.park_meadow[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.park_meadow[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.park_meadow[17][0]**

```text
草坪边·说话有点轻
```

**$.earlyMeet.park_meadow[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.park_meadow[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.park_meadow[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.park_meadow[18][0]**

```text
草坪边·只是路过
```

**$.earlyMeet.park_meadow[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.park_meadow[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.park_meadow[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.park_meadow[19][0]**

```text
草坪边·不太会找话题
```

**$.earlyMeet.park_meadow[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.park_meadow[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.park_meadow[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.park_meadow[20][0]**

```text
草坪边·认一认方向
```

**$.earlyMeet.park_meadow[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.park_meadow[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.park_meadow[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.park_meadow[21][0]**

```text
草坪边·不急着问
```

**$.earlyMeet.park_meadow[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.park_meadow[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.park_meadow[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.park_meadow[22][0]**

```text
草坪边·名字先记着
```

**$.earlyMeet.park_meadow[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.park_meadow[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.park_meadow[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.park_meadow[23][0]**

```text
草坪边·开头忘词
```

**$.earlyMeet.park_meadow[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.park_meadow[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.park_meadow[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.park_meadow[24][0]**

```text
草坪边·眼神对上
```

**$.earlyMeet.park_meadow[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.park_meadow[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.park_meadow[24][3]**

```text
>你好啊。
```

**$.earlyMeet.park_meadow[25][0]**

```text
草坪边·差点碰到
```

**$.earlyMeet.park_meadow[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.park_meadow[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.park_meadow[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.park_meadow[26][0]**

```text
草坪边·站稳再聊
```

**$.earlyMeet.park_meadow[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.park_meadow[26][2]**

```text
好，不急。
```

**$.earlyMeet.park_meadow[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.park_meadow[27][0]**

```text
草坪边·没什么正事
```

**$.earlyMeet.park_meadow[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.park_meadow[27][2]**

```text
你好。
```

**$.earlyMeet.park_meadow[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.park_meadow[28][0]**

```text
草坪边·先不多打扰
```

**$.earlyMeet.park_meadow[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.park_meadow[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.park_meadow[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.park_meadow[29][0]**

```text
草坪边·留到下次
```

**$.earlyMeet.park_meadow[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.park_meadow[29][2]**

```text
好，下次见。
```

**$.earlyMeet.park_meadow[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.park_grove[0][0]**

```text
树下的招呼
```

**$.earlyMeet.park_grove[0][1]**

```text
>这边树好多，我差点没看见你。
```

**$.earlyMeet.park_grove[0][2]**

```text
没事，我站得靠里。
```

**$.earlyMeet.park_grove[0][3]**

```text
>你好，我就从这儿过。
```

**$.earlyMeet.park_grove[1][0]**

```text
小摊边初见
```

**$.earlyMeet.park_grove[1][1]**

```text
>你好，你也在看那边的小摊？
```

**$.earlyMeet.park_grove[1][2]**

```text
嗯，还没想好。
```

**$.earlyMeet.park_grove[1][3]**

```text
>我也是，先看看。
```

**$.earlyMeet.park_grove[2][0]**

```text
树林边·简单问个路
```

**$.earlyMeet.park_grove[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.park_grove[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.park_grove[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.park_grove[3][0]**

```text
树林边·没有挡着吧
```

**$.earlyMeet.park_grove[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.park_grove[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.park_grove[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.park_grove[4][0]**

```text
树林边·想打个招呼
```

**$.earlyMeet.park_grove[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.park_grove[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.park_grove[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.park_grove[5][0]**

```text
树林边·话有点少
```

**$.earlyMeet.park_grove[5][1]**

```text
>你好啊。
```

**$.earlyMeet.park_grove[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.park_grove[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.park_grove[6][0]**

```text
树林边·先认个脸
```

**$.earlyMeet.park_grove[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.park_grove[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.park_grove[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.park_grove[7][0]**

```text
树林边·有点生疏
```

**$.earlyMeet.park_grove[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.park_grove[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.park_grove[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.park_grove[8][0]**

```text
树林边·不着急聊满
```

**$.earlyMeet.park_grove[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.park_grove[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.park_grove[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.park_grove[9][0]**

```text
树林边·顺手提醒
```

**$.earlyMeet.park_grove[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.park_grove[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.park_grove[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.park_grove[10][0]**

```text
树林边·先确认一下
```

**$.earlyMeet.park_grove[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.park_grove[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.park_grove[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.park_grove[11][0]**

```text
树林边·把名字听清
```

**$.earlyMeet.park_grove[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.park_grove[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.park_grove[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.park_grove[12][0]**

```text
树林边·有点认生
```

**$.earlyMeet.park_grove[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.park_grove[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.park_grove[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.park_grove[13][0]**

```text
树林边·先看看周围
```

**$.earlyMeet.park_grove[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.park_grove[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.park_grove[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.park_grove[14][0]**

```text
树林边·没听清一句
```

**$.earlyMeet.park_grove[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.park_grove[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.park_grove[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.park_grove[15][0]**

```text
树林边·不想挡着你
```

**$.earlyMeet.park_grove[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.park_grove[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.park_grove[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.park_grove[16][0]**

```text
树林边·把东西收好
```

**$.earlyMeet.park_grove[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.park_grove[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.park_grove[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.park_grove[17][0]**

```text
树林边·说话有点轻
```

**$.earlyMeet.park_grove[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.park_grove[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.park_grove[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.park_grove[18][0]**

```text
树林边·只是路过
```

**$.earlyMeet.park_grove[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.park_grove[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.park_grove[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.park_grove[19][0]**

```text
树林边·不太会找话题
```

**$.earlyMeet.park_grove[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.park_grove[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.park_grove[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.park_grove[20][0]**

```text
树林边·认一认方向
```

**$.earlyMeet.park_grove[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.park_grove[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.park_grove[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.park_grove[21][0]**

```text
树林边·不急着问
```

**$.earlyMeet.park_grove[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.park_grove[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.park_grove[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.park_grove[22][0]**

```text
树林边·名字先记着
```

**$.earlyMeet.park_grove[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.park_grove[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.park_grove[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.park_grove[23][0]**

```text
树林边·开头忘词
```

**$.earlyMeet.park_grove[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.park_grove[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.park_grove[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.park_grove[24][0]**

```text
树林边·眼神对上
```

**$.earlyMeet.park_grove[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.park_grove[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.park_grove[24][3]**

```text
>你好啊。
```

**$.earlyMeet.park_grove[25][0]**

```text
树林边·差点碰到
```

**$.earlyMeet.park_grove[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.park_grove[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.park_grove[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.park_grove[26][0]**

```text
树林边·站稳再聊
```

**$.earlyMeet.park_grove[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.park_grove[26][2]**

```text
好，不急。
```

**$.earlyMeet.park_grove[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.park_grove[27][0]**

```text
树林边·没什么正事
```

**$.earlyMeet.park_grove[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.park_grove[27][2]**

```text
你好。
```

**$.earlyMeet.park_grove[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.park_grove[28][0]**

```text
树林边·先不多打扰
```

**$.earlyMeet.park_grove[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.park_grove[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.park_grove[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.park_grove[29][0]**

```text
树林边·留到下次
```

**$.earlyMeet.park_grove[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.park_grove[29][2]**

```text
好，下次见。
```

**$.earlyMeet.park_grove[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.mall[0][0]**

```text
商场借过
```

**$.earlyMeet.mall[0][1]**

```text
>不好意思，这里能过去吗？
```

**$.earlyMeet.mall[0][2]**

```text
能，我让一下。
```

**$.earlyMeet.mall[0][3]**

```text
>谢谢，人多时我老怕挡路。
```

**$.earlyMeet.mall[1][0]**

```text
认商场方向
```

**$.earlyMeet.mall[1][1]**

```text
>你好，刚才那个路口在哪边？
```

**$.earlyMeet.mall[1][2]**

```text
我记得在那边。
```

**$.earlyMeet.mall[1][3]**

```text
>好，谢谢，我容易绕晕。
```

**$.earlyMeet.mall[2][0]**

```text
商场里·简单问个路
```

**$.earlyMeet.mall[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.mall[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.mall[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.mall[3][0]**

```text
商场里·没有挡着吧
```

**$.earlyMeet.mall[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.mall[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.mall[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.mall[4][0]**

```text
商场里·想打个招呼
```

**$.earlyMeet.mall[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.mall[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.mall[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.mall[5][0]**

```text
商场里·话有点少
```

**$.earlyMeet.mall[5][1]**

```text
>你好啊。
```

**$.earlyMeet.mall[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.mall[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.mall[6][0]**

```text
商场里·先认个脸
```

**$.earlyMeet.mall[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.mall[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.mall[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.mall[7][0]**

```text
商场里·有点生疏
```

**$.earlyMeet.mall[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.mall[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.mall[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.mall[8][0]**

```text
商场里·不着急聊满
```

**$.earlyMeet.mall[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.mall[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.mall[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.mall[9][0]**

```text
商场里·顺手提醒
```

**$.earlyMeet.mall[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.mall[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.mall[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.mall[10][0]**

```text
商场里·先确认一下
```

**$.earlyMeet.mall[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.mall[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.mall[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.mall[11][0]**

```text
商场里·把名字听清
```

**$.earlyMeet.mall[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.mall[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.mall[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.mall[12][0]**

```text
商场里·有点认生
```

**$.earlyMeet.mall[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.mall[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.mall[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.mall[13][0]**

```text
商场里·先看看周围
```

**$.earlyMeet.mall[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.mall[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.mall[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.mall[14][0]**

```text
商场里·没听清一句
```

**$.earlyMeet.mall[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.mall[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.mall[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.mall[15][0]**

```text
商场里·不想挡着你
```

**$.earlyMeet.mall[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.mall[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.mall[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.mall[16][0]**

```text
商场里·把东西收好
```

**$.earlyMeet.mall[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.mall[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.mall[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.mall[17][0]**

```text
商场里·说话有点轻
```

**$.earlyMeet.mall[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.mall[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.mall[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.mall[18][0]**

```text
商场里·只是路过
```

**$.earlyMeet.mall[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.mall[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.mall[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.mall[19][0]**

```text
商场里·不太会找话题
```

**$.earlyMeet.mall[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.mall[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.mall[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.mall[20][0]**

```text
商场里·认一认方向
```

**$.earlyMeet.mall[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.mall[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.mall[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.mall[21][0]**

```text
商场里·不急着问
```

**$.earlyMeet.mall[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.mall[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.mall[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.mall[22][0]**

```text
商场里·名字先记着
```

**$.earlyMeet.mall[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.mall[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.mall[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.mall[23][0]**

```text
商场里·开头忘词
```

**$.earlyMeet.mall[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.mall[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.mall[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.mall[24][0]**

```text
商场里·眼神对上
```

**$.earlyMeet.mall[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.mall[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.mall[24][3]**

```text
>你好啊。
```

**$.earlyMeet.mall[25][0]**

```text
商场里·差点碰到
```

**$.earlyMeet.mall[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.mall[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.mall[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.mall[26][0]**

```text
商场里·站稳再聊
```

**$.earlyMeet.mall[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.mall[26][2]**

```text
好，不急。
```

**$.earlyMeet.mall[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.mall[27][0]**

```text
商场里·没什么正事
```

**$.earlyMeet.mall[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.mall[27][2]**

```text
你好。
```

**$.earlyMeet.mall[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.mall[28][0]**

```text
商场里·先不多打扰
```

**$.earlyMeet.mall[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.mall[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.mall[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.mall[29][0]**

```text
商场里·留到下次
```

**$.earlyMeet.mall[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.mall[29][2]**

```text
好，下次见。
```

**$.earlyMeet.mall[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.beach[0][0]**

```text
码头边问候
```

**$.earlyMeet.beach[0][1]**

```text
>这里风挺明显的。
```

**$.earlyMeet.beach[0][2]**

```text
嗯，站稳一点就好。
```

**$.earlyMeet.beach[0][3]**

```text
>好，谢谢提醒。
```

**$.earlyMeet.beach[1][0]**

```text
海边初见
```

**$.earlyMeet.beach[1][1]**

```text
>你好，这里一直能站吗？
```

**$.earlyMeet.beach[1][2]**

```text
可以，别太靠边。
```

**$.earlyMeet.beach[1][3]**

```text
>明白，我就在里面一点。
```

**$.earlyMeet.beach[2][0]**

```text
码头边·简单问个路
```

**$.earlyMeet.beach[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.beach[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.beach[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.beach[3][0]**

```text
码头边·没有挡着吧
```

**$.earlyMeet.beach[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.beach[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.beach[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.beach[4][0]**

```text
码头边·想打个招呼
```

**$.earlyMeet.beach[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.beach[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.beach[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.beach[5][0]**

```text
码头边·话有点少
```

**$.earlyMeet.beach[5][1]**

```text
>你好啊。
```

**$.earlyMeet.beach[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.beach[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.beach[6][0]**

```text
码头边·先认个脸
```

**$.earlyMeet.beach[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.beach[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.beach[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.beach[7][0]**

```text
码头边·有点生疏
```

**$.earlyMeet.beach[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.beach[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.beach[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.beach[8][0]**

```text
码头边·不着急聊满
```

**$.earlyMeet.beach[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.beach[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.beach[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.beach[9][0]**

```text
码头边·顺手提醒
```

**$.earlyMeet.beach[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.beach[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.beach[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.beach[10][0]**

```text
码头边·先确认一下
```

**$.earlyMeet.beach[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.beach[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.beach[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.beach[11][0]**

```text
码头边·把名字听清
```

**$.earlyMeet.beach[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.beach[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.beach[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.beach[12][0]**

```text
码头边·有点认生
```

**$.earlyMeet.beach[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.beach[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.beach[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.beach[13][0]**

```text
码头边·先看看周围
```

**$.earlyMeet.beach[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.beach[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.beach[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.beach[14][0]**

```text
码头边·没听清一句
```

**$.earlyMeet.beach[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.beach[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.beach[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.beach[15][0]**

```text
码头边·不想挡着你
```

**$.earlyMeet.beach[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.beach[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.beach[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.beach[16][0]**

```text
码头边·把东西收好
```

**$.earlyMeet.beach[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.beach[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.beach[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.beach[17][0]**

```text
码头边·说话有点轻
```

**$.earlyMeet.beach[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.beach[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.beach[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.beach[18][0]**

```text
码头边·只是路过
```

**$.earlyMeet.beach[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.beach[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.beach[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.beach[19][0]**

```text
码头边·不太会找话题
```

**$.earlyMeet.beach[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.beach[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.beach[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.beach[20][0]**

```text
码头边·认一认方向
```

**$.earlyMeet.beach[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.beach[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.beach[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.beach[21][0]**

```text
码头边·不急着问
```

**$.earlyMeet.beach[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.beach[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.beach[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.beach[22][0]**

```text
码头边·名字先记着
```

**$.earlyMeet.beach[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.beach[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.beach[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.beach[23][0]**

```text
码头边·开头忘词
```

**$.earlyMeet.beach[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.beach[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.beach[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.beach[24][0]**

```text
码头边·眼神对上
```

**$.earlyMeet.beach[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.beach[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.beach[24][3]**

```text
>你好啊。
```

**$.earlyMeet.beach[25][0]**

```text
码头边·差点碰到
```

**$.earlyMeet.beach[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.beach[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.beach[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.beach[26][0]**

```text
码头边·站稳再聊
```

**$.earlyMeet.beach[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.beach[26][2]**

```text
好，不急。
```

**$.earlyMeet.beach[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.beach[27][0]**

```text
码头边·没什么正事
```

**$.earlyMeet.beach[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.beach[27][2]**

```text
你好。
```

**$.earlyMeet.beach[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.beach[28][0]**

```text
码头边·先不多打扰
```

**$.earlyMeet.beach[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.beach[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.beach[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.beach[29][0]**

```text
码头边·留到下次
```

**$.earlyMeet.beach[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.beach[29][2]**

```text
好，下次见。
```

**$.earlyMeet.beach[29][3]**

```text
>嗯，拜拜。
```

**$.earlyMeet.bar[0][0]**

```text
酒吧的空位
```

**$.earlyMeet.bar[0][1]**

```text
>这里有人吗？
```

**$.earlyMeet.bar[0][2]**

```text
没有，你坐。
```

**$.earlyMeet.bar[0][3]**

```text
>谢谢，我还没认熟地方。
```

**$.earlyMeet.bar[1][0]**

```text
吧台边搭话
```

**$.earlyMeet.bar[1][1]**

```text
>你好，你也是刚来吗？
```

**$.earlyMeet.bar[1][2]**

```text
嗯，刚坐下。
```

**$.earlyMeet.bar[1][3]**

```text
>我也是。先慢慢看看吧。
```

**$.earlyMeet.bar[2][0]**

```text
酒吧里·简单问个路
```

**$.earlyMeet.bar[2][1]**

```text
>你好，想问个路。
```

**$.earlyMeet.bar[2][2]**

```text
你说，我看看认不认识。
```

**$.earlyMeet.bar[2][3]**

```text
>好，我把地图打开。
```

**$.earlyMeet.bar[3][0]**

```text
酒吧里·没有挡着吧
```

**$.earlyMeet.bar[3][1]**

```text
>我站这儿挡着你了吗？
```

**$.earlyMeet.bar[3][2]**

```text
没有，能过去。
```

**$.earlyMeet.bar[3][3]**

```text
>好，那我再站一会儿。
```

**$.earlyMeet.bar[4][0]**

```text
酒吧里·想打个招呼
```

**$.earlyMeet.bar[4][1]**

```text
>你好，好像刚才也碰到过。
```

**$.earlyMeet.bar[4][2]**

```text
嗯，记得。
```

**$.earlyMeet.bar[4][3]**

```text
>那我没认错。
```

**$.earlyMeet.bar[5][0]**

```text
酒吧里·话有点少
```

**$.earlyMeet.bar[5][1]**

```text
>你好啊。
```

**$.earlyMeet.bar[5][2]**

```text
你好，有事吗？
```

**$.earlyMeet.bar[5][3]**

```text
>没事，就问个好。
```

**$.earlyMeet.bar[6][0]**

```text
酒吧里·先认个脸
```

**$.earlyMeet.bar[6][1]**

```text
>下次我可能还得看一眼才认得出你。
```

**$.earlyMeet.bar[6][2]**

```text
没事，见面叫我就行。
```

**$.earlyMeet.bar[6][3]**

```text
>好，名字记下了。
```

**$.earlyMeet.bar[7][0]**

```text
酒吧里·有点生疏
```

**$.earlyMeet.bar[7][1]**

```text
>刚想问个事，又忘了。
```

**$.earlyMeet.bar[7][2]**

```text
想起来再问吧。
```

**$.earlyMeet.bar[7][3]**

```text
>嗯，我再想想。
```

**$.earlyMeet.bar[8][0]**

```text
酒吧里·不着急聊满
```

**$.earlyMeet.bar[8][1]**

```text
>那我就不打扰了。
```

**$.earlyMeet.bar[8][2]**

```text
好，你慢慢走。
```

**$.earlyMeet.bar[8][3]**

```text
>下回碰见再说。
```

**$.earlyMeet.bar[9][0]**

```text
酒吧里·顺手提醒
```

**$.earlyMeet.bar[9][1]**

```text
>小心，刚才东西快掉了。
```

**$.earlyMeet.bar[9][2]**

```text
哦，谢谢，我拿好了。
```

**$.earlyMeet.bar[9][3]**

```text
>没事，正好看见。
```

**$.earlyMeet.bar[10][0]**

```text
酒吧里·先确认一下
```

**$.earlyMeet.bar[10][1]**

```text
>这儿能停一下吧？
```

**$.earlyMeet.bar[10][2]**

```text
能，我也刚来。
```

**$.earlyMeet.bar[10][3]**

```text
>好，谢谢。
```

**$.earlyMeet.bar[11][0]**

```text
酒吧里·把名字听清
```

**$.earlyMeet.bar[11][1]**

```text
>不好意思，你名字我没听清。
```

**$.earlyMeet.bar[11][2]**

```text
叫我{名字}就行。
```

**$.earlyMeet.bar[11][3]**

```text
>好，这回记住了。
```

**$.earlyMeet.bar[12][0]**

```text
酒吧里·有点认生
```

**$.earlyMeet.bar[12][1]**

```text
>你好，我住得不太远。
```

**$.earlyMeet.bar[12][2]**

```text
哦，我也是附近的。
```

**$.earlyMeet.bar[12][3]**

```text
>难怪好像见过。
```

**$.earlyMeet.bar[13][0]**

```text
酒吧里·先看看周围
```

**$.earlyMeet.bar[13][1]**

```text
>我先在附近看看。
```

**$.earlyMeet.bar[13][2]**

```text
嗯，我也随便走走。
```

**$.earlyMeet.bar[13][3]**

```text
>那你慢慢看。
```

**$.earlyMeet.bar[14][0]**

```text
酒吧里·没听清一句
```

**$.earlyMeet.bar[14][1]**

```text
>刚才是在跟我说话吗？
```

**$.earlyMeet.bar[14][2]**

```text
对，跟你打个招呼。
```

**$.earlyMeet.bar[14][3]**

```text
>哦哦，你好。
```

**$.earlyMeet.bar[15][0]**

```text
酒吧里·不想挡着你
```

**$.earlyMeet.bar[15][1]**

```text
>我往边上让一点。
```

**$.earlyMeet.bar[15][2]**

```text
谢谢，能过去。
```

**$.earlyMeet.bar[15][3]**

```text
>好，你先走。
```

**$.earlyMeet.bar[16][0]**

```text
酒吧里·把东西收好
```

**$.earlyMeet.bar[16][1]**

```text
>这个是不是快从包里掉了？
```

**$.earlyMeet.bar[16][2]**

```text
还真是，谢谢。
```

**$.earlyMeet.bar[16][3]**

```text
>塞深点就好。
```

**$.earlyMeet.bar[17][0]**

```text
酒吧里·说话有点轻
```

**$.earlyMeet.bar[17][1]**

```text
>刚才没听清，我再说一遍啊。
```

**$.earlyMeet.bar[17][2]**

```text
嗯，你说。
```

**$.earlyMeet.bar[17][3]**

```text
>我是问这条路能不能出去。
```

**$.earlyMeet.bar[18][0]**

```text
酒吧里·只是路过
```

**$.earlyMeet.bar[18][1]**

```text
>你也在这儿歇会儿？
```

**$.earlyMeet.bar[18][2]**

```text
嗯，走得有点累。
```

**$.earlyMeet.bar[18][3]**

```text
>我也是，先站一会儿。
```

**$.earlyMeet.bar[19][0]**

```text
酒吧里·不太会找话题
```

**$.earlyMeet.bar[19][1]**

```text
>平时不太会主动找人说话。
```

**$.earlyMeet.bar[19][2]**

```text
没事，你刚想问什么？
```

**$.earlyMeet.bar[19][3]**

```text
>哦，是想问那边怎么走。
```

**$.earlyMeet.bar[20][0]**

```text
酒吧里·认一认方向
```

**$.earlyMeet.bar[20][1]**

```text
>附近我还不熟。
```

**$.earlyMeet.bar[20][2]**

```text
我也没来过几次。
```

**$.earlyMeet.bar[20][3]**

```text
>那我先看一下牌子。
```

**$.earlyMeet.bar[21][0]**

```text
酒吧里·不急着问
```

**$.earlyMeet.bar[21][1]**

```text
>想问个事，怕你正忙。
```

**$.earlyMeet.bar[21][2]**

```text
现在没事，你说吧。
```

**$.earlyMeet.bar[21][3]**

```text
>好，我就问两句。
```

**$.earlyMeet.bar[22][0]**

```text
酒吧里·名字先记着
```

**$.earlyMeet.bar[22][1]**

```text
>名字我记着了。
```

**$.earlyMeet.bar[22][2]**

```text
嗯，我也记下了。
```

**$.earlyMeet.bar[22][3]**

```text
>以后看见再打招呼。
```

**$.earlyMeet.bar[23][0]**

```text
酒吧里·开头忘词
```

**$.earlyMeet.bar[23][1]**

```text
>我刚才有句话到嘴边又忘了。
```

**$.earlyMeet.bar[23][2]**

```text
要不先看看周围？
```

**$.earlyMeet.bar[23][3]**

```text
>好，想起来再问。
```

**$.earlyMeet.bar[24][0]**

```text
酒吧里·眼神对上
```

**$.earlyMeet.bar[24][1]**

```text
>刚才看你也看过来了。
```

**$.earlyMeet.bar[24][2]**

```text
嗯，打个招呼。
```

**$.earlyMeet.bar[24][3]**

```text
>你好啊。
```

**$.earlyMeet.bar[25][0]**

```text
酒吧里·差点碰到
```

**$.earlyMeet.bar[25][1]**

```text
>不好意思，刚差点碰着你。
```

**$.earlyMeet.bar[25][2]**

```text
没有碰到，没事。
```

**$.earlyMeet.bar[25][3]**

```text
>我刚没看前面。
```

**$.earlyMeet.bar[26][0]**

```text
酒吧里·站稳再聊
```

**$.earlyMeet.bar[26][1]**

```text
>我先把东西拿稳。
```

**$.earlyMeet.bar[26][2]**

```text
好，不急。
```

**$.earlyMeet.bar[26][3]**

```text
>好了，你刚才说什么？
```

**$.earlyMeet.bar[27][0]**

```text
酒吧里·没什么正事
```

**$.earlyMeet.bar[27][1]**

```text
>没什么正事，就跟你问个好。
```

**$.earlyMeet.bar[27][2]**

```text
你好。
```

**$.earlyMeet.bar[27][3]**

```text
>嗯，那你先忙。
```

**$.earlyMeet.bar[28][0]**

```text
酒吧里·先不多打扰
```

**$.earlyMeet.bar[28][1]**

```text
>你这会儿有事吗？
```

**$.earlyMeet.bar[28][2]**

```text
不急，怎么了？
```

**$.earlyMeet.bar[28][3]**

```text
>想问一下前面是不是通的。
```

**$.earlyMeet.bar[29][0]**

```text
酒吧里·留到下次
```

**$.earlyMeet.bar[29][1]**

```text
>那下次再聊。
```

**$.earlyMeet.bar[29][2]**

```text
好，下次见。
```

**$.earlyMeet.bar[29][3]**

```text
>嗯，拜拜。
```

**$.everydayPersonality.slow[0][0].title**

```text
没回的电话
```

**$.everydayPersonality.slow[0][0].lines[0]**

```text
>刚才有个不认识的号码，我没接。
```

**$.everydayPersonality.slow[0][0].lines[1]**

```text
怕是推销？
```

**$.everydayPersonality.slow[0][0].lines[2]**

```text
>也不知道该怎么开头，先搜了一下。
```

**$.everydayPersonality.slow[0][0].lines[3]**

```text
没事，真有事还会找你的。
```

**$.everydayPersonality.slow[0][1].title**

```text
到了再招呼
```

**$.everydayPersonality.slow[0][1].lines[0]**

```text
>我刚才看见你，犹豫了一下才叫。
```

**$.everydayPersonality.slow[0][1].lines[1]**

```text
哈哈，差点就错过了。
```

**$.everydayPersonality.slow[0][1].lines[2]**

```text
>嗯，我还在想怎么说。
```

**$.everydayPersonality.slow[0][1].lines[3]**

```text
喊名字就行，我又不会吓你。
```

**$.everydayPersonality.slow[1][0].title**

```text
先发消息
```

**$.everydayPersonality.slow[1][0].lines[0]**

```text
>我想问你件事，打了半天字。
```

**$.everydayPersonality.slow[1][0].lines[1]**

```text
你直接发呗。
```

**$.everydayPersonality.slow[1][0].lines[2]**

```text
>怕没说清，删了两遍。
```

**$.everydayPersonality.slow[1][0].lines[3]**

```text
没看懂我会问的，先发来。
```

**$.everydayPersonality.slow[1][1].title**

```text
安静了一会儿
```

**$.everydayPersonality.slow[1][1].lines[0]**

```text
>我刚才是不是半天没出声？
```

**$.everydayPersonality.slow[1][1].lines[1]**

```text
没事，我也在看东西。
```

**$.everydayPersonality.slow[1][1].lines[2]**

```text
>哦，我怕你以为我不想聊。
```

**$.everydayPersonality.slow[1][1].lines[3]**

```text
不会，你想说了再说呗。
```

**$.everydayPersonality.slow[2][0].title**

```text
熟了以后
```

**$.everydayPersonality.slow[2][0].lines[0]**

```text
>我对不熟的人真说不出这么多。
```

**$.everydayPersonality.slow[2][0].lines[1]**

```text
看出来了，你现在可不少说。
```

**$.everydayPersonality.slow[2][0].lines[2]**

```text
>哈哈，跟你就顺口了。
```

**$.everydayPersonality.slow[2][0].lines[3]**

```text
那行，你接着吐槽。
```

**$.everydayPersonality.slow[2][1].title**

```text
不用一直说话
```

**$.everydayPersonality.slow[2][1].lines[0]**

```text
>我就挂着电话，做点自己的事，行吗？
```

**$.everydayPersonality.slow[2][1].lines[1]**

```text
行啊，我也在收拾。
```

**$.everydayPersonality.slow[2][1].lines[2]**

```text
>有事我叫你。
```

**$.everydayPersonality.slow[2][1].lines[3]**

```text
嗯，别把我连垃圾一起收走就行。
```

**$.everydayPersonality.outgoing[0][0].title**

```text
顺手打招呼
```

**$.everydayPersonality.outgoing[0][0].lines[0]**

```text
>我跟楼下那个人打招呼，才发现认错了。
```

**$.everydayPersonality.outgoing[0][0].lines[1]**

```text
人家回你了吗？
```

**$.everydayPersonality.outgoing[0][0].lines[2]**

```text
>回了，还问我去哪儿。
```

**$.everydayPersonality.outgoing[0][0].lines[3]**

```text
哈哈，那你就当新认识一个。
```

**$.everydayPersonality.outgoing[0][1].title**

```text
想分享点事
```

**$.everydayPersonality.outgoing[0][1].lines[0]**

```text
>哎，我刚看见个挺好玩的东西。
```

**$.everydayPersonality.outgoing[0][1].lines[1]**

```text
什么啊？
```

**$.everydayPersonality.outgoing[0][1].lines[2]**

```text
>拍照拍糊了，等我重新找一下。
```

**$.everydayPersonality.outgoing[0][1].lines[3]**

```text
你先说是什么呗。
```

**$.everydayPersonality.outgoing[1][0].title**

```text
攒了一路
```

**$.everydayPersonality.outgoing[1][0].lines[0]**

```text
>我路上想了一堆话，一接通反而忘了。
```

**$.everydayPersonality.outgoing[1][0].lines[1]**

```text
先说记得的那个。
```

**$.everydayPersonality.outgoing[1][0].lines[2]**

```text
>哦对，那个店搬走了。
```

**$.everydayPersonality.outgoing[1][0].lines[3]**

```text
哪家？我还想着去呢。
```

**$.everydayPersonality.outgoing[1][1].title**

```text
多问一句
```

**$.everydayPersonality.outgoing[1][1].lines[0]**

```text
>我是不是一下问太多了？
```

**$.everydayPersonality.outgoing[1][1].lines[1]**

```text
有点，我先回前一个。
```

**$.everydayPersonality.outgoing[1][1].lines[2]**

```text
>哈哈好，你慢慢回。
```

**$.everydayPersonality.outgoing[1][1].lines[3]**

```text
你先别加题啊。
```

**$.everydayPersonality.outgoing[2][0].title**

```text
热闹也会累
```

**$.everydayPersonality.outgoing[2][0].lines[0]**

```text
>我今天跟好多人说话，回来嗓子都累了。
```

**$.everydayPersonality.outgoing[2][0].lines[1]**

```text
那你还给我打。
```

**$.everydayPersonality.outgoing[2][0].lines[2]**

```text
>给你打就随便说两句呗。
```

**$.everydayPersonality.outgoing[2][0].lines[3]**

```text
行，喝口水，我先讲。
```

**$.everydayPersonality.outgoing[2][1].title**

```text
没准备也能聊
```

**$.everydayPersonality.outgoing[2][1].lines[0]**

```text
>我也没啥事，顺手就点你头像了。
```

**$.everydayPersonality.outgoing[2][1].lines[1]**

```text
嗯，我正等水烧开。
```

**$.everydayPersonality.outgoing[2][1].lines[2]**

```text
>那我陪你等一下。
```

**$.everydayPersonality.outgoing[2][1].lines[3]**

```text
好，水开了也不赶你走。
```

**$.everydayPersonality.casual[0][0].title**

```text
临时改道
```

**$.everydayPersonality.casual[0][0].lines[0]**

```text
>我本来打算去另一边，走着走着拐弯了。
```

**$.everydayPersonality.casual[0][0].lines[1]**

```text
又被什么店吸引了？
```

**$.everydayPersonality.casual[0][0].lines[2]**

```text
>一家面包店，刚好闻着香。
```

**$.everydayPersonality.casual[0][0].lines[3]**

```text
那你买了没？
```

**$.everydayPersonality.casual[0][1].title**

```text
空着的计划
```

**$.everydayPersonality.casual[0][1].lines[0]**

```text
>我今天没怎么安排。
```

**$.everydayPersonality.casual[0][1].lines[1]**

```text
那就慢慢来呗。
```

**$.everydayPersonality.casual[0][1].lines[2]**

```text
>嗯，先把该做的做了。
```

**$.everydayPersonality.casual[0][1].lines[3]**

```text
剩下的到时候再看。
```

**$.everydayPersonality.casual[1][0].title**

```text
突然想到
```

**$.everydayPersonality.casual[1][0].lines[0]**

```text
>哎，我突然想试个小东西。
```

**$.everydayPersonality.casual[1][0].lines[1]**

```text
什么？
```

**$.everydayPersonality.casual[1][0].lines[2]**

```text
>先不说了，我做出来发你。
```

**$.everydayPersonality.casual[1][0].lines[3]**

```text
别卖关子，失败了也发啊。
```

**$.everydayPersonality.casual[1][1].title**

```text
约好才改
```

**$.everydayPersonality.casual[1][1].lines[0]**

```text
>我刚才想改主意，又想起还没跟你说。
```

**$.everydayPersonality.casual[1][1].lines[1]**

```text
那你现在说。
```

**$.everydayPersonality.casual[1][1].lines[2]**

```text
>下回能不能晚一点出门？
```

**$.everydayPersonality.casual[1][1].lines[3]**

```text
行啊，提前讲就好。
```

**$.everydayPersonality.casual[2][0].title**

```text
顺路但没顺成
```

**$.everydayPersonality.casual[2][0].lines[0]**

```text
>我说顺路去一趟，结果越走越远。
```

**$.everydayPersonality.casual[2][0].lines[1]**

```text
你这个顺路有点厉害。
```

**$.everydayPersonality.casual[2][0].lines[2]**

```text
>哈哈，下次先看地图。
```

**$.everydayPersonality.casual[2][0].lines[3]**

```text
也不用次次靠下次。
```

**$.everydayPersonality.casual[2][1].title**

```text
记住约定
```

**$.everydayPersonality.casual[2][1].lines[0]**

```text
>我怕自己又忘，先把咱俩约的事记上。
```

**$.everydayPersonality.casual[2][1].lines[1]**

```text
好，时间也写一下。
```

**$.everydayPersonality.casual[2][1].lines[2]**

```text
>写了，这回真写了。
```

**$.everydayPersonality.casual[2][1].lines[3]**

```text
行，我先信你一次。
```

**$.everydayPersonality.thoughtful[0][0].title**

```text
先问时间
```

**$.everydayPersonality.thoughtful[0][0].lines[0]**

```text
>我先问一下，你现在忙不忙？
```

**$.everydayPersonality.thoughtful[0][0].lines[1]**

```text
这会儿还好。
```

**$.everydayPersonality.thoughtful[0][0].lines[2]**

```text
>那我说两句，忙了你就直接讲。
```

**$.everydayPersonality.thoughtful[0][0].lines[3]**

```text
嗯，你说呗。
```

**$.everydayPersonality.thoughtful[0][1].title**

```text
带一把伞
```

**$.everydayPersonality.thoughtful[0][1].lines[0]**

```text
>我包里一般会塞把小伞。
```

**$.everydayPersonality.thoughtful[0][1].lines[1]**

```text
不嫌重啊？
```

**$.everydayPersonality.thoughtful[0][1].lines[2]**

```text
>还行，比临时淋雨省事。
```

**$.everydayPersonality.thoughtful[0][1].lines[3]**

```text
那我也找把小的放着。
```

**$.everydayPersonality.thoughtful[1][0].title**

```text
水温记住了
```

**$.everydayPersonality.thoughtful[1][0].lines[0]**

```text
>给你带水的话，要常温的吧？
```

**$.everydayPersonality.thoughtful[1][0].lines[1]**

```text
嗯，你还记得。
```

**$.everydayPersonality.thoughtful[1][0].lines[2]**

```text
>上次见你拿着冰的捂半天。
```

**$.everydayPersonality.thoughtful[1][0].lines[3]**

```text
哈哈，确实不太扛得住。
```

**$.everydayPersonality.thoughtful[1][1].title**

```text
改时间不难
```

**$.everydayPersonality.thoughtful[1][1].lines[0]**

```text
>咱们之前说的时间，你要不要再确认一下？
```

**$.everydayPersonality.thoughtful[1][1].lines[1]**

```text
我看看，应该没问题。
```

**$.everydayPersonality.thoughtful[1][1].lines[2]**

```text
>有事就换，别硬赶。
```

**$.everydayPersonality.thoughtful[1][1].lines[3]**

```text
好，我晚点回你个准话。
```

**$.everydayPersonality.thoughtful[2][0].title**

```text
不用这么客气
```

**$.everydayPersonality.thoughtful[2][0].lines[0]**

```text
>我是不是安排得有点细了？
```

**$.everydayPersonality.thoughtful[2][0].lines[1]**

```text
有点，不过挺省心的。
```

**$.everydayPersonality.thoughtful[2][0].lines[2]**

```text
>你嫌烦直接说啊。
```

**$.everydayPersonality.thoughtful[2][0].lines[3]**

```text
我先把需要改的挑出来给你。
```

**$.everydayPersonality.thoughtful[2][1].title**

```text
留个余地
```

**$.everydayPersonality.thoughtful[2][1].lines[0]**

```text
>我没把后面的时间排死。
```

**$.everydayPersonality.thoughtful[2][1].lines[1]**

```text
怕我又拖拉？
```

**$.everydayPersonality.thoughtful[2][1].lines[2]**

```text
>哈哈，不全是，走到哪儿再看看。
```

**$.everydayPersonality.thoughtful[2][1].lines[3]**

```text
行，这个安排还挺舒服。
```

**$.everydayPersonality.steady[0][0].title**

```text
等车这会儿
```

**$.everydayPersonality.steady[0][0].lines[0]**

```text
>我车还没来，先坐这儿等。
```

**$.everydayPersonality.steady[0][0].lines[1]**

```text
等多久了？
```

**$.everydayPersonality.steady[0][0].lines[2]**

```text
>一会儿了，着急也没用。
```

**$.everydayPersonality.steady[0][0].lines[3]**

```text
那看看有没有别的车呗。
```

**$.everydayPersonality.steady[0][1].title**

```text
先不发出去
```

**$.everydayPersonality.steady[0][1].lines[0]**

```text
>我刚才差点回一大段。
```

**$.everydayPersonality.steady[0][1].lines[1]**

```text
后来呢？
```

**$.everydayPersonality.steady[0][1].lines[2]**

```text
>删了，先把饭吃了再说。
```

**$.everydayPersonality.steady[0][1].lines[3]**

```text
嗯，吃完再看还想不想回。
```

**$.everydayPersonality.steady[1][0].title**

```text
理一理再讲
```

**$.everydayPersonality.steady[1][0].lines[0]**

```text
>那件事我刚才没想好怎么说。
```

**$.everydayPersonality.steady[1][0].lines[1]**

```text
现在想好啦？
```

**$.everydayPersonality.steady[1][0].lines[2]**

```text
>大概吧，你先听着。
```

**$.everydayPersonality.steady[1][0].lines[3]**

```text
行，漏了我再问。
```

**$.everydayPersonality.steady[1][1].title**

```text
不急着做决定
```

**$.everydayPersonality.steady[1][1].lines[0]**

```text
>我现在还没决定。
```

**$.everydayPersonality.steady[1][1].lines[1]**

```text
最晚什么时候得回？
```

**$.everydayPersonality.steady[1][1].lines[2]**

```text
>明天，那我再想想。
```

**$.everydayPersonality.steady[1][1].lines[3]**

```text
有时间就慢慢想呗。
```

**$.everydayPersonality.steady[2][0].title**

```text
看着还好
```

**$.everydayPersonality.steady[2][0].lines[0]**

```text
>你可能看不太出我刚才有点烦。
```

**$.everydayPersonality.steady[2][0].lines[1]**

```text
是有一点，说话短了。
```

**$.everydayPersonality.steady[2][0].lines[2]**

```text
>嗯，没想把火发你身上。
```

**$.everydayPersonality.steady[2][0].lines[3]**

```text
我知道，你先缓一下。
```

**$.everydayPersonality.steady[2][1].title**

```text
先听完
```

**$.everydayPersonality.steady[2][1].lines[0]**

```text
>你先说完，我再问。
```

**$.everydayPersonality.steady[2][1].lines[1]**

```text
我说得有点乱。
```

**$.everydayPersonality.steady[2][1].lines[2]**

```text
>没事，我能跟上。
```

**$.everydayPersonality.steady[2][1].lines[3]**

```text
那我从前面那段重新讲。
```

**$.everydayPersonality.sensitive[0][0].title**

```text
语气拿不准
```

**$.everydayPersonality.sensitive[0][0].lines[0]**

```text
>对方回了个哦，我都不知道什么意思。
```

**$.everydayPersonality.sensitive[0][0].lines[1]**

```text
也可能就是看到了。
```

**$.everydayPersonality.sensitive[0][0].lines[2]**

```text
>嗯，我准备直接问一句。
```

**$.everydayPersonality.sensitive[0][0].lines[3]**

```text
问吧，别在这儿猜半天。
```

**$.everydayPersonality.sensitive[0][1].title**

```text
小事有点烦
```

**$.everydayPersonality.sensitive[0][1].lines[0]**

```text
>有个小事，我好像想太久了。
```

**$.everydayPersonality.sensitive[0][1].lines[1]**

```text
什么事啊？
```

**$.everydayPersonality.sensitive[0][1].lines[2]**

```text
>其实挺小的，讲出来你别笑。
```

**$.everydayPersonality.sensitive[0][1].lines[3]**

```text
你先讲，我还没笑呢。
```

**$.everydayPersonality.sensitive[1][0].title**

```text
没回消息
```

**$.everydayPersonality.sensitive[1][0].lines[0]**

```text
>我刚才差点以为你不想回我。
```

**$.everydayPersonality.sensitive[1][0].lines[1]**

```text
我手里拿着东西，打不了字。
```

**$.everydayPersonality.sensitive[1][0].lines[2]**

```text
>哦，那我瞎想了。
```

**$.everydayPersonality.sensitive[1][0].lines[3]**

```text
没事，我看到了就会回。
```

**$.everydayPersonality.sensitive[1][1].title**

```text
记住的一句话
```

**$.everydayPersonality.sensitive[1][1].lines[0]**

```text
>你上次那句话，我后来又想了想。
```

**$.everydayPersonality.sensitive[1][1].lines[1]**

```text
我说啥了？
```

**$.everydayPersonality.sensitive[1][1].lines[2]**

```text
>等会儿，我找一下记录。
```

**$.everydayPersonality.sensitive[1][1].lines[3]**

```text
好，我也看看我到底说了啥。
```

**$.everydayPersonality.sensitive[2][0].title**

```text
直接问你
```

**$.everydayPersonality.sensitive[2][0].lines[0]**

```text
>我现在有不确定的就直接问你了。
```

**$.everydayPersonality.sensitive[2][0].lines[1]**

```text
问呗，省得猜错。
```

**$.everydayPersonality.sensitive[2][0].lines[2]**

```text
>那你刚才是真累了？
```

**$.everydayPersonality.sensitive[2][0].lines[3]**

```text
真累，没生你气。
```

**$.everydayPersonality.sensitive[2][1].title**

```text
小提醒
```

**$.everydayPersonality.sensitive[2][1].lines[0]**

```text
>我今天有点容易烦，不是冲你啊。
```

**$.everydayPersonality.sensitive[2][1].lines[1]**

```text
嗯，那咱们慢点说。
```

**$.everydayPersonality.sensitive[2][1].lines[2]**

```text
>我先喝口水。
```

**$.everydayPersonality.sensitive[2][1].lines[3]**

```text
好，我等你。
```

**$.everydayPersonality.balanced[0][0].title**

```text
想不想热闹
```

**$.everydayPersonality.balanced[0][0].lines[0]**

```text
>你现在想出去还是想待着？
```

**$.everydayPersonality.balanced[0][0].lines[1]**

```text
我偏想待一会儿。
```

**$.everydayPersonality.balanced[0][0].lines[2]**

```text
>行，我也没那么想动。
```

**$.everydayPersonality.balanced[0][0].lines[3]**

```text
那先不折腾。
```

**$.everydayPersonality.balanced[0][1].title**

```text
看当时状态
```

**$.everydayPersonality.balanced[0][1].lines[0]**

```text
>我有时候能聊好多，有时候就不想出声。
```

**$.everydayPersonality.balanced[0][1].lines[1]**

```text
我也是，看当天累不累。
```

**$.everydayPersonality.balanced[0][1].lines[2]**

```text
>所以没回很快也别多想。
```

**$.everydayPersonality.balanced[0][1].lines[3]**

```text
嗯，急事再喊一声。
```

**$.everydayPersonality.balanced[1][0].title**

```text
计划别太满
```

**$.everydayPersonality.balanced[1][0].lines[0]**

```text
>我把要做的记了两件，别的先空着。
```

**$.everydayPersonality.balanced[1][0].lines[1]**

```text
不怕临时想不起来？
```

**$.everydayPersonality.balanced[1][0].lines[2]**

```text
>想不起来就下回。
```

**$.everydayPersonality.balanced[1][0].lines[3]**

```text
行，你这清单看着不累。
```

**$.everydayPersonality.balanced[1][1].title**

```text
想法又变了
```

**$.everydayPersonality.balanced[1][1].lines[0]**

```text
>我刚才说那个，现在有点不确定。
```

**$.everydayPersonality.balanced[1][1].lines[1]**

```text
哪一部分？
```

**$.everydayPersonality.balanced[1][1].lines[2]**

```text
>后面那段，我再捋一下。
```

**$.everydayPersonality.balanced[1][1].lines[3]**

```text
好，没定下来就慢慢说。
```

**$.everydayPersonality.balanced[2][0].title**

```text
熟了就好问
```

**$.everydayPersonality.balanced[2][0].lines[0]**

```text
>我先直接问了啊。
```

**$.everydayPersonality.balanced[2][0].lines[1]**

```text
问吧。
```

**$.everydayPersonality.balanced[2][0].lines[2]**

```text
>你这会儿想聊，还是想自己待着？
```

**$.everydayPersonality.balanced[2][0].lines[3]**

```text
想聊两句，不过可能不多说。
```

**$.everydayPersonality.balanced[2][1].title**

```text
不用猜了
```

**$.everydayPersonality.balanced[2][1].lines[0]**

```text
>咱俩别一边说一边猜了。
```

**$.everydayPersonality.balanced[2][1].lines[1]**

```text
那你直接说想怎么弄。
```

**$.everydayPersonality.balanced[2][1].lines[2]**

```text
>我想先把眼前这点弄完。
```

**$.everydayPersonality.balanced[2][1].lines[3]**

```text
好，弄完再找我就行。
```
