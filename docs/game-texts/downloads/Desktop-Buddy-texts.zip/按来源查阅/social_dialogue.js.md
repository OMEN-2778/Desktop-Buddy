# prototype/demo/social_dialogue.js

**L17**

```text
聊到心里
```

**L60**

```text
慢慢认识
```

**L62**

```text
随口聊聊
```
