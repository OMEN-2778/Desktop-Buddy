# prototype/demo/npc_talk.json

**$.front.adult[0][0]**

```text
门口的猫
```

**$.front.adult[0][1]**

```text
那只猫是不是一直看着这边？
```

**$.front.adult[0][2]**

```text
>嗯，你一停下来它就抬头。
```

**$.front.adult[0][3]**

```text
我也没拿吃的啊。
```

**$.front.adult[0][4]**

```text
>可能等你走开，好下台阶。
```

**$.front.adult[1][0]**

```text
门牌记忆
```

**$.front.adult[1][1]**

```text
你住这附近？我怕记错门牌。
```

**$.front.adult[1][2]**

```text
>我也常看一眼，门都差不多。
```

**$.front.adult[1][3]**

```text
对，尤其天暗了以后。
```

**$.front.adult[1][4]**

```text
>看清再开，别闹误会。
```

**$.front.adult[2][0]**

```text
自行车铃
```

**$.front.adult[2][1]**

```text
刚才有车铃，我没听清。
```

**$.front.adult[2][2]**

```text
>有人从后面过，提醒让路呢。
```

**$.front.adult[2][3]**

```text
哦，我还回头找了半天。
```

**$.front.adult[2][4]**

```text
>现在过去了，没事。
```

**$.front.adult[3][0]**

```text
邻居的香味
```

**$.front.adult[3][1]**

```text
谁家做饭这么香。
```

**$.front.adult[3][2]**

```text
>好像前面那家，我刚走过来就闻见了。
```

**$.front.adult[3][3]**

```text
闻着像炒菜。
```

**$.front.adult[3][4]**

```text
>嗯，弄得我也想吃点东西。
```

**$.front.adult[4][0]**

```text
门口也旅行
```

**$.front.adult[4][1]**

```text
今天就在门口转转。
```

**$.front.adult[4][2]**

```text
>我也是，没打算走远。
```

**$.front.adult[4][3]**

```text
带了钥匙就下来了。
```

**$.front.adult[4][4]**

```text
>我还得回去拿个东西。
```

**$.front.adult[5][0]**

```text
空信箱
```

**$.front.adult[5][1]**

```text
信箱里又没东西。
```

**$.front.adult[5][2]**

```text
>最近信少了，都发手机上。
```

**$.front.adult[5][3]**

```text
是，我好久没开过。
```

**$.front.adult[5][4]**

```text
>偶尔看看，别漏了通知。
```

**$.front.adult[6][0]**

```text
台阶的休息
```

**$.front.adult[6][1]**

```text
这台阶能坐一下吧？
```

**$.front.adult[6][2]**

```text
>能，先看看有没有灰。
```

**$.front.adult[6][3]**

```text
我垫张纸。
```

**$.front.adult[6][4]**

```text
>这样行，坐着歇会儿。
```

**$.front.adult[7][0]**

```text
云的形状
```

**$.front.adult[7][1]**

```text
你看那朵云像不像狗？
```

**$.front.adult[7][2]**

```text
>我看像面包。
```

**$.front.adult[7][3]**

```text
你是不是没吃饭？
```

**$.front.adult[7][4]**

```text
>有点，一说还真饿了。
```

**$.front.adult[8][0]**

```text
忘带钥匙
```

**$.front.adult[8][1]**

```text
我出门得摸好几遍钥匙。
```

**$.front.adult[8][2]**

```text
>怕锁屋里吧。
```

**$.front.adult[8][3]**

```text
嗯，门一关还要再摸。
```

**$.front.adult[8][4]**

```text
>我也一样，真锁一次就记住了。
```

**$.front.adult[9][0]**

```text
小街的变化
```

**$.front.adult[9][1]**

```text
这边花盆是不是挪过了？
```

**$.front.adult[9][2]**

```text
>好像是，以前没靠这么外面。
```

**$.front.adult[9][3]**

```text
难怪走着觉得不一样。
```

**$.front.adult[9][4]**

```text
>留条路就行，别碰倒了。
```

**$.front.adult[10][0]**

```text
树下的风
```

**$.front.adult[10][1]**

```text
树下风大一点。
```

**$.front.adult[10][2]**

```text
>嗯，站这儿凉快。
```

**$.front.adult[10][3]**

```text
头发都吹乱了。
```

**$.front.adult[10][4]**

```text
>理一下，别挡着眼睛。
```

**$.front.adult[11][0]**

```text
影子的步伐
```

**$.front.adult[11][1]**

```text
影子拉这么长了。
```

**$.front.adult[11][2]**

```text
>嗯，你往这边站就看见了。
```

**$.front.adult[11][3]**

```text
刚一直在看手机，没注意。
```

**$.front.adult[11][4]**

```text
>走路还是看前面吧。
```

**$.front.adult[12][0]**

```text
路边小花
```

**$.front.adult[12][1]**

```text
墙缝里长了朵花。
```

**$.front.adult[12][2]**

```text
>还真是，我刚都没看见。
```

**$.front.adult[12][3]**

```text
土这么少也能长。
```

**$.front.adult[12][4]**

```text
>别碰它，拍张照就好。
```

**$.front.adult[13][0]**

```text
顺路相遇
```

**$.front.adult[13][1]**

```text
你好，好像在这儿见过你。
```

**$.front.adult[13][2]**

```text
>嗯，我有时候从这边走。
```

**$.front.adult[13][3]**

```text
我也住附近。
```

**$.front.adult[13][4]**

```text
>那以后估计还会碰见。
```

**$.front.adult[14][0]**

```text
遛自己
```

**$.front.adult[14][1]**

```text
没什么事，出来走两步。
```

**$.front.adult[14][2]**

```text
>我也是，屋里坐久了。
```

**$.front.adult[14][3]**

```text
不想跑太远。
```

**$.front.adult[14][4]**

```text
>那就在这边转一圈吧。
```

**$.front.adult[15][0]**

```text
门垫的欢迎
```

**$.front.adult[15][1]**

```text
你也有那个欢迎门垫？
```

**$.front.adult[15][2]**

```text
>有，买东西顺便带的。
```

**$.front.adult[15][3]**

```text
我老把字踩花。
```

**$.front.adult[15][4]**

```text
>我的也是，洗完还不太干净。
```

**$.front.adult[16][0]**

```text
猫的午觉
```

**$.front.adult[16][1]**

```text
猫还在那儿睡呢。
```

**$.front.adult[16][2]**

```text
>你刚才看见它了？
```

**$.front.adult[16][3]**

```text
嗯，我出去时就在那儿。
```

**$.front.adult[16][4]**

```text
>睡挺久了，叫一声也不动。
```

**$.front.adult[17][0]**

```text
街边长椅
```

**$.front.adult[17][1]**

```text
这儿有个能坐的地方挺好。
```

**$.front.adult[17][2]**

```text
>嗯，买东西回来能歇一下。
```

**$.front.adult[17][3]**

```text
拎着东西走久了手疼。
```

**$.front.adult[17][4]**

```text
>下次少拎点，分两趟吧。
```

**$.front.adult[18][0]**

```text
路灯报到
```

**$.front.adult[18][1]**

```text
这边路灯亮得挺准时。
```

**$.front.adult[18][2]**

```text
>嗯，暗下来就会开。
```

**$.front.adult[18][3]**

```text
我回家都靠这几盏认路。
```

**$.front.adult[18][4]**

```text
>我也是，灯下门牌好看清点。
```

**$.front.adult[19][0]**

```text
擦肩的招呼
```

**$.front.adult[19][1]**

```text
刚差点认错人了。
```

**$.front.adult[19][2]**

```text
>我像你认识的人？
```

**$.front.adult[19][3]**

```text
背影有点像，转过来就不像了。
```

**$.front.adult[19][4]**

```text
>还好没叫错名字。
```

**$.front.adult[20][0]**

```text
花盆搬家
```

**$.front.adult[20][1]**

```text
这花盆挪位置了吧？
```

**$.front.adult[20][2]**

```text
>是，我记得原来靠里面。
```

**$.front.adult[20][3]**

```text
我还以为自己记错了。
```

**$.front.adult[20][4]**

```text
>往外一点更晒得着。
```

**$.front.adult[21][0]**

```text
晚饭的讨论
```

**$.front.adult[21][1]**

```text
每天从这儿过都闻见饭香。
```

**$.front.adult[21][2]**

```text
>有时候闻着就知道做什么。
```

**$.front.adult[21][3]**

```text
今天这个没猜出来。
```

**$.front.adult[21][4]**

```text
>我也没，像是放了不少葱。
```

**$.front.adult[22][0]**

```text
小小的好事
```

**$.front.adult[22][1]**

```text
刚有人帮我扶住门了。
```

**$.front.adult[22][2]**

```text
>你手里东西多？
```

**$.front.adult[22][3]**

```text
嗯，差点腾不出手。
```

**$.front.adult[22][4]**

```text
>还好有人在旁边。
```

**$.front.adult[23][0]**

```text
回家以前
```

**$.front.adult[23][1]**

```text
出来一圈，还是想回家坐着。
```

**$.front.adult[23][2]**

```text
>走累了？
```

**$.front.adult[23][3]**

```text
有一点，没换舒服的鞋。
```

**$.front.adult[23][4]**

```text
>那别走远了，早点回。
```

**$.front.adult[24][0]**

```text
借一声问候
```

**$.front.adult[24][1].mm**

```text
{对方称呼}，刚才没好意思打招呼。
```

**$.front.adult[24][1].mf**

```text
你好，刚才没好意思打招呼。
```

**$.front.adult[24][1].fm**

```text
你好，{对方称呼}，刚才没好意思打招呼。
```

**$.front.adult[24][1].ff**

```text
你好，刚才没好意思打招呼。
```

**$.front.adult[24][2].mm**

```text
>{主角称呼}，怎么了，怕认错？
```

**$.front.adult[24][2].mf**

```text
>怎么了，怕认错？
```

**$.front.adult[24][2].fm**

```text
>怎么了，怕认错？
```

**$.front.adult[24][2].ff**

```text
>{主角称呼}，怎么了，怕认错？
```

**$.front.adult[24][3]**

```text
有点，你转身才看清。
```

**$.front.adult[24][4]**

```text
>哦，是我，没认错。
```

**$.front.adult[25][0]**

```text
多出来的晴朗
```

**$.front.adult[25][1].mm**

```text
{对方称呼}，出来以后好一点，没那么闷。
```

**$.front.adult[25][1].mf**

```text
你好，出来以后好一点，没那么闷。
```

**$.front.adult[25][1].fm**

```text
你好，{对方称呼}，出来以后好一点，没那么闷。
```

**$.front.adult[25][1].ff**

```text
你好，出来以后好一点，没那么闷。
```

**$.front.adult[25][2].mm**

```text
>{主角称呼}，屋里待久了吧。
```

**$.front.adult[25][2].mf**

```text
>屋里待久了吧。
```

**$.front.adult[25][2].fm**

```text
>屋里待久了吧。
```

**$.front.adult[25][2].ff**

```text
>{主角称呼}，屋里待久了吧。
```

**$.front.adult[25][3]**

```text
嗯，坐了好半天。
```

**$.front.adult[25][4]**

```text
>那再走两步，别老坐着。
```

**$.front.adult[26][0]**

```text
小街的音量
```

**$.front.adult[26][1].mm**

```text
{对方称呼}，这条街平时也这么安静？
```

**$.front.adult[26][1].mf**

```text
你好，这条街平时也这么安静？
```

**$.front.adult[26][1].fm**

```text
你好，{对方称呼}，这条街平时也这么安静？
```

**$.front.adult[26][1].ff**

```text
你好，这条街平时也这么安静？
```

**$.front.adult[26][2].mm**

```text
>{主角称呼}，大部分时候是，偶尔有车过。
```

**$.front.adult[26][2].mf**

```text
>大部分时候是，偶尔有车过。
```

**$.front.adult[26][2].fm**

```text
>大部分时候是，偶尔有车过。
```

**$.front.adult[26][2].ff**

```text
>{主角称呼}，大部分时候是，偶尔有车过。
```

**$.front.adult[26][3]**

```text
我刚听见关门声。
```

**$.front.adult[26][4]**

```text
>嗯，旁边那家有人出来。
```

**$.front.adult[27][0]**

```text
同一阵风
```

**$.front.adult[27][1].mm**

```text
{对方称呼}，风是不是吹眼睛里了？
```

**$.front.adult[27][1].mf**

```text
你好，风是不是吹眼睛里了？
```

**$.front.adult[27][1].fm**

```text
你好，{对方称呼}，风是不是吹眼睛里了？
```

**$.front.adult[27][1].ff**

```text
你好，风是不是吹眼睛里了？
```

**$.front.adult[27][2].mm**

```text
>{主角称呼}，有一点，你也是？
```

**$.front.adult[27][2].mf**

```text
>有一点，你也是？
```

**$.front.adult[27][2].fm**

```text
>有一点，你也是？
```

**$.front.adult[27][2].ff**

```text
>{主角称呼}，有一点，你也是？
```

**$.front.adult[27][3]**

```text
对，刚一下没睁开。
```

**$.front.adult[27][4]**

```text
>背着风站会儿就好了。
```

**$.front.adult[28][0]**

```text
半条街的远方
```

**$.front.adult[28][1].mm**

```text
{对方称呼}，今天打算走到哪儿？
```

**$.front.adult[28][1].mf**

```text
你好，今天打算走到哪儿？
```

**$.front.adult[28][1].fm**

```text
你好，{对方称呼}，今天打算走到哪儿？
```

**$.front.adult[28][1].ff**

```text
你好，今天打算走到哪儿？
```

**$.front.adult[28][2].mm**

```text
>{主角称呼}，先到前面路口。
```

**$.front.adult[28][2].mf**

```text
>先到前面路口。
```

**$.front.adult[28][2].fm**

```text
>先到前面路口。
```

**$.front.adult[28][2].ff**

```text
>{主角称呼}，先到前面路口。
```

**$.front.adult[28][3]**

```text
然后回来？
```

**$.front.adult[28][4]**

```text
>嗯，不想走太远。
```

**$.front.adult[29][0]**

```text
还没想好的话
```

**$.front.adult[29][1].mm**

```text
{对方称呼}，刚想问你件事，又忘了。
```

**$.front.adult[29][1].mf**

```text
你好，刚想问你件事，又忘了。
```

**$.front.adult[29][1].fm**

```text
你好，{对方称呼}，刚想问你件事，又忘了。
```

**$.front.adult[29][1].ff**

```text
你好，刚想问你件事，又忘了。
```

**$.front.adult[29][2].mm**

```text
>{主角称呼}，什么方面的？
```

**$.front.adult[29][2].mf**

```text
>什么方面的？
```

**$.front.adult[29][2].fm**

```text
>什么方面的？
```

**$.front.adult[29][2].ff**

```text
>{主角称呼}，什么方面的？
```

**$.front.adult[29][3]**

```text
好像是问路，不对……
```

**$.front.adult[29][4]**

```text
>想起来再问，我还在这边。
```

**$.front.adult[30][0]**

```text
门边的植物
```

**$.front.adult[30][1].mm**

```text
{对方称呼}，这盆叶子都朝外长。
```

**$.front.adult[30][1].mf**

```text
你好，这盆叶子都朝外长。
```

**$.front.adult[30][1].fm**

```text
你好，{对方称呼}，这盆叶子都朝外长。
```

**$.front.adult[30][1].ff**

```text
你好，这盆叶子都朝外长。
```

**$.front.adult[30][2].mm**

```text
>{主角称呼}，外面光多一点吧。
```

**$.front.adult[30][2].mf**

```text
>外面光多一点吧。
```

**$.front.adult[30][2].fm**

```text
>外面光多一点吧。
```

**$.front.adult[30][2].ff**

```text
>{主角称呼}，外面光多一点吧。
```

**$.front.adult[30][3]**

```text
难怪另一面稀。
```

**$.front.adult[30][4]**

```text
>转个方向可能好点。
```

**$.front.adult[31][0]**

```text
鞋底的小石子
```

**$.front.adult[31][1].mm**

```text
{对方称呼}，我鞋底好像卡东西了。
```

**$.front.adult[31][1].mf**

```text
你好，我鞋底好像卡东西了。
```

**$.front.adult[31][1].fm**

```text
你好，{对方称呼}，我鞋底好像卡东西了。
```

**$.front.adult[31][1].ff**

```text
你好，我鞋底好像卡东西了。
```

**$.front.adult[31][2].mm**

```text
>{主角称呼}，看看是不是小石子。
```

**$.front.adult[31][2].mf**

```text
>看看是不是小石子。
```

**$.front.adult[31][2].fm**

```text
>看看是不是小石子。
```

**$.front.adult[31][2].ff**

```text
>{主角称呼}，看看是不是小石子。
```

**$.front.adult[31][3]**

```text
还真是，夹缝里了。
```

**$.front.adult[31][4]**

```text
>拿出来吧，走久了不舒服。
```

**$.front.adult[32][0]**

```text
路口的停顿
```

**$.front.adult[32][1].mm**

```text
{对方称呼}，我在这儿停一下。
```

**$.front.adult[32][1].mf**

```text
你好，我在这儿停一下。
```

**$.front.adult[32][1].fm**

```text
你好，{对方称呼}，我在这儿停一下。
```

**$.front.adult[32][1].ff**

```text
你好，我在这儿停一下。
```

**$.front.adult[32][2].mm**

```text
>{主角称呼}，好，往边上站点。
```

**$.front.adult[32][2].mf**

```text
>好，往边上站点。
```

**$.front.adult[32][2].fm**

```text
>好，往边上站点。
```

**$.front.adult[32][2].ff**

```text
>{主角称呼}，好，往边上站点。
```

**$.front.adult[32][3]**

```text
嗯，不挡着人。
```

**$.front.adult[32][4]**

```text
>这儿来回走的人不少。
```

**$.front.adult[33][0]**

```text
邻居的窗帘
```

**$.front.adult[33][1].mm**

```text
{对方称呼}，那家是不是换窗帘了？
```

**$.front.adult[33][1].mf**

```text
你好，那家是不是换窗帘了？
```

**$.front.adult[33][1].fm**

```text
你好，{对方称呼}，那家是不是换窗帘了？
```

**$.front.adult[33][1].ff**

```text
你好，那家是不是换窗帘了？
```

**$.front.adult[33][2].mm**

```text
>{主角称呼}，好像换了，原来深一点。
```

**$.front.adult[33][2].mf**

```text
>好像换了，原来深一点。
```

**$.front.adult[33][2].fm**

```text
>好像换了，原来深一点。
```

**$.front.adult[33][2].ff**

```text
>{主角称呼}，好像换了，原来深一点。
```

**$.front.adult[33][3]**

```text
今天才注意到。
```

**$.front.adult[33][4]**

```text
>我刚也看了一眼。
```

**$.front.adult[34][0]**

```text
忘记看手机
```

**$.front.adult[34][1].mm**

```text
{对方称呼}，出来半天都没看手机。
```

**$.front.adult[34][1].mf**

```text
你好，出来半天都没看手机。
```

**$.front.adult[34][1].fm**

```text
你好，{对方称呼}，出来半天都没看手机。
```

**$.front.adult[34][1].ff**

```text
你好，出来半天都没看手机。
```

**$.front.adult[34][2].mm**

```text
>{主角称呼}，有消息吗？
```

**$.front.adult[34][2].mf**

```text
>有消息吗？
```

**$.front.adult[34][2].fm**

```text
>有消息吗？
```

**$.front.adult[34][2].ff**

```text
>{主角称呼}，有消息吗？
```

**$.front.adult[34][3]**

```text
没几条，不急。
```

**$.front.adult[34][4]**

```text
>那晚点再看也行。
```

**$.front.adult[35][0]**

```text
鞋子的泥点
```

**$.front.adult[35][1].mm**

```text
{对方称呼}，鞋上这点泥怎么蹭的。
```

**$.front.adult[35][1].mf**

```text
你好，鞋上这点泥怎么蹭的。
```

**$.front.adult[35][1].fm**

```text
你好，{对方称呼}，鞋上这点泥怎么蹭的。
```

**$.front.adult[35][1].ff**

```text
你好，鞋上这点泥怎么蹭的。
```

**$.front.adult[35][2].mm**

```text
>{主角称呼}，刚走过那块土吧。
```

**$.front.adult[35][2].mf**

```text
>刚走过那块土吧。
```

**$.front.adult[35][2].fm**

```text
>刚走过那块土吧。
```

**$.front.adult[35][2].ff**

```text
>{主角称呼}，刚走过那块土吧。
```

**$.front.adult[35][3]**

```text
可能，回去得擦一下。
```

**$.front.adult[35][4]**

```text
>先别拿手抹，越抹越脏。
```

**$.front.adult[36][0]**

```text
门口的勇气
```

**$.front.adult[36][1].mm**

```text
{对方称呼}，有时候在家待久了就懒得出门。
```

**$.front.adult[36][1].mf**

```text
你好，有时候在家待久了就懒得出门。
```

**$.front.adult[36][1].fm**

```text
你好，{对方称呼}，有时候在家待久了就懒得出门。
```

**$.front.adult[36][1].ff**

```text
你好，有时候在家待久了就懒得出门。
```

**$.front.adult[36][2].mm**

```text
>{主角称呼}，我也会，穿鞋都磨蹭。
```

**$.front.adult[36][2].mf**

```text
>我也会，穿鞋都磨蹭。
```

**$.front.adult[36][2].fm**

```text
>我也会，穿鞋都磨蹭。
```

**$.front.adult[36][2].ff**

```text
>{主角称呼}，我也会，穿鞋都磨蹭。
```

**$.front.adult[36][3]**

```text
今天总算下来了。
```

**$.front.adult[36][4]**

```text
>出来走走还行吧？
```

**$.front.adult[37][0]**

```text
铃声的误会
```

**$.front.adult[37][1].mm**

```text
{对方称呼}，刚以为我手机响了。
```

**$.front.adult[37][1].mf**

```text
你好，刚以为我手机响了。
```

**$.front.adult[37][1].fm**

```text
你好，{对方称呼}，刚以为我手机响了。
```

**$.front.adult[37][1].ff**

```text
你好，刚以为我手机响了。
```

**$.front.adult[37][2].mm**

```text
>{主角称呼}，是不是旁边自行车的铃？
```

**$.front.adult[37][2].mf**

```text
>是不是旁边自行车的铃？
```

**$.front.adult[37][2].fm**

```text
>是不是旁边自行车的铃？
```

**$.front.adult[37][2].ff**

```text
>{主角称呼}，是不是旁边自行车的铃？
```

**$.front.adult[37][3]**

```text
嗯，拿出来才发现没有。
```

**$.front.adult[37][4]**

```text
>铃声太像了吧。
```

**$.front.adult[38][0]**

```text
小街考古
```

**$.front.adult[38][1].mm**

```text
{对方称呼}，这块砖我以前都没注意。
```

**$.front.adult[38][1].mf**

```text
你好，这块砖我以前都没注意。
```

**$.front.adult[38][1].fm**

```text
你好，{对方称呼}，这块砖我以前都没注意。
```

**$.front.adult[38][1].ff**

```text
你好，这块砖我以前都没注意。
```

**$.front.adult[38][2].mm**

```text
>{主角称呼}，边上是不是补过？
```

**$.front.adult[38][2].mf**

```text
>边上是不是补过？
```

**$.front.adult[38][2].fm**

```text
>边上是不是补过？
```

**$.front.adult[38][2].ff**

```text
>{主角称呼}，边上是不是补过？
```

**$.front.adult[38][3]**

```text
对，颜色不一样。
```

**$.front.adult[38][4]**

```text
>我也没发现，走路总顾别的。
```

**$.front.adult[39][0]**

```text
散步的伴奏
```

**$.front.adult[39][1].mm**

```text
{对方称呼}，钥匙在兜里一直响。
```

**$.front.adult[39][1].mf**

```text
你好，钥匙在兜里一直响。
```

**$.front.adult[39][1].fm**

```text
你好，{对方称呼}，钥匙在兜里一直响。
```

**$.front.adult[39][1].ff**

```text
你好，钥匙在兜里一直响。
```

**$.front.adult[39][2].mm**

```text
>{主角称呼}，是不是钥匙圈松了？
```

**$.front.adult[39][2].mf**

```text
>是不是钥匙圈松了？
```

**$.front.adult[39][2].fm**

```text
>是不是钥匙圈松了？
```

**$.front.adult[39][2].ff**

```text
>{主角称呼}，是不是钥匙圈松了？
```

**$.front.adult[39][3]**

```text
没有，就是碰一起。
```

**$.front.adult[39][4]**

```text
>那换个口袋呢，别掉了。
```

**$.front.adult[40][0]**

```text
临时的目的地
```

**$.front.adult[40][1].mm**

```text
{对方称呼}，出门没想好去哪。
```

**$.front.adult[40][1].mf**

```text
你好，出门没想好去哪。
```

**$.front.adult[40][1].fm**

```text
你好，{对方称呼}，出门没想好去哪。
```

**$.front.adult[40][1].ff**

```text
你好，出门没想好去哪。
```

**$.front.adult[40][2].mm**

```text
>{主角称呼}，我也是，先走着。
```

**$.front.adult[40][2].mf**

```text
>我也是，先走着。
```

**$.front.adult[40][2].fm**

```text
>我也是，先走着。
```

**$.front.adult[40][2].ff**

```text
>{主角称呼}，我也是，先走着。
```

**$.front.adult[40][3]**

```text
走到这儿正好碰见你。
```

**$.front.adult[40][4]**

```text
>那聊两句再走。
```

**$.front.adult[41][0]**

```text
猫的许可
```

**$.front.adult[41][1].mm**

```text
{对方称呼}，我看猫半天，它也没跑。
```

**$.front.adult[41][1].mf**

```text
你好，我看猫半天，它也没跑。
```

**$.front.adult[41][1].fm**

```text
你好，{对方称呼}，我看猫半天，它也没跑。
```

**$.front.adult[41][1].ff**

```text
你好，我看猫半天，它也没跑。
```

**$.front.adult[41][2].mm**

```text
>{主角称呼}，你别走太近，远点它不管。
```

**$.front.adult[41][2].mf**

```text
>你别走太近，远点它不管。
```

**$.front.adult[41][2].fm**

```text
>你别走太近，远点它不管。
```

**$.front.adult[41][2].ff**

```text
>{主角称呼}，你别走太近，远点它不管。
```

**$.front.adult[41][3]**

```text
就站这儿吧。
```

**$.front.adult[41][4]**

```text
>嗯，别拿手逗它。
```

**$.front.adult[42][0]**

```text
多看一眼
```

**$.front.adult[42][1].mm**

```text
{对方称呼}，路过这门我总看一眼。
```

**$.front.adult[42][1].mf**

```text
你好，路过这门我总看一眼。
```

**$.front.adult[42][1].fm**

```text
你好，{对方称呼}，路过这门我总看一眼。
```

**$.front.adult[42][1].ff**

```text
你好，路过这门我总看一眼。
```

**$.front.adult[42][2].mm**

```text
>{主角称呼}，以前认识住这儿的人？
```

**$.front.adult[42][2].mf**

```text
>以前认识住这儿的人？
```

**$.front.adult[42][2].fm**

```text
>以前认识住这儿的人？
```

**$.front.adult[42][2].ff**

```text
>{主角称呼}，以前认识住这儿的人？
```

**$.front.adult[42][3]**

```text
没有，就是觉得门挺好认。
```

**$.front.adult[42][4]**

```text
>哦，颜色跟旁边不一样。
```

**$.front.adult[43][0]**

```text
被风打断
```

**$.front.adult[43][1].mm**

```text
{对方称呼}，风太大，刚才没说清。
```

**$.front.adult[43][1].mf**

```text
你好，风太大，刚才没说清。
```

**$.front.adult[43][1].fm**

```text
你好，{对方称呼}，风太大，刚才没说清。
```

**$.front.adult[43][1].ff**

```text
你好，风太大，刚才没说清。
```

**$.front.adult[43][2].mm**

```text
>{主角称呼}，你再说一遍？
```

**$.front.adult[43][2].mf**

```text
>你再说一遍？
```

**$.front.adult[43][2].fm**

```text
>你再说一遍？
```

**$.front.adult[43][2].ff**

```text
>{主角称呼}，你再说一遍？
```

**$.front.adult[43][3]**

```text
我是问前面那家开门没。
```

**$.front.adult[43][4]**

```text
>刚才看着开了，你过去看看。
```

**$.front.adult[44][0]**

```text
小小的礼让
```

**$.front.adult[44][1].mm**

```text
{对方称呼}，咱俩差点又让同一边了。
```

**$.front.adult[44][1].mf**

```text
你好，咱俩差点又让同一边了。
```

**$.front.adult[44][1].fm**

```text
你好，{对方称呼}，咱俩差点又让同一边了。
```

**$.front.adult[44][1].ff**

```text
你好，咱俩差点又让同一边了。
```

**$.front.adult[44][2].mm**

```text
>{主角称呼}，你先走，我站着。
```

**$.front.adult[44][2].mf**

```text
>你先走，我站着。
```

**$.front.adult[44][2].fm**

```text
>你先走，我站着。
```

**$.front.adult[44][2].ff**

```text
>{主角称呼}，你先走，我站着。
```

**$.front.adult[44][3]**

```text
好，这回别一起动。
```

**$.front.adult[44][4]**

```text
>嗯，你过吧。
```

**$.front.adult[45][0]**

```text
不必说服自己
```

**$.front.adult[45][1].mm**

```text
{对方称呼}，散个步还老想找个理由。
```

**$.front.adult[45][1].mf**

```text
你好，散个步还老想找个理由。
```

**$.front.adult[45][1].fm**

```text
你好，{对方称呼}，散个步还老想找个理由。
```

**$.front.adult[45][1].ff**

```text
你好，散个步还老想找个理由。
```

**$.front.adult[45][2].mm**

```text
>{主角称呼}，没事出来走走不就行。
```

**$.front.adult[45][2].mf**

```text
>没事出来走走不就行。
```

**$.front.adult[45][2].fm**

```text
>没事出来走走不就行。
```

**$.front.adult[45][2].ff**

```text
>{主角称呼}，没事出来走走不就行。
```

**$.front.adult[45][3]**

```text
也是，也没谁问。
```

**$.front.adult[45][4]**

```text
>你就当下来透口气。
```

**$.front.adult[46][0]**

```text
走回来的意义
```

**$.front.adult[46][1].mm**

```text
{对方称呼}，绕一圈又回来了。
```

**$.front.adult[46][1].mf**

```text
你好，绕一圈又回来了。
```

**$.front.adult[46][1].fm**

```text
你好，{对方称呼}，绕一圈又回来了。
```

**$.front.adult[46][1].ff**

```text
你好，绕一圈又回来了。
```

**$.front.adult[46][2].mm**

```text
>{主角称呼}，没走很远吧。
```

**$.front.adult[46][2].mf**

```text
>没走很远吧。
```

**$.front.adult[46][2].fm**

```text
>没走很远吧。
```

**$.front.adult[46][2].ff**

```text
>{主角称呼}，没走很远吧。
```

**$.front.adult[46][3]**

```text
嗯，刚到路口就转了。
```

**$.front.adult[46][4]**

```text
>这样也好，省得太累。
```

**$.front.adult[47][0]**

```text
约在下一次
```

**$.front.adult[47][1].mm**

```text
{对方称呼}，那下次碰见再聊。
```

**$.front.adult[47][1].mf**

```text
你好，那下次碰见再聊。
```

**$.front.adult[47][1].fm**

```text
你好，{对方称呼}，那下次碰见再聊。
```

**$.front.adult[47][1].ff**

```text
你好，那下次碰见再聊。
```

**$.front.adult[47][2].mm**

```text
>{主角称呼}，好，我常走这边。
```

**$.front.adult[47][2].mf**

```text
>好，我常走这边。
```

**$.front.adult[47][2].fm**

```text
>好，我常走这边。
```

**$.front.adult[47][2].ff**

```text
>{主角称呼}，好，我常走这边。
```

**$.front.adult[47][3]**

```text
记住了。
```

**$.front.adult[47][4]**

```text
>嗯，回头见。
```

**$.front.kid[0][0]**

```text
数地砖
```

**$.front.kid[0][1]**

```text
你在数地上的砖吗？
```

**$.front.kid[0][2]**

```text
>对，可是有人经过，我就忘了数到哪块。
```

**$.front.kid[0][3]**

```text
可以给它们起名字试试。
```

**$.front.kid[0][4]**

```text
>那我先从这块饼干开始。
```

**$.front.kid[1][0]**

```text
叶子船
```

**$.front.kid[1][1]**

```text
这片叶子像小船。
```

**$.front.kid[1][2]**

```text
>可它没有水可以出发。
```

**$.front.kid[1][3]**

```text
先停在树边等天气吧。
```

**$.front.kid[1][4]**

```text
>好，我给它放半天假。
```

**$.front.kid[2][0]**

```text
猫的名字
```

**$.front.kid[2][1]**

```text
你认识窗台上的猫吗？
```

**$.front.kid[2][2]**

```text
>不认识，我每天给它换一个名字。
```

**$.front.kid[2][3]**

```text
它答应过哪个？
```

**$.front.kid[2][4]**

```text
>没有，它对我的创意很冷淡。
```

**$.front.kid[3][0]**

```text
影子赛跑
```

**$.front.kid[3][1]**

```text
你刚才是不是在跟影子比赛？
```

**$.front.kid[3][2]**

```text
>对，它一直贴着我，太难甩掉了。
```

**$.front.kid[3][3]**

```text
要不改成并排散步？
```

**$.front.kid[3][4]**

```text
>好，今天允许它当队友。
```

**$.front.kid[4][0]**

```text
小石子
```

**$.front.kid[4][1]**

```text
这颗石子摸起来好圆。
```

**$.front.kid[4][2]**

```text
>我挑了很久，它最像一颗土豆。
```

**$.front.kid[4][3]**

```text
看得出你认真选过。
```

**$.front.kid[4][4]**

```text
>谢谢，不过不能拿去煮。
```

**$.front.kid[5][0]**

```text
回家记号
```

**$.front.kid[5][1]**

```text
你怎么记得回家的路？
```

**$.front.kid[5][2]**

```text
>记住那盏灯，再记住门口那盆花。
```

**$.front.kid[5][3]**

```text
这个办法很牢靠。
```

**$.front.kid[5][4]**

```text
>我还记得，回家有拖鞋等我。
```

**$.front.kid[6][0]**

```text
认真的你好
```

**$.front.kid[6][1].mm**

```text
{对方称呼}，你刚才是不是想说什么？
```

**$.front.kid[6][1].mf**

```text
你好，你刚才是不是想说什么？
```

**$.front.kid[6][1].fm**

```text
你好，{对方称呼}，你刚才是不是想说什么？
```

**$.front.kid[6][1].ff**

```text
打个招呼，你刚才是不是想说什么？
```

**$.front.kid[6][2].mm**

```text
>{主角称呼}，嗯，想说你好，可是想了半天。
```

**$.front.kid[6][2].mf**

```text
>{主角称呼}，说起来，想说你好，可是想了半天。
```

**$.front.kid[6][2].fm**

```text
>{主角称呼}，其实，想说你好，可是想了半天。
```

**$.front.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，想说你好，可是想了半天。
```

**$.front.kid[6][3]**

```text
现在说也刚刚好。
```

**$.front.kid[6][4]**

```text
>你好，我没有迟到吧？
```

**$.front.kid[7][0]**

```text
小花的座位
```

**$.front.kid[7][1].mm**

```text
{对方称呼}，你给小花旁边留了块空地？
```

**$.front.kid[7][1].mf**

```text
你好，你给小花旁边留了块空地？
```

**$.front.kid[7][1].fm**

```text
你好，{对方称呼}，你给小花旁边留了块空地？
```

**$.front.kid[7][1].ff**

```text
打个招呼，你给小花旁边留了块空地？
```

**$.front.kid[7][2].mm**

```text
>{主角称呼}，说起来，我怕大家走路踩到它。
```

**$.front.kid[7][2].mf**

```text
>{主角称呼}，其实，我怕大家走路踩到它。
```

**$.front.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，我怕大家走路踩到它。
```

**$.front.kid[7][2].ff**

```text
>{主角称呼}，嗯，我怕大家走路踩到它。
```

**$.front.kid[7][3]**

```text
你替它想得很周到。
```

**$.front.kid[7][4]**

```text
>它这么小，得有人看见才行。
```

**$.front.kid[8][0]**

```text
门牌的小秘密
```

**$.front.kid[8][1].mm**

```text
{对方称呼}，你为什么盯着门牌看？
```

**$.front.kid[8][1].mf**

```text
你好，你为什么盯着门牌看？
```

**$.front.kid[8][1].fm**

```text
你好，{对方称呼}，你为什么盯着门牌看？
```

**$.front.kid[8][1].ff**

```text
打个招呼，你为什么盯着门牌看？
```

**$.front.kid[8][2].mm**

```text
>{主角称呼}，其实，它每次都写一样，我想看它会不会换。
```

**$.front.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，它每次都写一样，我想看它会不会换。
```

**$.front.kid[8][2].fm**

```text
>{主角称呼}，嗯，它每次都写一样，我想看它会不会换。
```

**$.front.kid[8][2].ff**

```text
>{主角称呼}，说起来，它每次都写一样，我想看它会不会换。
```

**$.front.kid[8][3]**

```text
今天有变化吗？
```

**$.front.kid[8][4]**

```text
>没有，它比我的作业认真。
```

**$.front.kid[9][0]**

```text
路边的朋友
```

**$.front.kid[9][1].mm**

```text
{对方称呼}，那只蚂蚁又来了？
```

**$.front.kid[9][1].mf**

```text
你好，那只蚂蚁又来了？
```

**$.front.kid[9][1].fm**

```text
你好，{对方称呼}，那只蚂蚁又来了？
```

**$.front.kid[9][1].ff**

```text
打个招呼，那只蚂蚁又来了？
```

**$.front.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，可能不是同一只，但我都问好。
```

**$.front.kid[9][2].mf**

```text
>{主角称呼}，嗯，可能不是同一只，但我都问好。
```

**$.front.kid[9][2].fm**

```text
>{主角称呼}，说起来，可能不是同一只，但我都问好。
```

**$.front.kid[9][2].ff**

```text
>{主角称呼}，其实，可能不是同一只，但我都问好。
```

**$.front.kid[9][3]**

```text
问候不太挑对象呀。
```

**$.front.kid[9][4]**

```text
>对，它们也很努力在走路。
```

**$.front.kid[10][0]**

```text
影子的礼貌
```

**$.front.kid[10][1].mm**

```text
{对方称呼}，怎么忽然往旁边站了？
```

**$.front.kid[10][1].mf**

```text
你好，怎么忽然往旁边站了？
```

**$.front.kid[10][1].fm**

```text
你好，{对方称呼}，怎么忽然往旁边站了？
```

**$.front.kid[10][1].ff**

```text
打个招呼，怎么忽然往旁边站了？
```

**$.front.kid[10][2].mm**

```text
>{主角称呼}，嗯，我怕影子挡住别人。
```

**$.front.kid[10][2].mf**

```text
>{主角称呼}，说起来，我怕影子挡住别人。
```

**$.front.kid[10][2].fm**

```text
>{主角称呼}，其实，我怕影子挡住别人。
```

**$.front.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，我怕影子挡住别人。
```

**$.front.kid[10][3]**

```text
它挡住也不会碰到人。
```

**$.front.kid[10][4]**

```text
>那我白替它紧张了一下。
```

**$.front.kid[11][0]**

```text
先说再见
```

**$.front.kid[11][1].mm**

```text
{对方称呼}，你怎么先挥起手了？
```

**$.front.kid[11][1].mf**

```text
你好，你怎么先挥起手了？
```

**$.front.kid[11][1].fm**

```text
你好，{对方称呼}，你怎么先挥起手了？
```

**$.front.kid[11][1].ff**

```text
打个招呼，你怎么先挥起手了？
```

**$.front.kid[11][2].mm**

```text
>{主角称呼}，说起来，我怕等会儿不好意思说再见。
```

**$.front.kid[11][2].mf**

```text
>{主角称呼}，其实，我怕等会儿不好意思说再见。
```

**$.front.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，我怕等会儿不好意思说再见。
```

**$.front.kid[11][2].ff**

```text
>{主角称呼}，嗯，我怕等会儿不好意思说再见。
```

**$.front.kid[11][3]**

```text
可以先好好聊完。
```

**$.front.kid[11][4]**

```text
>好，那我把手收回来等一会儿。
```

**$.park_gazebo.adult[0][0]**

```text
亭子的风
```

**$.park_gazebo.adult[0][1]**

```text
这边是不是凉快些？
```

**$.park_gazebo.adult[0][2]**

```text
>亭子通风，坐里面还好。
```

**$.park_gazebo.adult[0][3]**

```text
刚走过来有点热。
```

**$.park_gazebo.adult[0][4]**

```text
>坐一会儿就好了。
```

**$.park_gazebo.adult[1][0]**

```text
湖面的倒影
```

**$.park_gazebo.adult[1][1]**

```text
水里倒影还挺清楚。
```

**$.park_gazebo.adult[1][2]**

```text
>风一大就散了。
```

**$.park_gazebo.adult[1][3]**

```text
我刚想拍一张。
```

**$.park_gazebo.adult[1][4]**

```text
>等会儿看看能不能拍到。
```

**$.park_gazebo.adult[2][0]**

```text
栏杆上的鸟
```

**$.park_gazebo.adult[2][1]**

```text
栏杆那只鸟站好久了。
```

**$.park_gazebo.adult[2][2]**

```text
>你一靠近它估计就飞。
```

**$.park_gazebo.adult[2][3]**

```text
那我站这儿看。
```

**$.park_gazebo.adult[2][4]**

```text
>嗯，别惊着它。
```

**$.park_gazebo.adult[3][0]**

```text
小坐一下
```

**$.park_gazebo.adult[3][1]**

```text
本来只想从这儿路过。
```

**$.park_gazebo.adult[3][2]**

```text
>结果坐下就不想起了？
```

**$.park_gazebo.adult[3][3]**

```text
是，腿刚缓过来。
```

**$.park_gazebo.adult[3][4]**

```text
>我也是，歇够再走。
```

**$.park_gazebo.adult[4][0]**

```text
湖风翻页
```

**$.park_gazebo.adult[4][1]**

```text
在这儿看书，风老吹页。
```

**$.park_gazebo.adult[4][2]**

```text
>拿个东西压一下呢？
```

**$.park_gazebo.adult[4][3]**

```text
我先用手按着。
```

**$.park_gazebo.adult[4][4]**

```text
>别按太紧，翻页时容易撕。
```

**$.park_gazebo.adult[5][0]**

```text
远近的声音
```

**$.park_gazebo.adult[5][1]**

```text
对岸有人说话，还能听见。
```

**$.park_gazebo.adult[5][2]**

```text
>隔着水传过来，听不太清。
```

**$.park_gazebo.adult[5][3]**

```text
对，就听见几声。
```

**$.park_gazebo.adult[5][4]**

```text
>我刚还以为在后面。
```

**$.park_gazebo.adult[6][0]**

```text
亭柱的影子
```

**$.park_gazebo.adult[6][1]**

```text
柱子影子都移过来了。
```

**$.park_gazebo.adult[6][2]**

```text
>太阳换位置了吧。
```

**$.park_gazebo.adult[6][3]**

```text
我坐这儿有一会儿了。
```

**$.park_gazebo.adult[6][4]**

```text
>难怪，我刚来时没看见你。
```

**$.park_gazebo.adult[7][0]**

```text
拍照的手
```

**$.park_gazebo.adult[7][1]**

```text
湖怎么拍都拍不好。
```

**$.park_gazebo.adult[7][2]**

```text
>逆光？换一边试试。
```

**$.park_gazebo.adult[7][3]**

```text
换了，还是有点灰。
```

**$.park_gazebo.adult[7][4]**

```text
>那先别拍了，看看也挺好。
```

**$.park_gazebo.adult[8][0]**

```text
长椅评审
```

**$.park_gazebo.adult[8][1]**

```text
这座位硬不硬？
```

**$.park_gazebo.adult[8][2]**

```text
>坐一会儿还行，久了有点硬。
```

**$.park_gazebo.adult[8][3]**

```text
我就歇几分钟。
```

**$.park_gazebo.adult[8][4]**

```text
>那坐吧，这边没什么灰。
```

**$.park_gazebo.adult[9][0]**

```text
水边的静
```

**$.park_gazebo.adult[9][1]**

```text
这边比外面安静。
```

**$.park_gazebo.adult[9][2]**

```text
>嗯，路过的人没那么多。
```

**$.park_gazebo.adult[9][3]**

```text
刚才那边一直有人跑。
```

**$.park_gazebo.adult[9][4]**

```text
>跑步的多半走外圈。
```

**$.park_gazebo.adult[10][0]**

```text
檐下看天
```

**$.park_gazebo.adult[10][1]**

```text
从这里看出去像个画框。
```

**$.park_gazebo.adult[10][2]**

```text
>亭檐刚好挡住上面一点。
```

**$.park_gazebo.adult[10][3]**

```text
拍照应该不错。
```

**$.park_gazebo.adult[10][4]**

```text
>你试试，别拍进那根柱子。
```

**$.park_gazebo.adult[11][0]**

```text
湖里的云
```

**$.park_gazebo.adult[11][1]**

```text
水里的云看着挺近。
```

**$.park_gazebo.adult[11][2]**

```text
>看着近，岸边别往下探。
```

**$.park_gazebo.adult[11][3]**

```text
没想下去，就看一眼。
```

**$.park_gazebo.adult[11][4]**

```text
>嗯，边上有点滑。
```

**$.park_gazebo.adult[12][0]**

```text
一起找鸭子
```

**$.park_gazebo.adult[12][1]**

```text
刚才鸭子还在这儿呢。
```

**$.park_gazebo.adult[12][2]**

```text
>游到那边去了，芦苇后面。
```

**$.park_gazebo.adult[12][3]**

```text
哦，看见一点了。
```

**$.park_gazebo.adult[12][4]**

```text
>一会儿应该还会出来。
```

**$.park_gazebo.adult[13][0]**

```text
亭边的树
```

**$.park_gazebo.adult[13][1]**

```text
这树把半个亭子挡了。
```

**$.park_gazebo.adult[13][2]**

```text
>挺好的，太阳晒不到里面。
```

**$.park_gazebo.adult[13][3]**

```text
夏天坐这边应该舒服。
```

**$.park_gazebo.adult[13][4]**

```text
>嗯，就是有时候会掉点叶子。
```

**$.park_gazebo.adult[14][0]**

```text
微风的节奏
```

**$.park_gazebo.adult[14][1]**

```text
叶子一阵一阵响。
```

**$.park_gazebo.adult[14][2]**

```text
>风从湖那边过来。
```

**$.park_gazebo.adult[14][3]**

```text
不刮的时候还挺静。
```

**$.park_gazebo.adult[14][4]**

```text
>对，刚能听见那边有人咳了一声。
```

**$.park_gazebo.adult[15][0]**

```text
忘记带书
```

**$.park_gazebo.adult[15][1]**

```text
特地带书来看，结果书忘了。
```

**$.park_gazebo.adult[15][2]**

```text
>那就坐会儿，下回再带。
```

**$.park_gazebo.adult[15][3]**

```text
包都背来了，书没装进去。
```

**$.park_gazebo.adult[15][4]**

```text
>我也干过，背一堆用不上的。
```

**$.park_gazebo.adult[16][0]**

```text
对岸的路
```

**$.park_gazebo.adult[16][1]**

```text
对岸看着挺远的。
```

**$.park_gazebo.adult[16][2]**

```text
>绕着走得一会儿。
```

**$.park_gazebo.adult[16][3]**

```text
我还想过去看看。
```

**$.park_gazebo.adult[16][4]**

```text
>那慢慢走，别非得绕一整圈。
```

**$.park_gazebo.adult[17][0]**

```text
座位的礼貌
```

**$.park_gazebo.adult[17][1]**

```text
我坐这儿会不会挡住你？
```

**$.park_gazebo.adult[17][2]**

```text
>不会，我看那边呢。
```

**$.park_gazebo.adult[17][3]**

```text
好，谢谢。
```

**$.park_gazebo.adult[17][4]**

```text
>你坐吧，空着的。
```

**$.park_gazebo.adult[18][0]**

```text
湖边猜风
```

**$.park_gazebo.adult[18][1]**

```text
看水纹能知道风往哪吹吗？
```

**$.park_gazebo.adult[18][2]**

```text
>大概往那边，你看那一片。
```

**$.park_gazebo.adult[18][3]**

```text
我有点看不出来。
```

**$.park_gazebo.adult[18][4]**

```text
>看叶子可能更明显。
```

**$.park_gazebo.adult[19][0]**

```text
亭子的回声
```

**$.park_gazebo.adult[19][1]**

```text
这儿说话不用很大声。
```

**$.park_gazebo.adult[19][2]**

```text
>嗯，近点听得见。
```

**$.park_gazebo.adult[19][3]**

```text
刚才在外面我一直喊。
```

**$.park_gazebo.adult[19][4]**

```text
>外面风大，这边好一点。
```

**$.park_gazebo.adult[20][0]**

```text
落叶的漂流
```

**$.park_gazebo.adult[20][1]**

```text
那叶子漂好久了。
```

**$.park_gazebo.adult[20][2]**

```text
>打转呢，水往那边带。
```

**$.park_gazebo.adult[20][3]**

```text
刚才又绕回来了。
```

**$.park_gazebo.adult[20][4]**

```text
>可能一时漂不出去。
```

**$.park_gazebo.adult[21][0]**

```text
错把水声
```

**$.park_gazebo.adult[21][1]**

```text
刚以为有人叫我。
```

**$.park_gazebo.adult[21][2]**

```text
>是水拍岸的声音吧。
```

**$.park_gazebo.adult[21][3]**

```text
对，回头也没人。
```

**$.park_gazebo.adult[21][4]**

```text
>我刚也听见一下。
```

**$.park_gazebo.adult[22][0]**

```text
等一阵风
```

**$.park_gazebo.adult[22][1]**

```text
你在这儿等人吗？
```

**$.park_gazebo.adult[22][2]**

```text
>没有，歇一会儿。
```

**$.park_gazebo.adult[22][3]**

```text
我还以为你站好久是在等。
```

**$.park_gazebo.adult[22][4]**

```text
>刚坐久了，起来活动一下。
```

**$.park_gazebo.adult[23][0]**

```text
记住此刻
```

**$.park_gazebo.adult[23][1]**

```text
这里我以前来过一次。
```

**$.park_gazebo.adult[23][2]**

```text
>那时候也是这个样子？
```

**$.park_gazebo.adult[23][3]**

```text
差不多，树好像密点了。
```

**$.park_gazebo.adult[23][4]**

```text
>隔久了才看得出来。
```

**$.park_gazebo.adult[24][0]**

```text
并排的风景
```

**$.park_gazebo.adult[24][1].mm**

```text
{对方称呼}，刚走到这儿想找人聊两句。
```

**$.park_gazebo.adult[24][1].mf**

```text
你好，刚走到这儿想找人聊两句。
```

**$.park_gazebo.adult[24][1].fm**

```text
你好，{对方称呼}，刚走到这儿想找人聊两句。
```

**$.park_gazebo.adult[24][1].ff**

```text
你好，刚走到这儿想找人聊两句。
```

**$.park_gazebo.adult[24][2].mm**

```text
>{主角称呼}，好啊，你从哪边过来的？
```

**$.park_gazebo.adult[24][2].mf**

```text
>好啊，你从哪边过来的？
```

**$.park_gazebo.adult[24][2].fm**

```text
>好啊，你从哪边过来的？
```

**$.park_gazebo.adult[24][2].ff**

```text
>{主角称呼}，好啊，你从哪边过来的？
```

**$.park_gazebo.adult[24][3]**

```text
中央那块草坪。
```

**$.park_gazebo.adult[24][4]**

```text
>我刚也从那边来。
```

**$.park_gazebo.adult[25][0]**

```text
亭檐的分镜
```

**$.park_gazebo.adult[25][1].mm**

```text
{对方称呼}，亭檐刚好挡掉上面一点。
```

**$.park_gazebo.adult[25][1].mf**

```text
你好，亭檐刚好挡掉上面一点。
```

**$.park_gazebo.adult[25][1].fm**

```text
你好，{对方称呼}，亭檐刚好挡掉上面一点。
```

**$.park_gazebo.adult[25][1].ff**

```text
你好，亭檐刚好挡掉上面一点。
```

**$.park_gazebo.adult[25][2].mm**

```text
>{主角称呼}，你拍照时别站太近。
```

**$.park_gazebo.adult[25][2].mf**

```text
>你拍照时别站太近。
```

**$.park_gazebo.adult[25][2].fm**

```text
>你拍照时别站太近。
```

**$.park_gazebo.adult[25][2].ff**

```text
>{主角称呼}，你拍照时别站太近。
```

**$.park_gazebo.adult[25][3]**

```text
往后点能拍全？
```

**$.park_gazebo.adult[25][4]**

```text
>嗯，不过再后面就是台阶了。
```

**$.park_gazebo.adult[26][0]**

```text
坐下的许可
```

**$.park_gazebo.adult[26][1].mm**

```text
{对方称呼}，有点累，又想多走一点。
```

**$.park_gazebo.adult[26][1].mf**

```text
你好，有点累，又想多走一点。
```

**$.park_gazebo.adult[26][1].fm**

```text
你好，{对方称呼}，有点累，又想多走一点。
```

**$.park_gazebo.adult[26][1].ff**

```text
你好，有点累，又想多走一点。
```

**$.park_gazebo.adult[26][2].mm**

```text
>{主角称呼}，先歇着，歇好了再看。
```

**$.park_gazebo.adult[26][2].mf**

```text
>先歇着，歇好了再看。
```

**$.park_gazebo.adult[26][2].fm**

```text
>先歇着，歇好了再看。
```

**$.park_gazebo.adult[26][2].ff**

```text
>{主角称呼}，先歇着，歇好了再看。
```

**$.park_gazebo.adult[26][3]**

```text
那我坐会儿。
```

**$.park_gazebo.adult[26][4]**

```text
>这边空着，你坐。
```

**$.park_gazebo.adult[27][0]**

```text
远处的说笑
```

**$.park_gazebo.adult[27][1].mm**

```text
{对方称呼}，对岸是不是有人笑？
```

**$.park_gazebo.adult[27][1].mf**

```text
你好，对岸是不是有人笑？
```

**$.park_gazebo.adult[27][1].fm**

```text
你好，{对方称呼}，对岸是不是有人笑？
```

**$.park_gazebo.adult[27][1].ff**

```text
你好，对岸是不是有人笑？
```

**$.park_gazebo.adult[27][2].mm**

```text
>{主角称呼}，听着像，但听不清说什么。
```

**$.park_gazebo.adult[27][2].mf**

```text
>听着像，但听不清说什么。
```

**$.park_gazebo.adult[27][2].fm**

```text
>听着像，但听不清说什么。
```

**$.park_gazebo.adult[27][2].ff**

```text
>{主角称呼}，听着像，但听不清说什么。
```

**$.park_gazebo.adult[27][3]**

```text
一阵一阵的。
```

**$.park_gazebo.adult[27][4]**

```text
>风吹过来才听得见。
```

**$.park_gazebo.adult[28][0]**

```text
慢半拍的水
```

**$.park_gazebo.adult[28][1].mm**

```text
{对方称呼}，风过去了，水纹还没散。
```

**$.park_gazebo.adult[28][1].mf**

```text
你好，风过去了，水纹还没散。
```

**$.park_gazebo.adult[28][1].fm**

```text
你好，{对方称呼}，风过去了，水纹还没散。
```

**$.park_gazebo.adult[28][1].ff**

```text
你好，风过去了，水纹还没散。
```

**$.park_gazebo.adult[28][2].mm**

```text
>{主角称呼}，要过一会儿吧。
```

**$.park_gazebo.adult[28][2].mf**

```text
>要过一会儿吧。
```

**$.park_gazebo.adult[28][2].fm**

```text
>要过一会儿吧。
```

**$.park_gazebo.adult[28][2].ff**

```text
>{主角称呼}，要过一会儿吧。
```

**$.park_gazebo.adult[28][3]**

```text
还一圈一圈往外。
```

**$.park_gazebo.adult[28][4]**

```text
>嗯，等下没风就平一点。
```

**$.park_gazebo.adult[29][0]**

```text
望湖的习惯
```

**$.park_gazebo.adult[29][1].mm**

```text
{对方称呼}，我每次来都先看湖。
```

**$.park_gazebo.adult[29][1].mf**

```text
你好，我每次来都先看湖。
```

**$.park_gazebo.adult[29][1].fm**

```text
你好，{对方称呼}，我每次来都先看湖。
```

**$.park_gazebo.adult[29][1].ff**

```text
你好，我每次来都先看湖。
```

**$.park_gazebo.adult[29][2].mm**

```text
>{主角称呼}，今天水看着还挺清。
```

**$.park_gazebo.adult[29][2].mf**

```text
>今天水看着还挺清。
```

**$.park_gazebo.adult[29][2].fm**

```text
>今天水看着还挺清。
```

**$.park_gazebo.adult[29][2].ff**

```text
>{主角称呼}，今天水看着还挺清。
```

**$.park_gazebo.adult[29][3]**

```text
是，比我上回来的时候清。
```

**$.park_gazebo.adult[29][4]**

```text
>前面那片能看见底。
```

**$.park_gazebo.adult[30][0]**

```text
亭柱的凉意
```

**$.park_gazebo.adult[30][1].mm**

```text
{对方称呼}，柱子摸着凉凉的。
```

**$.park_gazebo.adult[30][1].mf**

```text
你好，柱子摸着凉凉的。
```

**$.park_gazebo.adult[30][1].fm**

```text
你好，{对方称呼}，柱子摸着凉凉的。
```

**$.park_gazebo.adult[30][1].ff**

```text
你好，柱子摸着凉凉的。
```

**$.park_gazebo.adult[30][2].mm**

```text
>{主角称呼}，没晒到太阳吧。
```

**$.park_gazebo.adult[30][2].mf**

```text
>没晒到太阳吧。
```

**$.park_gazebo.adult[30][2].fm**

```text
>没晒到太阳吧。
```

**$.park_gazebo.adult[30][2].ff**

```text
>{主角称呼}，没晒到太阳吧。
```

**$.park_gazebo.adult[30][3]**

```text
我就碰了一下。
```

**$.park_gazebo.adult[30][4]**

```text
>这边一直在阴影里。
```

**$.park_gazebo.adult[31][0]**

```text
一块阴影
```

**$.park_gazebo.adult[31][1].mm**

```text
{对方称呼}，这块阴影刚好够站。
```

**$.park_gazebo.adult[31][1].mf**

```text
你好，这块阴影刚好够站。
```

**$.park_gazebo.adult[31][1].fm**

```text
你好，{对方称呼}，这块阴影刚好够站。
```

**$.park_gazebo.adult[31][1].ff**

```text
你好，这块阴影刚好够站。
```

**$.park_gazebo.adult[31][2].mm**

```text
>{主角称呼}，再往里面一点更凉。
```

**$.park_gazebo.adult[31][2].mf**

```text
>再往里面一点更凉。
```

**$.park_gazebo.adult[31][2].fm**

```text
>再往里面一点更凉。
```

**$.park_gazebo.adult[31][2].ff**

```text
>{主角称呼}，再往里面一点更凉。
```

**$.park_gazebo.adult[31][3]**

```text
嗯，也不晒脖子。
```

**$.park_gazebo.adult[31][4]**

```text
>坐里面也行，有空位。
```

**$.park_gazebo.adult[32][0]**

```text
水声的省略号
```

**$.park_gazebo.adult[32][1].mm**

```text
{对方称呼}，水声是一下一下的。
```

**$.park_gazebo.adult[32][1].mf**

```text
你好，水声是一下一下的。
```

**$.park_gazebo.adult[32][1].fm**

```text
你好，{对方称呼}，水声是一下一下的。
```

**$.park_gazebo.adult[32][1].ff**

```text
你好，水声是一下一下的。
```

**$.park_gazebo.adult[32][2].mm**

```text
>{主角称呼}，嗯，拍在同一块石头上。
```

**$.park_gazebo.adult[32][2].mf**

```text
>嗯，拍在同一块石头上。
```

**$.park_gazebo.adult[32][2].fm**

```text
>嗯，拍在同一块石头上。
```

**$.park_gazebo.adult[32][2].ff**

```text
>{主角称呼}，嗯，拍在同一块石头上。
```

**$.park_gazebo.adult[32][3]**

```text
我刚还以为谁在敲东西。
```

**$.park_gazebo.adult[32][4]**

```text
>看水一来就知道了。
```

**$.park_gazebo.adult[33][0]**

```text
忘了烦哪件事
```

**$.park_gazebo.adult[33][1].mm**

```text
{对方称呼}，站这儿忘了刚烦什么。
```

**$.park_gazebo.adult[33][1].mf**

```text
你好，站这儿忘了刚烦什么。
```

**$.park_gazebo.adult[33][1].fm**

```text
你好，{对方称呼}，站这儿忘了刚烦什么。
```

**$.park_gazebo.adult[33][1].ff**

```text
你好，站这儿忘了刚烦什么。
```

**$.park_gazebo.adult[33][2].mm**

```text
>{主角称呼}，那先别想起来了。
```

**$.park_gazebo.adult[33][2].mf**

```text
>那先别想起来了。
```

**$.park_gazebo.adult[33][2].fm**

```text
>那先别想起来了。
```

**$.park_gazebo.adult[33][2].ff**

```text
>{主角称呼}，那先别想起来了。
```

**$.park_gazebo.adult[33][3]**

```text
嗯，我再歇一会儿。
```

**$.park_gazebo.adult[33][4]**

```text
>等回去要办事了再说。
```

**$.park_gazebo.adult[34][0]**

```text
亭边的过客
```

**$.park_gazebo.adult[34][1].mm**

```text
{对方称呼}，从这儿路过的人挺多。
```

**$.park_gazebo.adult[34][1].mf**

```text
你好，从这儿路过的人挺多。
```

**$.park_gazebo.adult[34][1].fm**

```text
你好，{对方称呼}，从这儿路过的人挺多。
```

**$.park_gazebo.adult[34][1].ff**

```text
你好，从这儿路过的人挺多。
```

**$.park_gazebo.adult[34][2].mm**

```text
>{主角称呼}，都往湖边走。
```

**$.park_gazebo.adult[34][2].mf**

```text
>都往湖边走。
```

**$.park_gazebo.adult[34][2].fm**

```text
>都往湖边走。
```

**$.park_gazebo.adult[34][2].ff**

```text
>{主角称呼}，都往湖边走。
```

**$.park_gazebo.adult[34][3]**

```text
刚才有人又绕回来了。
```

**$.park_gazebo.adult[34][4]**

```text
>可能也跟我们一样，走走停停。
```

**$.park_gazebo.adult[35][0]**

```text
不用拍好的照片
```

**$.park_gazebo.adult[35][1].mm**

```text
{对方称呼}，我拍出来亭子总有点歪。
```

**$.park_gazebo.adult[35][1].mf**

```text
你好，我拍出来亭子总有点歪。
```

**$.park_gazebo.adult[35][1].fm**

```text
你好，{对方称呼}，我拍出来亭子总有点歪。
```

**$.park_gazebo.adult[35][1].ff**

```text
你好，我拍出来亭子总有点歪。
```

**$.park_gazebo.adult[35][2].mm**

```text
>{主角称呼}，手机稍微往这边转。
```

**$.park_gazebo.adult[35][2].mf**

```text
>手机稍微往这边转。
```

**$.park_gazebo.adult[35][2].fm**

```text
>手机稍微往这边转。
```

**$.park_gazebo.adult[35][2].ff**

```text
>{主角称呼}，手机稍微往这边转。
```

**$.park_gazebo.adult[35][3]**

```text
这样呢？
```

**$.park_gazebo.adult[35][4]**

```text
>好多了，柱子对着直线看。
```

**$.park_gazebo.adult[36][0]**

```text
风的长短句
```

**$.park_gazebo.adult[36][1].mm**

```text
{对方称呼}，这一阵风比刚才长。
```

**$.park_gazebo.adult[36][1].mf**

```text
你好，这一阵风比刚才长。
```

**$.park_gazebo.adult[36][1].fm**

```text
你好，{对方称呼}，这一阵风比刚才长。
```

**$.park_gazebo.adult[36][1].ff**

```text
你好，这一阵风比刚才长。
```

**$.park_gazebo.adult[36][2].mm**

```text
>{主角称呼}，树叶一直在动。
```

**$.park_gazebo.adult[36][2].mf**

```text
>树叶一直在动。
```

**$.park_gazebo.adult[36][2].fm**

```text
>树叶一直在动。
```

**$.park_gazebo.adult[36][2].ff**

```text
>{主角称呼}，树叶一直在动。
```

**$.park_gazebo.adult[36][3]**

```text
前面一下就停了。
```

**$.park_gazebo.adult[36][4]**

```text
>嗯，不是一直那么大。
```

**$.park_gazebo.adult[37][0]**

```text
水鸟的距离
```

**$.park_gazebo.adult[37][1].mm**

```text
{对方称呼}，水鸟站得真远。
```

**$.park_gazebo.adult[37][1].mf**

```text
你好，水鸟站得真远。
```

**$.park_gazebo.adult[37][1].fm**

```text
你好，{对方称呼}，水鸟站得真远。
```

**$.park_gazebo.adult[37][1].ff**

```text
你好，水鸟站得真远。
```

**$.park_gazebo.adult[37][2].mm**

```text
>{主角称呼}，远点好，别把它吓走。
```

**$.park_gazebo.adult[37][2].mf**

```text
>远点好，别把它吓走。
```

**$.park_gazebo.adult[37][2].fm**

```text
>远点好，别把它吓走。
```

**$.park_gazebo.adult[37][2].ff**

```text
>{主角称呼}，远点好，别把它吓走。
```

**$.park_gazebo.adult[37][3]**

```text
我就在这儿看。
```

**$.park_gazebo.adult[37][4]**

```text
>伸手放大拍也行，别走下去。
```

**$.park_gazebo.adult[38][0]**

```text
亭里的时间
```

**$.park_gazebo.adult[38][1].mm**

```text
{对方称呼}，我是不是坐太久了。
```

**$.park_gazebo.adult[38][1].mf**

```text
你好，我是不是坐太久了。
```

**$.park_gazebo.adult[38][1].fm**

```text
你好，{对方称呼}，我是不是坐太久了。
```

**$.park_gazebo.adult[38][1].ff**

```text
你好，我是不是坐太久了。
```

**$.park_gazebo.adult[38][2].mm**

```text
>{主角称呼}，有事要走吗？
```

**$.park_gazebo.adult[38][2].mf**

```text
>有事要走吗？
```

**$.park_gazebo.adult[38][2].fm**

```text
>有事要走吗？
```

**$.park_gazebo.adult[38][2].ff**

```text
>{主角称呼}，有事要走吗？
```

**$.park_gazebo.adult[38][3]**

```text
没什么事。
```

**$.park_gazebo.adult[38][4]**

```text
>那多坐会儿也没关系。
```

**$.park_gazebo.adult[39][0]**

```text
不急的回答
```

**$.park_gazebo.adult[39][1].mm**

```text
{对方称呼}，刚才那个我还没想好。
```

**$.park_gazebo.adult[39][1].mf**

```text
你好，刚才那个我还没想好。
```

**$.park_gazebo.adult[39][1].fm**

```text
你好，{对方称呼}，刚才那个我还没想好。
```

**$.park_gazebo.adult[39][1].ff**

```text
你好，刚才那个我还没想好。
```

**$.park_gazebo.adult[39][2].mm**

```text
>{主角称呼}，不急，你慢慢想。
```

**$.park_gazebo.adult[39][2].mf**

```text
>不急，你慢慢想。
```

**$.park_gazebo.adult[39][2].fm**

```text
>不急，你慢慢想。
```

**$.park_gazebo.adult[39][2].ff**

```text
>{主角称呼}，不急，你慢慢想。
```

**$.park_gazebo.adult[39][3]**

```text
我可能得看看地图。
```

**$.park_gazebo.adult[39][4]**

```text
>嗯，要不先说点别的。
```

**$.park_gazebo.adult[40][0]**

```text
眼睛先到了
```

**$.park_gazebo.adult[40][1].mm**

```text
{对方称呼}，还没走到我就看见湖了。
```

**$.park_gazebo.adult[40][1].mf**

```text
你好，还没走到我就看见湖了。
```

**$.park_gazebo.adult[40][1].fm**

```text
你好，{对方称呼}，还没走到我就看见湖了。
```

**$.park_gazebo.adult[40][1].ff**

```text
你好，还没走到我就看见湖了。
```

**$.park_gazebo.adult[40][2].mm**

```text
>{主角称呼}，这边树缝能看见。
```

**$.park_gazebo.adult[40][2].mf**

```text
>这边树缝能看见。
```

**$.park_gazebo.adult[40][2].fm**

```text
>这边树缝能看见。
```

**$.park_gazebo.adult[40][2].ff**

```text
>{主角称呼}，这边树缝能看见。
```

**$.park_gazebo.adult[40][3]**

```text
走近看比远处大。
```

**$.park_gazebo.adult[40][4]**

```text
>嗯，另一边还绕过去一截。
```

**$.park_gazebo.adult[41][0]**

```text
看天的小空隙
```

**$.park_gazebo.adult[41][1].mm**

```text
{对方称呼}，树枝中间这块天挺好看。
```

**$.park_gazebo.adult[41][1].mf**

```text
你好，树枝中间这块天挺好看。
```

**$.park_gazebo.adult[41][1].fm**

```text
你好，{对方称呼}，树枝中间这块天挺好看。
```

**$.park_gazebo.adult[41][1].ff**

```text
你好，树枝中间这块天挺好看。
```

**$.park_gazebo.adult[41][2].mm**

```text
>{主角称呼}，你往左一点看得更多。
```

**$.park_gazebo.adult[41][2].mf**

```text
>你往左一点看得更多。
```

**$.park_gazebo.adult[41][2].fm**

```text
>你往左一点看得更多。
```

**$.park_gazebo.adult[41][2].ff**

```text
>{主角称呼}，你往左一点看得更多。
```

**$.park_gazebo.adult[41][3]**

```text
哦，这下没挡着了。
```

**$.park_gazebo.adult[41][4]**

```text
>拍的时候小心别带上柱子。
```

**$.park_gazebo.adult[42][0]**

```text
栏杆的温度
```

**$.park_gazebo.adult[42][1].mm**

```text
{对方称呼}，栏杆这边摸着热一点。
```

**$.park_gazebo.adult[42][1].mf**

```text
你好，栏杆这边摸着热一点。
```

**$.park_gazebo.adult[42][1].fm**

```text
你好，{对方称呼}，栏杆这边摸着热一点。
```

**$.park_gazebo.adult[42][1].ff**

```text
你好，栏杆这边摸着热一点。
```

**$.park_gazebo.adult[42][2].mm**

```text
>{主角称呼}，太阳刚晒过吧。
```

**$.park_gazebo.adult[42][2].mf**

```text
>太阳刚晒过吧。
```

**$.park_gazebo.adult[42][2].fm**

```text
>太阳刚晒过吧。
```

**$.park_gazebo.adult[42][2].ff**

```text
>{主角称呼}，太阳刚晒过吧。
```

**$.park_gazebo.adult[42][3]**

```text
另一边又凉。
```

**$.park_gazebo.adult[42][4]**

```text
>嗯，别往外探，碰一下就行。
```

**$.park_gazebo.adult[43][0]**

```text
风景不打分
```

**$.park_gazebo.adult[43][1].mm**

```text
{对方称呼}，我就想在这儿发会儿呆。
```

**$.park_gazebo.adult[43][1].mf**

```text
你好，我就想在这儿发会儿呆。
```

**$.park_gazebo.adult[43][1].fm**

```text
你好，{对方称呼}，我就想在这儿发会儿呆。
```

**$.park_gazebo.adult[43][1].ff**

```text
你好，我就想在这儿发会儿呆。
```

**$.park_gazebo.adult[43][2].mm**

```text
>{主角称呼}，行啊，又不用一直走。
```

**$.park_gazebo.adult[43][2].mf**

```text
>行啊，又不用一直走。
```

**$.park_gazebo.adult[43][2].fm**

```text
>行啊，又不用一直走。
```

**$.park_gazebo.adult[43][2].ff**

```text
>{主角称呼}，行啊，又不用一直走。
```

**$.park_gazebo.adult[43][3]**

```text
那再坐一下。
```

**$.park_gazebo.adult[43][4]**

```text
>我也没急事。
```

**$.park_gazebo.adult[44][0]**

```text
一起找声音
```

**$.park_gazebo.adult[44][1].mm**

```text
{对方称呼}，刚才什么响了？
```

**$.park_gazebo.adult[44][1].mf**

```text
你好，刚才什么响了？
```

**$.park_gazebo.adult[44][1].fm**

```text
你好，{对方称呼}，刚才什么响了？
```

**$.park_gazebo.adult[44][1].ff**

```text
你好，刚才什么响了？
```

**$.park_gazebo.adult[44][2].mm**

```text
>{主角称呼}，好像鸟落栏杆上了。
```

**$.park_gazebo.adult[44][2].mf**

```text
>好像鸟落栏杆上了。
```

**$.park_gazebo.adult[44][2].fm**

```text
>好像鸟落栏杆上了。
```

**$.park_gazebo.adult[44][2].ff**

```text
>{主角称呼}，好像鸟落栏杆上了。
```

**$.park_gazebo.adult[44][3]**

```text
现在又没声了。
```

**$.park_gazebo.adult[44][4]**

```text
>可能飞走了，先别找了。
```

**$.park_gazebo.adult[45][0]**

```text
多坐的一分钟
```

**$.park_gazebo.adult[45][1].mm**

```text
{对方称呼}，本来说走，又坐下了。
```

**$.park_gazebo.adult[45][1].mf**

```text
你好，本来说走，又坐下了。
```

**$.park_gazebo.adult[45][1].fm**

```text
你好，{对方称呼}，本来说走，又坐下了。
```

**$.park_gazebo.adult[45][1].ff**

```text
你好，本来说走，又坐下了。
```

**$.park_gazebo.adult[45][2].mm**

```text
>{主角称呼}，腿还酸？
```

**$.park_gazebo.adult[45][2].mf**

```text
>腿还酸？
```

**$.park_gazebo.adult[45][2].fm**

```text
>腿还酸？
```

**$.park_gazebo.adult[45][2].ff**

```text
>{主角称呼}，腿还酸？
```

**$.park_gazebo.adult[45][3]**

```text
有一点。
```

**$.park_gazebo.adult[45][4]**

```text
>那再缓两分钟。
```

**$.park_gazebo.adult[46][0]**

```text
轻轻的提醒
```

**$.park_gazebo.adult[46][1].mm**

```text
{对方称呼}，刚才谢谢你提醒脚下。
```

**$.park_gazebo.adult[46][1].mf**

```text
你好，刚才谢谢你提醒脚下。
```

**$.park_gazebo.adult[46][1].fm**

```text
你好，{对方称呼}，刚才谢谢你提醒脚下。
```

**$.park_gazebo.adult[46][1].ff**

```text
你好，刚才谢谢你提醒脚下。
```

**$.park_gazebo.adult[46][2].mm**

```text
>{主角称呼}，那块有点滑，我刚也差点踩。
```

**$.park_gazebo.adult[46][2].mf**

```text
>那块有点滑，我刚也差点踩。
```

**$.park_gazebo.adult[46][2].fm**

```text
>那块有点滑，我刚也差点踩。
```

**$.park_gazebo.adult[46][2].ff**

```text
>{主角称呼}，那块有点滑，我刚也差点踩。
```

**$.park_gazebo.adult[46][3]**

```text
我一直在看水。
```

**$.park_gazebo.adult[46][4]**

```text
>走路的时候先看路吧。
```

**$.park_gazebo.adult[47][0]**

```text
把话留住
```

**$.park_gazebo.adult[47][1].mm**

```text
{对方称呼}，今天聊的这个我记着了。
```

**$.park_gazebo.adult[47][1].mf**

```text
你好，今天聊的这个我记着了。
```

**$.park_gazebo.adult[47][1].fm**

```text
你好，{对方称呼}，今天聊的这个我记着了。
```

**$.park_gazebo.adult[47][1].ff**

```text
你好，今天聊的这个我记着了。
```

**$.park_gazebo.adult[47][2].mm**

```text
>{主角称呼}，下次来可以再看看。
```

**$.park_gazebo.adult[47][2].mf**

```text
>下次来可以再看看。
```

**$.park_gazebo.adult[47][2].fm**

```text
>下次来可以再看看。
```

**$.park_gazebo.adult[47][2].ff**

```text
>{主角称呼}，下次来可以再看看。
```

**$.park_gazebo.adult[47][3]**

```text
行，到时看有没有变。
```

**$.park_gazebo.adult[47][4]**

```text
>嗯，回头见。
```

**$.park_gazebo.kid[0][0]**

```text
亭子当船
```

**$.park_gazebo.kid[0][1]**

```text
你在看亭子的哪一边？
```

**$.park_gazebo.kid[0][2]**

```text
>我觉得它像一艘不会晕的船。
```

**$.park_gazebo.kid[0][3]**

```text
乘客还可以随时上岸。
```

**$.park_gazebo.kid[0][4]**

```text
>对，特别适合我这种船长。
```

**$.park_gazebo.kid[1][0]**

```text
倒影握手
```

**$.park_gazebo.kid[1][1]**

```text
你刚才在跟水里的人挥手吗？
```

**$.park_gazebo.kid[1][2]**

```text
>嗯，它每次都特别配合。
```

**$.park_gazebo.kid[1][3]**

```text
你停下来，它也就停下来。
```

**$.park_gazebo.kid[1][4]**

```text
>我们已经很有默契了。
```

**$.park_gazebo.kid[2][0]**

```text
鸭子名字
```

**$.park_gazebo.kid[2][1]**

```text
那几只鸭子你能分清吗？
```

**$.park_gazebo.kid[2][2]**

```text
>能，那只是大摇大摆，那只是慢慢吞吞。
```

**$.park_gazebo.kid[2][3]**

```text
名字听着很贴切。
```

**$.park_gazebo.kid[2][4]**

```text
>第三只叫先别跑，我还没想好。
```

**$.park_gazebo.kid[3][0]**

```text
小声游戏
```

**$.park_gazebo.kid[3][1]**

```text
为什么说话这么轻？
```

**$.park_gazebo.kid[3][2]**

```text
>我在跟风比赛，看谁更轻。
```

**$.park_gazebo.kid[3][3]**

```text
那我也小声一点。
```

**$.park_gazebo.kid[3][4]**

```text
>好，我们不能把湖吵醒。
```

**$.park_gazebo.kid[4][0]**

```text
云朵认字
```

**$.park_gazebo.kid[4][1]**

```text
你指着云在念什么？
```

**$.park_gazebo.kid[4][2]**

```text
>这朵像一，这朵像歪掉的三。
```

**$.park_gazebo.kid[4][3]**

```text
那风是不是在写字？
```

**$.park_gazebo.kid[4][4]**

```text
>它写得有点潦草，但很努力。
```

**$.park_gazebo.kid[5][0]**

```text
湖面宝物
```

**$.park_gazebo.kid[5][1]**

```text
你在找什么亮闪闪的东西？
```

**$.park_gazebo.kid[5][2]**

```text
>水上好多小星星，可惜捞不起来。
```

**$.park_gazebo.kid[5][3]**

```text
看一会儿，也算拥有过。
```

**$.park_gazebo.kid[5][4]**

```text
>那我今天的口袋已经满了。
```

**$.park_gazebo.kid[6][0]**

```text
亭子的名字
```

**$.park_gazebo.kid[6][1].mm**

```text
{对方称呼}，你觉得亭子知道自己的名字吗？
```

**$.park_gazebo.kid[6][1].mf**

```text
你好，你觉得亭子知道自己的名字吗？
```

**$.park_gazebo.kid[6][1].fm**

```text
你好，{对方称呼}，你觉得亭子知道自己的名字吗？
```

**$.park_gazebo.kid[6][1].ff**

```text
打个招呼，你觉得亭子知道自己的名字吗？
```

**$.park_gazebo.kid[6][2].mm**

```text
>{主角称呼}，嗯，不知道，可我每次都来跟它问好。
```

**$.park_gazebo.kid[6][2].mf**

```text
>{主角称呼}，说起来，不知道，可我每次都来跟它问好。
```

**$.park_gazebo.kid[6][2].fm**

```text
>{主角称呼}，其实，不知道，可我每次都来跟它问好。
```

**$.park_gazebo.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，不知道，可我每次都来跟它问好。
```

**$.park_gazebo.kid[6][3]**

```text
它可能已经记得你了。
```

**$.park_gazebo.kid[6][4]**

```text
>那我今天再认真挥一下手。
```

**$.park_gazebo.kid[7][0]**

```text
风吹帽沿
```

**$.park_gazebo.kid[7][1].mm**

```text
{对方称呼}，怎么一直扶着帽子？
```

**$.park_gazebo.kid[7][1].mf**

```text
你好，怎么一直扶着帽子？
```

**$.park_gazebo.kid[7][1].fm**

```text
你好，{对方称呼}，怎么一直扶着帽子？
```

**$.park_gazebo.kid[7][1].ff**

```text
打个招呼，怎么一直扶着帽子？
```

**$.park_gazebo.kid[7][2].mm**

```text
>{主角称呼}，说起来，风想借，我还没答应。
```

**$.park_gazebo.kid[7][2].mf**

```text
>{主角称呼}，其实，风想借，我还没答应。
```

**$.park_gazebo.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，风想借，我还没答应。
```

**$.park_gazebo.kid[7][2].ff**

```text
>{主角称呼}，嗯，风想借，我还没答应。
```

**$.park_gazebo.kid[7][3]**

```text
抓稳一点，别追到水边。
```

**$.park_gazebo.kid[7][4]**

```text
>好，帽子要留下，鞋也得干着。
```

**$.park_gazebo.kid[8][0]**

```text
湖边的悄悄话
```

**$.park_gazebo.kid[8][1].mm**

```text
{对方称呼}，你在跟水说什么？
```

**$.park_gazebo.kid[8][1].mf**

```text
你好，你在跟水说什么？
```

**$.park_gazebo.kid[8][1].fm**

```text
你好，{对方称呼}，你在跟水说什么？
```

**$.park_gazebo.kid[8][1].ff**

```text
打个招呼，你在跟水说什么？
```

**$.park_gazebo.kid[8][2].mm**

```text
>{主角称呼}，其实，说今天过得还不错。
```

**$.park_gazebo.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，说今天过得还不错。
```

**$.park_gazebo.kid[8][2].fm**

```text
>{主角称呼}，嗯，说今天过得还不错。
```

**$.park_gazebo.kid[8][2].ff**

```text
>{主角称呼}，说起来，说今天过得还不错。
```

**$.park_gazebo.kid[8][3]**

```text
它怎么回答？
```

**$.park_gazebo.kid[8][4]**

```text
>它晃了一下，我当它听见了。
```

**$.park_gazebo.kid[9][0]**

```text
树影的游戏
```

**$.park_gazebo.kid[9][1].mm**

```text
{对方称呼}，你为什么站到这块影子里？
```

**$.park_gazebo.kid[9][1].mf**

```text
你好，你为什么站到这块影子里？
```

**$.park_gazebo.kid[9][1].fm**

```text
你好，{对方称呼}，你为什么站到这块影子里？
```

**$.park_gazebo.kid[9][1].ff**

```text
打个招呼，你为什么站到这块影子里？
```

**$.park_gazebo.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，我想试试能不能变成一片叶子。
```

**$.park_gazebo.kid[9][2].mf**

```text
>{主角称呼}，嗯，我想试试能不能变成一片叶子。
```

**$.park_gazebo.kid[9][2].fm**

```text
>{主角称呼}，说起来，我想试试能不能变成一片叶子。
```

**$.park_gazebo.kid[9][2].ff**

```text
>{主角称呼}，其实，我想试试能不能变成一片叶子。
```

**$.park_gazebo.kid[9][3]**

```text
现在感觉怎么样？
```

**$.park_gazebo.kid[9][4]**

```text
>还是有脚，可能只成功一半。
```

**$.park_gazebo.kid[10][0]**

```text
小鸟的舞台
```

**$.park_gazebo.kid[10][1].mm**

```text
{对方称呼}，你一直看着那块栏杆？
```

**$.park_gazebo.kid[10][1].mf**

```text
你好，你一直看着那块栏杆？
```

**$.park_gazebo.kid[10][1].fm**

```text
你好，{对方称呼}，你一直看着那块栏杆？
```

**$.park_gazebo.kid[10][1].ff**

```text
打个招呼，你一直看着那块栏杆？
```

**$.park_gazebo.kid[10][2].mm**

```text
>{主角称呼}，嗯，刚才有只鸟在那里唱了一句。
```

**$.park_gazebo.kid[10][2].mf**

```text
>{主角称呼}，说起来，刚才有只鸟在那里唱了一句。
```

**$.park_gazebo.kid[10][2].fm**

```text
>{主角称呼}，其实，刚才有只鸟在那里唱了一句。
```

**$.park_gazebo.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，刚才有只鸟在那里唱了一句。
```

**$.park_gazebo.kid[10][3]**

```text
它已经谢幕了吧。
```

**$.park_gazebo.kid[10][4]**

```text
>嗯，我还在等安可。
```

**$.park_gazebo.kid[11][0]**

```text
再看一眼湖
```

**$.park_gazebo.kid[11][1].mm**

```text
{对方称呼}，准备走了吗？
```

**$.park_gazebo.kid[11][1].mf**

```text
你好，准备走了吗？
```

**$.park_gazebo.kid[11][1].fm**

```text
你好，{对方称呼}，准备走了吗？
```

**$.park_gazebo.kid[11][1].ff**

```text
打个招呼，准备走了吗？
```

**$.park_gazebo.kid[11][2].mm**

```text
>{主角称呼}，说起来，嗯，但想再看一眼。
```

**$.park_gazebo.kid[11][2].mf**

```text
>{主角称呼}，其实，嗯，但想再看一眼。
```

**$.park_gazebo.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，嗯，但想再看一眼。
```

**$.park_gazebo.kid[11][2].ff**

```text
>{主角称呼}，嗯，嗯，但想再看一眼。
```

**$.park_gazebo.kid[11][3]**

```text
可以，慢一点也来得及。
```

**$.park_gazebo.kid[11][4]**

```text
>那我把这眼看得认真一点。
```

**$.park_lakeside.adult[0][0]**

```text
湖畔问路
```

**$.park_lakeside.adult[0][1]**

```text
你好，这条路能绕回去吗？
```

**$.park_lakeside.adult[0][2]**

```text
>能，沿着路走就行。
```

**$.park_lakeside.adult[0][3]**

```text
谢谢，我怕走错了。
```

**$.park_lakeside.adult[0][4]**

```text
>不客气，前面还有指示牌。
```

**$.park_lakeside.adult[1][0]**

```text
路灯记路
```

**$.park_lakeside.adult[1][1]**

```text
我就靠这盏灯记路。
```

**$.park_lakeside.adult[1][2]**

```text
>挺好认的，别的看着都像。
```

**$.park_lakeside.adult[1][3]**

```text
我刚才走岔了一回。
```

**$.park_lakeside.adult[1][4]**

```text
>白天还好，天暗了更容易绕。
```

**$.park_lakeside.adult[2][0]**

```text
公厕的安心
```

**$.park_lakeside.adult[2][1]**

```text
这里有公厕啊。
```

**$.park_lakeside.adult[2][2]**

```text
>嗯，前面就能看见。
```

**$.park_lakeside.adult[2][3]**

```text
早知道我就不用急着回了。
```

**$.park_lakeside.adult[2][4]**

```text
>往那边走，门口有标志。
```

**$.park_lakeside.adult[3][0]**

```text
走快的脚步
```

**$.park_lakeside.adult[3][1]**

```text
刚才走得有点急。
```

**$.park_lakeside.adult[3][2]**

```text
>这回不赶了？
```

**$.park_lakeside.adult[3][3]**

```text
嗯，找到公厕了。
```

**$.park_lakeside.adult[3][4]**

```text
>那慢慢逛吧。
```

**$.park_lakeside.adult[4][0]**

```text
洗手后的风
```

**$.park_lakeside.adult[4][1]**

```text
洗完手出来，风一吹好凉。
```

**$.park_lakeside.adult[4][2]**

```text
>擦干了就好点。
```

**$.park_lakeside.adult[4][3]**

```text
我刚甩了两下。
```

**$.park_lakeside.adult[4][4]**

```text
>还是擦一下吧，手背会干。
```

**$.park_lakeside.adult[5][0]**

```text
路边的芦苇
```

**$.park_lakeside.adult[5][1]**

```text
芦苇又往这边倒了。
```

**$.park_lakeside.adult[5][2]**

```text
>风挺大。
```

**$.park_lakeside.adult[5][3]**

```text
刚才没风时都竖着。
```

**$.park_lakeside.adult[5][4]**

```text
>嗯，离远点看，别往水边踩。
```

**$.park_lakeside.adult[6][0]**

```text
指示牌谢意
```

**$.park_lakeside.adult[6][1]**

```text
还好这儿有指示牌。
```

**$.park_lakeside.adult[6][2]**

```text
>刚在找路？
```

**$.park_lakeside.adult[6][3]**

```text
嗯，差点往反方向走。
```

**$.park_lakeside.adult[6][4]**

```text
>照着箭头就行，前面还有一块。
```

**$.park_lakeside.adult[7][0]**

```text
灯下的小虫
```

**$.park_lakeside.adult[7][1]**

```text
灯边好多小虫。
```

**$.park_lakeside.adult[7][2]**

```text
>别站正底下，容易落头上。
```

**$.park_lakeside.adult[7][3]**

```text
我往旁边一点。
```

**$.park_lakeside.adult[7][4]**

```text
>嗯，这边没那么多。
```

**$.park_lakeside.adult[8][0]**

```text
湖畔的慢
```

**$.park_lakeside.adult[8][1]**

```text
这条路走着还挺舒服。
```

**$.park_lakeside.adult[8][2]**

```text
>人少，路也平。
```

**$.park_lakeside.adult[8][3]**

```text
我不太爱走挤的地方。
```

**$.park_lakeside.adult[8][4]**

```text
>那这边适合，没那么吵。
```

**$.park_lakeside.adult[9][0]**

```text
左右的误会
```

**$.park_lakeside.adult[9][1]**

```text
我一说方向就把左右弄反。
```

**$.park_lakeside.adult[9][2]**

```text
>那说路灯那边吧。
```

**$.park_lakeside.adult[9][3]**

```text
这个我能看见。
```

**$.park_lakeside.adult[9][4]**

```text
>嗯，照着走就行。
```

**$.park_lakeside.adult[10][0]**

```text
带纸的习惯
```

**$.park_lakeside.adult[10][1]**

```text
出门还好带了纸。
```

**$.park_lakeside.adult[10][2]**

```text
>要用的时候找不着最麻烦。
```

**$.park_lakeside.adult[10][3]**

```text
我都放外面口袋。
```

**$.park_lakeside.adult[10][4]**

```text
>这样好拿，不用翻包。
```

**$.park_lakeside.adult[11][0]**

```text
湖岸的石头
```

**$.park_lakeside.adult[11][1]**

```text
岸边石头怎么两种颜色？
```

**$.park_lakeside.adult[11][2]**

```text
>湿的那边深一些。
```

**$.park_lakeside.adult[11][3]**

```text
哦，干了就浅了。
```

**$.park_lakeside.adult[11][4]**

```text
>对，别踩上去，有水的滑。
```

**$.park_lakeside.adult[12][0]**

```text
走错也好
```

**$.park_lakeside.adult[12][1]**

```text
刚走错了，才看见这片芦苇。
```

**$.park_lakeside.adult[12][2]**

```text
>这边平时路过的人少。
```

**$.park_lakeside.adult[12][3]**

```text
还挺好看。
```

**$.park_lakeside.adult[12][4]**

```text
>往前也能接回去，不用原路返。
```

**$.park_lakeside.adult[13][0]**

```text
凉快的位置
```

**$.park_lakeside.adult[13][1]**

```text
树下比旁边凉快。
```

**$.park_lakeside.adult[13][2]**

```text
>刚好挡着太阳。
```

**$.park_lakeside.adult[13][3]**

```text
我站这儿缓缓。
```

**$.park_lakeside.adult[13][4]**

```text
>嗯，别挡住后面的人就行。
```

**$.park_lakeside.adult[14][0]**

```text
公园维修
```

**$.park_lakeside.adult[14][1]**

```text
那块牌子好像修好了。
```

**$.park_lakeside.adult[14][2]**

```text
>前两天还歪着。
```

**$.park_lakeside.adult[14][3]**

```text
我刚才看已经扶正了。
```

**$.park_lakeside.adult[14][4]**

```text
>那就好，字也能看清了。
```

**$.park_lakeside.adult[15][0]**

```text
散步的补给
```

**$.park_lakeside.adult[15][1]**

```text
出来走走你带水吗？
```

**$.park_lakeside.adult[15][2]**

```text
>带一点，不带大瓶。
```

**$.park_lakeside.adult[15][3]**

```text
我有时候走到一半就渴。
```

**$.park_lakeside.adult[15][4]**

```text
>那下回带个小的，别嫌麻烦。
```

**$.park_lakeside.adult[16][0]**

```text
轻松的背影
```

**$.park_lakeside.adult[16][1]**

```text
那边人走得挺急。
```

**$.park_lakeside.adult[16][2]**

```text
>可能有事吧。
```

**$.park_lakeside.adult[16][3]**

```text
嗯，我往边上让让。
```

**$.park_lakeside.adult[16][4]**

```text
>留点路就好。
```

**$.park_lakeside.adult[17][0]**

```text
湖边的小路
```

**$.park_lakeside.adult[17][1]**

```text
这里比中央那边安静。
```

**$.park_lakeside.adult[17][2]**

```text
>嗯，树也密一点。
```

**$.park_lakeside.adult[17][3]**

```text
我就想找个清静点的地方。
```

**$.park_lakeside.adult[17][4]**

```text
>那再往里走走也行。
```

**$.park_lakeside.adult[18][0]**

```text
雨后的边缘
```

**$.park_lakeside.adult[18][1]**

```text
水边那块看着有点滑。
```

**$.park_lakeside.adult[18][2]**

```text
>是，别踩石头上。
```

**$.park_lakeside.adult[18][3]**

```text
我就在路上走。
```

**$.park_lakeside.adult[18][4]**

```text
>嗯，远点看也一样。
```

**$.park_lakeside.adult[19][0]**

```text
空着的手
```

**$.park_lakeside.adult[19][1]**

```text
不拿手机走路还挺轻松。
```

**$.park_lakeside.adult[19][2]**

```text
>至少不用一边看一边躲人。
```

**$.park_lakeside.adult[19][3]**

```text
我刚差点走过头。
```

**$.park_lakeside.adult[19][4]**

```text
>到路口再看吧。
```

**$.park_lakeside.adult[20][0]**

```text
路灯的形状
```

**$.park_lakeside.adult[20][1]**

```text
这路灯样子像朵倒着的花。
```

**$.park_lakeside.adult[20][2]**

```text
>有点，罩子朝下的。
```

**$.park_lakeside.adult[20][3]**

```text
我以前没抬头看过。
```

**$.park_lakeside.adult[20][4]**

```text
>我也刚注意。
```

**$.park_lakeside.adult[21][0]**

```text
绕回原处
```

**$.park_lakeside.adult[21][1]**

```text
怎么又绕到这里了。
```

**$.park_lakeside.adult[21][2]**

```text
>认得那块牌子吧。
```

**$.park_lakeside.adult[21][3]**

```text
嗯，刚才从它旁边走过。
```

**$.park_lakeside.adult[21][4]**

```text
>那你往另一边看看。
```

**$.park_lakeside.adult[22][0]**

```text
湖畔的问候
```

**$.park_lakeside.adult[22][1]**

```text
你也常来走这边？
```

**$.park_lakeside.adult[22][2]**

```text
>偶尔，想安静点就过来。
```

**$.park_lakeside.adult[22][3]**

```text
我今天第一次走这么里面。
```

**$.park_lakeside.adult[22][4]**

```text
>再往前还有段路。
```

**$.park_lakeside.adult[23][0]**

```text
下一段路
```

**$.park_lakeside.adult[23][1]**

```text
接下来往哪儿走？
```

**$.park_lakeside.adult[23][2]**

```text
>还没想好，先在树下站会儿。
```

**$.park_lakeside.adult[23][3]**

```text
我也先看看。
```

**$.park_lakeside.adult[23][4]**

```text
>嗯，不急。
```

**$.park_lakeside.adult[24][0]**

```text
湖畔的开场
```

**$.park_lakeside.adult[24][1].mm**

```text
{对方称呼}，你好，我刚从那边过来。
```

**$.park_lakeside.adult[24][1].mf**

```text
你好，你好，我刚从那边过来。
```

**$.park_lakeside.adult[24][1].fm**

```text
你好，{对方称呼}，你好，我刚从那边过来。
```

**$.park_lakeside.adult[24][1].ff**

```text
你好，你好，我刚从那边过来。
```

**$.park_lakeside.adult[24][2].mm**

```text
>{主角称呼}，那边人多不多？
```

**$.park_lakeside.adult[24][2].mf**

```text
>那边人多不多？
```

**$.park_lakeside.adult[24][2].fm**

```text
>那边人多不多？
```

**$.park_lakeside.adult[24][2].ff**

```text
>{主角称呼}，那边人多不多？
```

**$.park_lakeside.adult[24][3]**

```text
还行，能慢慢走。
```

**$.park_lakeside.adult[24][4]**

```text
>好，我一会儿也过去。
```

**$.park_lakeside.adult[25][0]**

```text
指路的方式
```

**$.park_lakeside.adult[25][1].mm**

```text
{对方称呼}，指路你一般怎么说？
```

**$.park_lakeside.adult[25][1].mf**

```text
你好，指路你一般怎么说？
```

**$.park_lakeside.adult[25][1].fm**

```text
你好，{对方称呼}，指路你一般怎么说？
```

**$.park_lakeside.adult[25][1].ff**

```text
你好，指路你一般怎么说？
```

**$.park_lakeside.adult[25][2].mm**

```text
>{主角称呼}，说路灯、牌子，人家看得见。
```

**$.park_lakeside.adult[25][2].mf**

```text
>说路灯、牌子，人家看得见。
```

**$.park_lakeside.adult[25][2].fm**

```text
>说路灯、牌子，人家看得见。
```

**$.park_lakeside.adult[25][2].ff**

```text
>{主角称呼}，说路灯、牌子，人家看得见。
```

**$.park_lakeside.adult[25][3]**

```text
光说左右我老记反。
```

**$.park_lakeside.adult[25][4]**

```text
>那就指给他看，省得绕。
```

**$.park_lakeside.adult[26][0]**

```text
公厕的小牌子
```

**$.park_lakeside.adult[26][1].mm**

```text
{对方称呼}，公厕牌子原来在这儿。
```

**$.park_lakeside.adult[26][1].mf**

```text
你好，公厕牌子原来在这儿。
```

**$.park_lakeside.adult[26][1].fm**

```text
你好，{对方称呼}，公厕牌子原来在这儿。
```

**$.park_lakeside.adult[26][1].ff**

```text
你好，公厕牌子原来在这儿。
```

**$.park_lakeside.adult[26][2].mm**

```text
>{主角称呼}，之前没看见？
```

**$.park_lakeside.adult[26][2].mf**

```text
>之前没看见？
```

**$.park_lakeside.adult[26][2].fm**

```text
>之前没看见？
```

**$.park_lakeside.adult[26][2].ff**

```text
>{主角称呼}，之前没看见？
```

**$.park_lakeside.adult[26][3]**

```text
嗯，我还往前找了一段。
```

**$.park_lakeside.adult[26][4]**

```text
>就在旁边，别再走过了。
```

**$.park_lakeside.adult[27][0]**

```text
轻快的脚步
```

**$.park_lakeside.adult[27][1].mm**

```text
{对方称呼}，这段路走着挺轻松。
```

**$.park_lakeside.adult[27][1].mf**

```text
你好，这段路走着挺轻松。
```

**$.park_lakeside.adult[27][1].fm**

```text
你好，{对方称呼}，这段路走着挺轻松。
```

**$.park_lakeside.adult[27][1].ff**

```text
你好，这段路走着挺轻松。
```

**$.park_lakeside.adult[27][2].mm**

```text
>{主角称呼}，地平，也没台阶。
```

**$.park_lakeside.adult[27][2].mf**

```text
>地平，也没台阶。
```

**$.park_lakeside.adult[27][2].fm**

```text
>地平，也没台阶。
```

**$.park_lakeside.adult[27][2].ff**

```text
>{主角称呼}，地平，也没台阶。
```

**$.park_lakeside.adult[27][3]**

```text
对，不用老看脚下。
```

**$.park_lakeside.adult[27][4]**

```text
>不过路边还是得注意。
```

**$.park_lakeside.adult[28][0]**

```text
风过芦苇
```

**$.park_lakeside.adult[28][1].mm**

```text
{对方称呼}，芦苇一下全往那边倒。
```

**$.park_lakeside.adult[28][1].mf**

```text
你好，芦苇一下全往那边倒。
```

**$.park_lakeside.adult[28][1].fm**

```text
你好，{对方称呼}，芦苇一下全往那边倒。
```

**$.park_lakeside.adult[28][1].ff**

```text
你好，芦苇一下全往那边倒。
```

**$.park_lakeside.adult[28][2].mm**

```text
>{主角称呼}，风大了，等停下来又回去。
```

**$.park_lakeside.adult[28][2].mf**

```text
>风大了，等停下来又回去。
```

**$.park_lakeside.adult[28][2].fm**

```text
>风大了，等停下来又回去。
```

**$.park_lakeside.adult[28][2].ff**

```text
>{主角称呼}，风大了，等停下来又回去。
```

**$.park_lakeside.adult[28][3]**

```text
还挺整齐。
```

**$.park_lakeside.adult[28][4]**

```text
>靠近看就没那么齐了。
```

**$.park_lakeside.adult[29][0]**

```text
水边的灰鞋
```

**$.park_lakeside.adult[29][1].mm**

```text
{对方称呼}，我鞋尖差点碰到水。
```

**$.park_lakeside.adult[29][1].mf**

```text
你好，我鞋尖差点碰到水。
```

**$.park_lakeside.adult[29][1].fm**

```text
你好，{对方称呼}，我鞋尖差点碰到水。
```

**$.park_lakeside.adult[29][1].ff**

```text
你好，我鞋尖差点碰到水。
```

**$.park_lakeside.adult[29][2].mm**

```text
>{主角称呼}，往里一点，边上湿。
```

**$.park_lakeside.adult[29][2].mf**

```text
>往里一点，边上湿。
```

**$.park_lakeside.adult[29][2].fm**

```text
>往里一点，边上湿。
```

**$.park_lakeside.adult[29][2].ff**

```text
>{主角称呼}，往里一点，边上湿。
```

**$.park_lakeside.adult[29][3]**

```text
嗯，还好没踩下去。
```

**$.park_lakeside.adult[29][4]**

```text
>干鞋舒服点，别弄湿了。
```

**$.park_lakeside.adult[30][0]**

```text
停一下再找
```

**$.park_lakeside.adult[30][1].mm**

```text
{对方称呼}，我越找牌子越找不到。
```

**$.park_lakeside.adult[30][1].mf**

```text
你好，我越找牌子越找不到。
```

**$.park_lakeside.adult[30][1].fm**

```text
你好，{对方称呼}，我越找牌子越找不到。
```

**$.park_lakeside.adult[30][1].ff**

```text
你好，我越找牌子越找不到。
```

**$.park_lakeside.adult[30][2].mm**

```text
>{主角称呼}，先停一下，看上面。
```

**$.park_lakeside.adult[30][2].mf**

```text
>先停一下，看上面。
```

**$.park_lakeside.adult[30][2].fm**

```text
>先停一下，看上面。
```

**$.park_lakeside.adult[30][2].ff**

```text
>{主角称呼}，先停一下，看上面。
```

**$.park_lakeside.adult[30][3]**

```text
哦，就在那儿。
```

**$.park_lakeside.adult[30][4]**

```text
>对，刚才你走过去了。
```

**$.park_lakeside.adult[31][0]**

```text
把手擦干
```

**$.park_lakeside.adult[31][1].mm**

```text
{对方称呼}，洗完手舒服多了。
```

**$.park_lakeside.adult[31][1].mf**

```text
你好，洗完手舒服多了。
```

**$.park_lakeside.adult[31][1].fm**

```text
你好，{对方称呼}，洗完手舒服多了。
```

**$.park_lakeside.adult[31][1].ff**

```text
你好，洗完手舒服多了。
```

**$.park_lakeside.adult[31][2].mm**

```text
>{主角称呼}，擦干了再走吧。
```

**$.park_lakeside.adult[31][2].mf**

```text
>擦干了再走吧。
```

**$.park_lakeside.adult[31][2].fm**

```text
>擦干了再走吧。
```

**$.park_lakeside.adult[31][2].ff**

```text
>{主角称呼}，擦干了再走吧。
```

**$.park_lakeside.adult[31][3]**

```text
还差手背这点。
```

**$.park_lakeside.adult[31][4]**

```text
>不急，纸先收好别掉了。
```

**$.park_lakeside.adult[32][0]**

```text
不用硬忍
```

**$.park_lakeside.adult[32][1].mm**

```text
{对方称呼}，我以前出门总拖到回家才去厕所。
```

**$.park_lakeside.adult[32][1].mf**

```text
你好，我以前出门总拖到回家才去厕所。
```

**$.park_lakeside.adult[32][1].fm**

```text
你好，{对方称呼}，我以前出门总拖到回家才去厕所。
```

**$.park_lakeside.adult[32][1].ff**

```text
你好，我以前出门总拖到回家才去厕所。
```

**$.park_lakeside.adult[32][2].mm**

```text
>{主角称呼}，现在这边有，先去呗。
```

**$.park_lakeside.adult[32][2].mf**

```text
>现在这边有，先去呗。
```

**$.park_lakeside.adult[32][2].fm**

```text
>现在这边有，先去呗。
```

**$.park_lakeside.adult[32][2].ff**

```text
>{主角称呼}，现在这边有，先去呗。
```

**$.park_lakeside.adult[32][3]**

```text
是，不用一路惦记着。
```

**$.park_lakeside.adult[32][4]**

```text
>人在这儿等着也行。
```

**$.park_lakeside.adult[33][0]**

```text
树边等候
```

**$.park_lakeside.adult[33][1].mm**

```text
{对方称呼}，树下等人比路口好。
```

**$.park_lakeside.adult[33][1].mf**

```text
你好，树下等人比路口好。
```

**$.park_lakeside.adult[33][1].fm**

```text
你好，{对方称呼}，树下等人比路口好。
```

**$.park_lakeside.adult[33][1].ff**

```text
你好，树下等人比路口好。
```

**$.park_lakeside.adult[33][2].mm**

```text
>{主角称呼}，不晒，也不用挡着人。
```

**$.park_lakeside.adult[33][2].mf**

```text
>不晒，也不用挡着人。
```

**$.park_lakeside.adult[33][2].fm**

```text
>不晒，也不用挡着人。
```

**$.park_lakeside.adult[33][2].ff**

```text
>{主角称呼}，不晒，也不用挡着人。
```

**$.park_lakeside.adult[33][3]**

```text
朋友快到了。
```

**$.park_lakeside.adult[33][4]**

```text
>到时招招手，别没看见。
```

**$.park_lakeside.adult[34][0]**

```text
湖畔的弯
```

**$.park_lakeside.adult[34][1].mm**

```text
{对方称呼}，拐过来就看不见刚才那边了。
```

**$.park_lakeside.adult[34][1].mf**

```text
你好，拐过来就看不见刚才那边了。
```

**$.park_lakeside.adult[34][1].fm**

```text
你好，{对方称呼}，拐过来就看不见刚才那边了。
```

**$.park_lakeside.adult[34][1].ff**

```text
你好，拐过来就看不见刚才那边了。
```

**$.park_lakeside.adult[34][2].mm**

```text
>{主角称呼}，树挡着了。
```

**$.park_lakeside.adult[34][2].mf**

```text
>树挡着了。
```

**$.park_lakeside.adult[34][2].fm**

```text
>树挡着了。
```

**$.park_lakeside.adult[34][2].ff**

```text
>{主角称呼}，树挡着了。
```

**$.park_lakeside.adult[34][3]**

```text
我还以为走远了。
```

**$.park_lakeside.adult[34][4]**

```text
>没多远，原路回去就是。
```

**$.park_lakeside.adult[35][0]**

```text
一盏灯的距离
```

**$.park_lakeside.adult[35][1].mm**

```text
{对方称呼}，走到下一盏灯就回来吧。
```

**$.park_lakeside.adult[35][1].mf**

```text
你好，走到下一盏灯就回来吧。
```

**$.park_lakeside.adult[35][1].fm**

```text
你好，{对方称呼}，走到下一盏灯就回来吧。
```

**$.park_lakeside.adult[35][1].ff**

```text
你好，走到下一盏灯就回来吧。
```

**$.park_lakeside.adult[35][2].mm**

```text
>{主角称呼}，嗯，看着不远。
```

**$.park_lakeside.adult[35][2].mf**

```text
>嗯，看着不远。
```

**$.park_lakeside.adult[35][2].fm**

```text
>嗯，看着不远。
```

**$.park_lakeside.adult[35][2].ff**

```text
>{主角称呼}，嗯，看着不远。
```

**$.park_lakeside.adult[35][3]**

```text
再远我怕累。
```

**$.park_lakeside.adult[35][4]**

```text
>够了就回来，没事。
```

**$.park_lakeside.adult[36][0]**

```text
不要急着赶
```

**$.park_lakeside.adult[36][1].mm**

```text
{对方称呼}，刚才一直走得很快。
```

**$.park_lakeside.adult[36][1].mf**

```text
你好，刚才一直走得很快。
```

**$.park_lakeside.adult[36][1].fm**

```text
你好，{对方称呼}，刚才一直走得很快。
```

**$.park_lakeside.adult[36][1].ff**

```text
你好，刚才一直走得很快。
```

**$.park_lakeside.adult[36][2].mm**

```text
>{主角称呼}，有事着急？
```

**$.park_lakeside.adult[36][2].mf**

```text
>有事着急？
```

**$.park_lakeside.adult[36][2].fm**

```text
>有事着急？
```

**$.park_lakeside.adult[36][2].ff**

```text
>{主角称呼}，有事着急？
```

**$.park_lakeside.adult[36][3]**

```text
没，就是习惯。
```

**$.park_lakeside.adult[36][4]**

```text
>那慢一点，脚也歇一下。
```

**$.park_lakeside.adult[37][0]**

```text
脚下的小缝
```

**$.park_lakeside.adult[37][1].mm**

```text
{对方称呼}，这几块砖我都认得了。
```

**$.park_lakeside.adult[37][1].mf**

```text
你好，这几块砖我都认得了。
```

**$.park_lakeside.adult[37][1].fm**

```text
你好，{对方称呼}，这几块砖我都认得了。
```

**$.park_lakeside.adult[37][1].ff**

```text
你好，这几块砖我都认得了。
```

**$.park_lakeside.adult[37][2].mm**

```text
>{主角称呼}，走过好几回了吧。
```

**$.park_lakeside.adult[37][2].mf**

```text
>走过好几回了吧。
```

**$.park_lakeside.adult[37][2].fm**

```text
>走过好几回了吧。
```

**$.park_lakeside.adult[37][2].ff**

```text
>{主角称呼}，走过好几回了吧。
```

**$.park_lakeside.adult[37][3]**

```text
嗯，中间这缝特别宽。
```

**$.park_lakeside.adult[37][4]**

```text
>看着点，鞋尖别卡进去。
```

**$.park_lakeside.adult[38][0]**

```text
一阵轻松
```

**$.park_lakeside.adult[38][1].mm**

```text
{对方称呼}，我刚深吸一口气，舒服些。
```

**$.park_lakeside.adult[38][1].mf**

```text
你好，我刚深吸一口气，舒服些。
```

**$.park_lakeside.adult[38][1].fm**

```text
你好，{对方称呼}，我刚深吸一口气，舒服些。
```

**$.park_lakeside.adult[38][1].ff**

```text
你好，我刚深吸一口气，舒服些。
```

**$.park_lakeside.adult[38][2].mm**

```text
>{主角称呼}，这边没那么闷。
```

**$.park_lakeside.adult[38][2].mf**

```text
>这边没那么闷。
```

**$.park_lakeside.adult[38][2].fm**

```text
>这边没那么闷。
```

**$.park_lakeside.adult[38][2].ff**

```text
>{主角称呼}，这边没那么闷。
```

**$.park_lakeside.adult[38][3]**

```text
嗯，站树下有点风。
```

**$.park_lakeside.adult[38][4]**

```text
>别一直对着风口就好。
```

**$.park_lakeside.adult[39][0]**

```text
不必看地图
```

**$.park_lakeside.adult[39][1].mm**

```text
{对方称呼}，地图开着，我反而没看周围。
```

**$.park_lakeside.adult[39][1].mf**

```text
你好，地图开着，我反而没看周围。
```

**$.park_lakeside.adult[39][1].fm**

```text
你好，{对方称呼}，地图开着，我反而没看周围。
```

**$.park_lakeside.adult[39][1].ff**

```text
你好，地图开着，我反而没看周围。
```

**$.park_lakeside.adult[39][2].mm**

```text
>{主角称呼}，到拐弯的地方再看。
```

**$.park_lakeside.adult[39][2].mf**

```text
>到拐弯的地方再看。
```

**$.park_lakeside.adult[39][2].fm**

```text
>到拐弯的地方再看。
```

**$.park_lakeside.adult[39][2].ff**

```text
>{主角称呼}，到拐弯的地方再看。
```

**$.park_lakeside.adult[39][3]**

```text
嗯，先收起来。
```

**$.park_lakeside.adult[39][4]**

```text
>认不清也能问一下。
```

**$.park_lakeside.adult[40][0]**

```text
水面的细节
```

**$.park_lakeside.adult[40][1].mm**

```text
{对方称呼}，近处水面纹路挺细。
```

**$.park_lakeside.adult[40][1].mf**

```text
你好，近处水面纹路挺细。
```

**$.park_lakeside.adult[40][1].fm**

```text
你好，{对方称呼}，近处水面纹路挺细。
```

**$.park_lakeside.adult[40][1].ff**

```text
你好，近处水面纹路挺细。
```

**$.park_lakeside.adult[40][2].mm**

```text
>{主角称呼}，风小一点就看得见。
```

**$.park_lakeside.adult[40][2].mf**

```text
>风小一点就看得见。
```

**$.park_lakeside.adult[40][2].fm**

```text
>风小一点就看得见。
```

**$.park_lakeside.adult[40][2].ff**

```text
>{主角称呼}，风小一点就看得见。
```

**$.park_lakeside.adult[40][3]**

```text
远处看就是一片。
```

**$.park_lakeside.adult[40][4]**

```text
>这边亮一点，也好看清。
```

**$.park_lakeside.adult[41][0]**

```text
没有大事
```

**$.park_lakeside.adult[41][1].mm**

```text
{对方称呼}，今天没什么事，就走走。
```

**$.park_lakeside.adult[41][1].mf**

```text
你好，今天没什么事，就走走。
```

**$.park_lakeside.adult[41][1].fm**

```text
你好，{对方称呼}，今天没什么事，就走走。
```

**$.park_lakeside.adult[41][1].ff**

```text
你好，今天没什么事，就走走。
```

**$.park_lakeside.adult[41][2].mm**

```text
>{主角称呼}，我也一样。
```

**$.park_lakeside.adult[41][2].mf**

```text
>我也一样。
```

**$.park_lakeside.adult[41][2].fm**

```text
>我也一样。
```

**$.park_lakeside.adult[41][2].ff**

```text
>{主角称呼}，我也一样。
```

**$.park_lakeside.adult[41][3]**

```text
回去还早。
```

**$.park_lakeside.adult[41][4]**

```text
>那再转一小段吧。
```

**$.park_lakeside.adult[42][0]**

```text
树的另一面
```

**$.park_lakeside.adult[42][1].mm**

```text
{对方称呼}，这棵树另一面光秃一点。
```

**$.park_lakeside.adult[42][1].mf**

```text
你好，这棵树另一面光秃一点。
```

**$.park_lakeside.adult[42][1].fm**

```text
你好，{对方称呼}，这棵树另一面光秃一点。
```

**$.park_lakeside.adult[42][1].ff**

```text
你好，这棵树另一面光秃一点。
```

**$.park_lakeside.adult[42][2].mm**

```text
>{主角称呼}，可能这边晒不到。
```

**$.park_lakeside.adult[42][2].mf**

```text
>可能这边晒不到。
```

**$.park_lakeside.adult[42][2].fm**

```text
>可能这边晒不到。
```

**$.park_lakeside.adult[42][2].ff**

```text
>{主角称呼}，可能这边晒不到。
```

**$.park_lakeside.adult[42][3]**

```text
我一直只看正面。
```

**$.park_lakeside.adult[42][4]**

```text
>绕一下才知道。
```

**$.park_lakeside.adult[43][0]**

```text
一小段并肩
```

**$.park_lakeside.adult[43][1].mm**

```text
{对方称呼}，刚才咱俩一直同路。
```

**$.park_lakeside.adult[43][1].mf**

```text
你好，刚才咱俩一直同路。
```

**$.park_lakeside.adult[43][1].fm**

```text
你好，{对方称呼}，刚才咱俩一直同路。
```

**$.park_lakeside.adult[43][1].ff**

```text
你好，刚才咱俩一直同路。
```

**$.park_lakeside.adult[43][2].mm**

```text
>{主角称呼}，是，我还以为你在等人。
```

**$.park_lakeside.adult[43][2].mf**

```text
>是，我还以为你在等人。
```

**$.park_lakeside.adult[43][2].fm**

```text
>是，我还以为你在等人。
```

**$.park_lakeside.adult[43][2].ff**

```text
>{主角称呼}，是，我还以为你在等人。
```

**$.park_lakeside.adult[43][3]**

```text
没有，就随便走。
```

**$.park_lakeside.adult[43][4]**

```text
>那刚好聊两句。
```

**$.park_lakeside.adult[44][0]**

```text
别追着风走
```

**$.park_lakeside.adult[44][1].mm**

```text
{对方称呼}，风从那边来，脸都有点凉。
```

**$.park_lakeside.adult[44][1].mf**

```text
你好，风从那边来，脸都有点凉。
```

**$.park_lakeside.adult[44][1].fm**

```text
你好，{对方称呼}，风从那边来，脸都有点凉。
```

**$.park_lakeside.adult[44][1].ff**

```text
你好，风从那边来，脸都有点凉。
```

**$.park_lakeside.adult[44][2].mm**

```text
>{主角称呼}，转过来站会儿。
```

**$.park_lakeside.adult[44][2].mf**

```text
>转过来站会儿。
```

**$.park_lakeside.adult[44][2].fm**

```text
>转过来站会儿。
```

**$.park_lakeside.adult[44][2].ff**

```text
>{主角称呼}，转过来站会儿。
```

**$.park_lakeside.adult[44][3]**

```text
这样好些。
```

**$.park_lakeside.adult[44][4]**

```text
>嗯，别对着风一直站。
```

**$.park_lakeside.adult[45][0]**

```text
照顾自己的次序
```

**$.park_lakeside.adult[45][1].mm**

```text
{对方称呼}，出来玩还是得先吃饭。
```

**$.park_lakeside.adult[45][1].mf**

```text
你好，出来玩还是得先吃饭。
```

**$.park_lakeside.adult[45][1].fm**

```text
你好，{对方称呼}，出来玩还是得先吃饭。
```

**$.park_lakeside.adult[45][1].ff**

```text
你好，出来玩还是得先吃饭。
```

**$.park_lakeside.adult[45][2].mm**

```text
>{主角称呼}，你没吃就出来了？
```

**$.park_lakeside.adult[45][2].mf**

```text
>你没吃就出来了？
```

**$.park_lakeside.adult[45][2].fm**

```text
>你没吃就出来了？
```

**$.park_lakeside.adult[45][2].ff**

```text
>{主角称呼}，你没吃就出来了？
```

**$.park_lakeside.adult[45][3]**

```text
就吃了点，现在饿。
```

**$.park_lakeside.adult[45][4]**

```text
>那先找点吃的，别硬走。
```

**$.park_lakeside.adult[46][0]**

```text
留给下一次
```

**$.park_lakeside.adult[46][1].mm**

```text
{对方称呼}，这回不走那么远了。
```

**$.park_lakeside.adult[46][1].mf**

```text
你好，这回不走那么远了。
```

**$.park_lakeside.adult[46][1].fm**

```text
你好，{对方称呼}，这回不走那么远了。
```

**$.park_lakeside.adult[46][1].ff**

```text
你好，这回不走那么远了。
```

**$.park_lakeside.adult[46][2].mm**

```text
>{主角称呼}，剩下的下次再来。
```

**$.park_lakeside.adult[46][2].mf**

```text
>剩下的下次再来。
```

**$.park_lakeside.adult[46][2].fm**

```text
>剩下的下次再来。
```

**$.park_lakeside.adult[46][2].ff**

```text
>{主角称呼}，剩下的下次再来。
```

**$.park_lakeside.adult[46][3]**

```text
嗯，腿有点酸。
```

**$.park_lakeside.adult[46][4]**

```text
>回去歇着，别一口气走完。
```

**$.park_lakeside.adult[47][0]**

```text
普通路上的好事
```

**$.park_lakeside.adult[47][1].mm**

```text
{对方称呼}，刚好碰到你，才知道路怎么走。
```

**$.park_lakeside.adult[47][1].mf**

```text
你好，刚好碰到你，才知道路怎么走。
```

**$.park_lakeside.adult[47][1].fm**

```text
你好，{对方称呼}，刚好碰到你，才知道路怎么走。
```

**$.park_lakeside.adult[47][1].ff**

```text
你好，刚好碰到你，才知道路怎么走。
```

**$.park_lakeside.adult[47][2].mm**

```text
>{主角称呼}，没事，我也是走了几回才记住。
```

**$.park_lakeside.adult[47][2].mf**

```text
>没事，我也是走了几回才记住。
```

**$.park_lakeside.adult[47][2].fm**

```text
>没事，我也是走了几回才记住。
```

**$.park_lakeside.adult[47][2].ff**

```text
>{主角称呼}，没事，我也是走了几回才记住。
```

**$.park_lakeside.adult[47][3]**

```text
谢了，不然又要绕。
```

**$.park_lakeside.adult[47][4]**

```text
>前面看牌子，别走过头。
```

**$.park_lakeside.kid[0][0]**

```text
跟着指示走
```

**$.park_lakeside.kid[0][1]**

```text
你在找什么呀？
```

**$.park_lakeside.kid[0][2]**

```text
>我在看牌子，上面那个箭头很认真。
```

**$.park_lakeside.kid[0][3]**

```text
它会带你去想去的地方。
```

**$.park_lakeside.kid[0][4]**

```text
>那我也认真一点，别和它对着走。
```

**$.park_lakeside.kid[1][0]**

```text
洗手泡泡
```

**$.park_lakeside.kid[1][1]**

```text
你手上的泡泡已经洗干净了吗？
```

**$.park_lakeside.kid[1][2]**

```text
>洗干净了，我数到最后一个才走。
```

**$.park_lakeside.kid[1][3]**

```text
很仔细呀。
```

**$.park_lakeside.kid[1][4]**

```text
>它们都退场了，现在轮到我散步。
```

**$.park_lakeside.kid[2][0]**

```text
小小的路灯
```

**$.park_lakeside.kid[2][1]**

```text
你为什么绕着路灯转？
```

**$.park_lakeside.kid[2][2]**

```text
>我在看它到底长不长脚。
```

**$.park_lakeside.kid[2][3]**

```text
发现了吗？
```

**$.park_lakeside.kid[2][4]**

```text
>没有，所以它每天都得站在这里。
```

**$.park_lakeside.kid[3][0]**

```text
芦苇点头
```

**$.park_lakeside.kid[3][1]**

```text
这些草是不是在点头？
```

**$.park_lakeside.kid[3][2]**

```text
>我刚问它们今天开不开心。
```

**$.park_lakeside.kid[3][3]**

```text
它们怎么回答？
```

**$.park_lakeside.kid[3][4]**

```text
>一直点头，可能是特别开心。
```

**$.park_lakeside.kid[4][0]**

```text
记路口诀
```

**$.park_lakeside.kid[4][1]**

```text
这次记得回去的路了吗？
```

**$.park_lakeside.kid[4][2]**

```text
>记得，先树，再灯，再不要乱跑。
```

**$.park_lakeside.kid[4][3]**

```text
最后一句很实用。
```

**$.park_lakeside.kid[4][4]**

```text
>那是我自己临时补进去的。
```

**$.park_lakeside.kid[5][0]**

```text
石子不下水
```

**$.park_lakeside.kid[5][1]**

```text
要把石子丢进湖里吗？
```

**$.park_lakeside.kid[5][2]**

```text
>不了，它本来躺得好好的。
```

**$.park_lakeside.kid[5][3]**

```text
你替它想得很周到。
```

**$.park_lakeside.kid[5][4]**

```text
>我可以看水，不一定要让它游泳。
```

**$.park_lakeside.kid[6][0]**

```text
洗手的认真
```

**$.park_lakeside.kid[6][1].mm**

```text
{对方称呼}，你刚才洗手洗得很仔细。
```

**$.park_lakeside.kid[6][1].mf**

```text
你好，你刚才洗手洗得很仔细。
```

**$.park_lakeside.kid[6][1].fm**

```text
你好，{对方称呼}，你刚才洗手洗得很仔细。
```

**$.park_lakeside.kid[6][1].ff**

```text
打个招呼，你刚才洗手洗得很仔细。
```

**$.park_lakeside.kid[6][2].mm**

```text
>{主角称呼}，嗯，我想把每根手指都照顾到。
```

**$.park_lakeside.kid[6][2].mf**

```text
>{主角称呼}，说起来，我想把每根手指都照顾到。
```

**$.park_lakeside.kid[6][2].fm**

```text
>{主角称呼}，其实，我想把每根手指都照顾到。
```

**$.park_lakeside.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，我想把每根手指都照顾到。
```

**$.park_lakeside.kid[6][3]**

```text
它们应该很高兴。
```

**$.park_lakeside.kid[6][4]**

```text
>特别是拇指，天天帮我拿东西。
```

**$.park_lakeside.kid[7][0]**

```text
灯旁的名字
```

**$.park_lakeside.kid[7][1].mm**

```text
{对方称呼}，你给路灯起了名字？
```

**$.park_lakeside.kid[7][1].mf**

```text
你好，你给路灯起了名字？
```

**$.park_lakeside.kid[7][1].fm**

```text
你好，{对方称呼}，你给路灯起了名字？
```

**$.park_lakeside.kid[7][1].ff**

```text
打个招呼，你给路灯起了名字？
```

**$.park_lakeside.kid[7][2].mm**

```text
>{主角称呼}，说起来，叫站得最直的那个。
```

**$.park_lakeside.kid[7][2].mf**

```text
>{主角称呼}，其实，叫站得最直的那个。
```

**$.park_lakeside.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，叫站得最直的那个。
```

**$.park_lakeside.kid[7][2].ff**

```text
>{主角称呼}，嗯，叫站得最直的那个。
```

**$.park_lakeside.kid[7][3]**

```text
这个名字听着很有精神。
```

**$.park_lakeside.kid[7][4]**

```text
>它也没反对，我先这么叫。
```

**$.park_lakeside.kid[8][0]**

```text
风的队伍
```

**$.park_lakeside.kid[8][1].mm**

```text
{对方称呼}，你在看芦苇排队吗？
```

**$.park_lakeside.kid[8][1].mf**

```text
你好，你在看芦苇排队吗？
```

**$.park_lakeside.kid[8][1].fm**

```text
你好，{对方称呼}，你在看芦苇排队吗？
```

**$.park_lakeside.kid[8][1].ff**

```text
打个招呼，你在看芦苇排队吗？
```

**$.park_lakeside.kid[8][2].mm**

```text
>{主角称呼}，其实，它们一直晃，我都排不好。
```

**$.park_lakeside.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，它们一直晃，我都排不好。
```

**$.park_lakeside.kid[8][2].fm**

```text
>{主角称呼}，嗯，它们一直晃，我都排不好。
```

**$.park_lakeside.kid[8][2].ff**

```text
>{主角称呼}，说起来，它们一直晃，我都排不好。
```

**$.park_lakeside.kid[8][3]**

```text
可以不排，看看就行。
```

**$.park_lakeside.kid[8][4]**

```text
>那今天当自由活动吧。
```

**$.park_lakeside.kid[9][0]**

```text
指示牌认字
```

**$.park_lakeside.kid[9][1].mm**

```text
{对方称呼}，有看不懂的字吗？
```

**$.park_lakeside.kid[9][1].mf**

```text
你好，有看不懂的字吗？
```

**$.park_lakeside.kid[9][1].fm**

```text
你好，{对方称呼}，有看不懂的字吗？
```

**$.park_lakeside.kid[9][1].ff**

```text
打个招呼，有看不懂的字吗？
```

**$.park_lakeside.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，有一点，不过我先看懂了箭头。
```

**$.park_lakeside.kid[9][2].mf**

```text
>{主角称呼}，嗯，有一点，不过我先看懂了箭头。
```

**$.park_lakeside.kid[9][2].fm**

```text
>{主角称呼}，说起来，有一点，不过我先看懂了箭头。
```

**$.park_lakeside.kid[9][2].ff**

```text
>{主角称呼}，其实，有一点，不过我先看懂了箭头。
```

**$.park_lakeside.kid[9][3]**

```text
慢慢认，也可以问大人。
```

**$.park_lakeside.kid[9][4]**

```text
>好，不能因为害羞就一直走错。
```

**$.park_lakeside.kid[10][0]**

```text
水边的亮点
```

**$.park_lakeside.kid[10][1].mm**

```text
{对方称呼}，你为什么一直蹲着看？
```

**$.park_lakeside.kid[10][1].mf**

```text
你好，你为什么一直蹲着看？
```

**$.park_lakeside.kid[10][1].fm**

```text
你好，{对方称呼}，你为什么一直蹲着看？
```

**$.park_lakeside.kid[10][1].ff**

```text
打个招呼，你为什么一直蹲着看？
```

**$.park_lakeside.kid[10][2].mm**

```text
>{主角称呼}，嗯，我发现一滴水，也能装下一点天。
```

**$.park_lakeside.kid[10][2].mf**

```text
>{主角称呼}，说起来，我发现一滴水，也能装下一点天。
```

**$.park_lakeside.kid[10][2].fm**

```text
>{主角称呼}，其实，我发现一滴水，也能装下一点天。
```

**$.park_lakeside.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，我发现一滴水，也能装下一点天。
```

**$.park_lakeside.kid[10][3]**

```text
看得真仔细。
```

**$.park_lakeside.kid[10][4]**

```text
>不过我会站远一点，不踩进水里。
```

**$.park_lakeside.kid[11][0]**

```text
走回来的把握
```

**$.park_lakeside.kid[11][1].mm**

```text
{对方称呼}，现在记住这条小路了吗？
```

**$.park_lakeside.kid[11][1].mf**

```text
你好，现在记住这条小路了吗？
```

**$.park_lakeside.kid[11][1].fm**

```text
你好，{对方称呼}，现在记住这条小路了吗？
```

**$.park_lakeside.kid[11][1].ff**

```text
打个招呼，现在记住这条小路了吗？
```

**$.park_lakeside.kid[11][2].mm**

```text
>{主角称呼}，说起来，记住了，刚才有人跟我说过话。
```

**$.park_lakeside.kid[11][2].mf**

```text
>{主角称呼}，其实，记住了，刚才有人跟我说过话。
```

**$.park_lakeside.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，记住了，刚才有人跟我说过话。
```

**$.park_lakeside.kid[11][2].ff**

```text
>{主角称呼}，嗯，记住了，刚才有人跟我说过话。
```

**$.park_lakeside.kid[11][3]**

```text
人也能成为记路的线索。
```

**$.park_lakeside.kid[11][4]**

```text
>那下次见面，我应该就不慌了。
```

**$.park_central.adult[0][0]**

```text
条纹草坪
```

**$.park_central.adult[0][1]**

```text
草坪这一条深一条浅的。
```

**$.park_central.adult[0][2]**

```text
>好像是割草方向不一样。
```

**$.park_central.adult[0][3]**

```text
我还以为种了两种草。
```

**$.park_central.adult[0][4]**

```text
>我也不确定，就听别人说的。
```

**$.park_central.adult[1][0]**

```text
长椅的空位
```

**$.park_central.adult[1][1]**

```text
那长椅有人坐吗？
```

**$.park_central.adult[1][2]**

```text
>没有，你过去坐吧。
```

**$.park_central.adult[1][3]**

```text
走久了腿有点酸。
```

**$.park_central.adult[1][4]**

```text
>歇一会儿，别硬走。
```

**$.park_central.adult[2][0]**

```text
散步圈数
```

**$.park_central.adult[2][1]**

```text
你记得走几圈了吗？
```

**$.park_central.adult[2][2]**

```text
>刚才还记着，一说话忘了。
```

**$.park_central.adult[2][3]**

```text
我也老这样。
```

**$.park_central.adult[2][4]**

```text
>算了，走够了就回。
```

**$.park_central.adult[3][0]**

```text
中央的热闹
```

**$.park_central.adult[3][1]**

```text
这里散步的人比湖边多。
```

**$.park_central.adult[3][2]**

```text
>嗯，路宽一点。
```

**$.park_central.adult[3][3]**

```text
我刚还让了几个跑步的。
```

**$.park_central.adult[3][4]**

```text
>靠边走就行，他们会绕开。
```

**$.park_central.adult[4][0]**

```text
草坪不能踩
```

**$.park_central.adult[4][1]**

```text
草坪修得真齐。
```

**$.park_central.adult[4][2]**

```text
>是，还是在小路上走吧。
```

**$.park_central.adult[4][3]**

```text
我也没打算踩进去。
```

**$.park_central.adult[4][4]**

```text
>嗯，脚印踩出来就不好看了。
```

**$.park_central.adult[5][0]**

```text
天空的小飞机
```

**$.park_central.adult[5][1]**

```text
刚飞过去的是飞机？
```

**$.park_central.adult[5][2]**

```text
>嗯，还能看见一点。
```

**$.park_central.adult[5][3]**

```text
我刚以为是鸟。
```

**$.park_central.adult[5][4]**

```text
>远了看不清，听声音像飞机。
```

**$.park_central.adult[6][0]**

```text
鸭子的队伍
```

**$.park_central.adult[6][1]**

```text
鸭子都排着走。
```

**$.park_central.adult[6][2]**

```text
>前面那只一停，后面的全停了。
```

**$.park_central.adult[6][3]**

```text
还会撞一起。
```

**$.park_central.adult[6][4]**

```text
>你看，又开始走了。
```

**$.park_central.adult[7][0]**

```text
长椅的故事
```

**$.park_central.adult[7][1]**

```text
长椅上那几个字谁写的？
```

**$.park_central.adult[7][2]**

```text
>不知道，看着有点掉色了。
```

**$.park_central.adult[7][3]**

```text
可惜，原来挺干净的。
```

**$.park_central.adult[7][4]**

```text
>是啊，别乱刻就好了。
```

**$.park_central.adult[8][0]**

```text
一万步以前
```

**$.park_central.adult[8][1]**

```text
今天走够一万步了吗？
```

**$.park_central.adult[8][2]**

```text
>没看，差不多了就回。
```

**$.park_central.adult[8][3]**

```text
我老忍不住看。
```

**$.park_central.adult[8][4]**

```text
>走路舒服就行，少几步没事。
```

**$.park_central.adult[9][0]**

```text
公园的边框
```

**$.park_central.adult[9][1]**

```text
这几条路我老分不清。
```

**$.park_central.adult[9][2]**

```text
>先记住中间这块草坪。
```

**$.park_central.adult[9][3]**

```text
嗯，绕回来还能认出来。
```

**$.park_central.adult[9][4]**

```text
>旁边的长椅也挺好认。
```

**$.park_central.adult[10][0]**

```text
风吹草面
```

**$.park_central.adult[10][1]**

```text
草上有一片颜色在动。
```

**$.park_central.adult[10][2]**

```text
>风吹的，草都偏过去了。
```

**$.park_central.adult[10][3]**

```text
哦，刚还以为眼花。
```

**$.park_central.adult[10][4]**

```text
>背光看更明显。
```

**$.park_central.adult[11][0]**

```text
熟悉的陌生人
```

**$.park_central.adult[11][1]**

```text
是不是在这儿见过你？
```

**$.park_central.adult[11][2]**

```text
>可能，我有时来走走。
```

**$.park_central.adult[11][3]**

```text
那今天打个招呼。
```

**$.park_central.adult[11][4]**

```text
>你好啊。
```

**$.park_central.adult[12][0]**

```text
小狗的节奏
```

**$.park_central.adult[12][1]**

```text
刚那小狗拽着主人走。
```

**$.park_central.adult[12][2]**

```text
>估计看见别的狗了。
```

**$.park_central.adult[12][3]**

```text
人差点没拉住。
```

**$.park_central.adult[12][4]**

```text
>小归小，劲儿挺大。
```

**$.park_central.adult[13][0]**

```text
树荫的形状
```

**$.park_central.adult[13][1]**

```text
树荫刚好能挡太阳。
```

**$.park_central.adult[13][2]**

```text
>站里面凉快不少。
```

**$.park_central.adult[13][3]**

```text
我往旁边挪一点。
```

**$.park_central.adult[13][4]**

```text
>嗯，别挤着就行。
```

**$.park_central.adult[14][0]**

```text
绕不过的晚饭
```

**$.park_central.adult[14][1]**

```text
一走路就开始想吃什么。
```

**$.park_central.adult[14][2]**

```text
>你出来前吃饭了吗？
```

**$.park_central.adult[14][3]**

```text
吃了，现在又有点馋。
```

**$.park_central.adult[14][4]**

```text
>先走完这段再说吧。
```

**$.park_central.adult[15][0]**

```text
快走和慢走
```

**$.park_central.adult[15][1]**

```text
大家怎么都比我走得快。
```

**$.park_central.adult[15][2]**

```text
>跑步的多，你不用跟着赶。
```

**$.park_central.adult[15][3]**

```text
我就随便转转。
```

**$.park_central.adult[15][4]**

```text
>那慢点走也没事。
```

**$.park_central.adult[16][0]**

```text
不带耳机
```

**$.park_central.adult[16][1]**

```text
今天没戴耳机，听见好多声音。
```

**$.park_central.adult[16][2]**

```text
>平时戴着就听不见。
```

**$.park_central.adult[16][3]**

```text
刚有鸟叫，我还找了一下。
```

**$.park_central.adult[16][4]**

```text
>在上面，树叶挡着了。
```

**$.park_central.adult[17][0]**

```text
一片叶子的事
```

**$.park_central.adult[17][1]**

```text
刚差点踩到一片叶子。
```

**$.park_central.adult[17][2]**

```text
>地上挺多的。
```

**$.park_central.adult[17][3]**

```text
这片还挺完整。
```

**$.park_central.adult[17][4]**

```text
>你想捡就捡干净点的。
```

**$.park_central.adult[18][0]**

```text
长椅的工作
```

**$.park_central.adult[18][1]**

```text
坐这儿是不是就不想起了？
```

**$.park_central.adult[18][2]**

```text
>有一点，刚走累了。
```

**$.park_central.adult[18][3]**

```text
我也歇一会儿。
```

**$.park_central.adult[18][4]**

```text
>这边空着，你坐。
```

**$.park_central.adult[19][0]**

```text
看云的结果
```

**$.park_central.adult[19][1]**

```text
云看了半天，也没看出像什么。
```

**$.park_central.adult[19][2]**

```text
>我刚觉得像鸟，一会儿又散了。
```

**$.park_central.adult[19][3]**

```text
现在就是一团。
```

**$.park_central.adult[19][4]**

```text
>嗯，风一吹就变了。
```

**$.park_central.adult[20][0]**

```text
走丢的计划
```

**$.park_central.adult[20][1]**

```text
本来定的路线走忘了。
```

**$.park_central.adult[20][2]**

```text
>怎么走的？
```

**$.park_central.adult[20][3]**

```text
看见小路就拐过来了。
```

**$.park_central.adult[20][4]**

```text
>看看牌子，别再走反了。
```

**$.park_central.adult[21][0]**

```text
中央的路灯
```

**$.park_central.adult[21][1]**

```text
中央这盏灯挺好认。
```

**$.park_central.adult[21][2]**

```text
>嗯，回来时看见它就知道到了。
```

**$.park_central.adult[21][3]**

```text
我刚就是靠这个找的。
```

**$.park_central.adult[21][4]**

```text
>旁边草坪也一样好认。
```

**$.park_central.adult[22][0]**

```text
遇到笑脸
```

**$.park_central.adult[22][1]**

```text
刚那人冲我笑，我没反应过来。
```

**$.park_central.adult[22][2]**

```text
>认识的？
```

**$.park_central.adult[22][3]**

```text
不认识，可能认错了。
```

**$.park_central.adult[22][4]**

```text
>点点头就行，没事。
```

**$.park_central.adult[23][0]**

```text
留点空白
```

**$.park_central.adult[23][1]**

```text
今天没给自己排太多事。
```

**$.park_central.adult[23][2]**

```text
>那就慢慢转。
```

**$.park_central.adult[23][3]**

```text
嗯，不赶着回去。
```

**$.park_central.adult[23][4]**

```text
>我也想多走一点。
```

**$.park_central.adult[24][0]**

```text
主动的第一句
```

**$.park_central.adult[24][1].mm**

```text
{对方称呼}，你好，刚才想跟你说句话。
```

**$.park_central.adult[24][1].mf**

```text
你好，你好，刚才想跟你说句话。
```

**$.park_central.adult[24][1].fm**

```text
你好，{对方称呼}，你好，刚才想跟你说句话。
```

**$.park_central.adult[24][1].ff**

```text
你好，你好，刚才想跟你说句话。
```

**$.park_central.adult[24][2].mm**

```text
>{主角称呼}，嗯，怎么了？
```

**$.park_central.adult[24][2].mf**

```text
>嗯，怎么了？
```

**$.park_central.adult[24][2].fm**

```text
>嗯，怎么了？
```

**$.park_central.adult[24][2].ff**

```text
>{主角称呼}，嗯，怎么了？
```

**$.park_central.adult[24][3]**

```text
想问前面能不能绕回来。
```

**$.park_central.adult[24][4]**

```text
>能，顺着小路走就行。
```

**$.park_central.adult[25][0]**

```text
草坪的尺子
```

**$.park_central.adult[25][1].mm**

```text
{对方称呼}，草坪这条纹真直。
```

**$.park_central.adult[25][1].mf**

```text
你好，草坪这条纹真直。
```

**$.park_central.adult[25][1].fm**

```text
你好，{对方称呼}，草坪这条纹真直。
```

**$.park_central.adult[25][1].ff**

```text
你好，草坪这条纹真直。
```

**$.park_central.adult[25][2].mm**

```text
>{主角称呼}，割的时候有方向吧。
```

**$.park_central.adult[25][2].mf**

```text
>割的时候有方向吧。
```

**$.park_central.adult[25][2].fm**

```text
>割的时候有方向吧。
```

**$.park_central.adult[25][2].ff**

```text
>{主角称呼}，割的时候有方向吧。
```

**$.park_central.adult[25][3]**

```text
我在家画线都没这么直。
```

**$.park_central.adult[25][4]**

```text
>人家有工具，不一样。
```

**$.park_central.adult[26][0]**

```text
绕圈的收获
```

**$.park_central.adult[26][1].mm**

```text
{对方称呼}，绕一圈又看见同一只狗。
```

**$.park_central.adult[26][1].mf**

```text
你好，绕一圈又看见同一只狗。
```

**$.park_central.adult[26][1].fm**

```text
你好，{对方称呼}，绕一圈又看见同一只狗。
```

**$.park_central.adult[26][1].ff**

```text
你好，绕一圈又看见同一只狗。
```

**$.park_central.adult[26][2].mm**

```text
>{主角称呼}，它也在绕圈吧。
```

**$.park_central.adult[26][2].mf**

```text
>它也在绕圈吧。
```

**$.park_central.adult[26][2].fm**

```text
>它也在绕圈吧。
```

**$.park_central.adult[26][2].ff**

```text
>{主角称呼}，它也在绕圈吧。
```

**$.park_central.adult[26][3]**

```text
比我还快。
```

**$.park_central.adult[26][4]**

```text
>四条腿跑起来是快。
```

**$.park_central.adult[27][0]**

```text
长椅申请表
```

**$.park_central.adult[27][1].mm**

```text
{对方称呼}，长椅有空位，我想歇会儿。
```

**$.park_central.adult[27][1].mf**

```text
你好，长椅有空位，我想歇会儿。
```

**$.park_central.adult[27][1].fm**

```text
你好，{对方称呼}，长椅有空位，我想歇会儿。
```

**$.park_central.adult[27][1].ff**

```text
你好，长椅有空位，我想歇会儿。
```

**$.park_central.adult[27][2].mm**

```text
>{主角称呼}，去吧，我刚从那边站起来。
```

**$.park_central.adult[27][2].mf**

```text
>去吧，我刚从那边站起来。
```

**$.park_central.adult[27][2].fm**

```text
>去吧，我刚从那边站起来。
```

**$.park_central.adult[27][2].ff**

```text
>{主角称呼}，去吧，我刚从那边站起来。
```

**$.park_central.adult[27][3]**

```text
座面脏不脏？
```

**$.park_central.adult[27][4]**

```text
>还好，先看看再坐。
```

**$.park_central.adult[28][0]**

```text
没选好的路线
```

**$.park_central.adult[28][1].mm**

```text
{对方称呼}，路太多，选哪条好。
```

**$.park_central.adult[28][1].mf**

```text
你好，路太多，选哪条好。
```

**$.park_central.adult[28][1].fm**

```text
你好，{对方称呼}，路太多，选哪条好。
```

**$.park_central.adult[28][1].ff**

```text
你好，路太多，选哪条好。
```

**$.park_central.adult[28][2].mm**

```text
>{主角称呼}，想往湖边还是草地？
```

**$.park_central.adult[28][2].mf**

```text
>想往湖边还是草地？
```

**$.park_central.adult[28][2].fm**

```text
>想往湖边还是草地？
```

**$.park_central.adult[28][2].ff**

```text
>{主角称呼}，想往湖边还是草地？
```

**$.park_central.adult[28][3]**

```text
想去湖边。
```

**$.park_central.adult[28][4]**

```text
>那先看那边的指示牌。
```

**$.park_central.adult[29][0]**

```text
公园的背景音
```

**$.park_central.adult[29][1].mm**

```text
{对方称呼}，不戴耳机听见好多声音。
```

**$.park_central.adult[29][1].mf**

```text
你好，不戴耳机听见好多声音。
```

**$.park_central.adult[29][1].fm**

```text
你好，{对方称呼}，不戴耳机听见好多声音。
```

**$.park_central.adult[29][1].ff**

```text
你好，不戴耳机听见好多声音。
```

**$.park_central.adult[29][2].mm**

```text
>{主角称呼}，嗯，还有人鞋底吱吱响。
```

**$.park_central.adult[29][2].mf**

```text
>嗯，还有人鞋底吱吱响。
```

**$.park_central.adult[29][2].fm**

```text
>嗯，还有人鞋底吱吱响。
```

**$.park_central.adult[29][2].ff**

```text
>{主角称呼}，嗯，还有人鞋底吱吱响。
```

**$.park_central.adult[29][3]**

```text
我刚也听到了。
```

**$.park_central.adult[29][4]**

```text
>还有那边狗叫，一阵一阵的。
```

**$.park_central.adult[30][0]**

```text
影子换位置
```

**$.park_central.adult[30][1].mm**

```text
{对方称呼}，树影都挪到路上了。
```

**$.park_central.adult[30][1].mf**

```text
你好，树影都挪到路上了。
```

**$.park_central.adult[30][1].fm**

```text
你好，{对方称呼}，树影都挪到路上了。
```

**$.park_central.adult[30][1].ff**

```text
你好，树影都挪到路上了。
```

**$.park_central.adult[30][2].mm**

```text
>{主角称呼}，太阳换位置了。
```

**$.park_central.adult[30][2].mf**

```text
>太阳换位置了。
```

**$.park_central.adult[30][2].fm**

```text
>太阳换位置了。
```

**$.park_central.adult[30][2].ff**

```text
>{主角称呼}，太阳换位置了。
```

**$.park_central.adult[30][3]**

```text
刚才还能站里面。
```

**$.park_central.adult[30][4]**

```text
>往边上一点还有荫。
```

**$.park_central.adult[31][0]**

```text
草边的边界
```

**$.park_central.adult[31][1].mm**

```text
{对方称呼}，这儿到草坪边上有个坎。
```

**$.park_central.adult[31][1].mf**

```text
你好，这儿到草坪边上有个坎。
```

**$.park_central.adult[31][1].fm**

```text
你好，{对方称呼}，这儿到草坪边上有个坎。
```

**$.park_central.adult[31][1].ff**

```text
你好，这儿到草坪边上有个坎。
```

**$.park_central.adult[31][2].mm**

```text
>{主角称呼}，嗯，别光看草。
```

**$.park_central.adult[31][2].mf**

```text
>嗯，别光看草。
```

**$.park_central.adult[31][2].fm**

```text
>嗯，别光看草。
```

**$.park_central.adult[31][2].ff**

```text
>{主角称呼}，嗯，别光看草。
```

**$.park_central.adult[31][3]**

```text
差点踢到。
```

**$.park_central.adult[31][4]**

```text
>走路抬点脚，别摔了。
```

**$.park_central.adult[32][0]**

```text
把脚步放平
```

**$.park_central.adult[32][1].mm**

```text
{对方称呼}，走太久脚底有点麻。
```

**$.park_central.adult[32][1].mf**

```text
你好，走太久脚底有点麻。
```

**$.park_central.adult[32][1].fm**

```text
你好，{对方称呼}，走太久脚底有点麻。
```

**$.park_central.adult[32][1].ff**

```text
你好，走太久脚底有点麻。
```

**$.park_central.adult[32][2].mm**

```text
>{主角称呼}，先坐一会儿。
```

**$.park_central.adult[32][2].mf**

```text
>先坐一会儿。
```

**$.park_central.adult[32][2].fm**

```text
>先坐一会儿。
```

**$.park_central.adult[32][2].ff**

```text
>{主角称呼}，先坐一会儿。
```

**$.park_central.adult[32][3]**

```text
嗯，不想再走了。
```

**$.park_central.adult[32][4]**

```text
>够了就回，别勉强。
```

**$.park_central.adult[33][0]**

```text
云的错别字
```

**$.park_central.adult[33][1].mm**

```text
{对方称呼}，云上那块缺口有点像个字。
```

**$.park_central.adult[33][1].mf**

```text
你好，云上那块缺口有点像个字。
```

**$.park_central.adult[33][1].fm**

```text
你好，{对方称呼}，云上那块缺口有点像个字。
```

**$.park_central.adult[33][1].ff**

```text
你好，云上那块缺口有点像个字。
```

**$.park_central.adult[33][2].mm**

```text
>{主角称呼}，什么字？
```

**$.park_central.adult[33][2].mf**

```text
>什么字？
```

**$.park_central.adult[33][2].fm**

```text
>什么字？
```

**$.park_central.adult[33][2].ff**

```text
>{主角称呼}，什么字？
```

**$.park_central.adult[33][3]**

```text
刚才像，现在不太像了。
```

**$.park_central.adult[33][4]**

```text
>这会儿都散了。
```

**$.park_central.adult[34][0]**

```text
别人走得快
```

**$.park_central.adult[34][1].mm**

```text
{对方称呼}，别人怎么一直从我旁边超。
```

**$.park_central.adult[34][1].mf**

```text
你好，别人怎么一直从我旁边超。
```

**$.park_central.adult[34][1].fm**

```text
你好，{对方称呼}，别人怎么一直从我旁边超。
```

**$.park_central.adult[34][1].ff**

```text
你好，别人怎么一直从我旁边超。
```

**$.park_central.adult[34][2].mm**

```text
>{主角称呼}，有人在快走，你不用跟。
```

**$.park_central.adult[34][2].mf**

```text
>有人在快走，你不用跟。
```

**$.park_central.adult[34][2].fm**

```text
>有人在快走，你不用跟。
```

**$.park_central.adult[34][2].ff**

```text
>{主角称呼}，有人在快走，你不用跟。
```

**$.park_central.adult[34][3]**

```text
嗯，我就随便转转。
```

**$.park_central.adult[34][4]**

```text
>那别急，慢慢走。
```

**$.park_central.adult[35][0]**

```text
长椅的两边
```

**$.park_central.adult[35][1].mm**

```text
{对方称呼}，长椅两头哪个舒服？
```

**$.park_central.adult[35][1].mf**

```text
你好，长椅两头哪个舒服？
```

**$.park_central.adult[35][1].fm**

```text
你好，{对方称呼}，长椅两头哪个舒服？
```

**$.park_central.adult[35][1].ff**

```text
你好，长椅两头哪个舒服？
```

**$.park_central.adult[35][2].mm**

```text
>{主角称呼}，这边不晒，另一头光多。
```

**$.park_central.adult[35][2].mf**

```text
>这边不晒，另一头光多。
```

**$.park_central.adult[35][2].fm**

```text
>这边不晒，另一头光多。
```

**$.park_central.adult[35][2].ff**

```text
>{主角称呼}，这边不晒，另一头光多。
```

**$.park_central.adult[35][3]**

```text
那我坐这边。
```

**$.park_central.adult[35][4]**

```text
>行，我往旁边挪一点。
```

**$.park_central.adult[36][0]**

```text
耳机歇一会儿
```

**$.park_central.adult[36][1].mm**

```text
{对方称呼}，耳机戴久了，摘下来有点不习惯。
```

**$.park_central.adult[36][1].mf**

```text
你好，耳机戴久了，摘下来有点不习惯。
```

**$.park_central.adult[36][1].fm**

```text
你好，{对方称呼}，耳机戴久了，摘下来有点不习惯。
```

**$.park_central.adult[36][1].ff**

```text
你好，耳机戴久了，摘下来有点不习惯。
```

**$.park_central.adult[36][2].mm**

```text
>{主角称呼}，耳朵闷吗？
```

**$.park_central.adult[36][2].mf**

```text
>耳朵闷吗？
```

**$.park_central.adult[36][2].fm**

```text
>耳朵闷吗？
```

**$.park_central.adult[36][2].ff**

```text
>{主角称呼}，耳朵闷吗？
```

**$.park_central.adult[36][3]**

```text
有一点。
```

**$.park_central.adult[36][4]**

```text
>先别戴了，透透气。
```

**$.park_central.adult[37][0]**

```text
热闹的空位
```

**$.park_central.adult[37][1].mm**

```text
{对方称呼}，这边挺热闹，但也能找到空位。
```

**$.park_central.adult[37][1].mf**

```text
你好，这边挺热闹，但也能找到空位。
```

**$.park_central.adult[37][1].fm**

```text
你好，{对方称呼}，这边挺热闹，但也能找到空位。
```

**$.park_central.adult[37][1].ff**

```text
你好，这边挺热闹，但也能找到空位。
```

**$.park_central.adult[37][2].mm**

```text
>{主角称呼}，前面那张刚有人走。
```

**$.park_central.adult[37][2].mf**

```text
>前面那张刚有人走。
```

**$.park_central.adult[37][2].fm**

```text
>前面那张刚有人走。
```

**$.park_central.adult[37][2].ff**

```text
>{主角称呼}，前面那张刚有人走。
```

**$.park_central.adult[37][3]**

```text
哦，我过去看看。
```

**$.park_central.adult[37][4]**

```text
>嗯，别急着跑。
```

**$.park_central.adult[38][0]**

```text
袜子的意见
```

**$.park_central.adult[38][1].mm**

```text
{对方称呼}，袜子有点皱，老磨脚。
```

**$.park_central.adult[38][1].mf**

```text
你好，袜子有点皱，老磨脚。
```

**$.park_central.adult[38][1].fm**

```text
你好，{对方称呼}，袜子有点皱，老磨脚。
```

**$.park_central.adult[38][1].ff**

```text
你好，袜子有点皱，老磨脚。
```

**$.park_central.adult[38][2].mm**

```text
>{主角称呼}，是不是缩到鞋里面了？
```

**$.park_central.adult[38][2].mf**

```text
>是不是缩到鞋里面了？
```

**$.park_central.adult[38][2].fm**

```text
>是不是缩到鞋里面了？
```

**$.park_central.adult[38][2].ff**

```text
>{主角称呼}，是不是缩到鞋里面了？
```

**$.park_central.adult[38][3]**

```text
可能，我坐下拉一下。
```

**$.park_central.adult[38][4]**

```text
>弄好再走，磨破更难受。
```

**$.park_central.adult[39][0]**

```text
散步没成果
```

**$.park_central.adult[39][1].mm**

```text
{对方称呼}，散步回来也没什么成果。
```

**$.park_central.adult[39][1].mf**

```text
你好，散步回来也没什么成果。
```

**$.park_central.adult[39][1].fm**

```text
你好，{对方称呼}，散步回来也没什么成果。
```

**$.park_central.adult[39][1].ff**

```text
你好，散步回来也没什么成果。
```

**$.park_central.adult[39][2].mm**

```text
>{主角称呼}，你本来想干什么？
```

**$.park_central.adult[39][2].mf**

```text
>你本来想干什么？
```

**$.park_central.adult[39][2].fm**

```text
>你本来想干什么？
```

**$.park_central.adult[39][2].ff**

```text
>{主角称呼}，你本来想干什么？
```

**$.park_central.adult[39][3]**

```text
没，就觉得总得有点什么。
```

**$.park_central.adult[39][4]**

```text
>腿走了不就行，歇会儿吧。
```

**$.park_central.adult[40][0]**

```text
看见同一只鸟
```

**$.park_central.adult[40][1].mm**

```text
{对方称呼}，刚才那只鸟你也看见了？
```

**$.park_central.adult[40][1].mf**

```text
你好，刚才那只鸟你也看见了？
```

**$.park_central.adult[40][1].fm**

```text
你好，{对方称呼}，刚才那只鸟你也看见了？
```

**$.park_central.adult[40][1].ff**

```text
你好，刚才那只鸟你也看见了？
```

**$.park_central.adult[40][2].mm**

```text
>{主角称呼}，看见了，尾巴挺长。
```

**$.park_central.adult[40][2].mf**

```text
>看见了，尾巴挺长。
```

**$.park_central.adult[40][2].fm**

```text
>看见了，尾巴挺长。
```

**$.park_central.adult[40][2].ff**

```text
>{主角称呼}，看见了，尾巴挺长。
```

**$.park_central.adult[40][3]**

```text
对，一飞就看清了。
```

**$.park_central.adult[40][4]**

```text
>现在钻树里面了。
```

**$.park_central.adult[41][0]**

```text
一张好椅子
```

**$.park_central.adult[41][1].mm**

```text
{对方称呼}，这长椅还挺结实。
```

**$.park_central.adult[41][1].mf**

```text
你好，这长椅还挺结实。
```

**$.park_central.adult[41][1].fm**

```text
你好，{对方称呼}，这长椅还挺结实。
```

**$.park_central.adult[41][1].ff**

```text
你好，这长椅还挺结实。
```

**$.park_central.adult[41][2].mm**

```text
>{主角称呼}，嗯，坐上去不晃。
```

**$.park_central.adult[41][2].mf**

```text
>嗯，坐上去不晃。
```

**$.park_central.adult[41][2].fm**

```text
>嗯，坐上去不晃。
```

**$.park_central.adult[41][2].ff**

```text
>{主角称呼}，嗯，坐上去不晃。
```

**$.park_central.adult[41][3]**

```text
我以为边上会翘。
```

**$.park_central.adult[41][4]**

```text
>没有，刚才两个人坐也稳。
```

**$.park_central.adult[42][0]**

```text
轻轻的偶遇
```

**$.park_central.adult[42][1].mm**

```text
{对方称呼}，没想到今天又碰上。
```

**$.park_central.adult[42][1].mf**

```text
你好，没想到今天又碰上。
```

**$.park_central.adult[42][1].fm**

```text
你好，{对方称呼}，没想到今天又碰上。
```

**$.park_central.adult[42][1].ff**

```text
你好，没想到今天又碰上。
```

**$.park_central.adult[42][2].mm**

```text
>{主角称呼}，你也走这条路啊。
```

**$.park_central.adult[42][2].mf**

```text
>你也走这条路啊。
```

**$.park_central.adult[42][2].fm**

```text
>你也走这条路啊。
```

**$.park_central.adult[42][2].ff**

```text
>{主角称呼}，你也走这条路啊。
```

**$.park_central.adult[42][3]**

```text
嗯，刚换到这边。
```

**$.park_central.adult[42][4]**

```text
>我一会儿还得往回走。
```

**$.park_central.adult[43][0]**

```text
画面里的自己
```

**$.park_central.adult[43][1].mm**

```text
{对方称呼}，拍草坪把自己影子拍进去了。
```

**$.park_central.adult[43][1].mf**

```text
你好，拍草坪把自己影子拍进去了。
```

**$.park_central.adult[43][1].fm**

```text
你好，{对方称呼}，拍草坪把自己影子拍进去了。
```

**$.park_central.adult[43][1].ff**

```text
你好，拍草坪把自己影子拍进去了。
```

**$.park_central.adult[43][2].mm**

```text
>{主角称呼}，换个方向站呢？
```

**$.park_central.adult[43][2].mf**

```text
>换个方向站呢？
```

**$.park_central.adult[43][2].fm**

```text
>换个方向站呢？
```

**$.park_central.adult[43][2].ff**

```text
>{主角称呼}，换个方向站呢？
```

**$.park_central.adult[43][3]**

```text
嗯，这边好多了。
```

**$.park_central.adult[43][4]**

```text
>别又把手指挡镜头上。
```

**$.park_central.adult[44][0]**

```text
把念头放一放
```

**$.park_central.adult[44][1].mm**

```text
{对方称呼}，刚一直在想一件烦事。
```

**$.park_central.adult[44][1].mf**

```text
你好，刚一直在想一件烦事。
```

**$.park_central.adult[44][1].fm**

```text
你好，{对方称呼}，刚一直在想一件烦事。
```

**$.park_central.adult[44][1].ff**

```text
你好，刚一直在想一件烦事。
```

**$.park_central.adult[44][2].mm**

```text
>{主角称呼}，要不要先停一下？
```

**$.park_central.adult[44][2].mf**

```text
>要不要先停一下？
```

**$.park_central.adult[44][2].fm**

```text
>要不要先停一下？
```

**$.park_central.adult[44][2].ff**

```text
>{主角称呼}，要不要先停一下？
```

**$.park_central.adult[44][3]**

```text
嗯，走着走着还在想。
```

**$.park_central.adult[44][4]**

```text
>先看看路，回去再处理。
```

**$.park_central.adult[45][0]**

```text
空着的下午
```

**$.park_central.adult[45][1].mm**

```text
{对方称呼}，下午没什么安排。
```

**$.park_central.adult[45][1].mf**

```text
你好，下午没什么安排。
```

**$.park_central.adult[45][1].fm**

```text
你好，{对方称呼}，下午没什么安排。
```

**$.park_central.adult[45][1].ff**

```text
你好，下午没什么安排。
```

**$.park_central.adult[45][2].mm**

```text
>{主角称呼}，那就在这儿转转。
```

**$.park_central.adult[45][2].mf**

```text
>那就在这儿转转。
```

**$.park_central.adult[45][2].fm**

```text
>那就在这儿转转。
```

**$.park_central.adult[45][2].ff**

```text
>{主角称呼}，那就在这儿转转。
```

**$.park_central.adult[45][3]**

```text
走累了再回。
```

**$.park_central.adult[45][4]**

```text
>嗯，我也这么想的。
```

**$.park_central.adult[46][0]**

```text
好好告别
```

**$.park_central.adult[46][1].mm**

```text
{对方称呼}，我先往回走了。
```

**$.park_central.adult[46][1].mf**

```text
你好，我先往回走了。
```

**$.park_central.adult[46][1].fm**

```text
你好，{对方称呼}，我先往回走了。
```

**$.park_central.adult[46][1].ff**

```text
你好，我先往回走了。
```

**$.park_central.adult[46][2].mm**

```text
>{主角称呼}，好，今天走挺久了吧。
```

**$.park_central.adult[46][2].mf**

```text
>好，今天走挺久了吧。
```

**$.park_central.adult[46][2].fm**

```text
>好，今天走挺久了吧。
```

**$.park_central.adult[46][2].ff**

```text
>{主角称呼}，好，今天走挺久了吧。
```

**$.park_central.adult[46][3]**

```text
是，回去得坐会儿。
```

**$.park_central.adult[46][4]**

```text
>行，回头见。
```

**$.park_central.adult[47][0]**

```text
平常的开心
```

**$.park_central.adult[47][1].mm**

```text
{对方称呼}，出来这一趟还挺开心。
```

**$.park_central.adult[47][1].mf**

```text
你好，出来这一趟还挺开心。
```

**$.park_central.adult[47][1].fm**

```text
你好，{对方称呼}，出来这一趟还挺开心。
```

**$.park_central.adult[47][1].ff**

```text
你好，出来这一趟还挺开心。
```

**$.park_central.adult[47][2].mm**

```text
>{主角称呼}，有碰见什么有意思的？
```

**$.park_central.adult[47][2].mf**

```text
>有碰见什么有意思的？
```

**$.park_central.adult[47][2].fm**

```text
>有碰见什么有意思的？
```

**$.park_central.adult[47][2].ff**

```text
>{主角称呼}，有碰见什么有意思的？
```

**$.park_central.adult[47][3]**

```text
也没什么，就是不闷了。
```

**$.park_central.adult[47][4]**

```text
>那就挺好，常出来走两步。
```

**$.park_central.kid[0][0]**

```text
草坪的条纹
```

**$.park_central.kid[0][1]**

```text
你在看哪一条草？
```

**$.park_central.kid[0][2]**

```text
>每条都在看，我觉得它像大西瓜。
```

**$.park_central.kid[0][3]**

```text
那我们站在西瓜外面。
```

**$.park_central.kid[0][4]**

```text
>对，不然就会变成籽。
```

**$.park_central.kid[1][0]**

```text
鸭子开会
```

**$.park_central.kid[1][1]**

```text
那几只鸭子在讨论什么？
```

**$.park_central.kid[1][2]**

```text
>可能在选今天谁先嘎。
```

**$.park_central.kid[1][3]**

```text
你想报名吗？
```

**$.park_central.kid[1][4]**

```text
>想，但我怕口音不标准。
```

**$.park_central.kid[2][0]**

```text
长椅公交
```

**$.park_central.kid[2][1]**

```text
你怎么在长椅旁边排队？
```

**$.park_central.kid[2][2]**

```text
>我想象它是一辆还没开走的公交。
```

**$.park_central.kid[2][3]**

```text
坐上去会去哪儿？
```

**$.park_central.kid[2][4]**

```text
>去休息站，永远不堵车。
```

**$.park_central.kid[3][0]**

```text
树影拼图
```

**$.park_central.kid[3][1]**

```text
影子被树叶分成好多块。
```

**$.park_central.kid[3][2]**

```text
>我想把它们拼成一只恐龙。
```

**$.park_central.kid[3][3]**

```text
风总会帮你换一块。
```

**$.park_central.kid[3][4]**

```text
>它是个有点着急的队友。
```

**$.park_central.kid[4][0]**

```text
脚步比赛
```

**$.park_central.kid[4][1]**

```text
你是不是故意走得很慢？
```

**$.park_central.kid[4][2]**

```text
>我在挑战今天最慢的人。
```

**$.park_central.kid[4][3]**

```text
那我可不跟你抢冠军。
```

**$.park_central.kid[4][4]**

```text
>谢谢，你真有比赛礼貌。
```

**$.park_central.kid[5][0]**

```text
口袋的发现
```

**$.park_central.kid[5][1]**

```text
你口袋里装着什么？
```

**$.park_central.kid[5][2]**

```text
>一片叶子，已经被批准跟我回家。
```

**$.park_central.kid[5][3]**

```text
叶子同意了吗？
```

**$.park_central.kid[5][4]**

```text
>我问过，它没有摇头。
```

**$.park_central.kid[6][0]**

```text
草坪毛衣
```

**$.park_central.kid[6][1].mm**

```text
{对方称呼}，你觉得草坪像什么？
```

**$.park_central.kid[6][1].mf**

```text
你好，你觉得草坪像什么？
```

**$.park_central.kid[6][1].fm**

```text
你好，{对方称呼}，你觉得草坪像什么？
```

**$.park_central.kid[6][1].ff**

```text
打个招呼，你觉得草坪像什么？
```

**$.park_central.kid[6][2].mm**

```text
>{主角称呼}，嗯，像一件大到没人穿得下的毛衣。
```

**$.park_central.kid[6][2].mf**

```text
>{主角称呼}，说起来，像一件大到没人穿得下的毛衣。
```

**$.park_central.kid[6][2].fm**

```text
>{主角称呼}，其实，像一件大到没人穿得下的毛衣。
```

**$.park_central.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，像一件大到没人穿得下的毛衣。
```

**$.park_central.kid[6][3]**

```text
它自己穿着也不错。
```

**$.park_central.kid[6][4]**

```text
>对，还给蚂蚁留了很多小路。
```

**$.park_central.kid[7][0]**

```text
鸭子的回答
```

**$.park_central.kid[7][1].mm**

```text
{对方称呼}，你刚才在问鸭子什么？
```

**$.park_central.kid[7][1].mf**

```text
你好，你刚才在问鸭子什么？
```

**$.park_central.kid[7][1].fm**

```text
你好，{对方称呼}，你刚才在问鸭子什么？
```

**$.park_central.kid[7][1].ff**

```text
打个招呼，你刚才在问鸭子什么？
```

**$.park_central.kid[7][2].mm**

```text
>{主角称呼}，说起来，问它知不知道我叫什么。
```

**$.park_central.kid[7][2].mf**

```text
>{主角称呼}，其实，问它知不知道我叫什么。
```

**$.park_central.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，问它知不知道我叫什么。
```

**$.park_central.kid[7][2].ff**

```text
>{主角称呼}，嗯，问它知不知道我叫什么。
```

**$.park_central.kid[7][3]**

```text
它怎么说？
```

**$.park_central.kid[7][4]**

```text
>一直嘎，我觉得还没记住。
```

**$.park_central.kid[8][0]**

```text
长椅的腿
```

**$.park_central.kid[8][1].mm**

```text
{对方称呼}，你在数椅子有几条腿吗？
```

**$.park_central.kid[8][1].mf**

```text
你好，你在数椅子有几条腿吗？
```

**$.park_central.kid[8][1].fm**

```text
你好，{对方称呼}，你在数椅子有几条腿吗？
```

**$.park_central.kid[8][1].ff**

```text
打个招呼，你在数椅子有几条腿吗？
```

**$.park_central.kid[8][2].mm**

```text
>{主角称呼}，其实，对，它站这么久，应该也挺累。
```

**$.park_central.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，对，它站这么久，应该也挺累。
```

**$.park_central.kid[8][2].fm**

```text
>{主角称呼}，嗯，对，它站这么久，应该也挺累。
```

**$.park_central.kid[8][2].ff**

```text
>{主角称呼}，说起来，对，它站这么久，应该也挺累。
```

**$.park_central.kid[8][3]**

```text
有人坐着，它可能更高兴。
```

**$.park_central.kid[8][4]**

```text
>那我轻轻坐，不一下子扑上去。
```

**$.park_central.kid[9][0]**

```text
一片叶子的票
```

**$.park_central.kid[9][1].mm**

```text
{对方称呼}，为什么把叶子夹在手里？
```

**$.park_central.kid[9][1].mf**

```text
你好，为什么把叶子夹在手里？
```

**$.park_central.kid[9][1].fm**

```text
你好，{对方称呼}，为什么把叶子夹在手里？
```

**$.park_central.kid[9][1].ff**

```text
打个招呼，为什么把叶子夹在手里？
```

**$.park_central.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，这是我今天散步的车票。
```

**$.park_central.kid[9][2].mf**

```text
>{主角称呼}，嗯，这是我今天散步的车票。
```

**$.park_central.kid[9][2].fm**

```text
>{主角称呼}，说起来，这是我今天散步的车票。
```

**$.park_central.kid[9][2].ff**

```text
>{主角称呼}，其实，这是我今天散步的车票。
```

**$.park_central.kid[9][3]**

```text
要交给谁检查？
```

**$.park_central.kid[9][4]**

```text
>我自己，我检查得很宽松。
```

**$.park_central.kid[10][0]**

```text
不急着跑
```

**$.park_central.kid[10][1].mm**

```text
{对方称呼}，今天怎么没有跑得很快？
```

**$.park_central.kid[10][1].mf**

```text
你好，今天怎么没有跑得很快？
```

**$.park_central.kid[10][1].fm**

```text
你好，{对方称呼}，今天怎么没有跑得很快？
```

**$.park_central.kid[10][1].ff**

```text
打个招呼，今天怎么没有跑得很快？
```

**$.park_central.kid[10][2].mm**

```text
>{主角称呼}，嗯，想看看平时跑过去错过的东西。
```

**$.park_central.kid[10][2].mf**

```text
>{主角称呼}，说起来，想看看平时跑过去错过的东西。
```

**$.park_central.kid[10][2].fm**

```text
>{主角称呼}，其实，想看看平时跑过去错过的东西。
```

**$.park_central.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，想看看平时跑过去错过的东西。
```

**$.park_central.kid[10][3]**

```text
已经发现什么了吗？
```

**$.park_central.kid[10][4]**

```text
>发现这块地砖有点像小熊。
```

**$.park_central.kid[11][0]**

```text
给风打分
```

**$.park_central.kid[11][1].mm**

```text
{对方称呼}，你在竖拇指给谁看？
```

**$.park_central.kid[11][1].mf**

```text
你好，你在竖拇指给谁看？
```

**$.park_central.kid[11][1].fm**

```text
你好，{对方称呼}，你在竖拇指给谁看？
```

**$.park_central.kid[11][1].ff**

```text
打个招呼，你在竖拇指给谁看？
```

**$.park_central.kid[11][2].mm**

```text
>{主角称呼}，说起来，给风，它刚才吹得刚刚好。
```

**$.park_central.kid[11][2].mf**

```text
>{主角称呼}，其实，给风，它刚才吹得刚刚好。
```

**$.park_central.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，给风，它刚才吹得刚刚好。
```

**$.park_central.kid[11][2].ff**

```text
>{主角称呼}，嗯，给风，它刚才吹得刚刚好。
```

**$.park_central.kid[11][3]**

```text
它应该收到了。
```

**$.park_central.kid[11][4]**

```text
>那我不多打几次，免得它骄傲。
```

**$.park_meadow.adult[0][0]**

```text
野餐毯边界
```

**$.park_meadow.adult[0][1]**

```text
毯子铺得挺平啊。
```

**$.park_meadow.adult[0][2]**

```text
>刚拿水瓶压了四个角。
```

**$.park_meadow.adult[0][3]**

```text
风大时不会掀起来？
```

**$.park_meadow.adult[0][4]**

```text
>不压真不行，刚吹翻一回。
```

**$.park_meadow.adult[1][0]**

```text
饭盒的安排
```

**$.park_meadow.adult[1][1]**

```text
出来野餐你带多少东西？
```

**$.park_meadow.adult[1][2]**

```text
>我老带多，回去还得背。
```

**$.park_meadow.adult[1][3]**

```text
怕不够吃吧。
```

**$.park_meadow.adult[1][4]**

```text
>对，结果每次都剩。
```

**$.park_meadow.adult[2][0]**

```text
草坪的午饭
```

**$.park_meadow.adult[2][1]**

```text
外面吃东西好像更香。
```

**$.park_meadow.adult[2][2]**

```text
>可能走累了，饿的。
```

**$.park_meadow.adult[2][3]**

```text
也是，我都走半天了。
```

**$.park_meadow.adult[2][4]**

```text
>先吃点吧，别饿太久。
```

**$.park_meadow.adult[3][0]**

```text
野餐的位置
```

**$.park_meadow.adult[3][1]**

```text
站这里没挡着你们吧？
```

**$.park_meadow.adult[3][2]**

```text
>没有，这边还宽。
```

**$.park_meadow.adult[3][3]**

```text
那我借过一下。
```

**$.park_meadow.adult[3][4]**

```text
>好，慢点。
```

**$.park_meadow.adult[4][0]**

```text
轻装出门
```

**$.park_meadow.adult[4][1]**

```text
你带的东西挺少。
```

**$.park_meadow.adult[4][2]**

```text
>上次带太多，累着了。
```

**$.park_meadow.adult[4][3]**

```text
这次够吃就行。
```

**$.park_meadow.adult[4][4]**

```text
>嗯，空盒子也沉。
```

**$.park_meadow.adult[5][0]**

```text
袋子的声音
```

**$.park_meadow.adult[5][1]**

```text
刚袋子一响，大家都看过来。
```

**$.park_meadow.adult[5][2]**

```text
>估计以为开吃的了。
```

**$.park_meadow.adult[5][3]**

```text
我就拿个纸巾。
```

**$.park_meadow.adult[5][4]**

```text
>哈哈，声音真像拆零食。
```

**$.park_meadow.adult[6][0]**

```text
餐巾纸的远行
```

**$.park_meadow.adult[6][1]**

```text
这纸差点吹跑了。
```

**$.park_meadow.adult[6][2]**

```text
>拿东西压着吧。
```

**$.park_meadow.adult[6][3]**

```text
我塞袋子里。
```

**$.park_meadow.adult[6][4]**

```text
>好，走前别落下。
```

**$.park_meadow.adult[7][0]**

```text
果汁的颜色
```

**$.park_meadow.adult[7][1]**

```text
果汁是不是洒了？
```

**$.park_meadow.adult[7][2]**

```text
>嗯，袖子上这一块。
```

**$.park_meadow.adult[7][3]**

```text
得赶紧擦，不然黏。
```

**$.park_meadow.adult[7][4]**

```text
>我拿纸蘸点水试试。
```

**$.park_meadow.adult[8][0]**

```text
小小的分享
```

**$.park_meadow.adult[8][1]**

```text
刚看见有人分水果。
```

**$.park_meadow.adult[8][2]**

```text
>那盒挺大，一人吃不完。
```

**$.park_meadow.adult[8][3]**

```text
自己切的吧，看着挺新鲜。
```

**$.park_meadow.adult[8][4]**

```text
>嗯，还带了小叉子。
```

**$.park_meadow.adult[9][0]**

```text
毯子的领土
```

**$.park_meadow.adult[9][1]**

```text
毯子铺开还挺占地方。
```

**$.park_meadow.adult[9][2]**

```text
>东西一摆就不够了。
```

**$.park_meadow.adult[9][3]**

```text
脚都快没地方放。
```

**$.park_meadow.adult[9][4]**

```text
>把空盒子先收起来吧。
```

**$.park_meadow.adult[10][0]**

```text
看见蚂蚁
```

**$.park_meadow.adult[10][1]**

```text
这儿有只蚂蚁。
```

**$.park_meadow.adult[10][2]**

```text
>刚才有饼干屑，估计闻到了。
```

**$.park_meadow.adult[10][3]**

```text
那我收一下。
```

**$.park_meadow.adult[10][4]**

```text
>碎的也装袋里，别留着。
```

**$.park_meadow.adult[11][0]**

```text
不用讲究
```

**$.park_meadow.adult[11][1]**

```text
我总觉得自己野餐准备得不好看。
```

**$.park_meadow.adult[11][2]**

```text
>吃着方便就行，还得自己收呢。
```

**$.park_meadow.adult[11][3]**

```text
照片里倒都特别整齐。
```

**$.park_meadow.adult[11][4]**

```text
>拍照前也得摆半天吧。
```

**$.park_meadow.adult[12][0]**

```text
杯子的归属
```

**$.park_meadow.adult[12][1]**

```text
哪个杯子是你的？
```

**$.park_meadow.adult[12][2]**

```text
>边上绑了绳子那个。
```

**$.park_meadow.adult[12][3]**

```text
这个办法好。
```

**$.park_meadow.adult[12][4]**

```text
>嗯，不然转头就忘。
```

**$.park_meadow.adult[13][0]**

```text
草香的提醒
```

**$.park_meadow.adult[13][1]**

```text
这里有股青草味。
```

**$.park_meadow.adult[13][2]**

```text
>刚割过吧。
```

**$.park_meadow.adult[13][3]**

```text
闻着还行，就是有点冲。
```

**$.park_meadow.adult[13][4]**

```text
>等会儿就散一些了。
```

**$.park_meadow.adult[14][0]**

```text
不够长的毯子
```

**$.park_meadow.adult[14][1]**

```text
毯子怎么总短一边。
```

**$.park_meadow.adult[14][2]**

```text
>盒子放太多了。
```

**$.park_meadow.adult[14][3]**

```text
我把这袋拿起来。
```

**$.park_meadow.adult[14][4]**

```text
>对，这下脚能放了。
```

**$.park_meadow.adult[15][0]**

```text
空手的野餐
```

**$.park_meadow.adult[15][1]**

```text
我没带东西，就来看看。
```

**$.park_meadow.adult[15][2]**

```text
>没事，这边也能走走。
```

**$.park_meadow.adult[15][3]**

```text
看别人摆着还挺热闹。
```

**$.park_meadow.adult[15][4]**

```text
>嗯，等会儿我也再转一圈。
```

**$.park_meadow.adult[16][0]**

```text
水果的选择
```

**$.park_meadow.adult[16][1]**

```text
野餐带什么水果方便？
```

**$.park_meadow.adult[16][2]**

```text
>橘子吧，别挑太酸的。
```

**$.park_meadow.adult[16][3]**

```text
苹果呢？
```

**$.park_meadow.adult[16][4]**

```text
>也行，先洗干净就好。
```

**$.park_meadow.adult[17][0]**

```text
一点没变
```

**$.park_meadow.adult[17][1]**

```text
我们在这儿聊多久了？
```

**$.park_meadow.adult[17][2]**

```text
>没看，应该一会儿了。
```

**$.park_meadow.adult[17][3]**

```text
好，我再坐两分钟。
```

**$.park_meadow.adult[17][4]**

```text
>行，不着急。
```

**$.park_meadow.adult[18][0]**

```text
饭后散步
```

**$.park_meadow.adult[18][1]**

```text
吃完走两步挺好。
```

**$.park_meadow.adult[18][2]**

```text
>嗯，别一坐就不想动了。
```

**$.park_meadow.adult[18][3]**

```text
我先慢慢走。
```

**$.park_meadow.adult[18][4]**

```text
>刚吃完，也别跑。
```

**$.park_meadow.adult[19][0]**

```text
野餐摄影
```

**$.park_meadow.adult[19][1]**

```text
拍野餐照怎么都拍不好看。
```

**$.park_meadow.adult[19][2]**

```text
>东西放太满了吧。
```

**$.park_meadow.adult[19][3]**

```text
都想拍进去。
```

**$.park_meadow.adult[19][4]**

```text
>先拿开两盒看看。
```

**$.park_meadow.adult[20][0]**

```text
收拾的默契
```

**$.park_meadow.adult[20][1]**

```text
你收盒子，我捡纸吧。
```

**$.park_meadow.adult[20][2]**

```text
>好，袋子给我一个。
```

**$.park_meadow.adult[20][3]**

```text
这个还没装东西。
```

**$.park_meadow.adult[20][4]**

```text
>行，碎屑我也一起收了。
```

**$.park_meadow.adult[21][0]**

```text
野餐的时钟
```

**$.park_meadow.adult[21][1]**

```text
出来野餐一下就过了好久。
```

**$.park_meadow.adult[21][2]**

```text
>摆东西就摆半天。
```

**$.park_meadow.adult[21][3]**

```text
收起来也不快。
```

**$.park_meadow.adult[21][4]**

```text
>是，回去还得洗。
```

**$.park_meadow.adult[22][0]**

```text
借一阵风
```

**$.park_meadow.adult[22][1]**

```text
刚才那阵风还挺舒服。
```

**$.park_meadow.adult[22][2]**

```text
>嗯，这儿不挡风。
```

**$.park_meadow.adult[22][3]**

```text
就怕把纸吹走。
```

**$.park_meadow.adult[22][4]**

```text
>先压好，再坐下。
```

**$.park_meadow.adult[23][0]**

```text
散场以后
```

**$.park_meadow.adult[23][1]**

```text
散场以后垃圾要带走吧。
```

**$.park_meadow.adult[23][2]**

```text
>当然，这袋一起装了。
```

**$.park_meadow.adult[23][3]**

```text
空瓶也拿上。
```

**$.park_meadow.adult[23][4]**

```text
>嗯，别落椅子底下。
```

**$.park_meadow.adult[24][0]**

```text
野餐旁的招呼
```

**$.park_meadow.adult[24][1].mm**

```text
{对方称呼}，你好，这里空位能站一下吗？
```

**$.park_meadow.adult[24][1].mf**

```text
你好，你好，这里空位能站一下吗？
```

**$.park_meadow.adult[24][1].fm**

```text
你好，{对方称呼}，你好，这里空位能站一下吗？
```

**$.park_meadow.adult[24][1].ff**

```text
你好，你好，这里空位能站一下吗？
```

**$.park_meadow.adult[24][2].mm**

```text
>{主角称呼}，可以，我们就坐这块。
```

**$.park_meadow.adult[24][2].mf**

```text
>可以，我们就坐这块。
```

**$.park_meadow.adult[24][2].fm**

```text
>可以，我们就坐这块。
```

**$.park_meadow.adult[24][2].ff**

```text
>{主角称呼}，可以，我们就坐这块。
```

**$.park_meadow.adult[24][3]**

```text
我怕挤到你们东西。
```

**$.park_meadow.adult[24][4]**

```text
>没有，你过吧。
```

**$.park_meadow.adult[25][0]**

```text
毯子有脾气
```

**$.park_meadow.adult[25][1].mm**

```text
{对方称呼}，毯子一个角又翻起来了。
```

**$.park_meadow.adult[25][1].mf**

```text
你好，毯子一个角又翻起来了。
```

**$.park_meadow.adult[25][1].fm**

```text
你好，{对方称呼}，毯子一个角又翻起来了。
```

**$.park_meadow.adult[25][1].ff**

```text
你好，毯子一个角又翻起来了。
```

**$.park_meadow.adult[25][2].mm**

```text
>{主角称呼}，拿个满瓶子压着。
```

**$.park_meadow.adult[25][2].mf**

```text
>拿个满瓶子压着。
```

**$.park_meadow.adult[25][2].fm**

```text
>拿个满瓶子压着。
```

**$.park_meadow.adult[25][2].ff**

```text
>{主角称呼}，拿个满瓶子压着。
```

**$.park_meadow.adult[25][3]**

```text
空的压不住？
```

**$.park_meadow.adult[25][4]**

```text
>刚试了，跟着一起倒。
```

**$.park_meadow.adult[26][0]**

```text
盒子先坐好
```

**$.park_meadow.adult[26][1].mm**

```text
{对方称呼}，盒子放这儿平吗？
```

**$.park_meadow.adult[26][1].mf**

```text
你好，盒子放这儿平吗？
```

**$.park_meadow.adult[26][1].fm**

```text
你好，{对方称呼}，盒子放这儿平吗？
```

**$.park_meadow.adult[26][1].ff**

```text
你好，盒子放这儿平吗？
```

**$.park_meadow.adult[26][2].mm**

```text
>{主角称呼}，再往里面点。
```

**$.park_meadow.adult[26][2].mf**

```text
>再往里面点。
```

**$.park_meadow.adult[26][2].fm**

```text
>再往里面点。
```

**$.park_meadow.adult[26][2].ff**

```text
>{主角称呼}，再往里面点。
```

**$.park_meadow.adult[26][3]**

```text
这样呢？
```

**$.park_meadow.adult[26][4]**

```text
>行，别压着拉链。
```

**$.park_meadow.adult[27][0]**

```text
一口的分量
```

**$.park_meadow.adult[27][1].mm**

```text
{对方称呼}，这一口是不是有点大。
```

**$.park_meadow.adult[27][1].mf**

```text
你好，这一口是不是有点大。
```

**$.park_meadow.adult[27][1].fm**

```text
你好，{对方称呼}，这一口是不是有点大。
```

**$.park_meadow.adult[27][1].ff**

```text
你好，这一口是不是有点大。
```

**$.park_meadow.adult[27][2].mm**

```text
>{主角称呼}，慢点，别急着说话。
```

**$.park_meadow.adult[27][2].mf**

```text
>慢点，别急着说话。
```

**$.park_meadow.adult[27][2].fm**

```text
>慢点，别急着说话。
```

**$.park_meadow.adult[27][2].ff**

```text
>{主角称呼}，慢点，别急着说话。
```

**$.park_meadow.adult[27][3]**

```text
我先咽下去。
```

**$.park_meadow.adult[27][4]**

```text
>嗯，吃完再说。
```

**$.park_meadow.adult[28][0]**

```text
收好包装纸
```

**$.park_meadow.adult[28][1].mm**

```text
{对方称呼}，这包装纸先装起来。
```

**$.park_meadow.adult[28][1].mf**

```text
你好，这包装纸先装起来。
```

**$.park_meadow.adult[28][1].fm**

```text
你好，{对方称呼}，这包装纸先装起来。
```

**$.park_meadow.adult[28][1].ff**

```text
你好，这包装纸先装起来。
```

**$.park_meadow.adult[28][2].mm**

```text
>{主角称呼}，别一会儿吹跑。
```

**$.park_meadow.adult[28][2].mf**

```text
>别一会儿吹跑。
```

**$.park_meadow.adult[28][2].fm**

```text
>别一会儿吹跑。
```

**$.park_meadow.adult[28][2].ff**

```text
>{主角称呼}，别一会儿吹跑。
```

**$.park_meadow.adult[28][3]**

```text
袋子在哪？
```

**$.park_meadow.adult[28][4]**

```text
>右边那个，口开着的。
```

**$.park_meadow.adult[29][0]**

```text
野餐的邀请
```

**$.park_meadow.adult[29][1].mm**

```text
{对方称呼}，今天你也带吃的了？
```

**$.park_meadow.adult[29][1].mf**

```text
你好，今天你也带吃的了？
```

**$.park_meadow.adult[29][1].fm**

```text
你好，{对方称呼}，今天你也带吃的了？
```

**$.park_meadow.adult[29][1].ff**

```text
你好，今天你也带吃的了？
```

**$.park_meadow.adult[29][2].mm**

```text
>{主角称呼}，嗯，简单带了点。
```

**$.park_meadow.adult[29][2].mf**

```text
>嗯，简单带了点。
```

**$.park_meadow.adult[29][2].fm**

```text
>嗯，简单带了点。
```

**$.park_meadow.adult[29][2].ff**

```text
>{主角称呼}，嗯，简单带了点。
```

**$.park_meadow.adult[29][3]**

```text
看着够好几个人吃。
```

**$.park_meadow.adult[29][4]**

```text
>还是带多了，下次少一点。
```

**$.park_meadow.adult[30][0]**

```text
杯子的太阳
```

**$.park_meadow.adult[30][1].mm**

```text
{对方称呼}，杯子晒着有点热。
```

**$.park_meadow.adult[30][1].mf**

```text
你好，杯子晒着有点热。
```

**$.park_meadow.adult[30][1].fm**

```text
你好，{对方称呼}，杯子晒着有点热。
```

**$.park_meadow.adult[30][1].ff**

```text
你好，杯子晒着有点热。
```

**$.park_meadow.adult[30][2].mm**

```text
>{主角称呼}，挪到包后面吧。
```

**$.park_meadow.adult[30][2].mf**

```text
>挪到包后面吧。
```

**$.park_meadow.adult[30][2].fm**

```text
>挪到包后面吧。
```

**$.park_meadow.adult[30][2].ff**

```text
>{主角称呼}，挪到包后面吧。
```

**$.park_meadow.adult[30][3]**

```text
哦，那边有点影子。
```

**$.park_meadow.adult[30][4]**

```text
>嗯，放里面还稳一点。
```

**$.park_meadow.adult[31][0]**

```text
饭后的方向
```

**$.park_meadow.adult[31][1].mm**

```text
{对方称呼}，吃完还走哪儿？
```

**$.park_meadow.adult[31][1].mf**

```text
你好，吃完还走哪儿？
```

**$.park_meadow.adult[31][1].fm**

```text
你好，{对方称呼}，吃完还走哪儿？
```

**$.park_meadow.adult[31][1].ff**

```text
你好，吃完还走哪儿？
```

**$.park_meadow.adult[31][2].mm**

```text
>{主角称呼}，先绕着这边走走。
```

**$.park_meadow.adult[31][2].mf**

```text
>先绕着这边走走。
```

**$.park_meadow.adult[31][2].fm**

```text
>先绕着这边走走。
```

**$.park_meadow.adult[31][2].ff**

```text
>{主角称呼}，先绕着这边走走。
```

**$.park_meadow.adult[31][3]**

```text
也别走太远。
```

**$.park_meadow.adult[31][4]**

```text
>好，东西还得拎回去。
```

**$.park_meadow.adult[32][0]**

```text
饼干的小事
```

**$.park_meadow.adult[32][1].mm**

```text
{对方称呼}，这饼干一拿就碎。
```

**$.park_meadow.adult[32][1].mf**

```text
你好，这饼干一拿就碎。
```

**$.park_meadow.adult[32][1].fm**

```text
你好，{对方称呼}，这饼干一拿就碎。
```

**$.park_meadow.adult[32][1].ff**

```text
你好，这饼干一拿就碎。
```

**$.park_meadow.adult[32][2].mm**

```text
>{主角称呼}，底下接着点。
```

**$.park_meadow.adult[32][2].mf**

```text
>底下接着点。
```

**$.park_meadow.adult[32][2].fm**

```text
>底下接着点。
```

**$.park_meadow.adult[32][2].ff**

```text
>{主角称呼}，底下接着点。
```

**$.park_meadow.adult[32][3]**

```text
来不及了，掉手里了。
```

**$.park_meadow.adult[32][4]**

```text
>那先吃碎的，别拍地上。
```

**$.park_meadow.adult[33][0]**

```text
袋子别超重
```

**$.park_meadow.adult[33][1].mm**

```text
{对方称呼}，袋子别装这么满吧。
```

**$.park_meadow.adult[33][1].mf**

```text
你好，袋子别装这么满吧。
```

**$.park_meadow.adult[33][1].fm**

```text
你好，{对方称呼}，袋子别装这么满吧。
```

**$.park_meadow.adult[33][1].ff**

```text
你好，袋子别装这么满吧。
```

**$.park_meadow.adult[33][2].mm**

```text
>{主角称呼}，怕提手断了？
```

**$.park_meadow.adult[33][2].mf**

```text
>怕提手断了？
```

**$.park_meadow.adult[33][2].fm**

```text
>怕提手断了？
```

**$.park_meadow.adult[33][2].ff**

```text
>{主角称呼}，怕提手断了？
```

**$.park_meadow.adult[33][3]**

```text
已经有点勒手。
```

**$.park_meadow.adult[33][4]**

```text
>那分一点到这个袋里。
```

**$.park_meadow.adult[34][0]**

```text
看风不吃风
```

**$.park_meadow.adult[34][1].mm**

```text
{对方称呼}，一直看天，饭都快忘了吃。
```

**$.park_meadow.adult[34][1].mf**

```text
你好，一直看天，饭都快忘了吃。
```

**$.park_meadow.adult[34][1].fm**

```text
你好，{对方称呼}，一直看天，饭都快忘了吃。
```

**$.park_meadow.adult[34][1].ff**

```text
你好，一直看天，饭都快忘了吃。
```

**$.park_meadow.adult[34][2].mm**

```text
>{主角称呼}，先吃吧，凉了就不好吃了。
```

**$.park_meadow.adult[34][2].mf**

```text
>先吃吧，凉了就不好吃了。
```

**$.park_meadow.adult[34][2].fm**

```text
>先吃吧，凉了就不好吃了。
```

**$.park_meadow.adult[34][2].ff**

```text
>{主角称呼}，先吃吧，凉了就不好吃了。
```

**$.park_meadow.adult[34][3]**

```text
嗯，马上。
```

**$.park_meadow.adult[34][4]**

```text
>云一会儿还会有。
```

**$.park_meadow.adult[35][0]**

```text
野餐的尾声
```

**$.park_meadow.adult[35][1].mm**

```text
{对方称呼}，差不多该收了吧。
```

**$.park_meadow.adult[35][1].mf**

```text
你好，差不多该收了吧。
```

**$.park_meadow.adult[35][1].fm**

```text
你好，{对方称呼}，差不多该收了吧。
```

**$.park_meadow.adult[35][1].ff**

```text
你好，差不多该收了吧。
```

**$.park_meadow.adult[35][2].mm**

```text
>{主角称呼}，嗯，空盒先套起来。
```

**$.park_meadow.adult[35][2].mf**

```text
>嗯，空盒先套起来。
```

**$.park_meadow.adult[35][2].fm**

```text
>嗯，空盒先套起来。
```

**$.park_meadow.adult[35][2].ff**

```text
>{主角称呼}，嗯，空盒先套起来。
```

**$.park_meadow.adult[35][3]**

```text
这个盖是哪个的？
```

**$.park_meadow.adult[35][4]**

```text
>我看看，可能旁边那个。
```

**$.park_meadow.adult[36][0]**

```text
小毯子大空间
```

**$.park_meadow.adult[36][1].mm**

```text
{对方称呼}，毯子不大，东西倒摆不少。
```

**$.park_meadow.adult[36][1].mf**

```text
你好，毯子不大，东西倒摆不少。
```

**$.park_meadow.adult[36][1].fm**

```text
你好，{对方称呼}，毯子不大，东西倒摆不少。
```

**$.park_meadow.adult[36][1].ff**

```text
你好，毯子不大，东西倒摆不少。
```

**$.park_meadow.adult[36][2].mm**

```text
>{主角称呼}，脚都没地方放。
```

**$.park_meadow.adult[36][2].mf**

```text
>脚都没地方放。
```

**$.park_meadow.adult[36][2].fm**

```text
>脚都没地方放。
```

**$.park_meadow.adult[36][2].ff**

```text
>{主角称呼}，脚都没地方放。
```

**$.park_meadow.adult[36][3]**

```text
我把包先挪走。
```

**$.park_meadow.adult[36][4]**

```text
>这样就宽点了。
```

**$.park_meadow.adult[37][0]**

```text
对着天空吃饭
```

**$.park_meadow.adult[37][1].mm**

```text
{对方称呼}，抬头吃饭差点呛着。
```

**$.park_meadow.adult[37][1].mf**

```text
你好，抬头吃饭差点呛着。
```

**$.park_meadow.adult[37][1].fm**

```text
你好，{对方称呼}，抬头吃饭差点呛着。
```

**$.park_meadow.adult[37][1].ff**

```text
你好，抬头吃饭差点呛着。
```

**$.park_meadow.adult[37][2].mm**

```text
>{主角称呼}，你先看碗，别光看天。
```

**$.park_meadow.adult[37][2].mf**

```text
>你先看碗，别光看天。
```

**$.park_meadow.adult[37][2].fm**

```text
>你先看碗，别光看天。
```

**$.park_meadow.adult[37][2].ff**

```text
>{主角称呼}，你先看碗，别光看天。
```

**$.park_meadow.adult[37][3]**

```text
嗯，刚有鸟过去。
```

**$.park_meadow.adult[37][4]**

```text
>吃完再找吧。
```

**$.park_meadow.adult[38][0]**

```text
饭盒的记忆
```

**$.park_meadow.adult[38][1].mm**

```text
{对方称呼}，这饭盒你用挺久了吧。
```

**$.park_meadow.adult[38][1].mf**

```text
你好，这饭盒你用挺久了吧。
```

**$.park_meadow.adult[38][1].fm**

```text
你好，{对方称呼}，这饭盒你用挺久了吧。
```

**$.park_meadow.adult[38][1].ff**

```text
你好，这饭盒你用挺久了吧。
```

**$.park_meadow.adult[38][2].mm**

```text
>{主角称呼}，嗯，盖子有点难扣了。
```

**$.park_meadow.adult[38][2].mf**

```text
>嗯，盖子有点难扣了。
```

**$.park_meadow.adult[38][2].fm**

```text
>嗯，盖子有点难扣了。
```

**$.park_meadow.adult[38][2].ff**

```text
>{主角称呼}，嗯，盖子有点难扣了。
```

**$.park_meadow.adult[38][3]**

```text
密封圈还在？
```

**$.park_meadow.adult[38][4]**

```text
>在，回去再洗一下。
```

**$.park_meadow.adult[39][0]**

```text
脚边的小客人
```

**$.park_meadow.adult[39][1].mm**

```text
{对方称呼}，脚边来只小虫。
```

**$.park_meadow.adult[39][1].mf**

```text
你好，脚边来只小虫。
```

**$.park_meadow.adult[39][1].fm**

```text
你好，{对方称呼}，脚边来只小虫。
```

**$.park_meadow.adult[39][1].ff**

```text
你好，脚边来只小虫。
```

**$.park_meadow.adult[39][2].mm**

```text
>{主角称呼}，别把吃的放地上。
```

**$.park_meadow.adult[39][2].mf**

```text
>别把吃的放地上。
```

**$.park_meadow.adult[39][2].fm**

```text
>别把吃的放地上。
```

**$.park_meadow.adult[39][2].ff**

```text
>{主角称呼}，别把吃的放地上。
```

**$.park_meadow.adult[39][3]**

```text
我拿起来了。
```

**$.park_meadow.adult[39][4]**

```text
>嗯，先看看它去哪儿。
```

**$.park_meadow.adult[40][0]**

```text
不追求同款
```

**$.park_meadow.adult[40][1].mm**

```text
{对方称呼}，我没买照片里那种整套餐具。
```

**$.park_meadow.adult[40][1].mf**

```text
你好，我没买照片里那种整套餐具。
```

**$.park_meadow.adult[40][1].fm**

```text
你好，{对方称呼}，我没买照片里那种整套餐具。
```

**$.park_meadow.adult[40][1].ff**

```text
你好，我没买照片里那种整套餐具。
```

**$.park_meadow.adult[40][2].mm**

```text
>{主角称呼}，家里的能用就行。
```

**$.park_meadow.adult[40][2].mf**

```text
>家里的能用就行。
```

**$.park_meadow.adult[40][2].fm**

```text
>家里的能用就行。
```

**$.park_meadow.adult[40][2].ff**

```text
>{主角称呼}，家里的能用就行。
```

**$.park_meadow.adult[40][3]**

```text
就是颜色不一样。
```

**$.park_meadow.adult[40][4]**

```text
>谁还挨个看颜色啊。
```

**$.park_meadow.adult[41][0]**

```text
差一把叉子
```

**$.park_meadow.adult[41][1].mm**

```text
{对方称呼}，是不是少带一把叉子？
```

**$.park_meadow.adult[41][1].mf**

```text
你好，是不是少带一把叉子？
```

**$.park_meadow.adult[41][1].fm**

```text
你好，{对方称呼}，是不是少带一把叉子？
```

**$.park_meadow.adult[41][1].ff**

```text
你好，是不是少带一把叉子？
```

**$.park_meadow.adult[41][2].mm**

```text
>{主角称呼}，我翻一下包。
```

**$.park_meadow.adult[41][2].mf**

```text
>我翻一下包。
```

**$.park_meadow.adult[41][2].fm**

```text
>我翻一下包。
```

**$.park_meadow.adult[41][2].ff**

```text
>{主角称呼}，我翻一下包。
```

**$.park_meadow.adult[41][3]**

```text
没的话我用勺也行。
```

**$.park_meadow.adult[41][4]**

```text
>找到了，压盒子底下了。
```

**$.park_meadow.adult[42][0]**

```text
风的干扰项
```

**$.park_meadow.adult[42][1].mm**

```text
{对方称呼}，刚夹起来纸就吹了。
```

**$.park_meadow.adult[42][1].mf**

```text
你好，刚夹起来纸就吹了。
```

**$.park_meadow.adult[42][1].fm**

```text
你好，{对方称呼}，刚夹起来纸就吹了。
```

**$.park_meadow.adult[42][1].ff**

```text
你好，刚夹起来纸就吹了。
```

**$.park_meadow.adult[42][2].mm**

```text
>{主角称呼}，用手按一下。
```

**$.park_meadow.adult[42][2].mf**

```text
>用手按一下。
```

**$.park_meadow.adult[42][2].fm**

```text
>用手按一下。
```

**$.park_meadow.adult[42][2].ff**

```text
>{主角称呼}，用手按一下。
```

**$.park_meadow.adult[42][3]**

```text
一松就跑。
```

**$.park_meadow.adult[42][4]**

```text
>拿水瓶压着吧。
```

**$.park_meadow.adult[43][0]**

```text
不着急的饭点
```

**$.park_meadow.adult[43][1].mm**

```text
{对方称呼}，是不是该吃饭了。
```

**$.park_meadow.adult[43][1].mf**

```text
你好，是不是该吃饭了。
```

**$.park_meadow.adult[43][1].fm**

```text
你好，{对方称呼}，是不是该吃饭了。
```

**$.park_meadow.adult[43][1].ff**

```text
你好，是不是该吃饭了。
```

**$.park_meadow.adult[43][2].mm**

```text
>{主角称呼}，你饿了就先吃，不用等大家。
```

**$.park_meadow.adult[43][2].mf**

```text
>你饿了就先吃，不用等大家。
```

**$.park_meadow.adult[43][2].fm**

```text
>你饿了就先吃，不用等大家。
```

**$.park_meadow.adult[43][2].ff**

```text
>{主角称呼}，你饿了就先吃，不用等大家。
```

**$.park_meadow.adult[43][3]**

```text
嗯，我先开这个。
```

**$.park_meadow.adult[43][4]**

```text
>少拆几样，吃完再开。
```

**$.park_meadow.adult[44][0]**

```text
没有热闹也好
```

**$.park_meadow.adult[44][1].mm**

```text
{对方称呼}，这边没那么热闹也挺好。
```

**$.park_meadow.adult[44][1].mf**

```text
你好，这边没那么热闹也挺好。
```

**$.park_meadow.adult[44][1].fm**

```text
你好，{对方称呼}，这边没那么热闹也挺好。
```

**$.park_meadow.adult[44][1].ff**

```text
你好，这边没那么热闹也挺好。
```

**$.park_meadow.adult[44][2].mm**

```text
>{主角称呼}，嗯，地方宽一点。
```

**$.park_meadow.adult[44][2].mf**

```text
>嗯，地方宽一点。
```

**$.park_meadow.adult[44][2].fm**

```text
>嗯，地方宽一点。
```

**$.park_meadow.adult[44][2].ff**

```text
>{主角称呼}，嗯，地方宽一点。
```

**$.park_meadow.adult[44][3]**

```text
能坐得开。
```

**$.park_meadow.adult[44][4]**

```text
>还不用老收腿让人过。
```

**$.park_meadow.adult[45][0]**

```text
一阵草的香
```

**$.park_meadow.adult[45][1].mm**

```text
{对方称呼}，好像闻到新割草的味。
```

**$.park_meadow.adult[45][1].mf**

```text
你好，好像闻到新割草的味。
```

**$.park_meadow.adult[45][1].fm**

```text
你好，{对方称呼}，好像闻到新割草的味。
```

**$.park_meadow.adult[45][1].ff**

```text
你好，好像闻到新割草的味。
```

**$.park_meadow.adult[45][2].mm**

```text
>{主角称呼}，旁边这块刚修过吧。
```

**$.park_meadow.adult[45][2].mf**

```text
>旁边这块刚修过吧。
```

**$.park_meadow.adult[45][2].fm**

```text
>旁边这块刚修过吧。
```

**$.park_meadow.adult[45][2].ff**

```text
>{主角称呼}，旁边这块刚修过吧。
```

**$.park_meadow.adult[45][3]**

```text
是，断草还在呢。
```

**$.park_meadow.adult[45][4]**

```text
>别把毯子铺上去，会沾一身。
```

**$.park_meadow.adult[46][0]**

```text
别忘了喝水
```

**$.park_meadow.adult[46][1].mm**

```text
{对方称呼}，聊半天都没喝水。
```

**$.park_meadow.adult[46][1].mf**

```text
你好，聊半天都没喝水。
```

**$.park_meadow.adult[46][1].fm**

```text
你好，{对方称呼}，聊半天都没喝水。
```

**$.park_meadow.adult[46][1].ff**

```text
你好，聊半天都没喝水。
```

**$.park_meadow.adult[46][2].mm**

```text
>{主角称呼}，先喝两口。
```

**$.park_meadow.adult[46][2].mf**

```text
>先喝两口。
```

**$.park_meadow.adult[46][2].fm**

```text
>先喝两口。
```

**$.park_meadow.adult[46][2].ff**

```text
>{主角称呼}，先喝两口。
```

**$.park_meadow.adult[46][3]**

```text
壶在哪儿？
```

**$.park_meadow.adult[46][4]**

```text
>包侧面那个袋里。
```

**$.park_meadow.adult[47][0]**

```text
带着轻松回去
```

**$.park_meadow.adult[47][1].mm**

```text
{对方称呼}，回去东西比来时还乱。
```

**$.park_meadow.adult[47][1].mf**

```text
你好，回去东西比来时还乱。
```

**$.park_meadow.adult[47][1].fm**

```text
你好，{对方称呼}，回去东西比来时还乱。
```

**$.park_meadow.adult[47][1].ff**

```text
你好，回去东西比来时还乱。
```

**$.park_meadow.adult[47][2].mm**

```text
>{主角称呼}，收的时候没叠吧。
```

**$.park_meadow.adult[47][2].mf**

```text
>收的时候没叠吧。
```

**$.park_meadow.adult[47][2].fm**

```text
>收的时候没叠吧。
```

**$.park_meadow.adult[47][2].ff**

```text
>{主角称呼}，收的时候没叠吧。
```

**$.park_meadow.adult[47][3]**

```text
嗯，一股脑塞的。
```

**$.park_meadow.adult[47][4]**

```text
>先背回去再慢慢收。
```

**$.park_meadow.kid[0][0]**

```text
餐巾纸船
```

**$.park_meadow.kid[0][1]**

```text
你把餐巾纸折成了什么？
```

**$.park_meadow.kid[0][2]**

```text
>小船，不过它今天只在饭盒旁边停着。
```

**$.park_meadow.kid[0][3]**

```text
不下水吗？
```

**$.park_meadow.kid[0][4]**

```text
>不了，弄湿了就不能擦嘴了。
```

**$.park_meadow.kid[1][0]**

```text
饼干圆孔
```

**$.park_meadow.kid[1][1]**

```text
你在研究饼干上的小孔吗？
```

**$.park_meadow.kid[1][2]**

```text
>我想知道它们是不是窗户。
```

**$.park_meadow.kid[1][3]**

```text
那里面住着谁？
```

**$.park_meadow.kid[1][4]**

```text
>一群闻起来很香的小居民。
```

**$.park_meadow.kid[2][0]**

```text
毯子海岛
```

**$.park_meadow.kid[2][1]**

```text
怎么不肯踩出毯子？
```

**$.park_meadow.kid[2][2]**

```text
>外面现在是海，我在等船。
```

**$.park_meadow.kid[2][3]**

```text
那我绕远一点，免得掀起浪。
```

**$.park_meadow.kid[2][4]**

```text
>谢谢，你是很体贴的路人。
```

**$.park_meadow.kid[3][0]**

```text
蚂蚁搬家
```

**$.park_meadow.kid[3][1]**

```text
你跟着蚂蚁看好久了。
```

**$.park_meadow.kid[3][2]**

```text
>它搬的东西比自己还大。
```

**$.park_meadow.kid[3][3]**

```text
我们别挡着它。
```

**$.park_meadow.kid[3][4]**

```text
>好，让它今天早点回家。
```

**$.park_meadow.kid[4][0]**

```text
饭盒谜题
```

**$.park_meadow.kid[4][1]**

```text
饭盒怎么还不打开？
```

**$.park_meadow.kid[4][2]**

```text
>我在猜里面是饭还是惊喜。
```

**$.park_meadow.kid[4][3]**

```text
两种可以同时出现。
```

**$.park_meadow.kid[4][4]**

```text
>那我今天运气真不错。
```

**$.park_meadow.kid[5][0]**

```text
天空餐桌
```

**$.park_meadow.kid[5][1]**

```text
你把杯子摆成一排做什么？
```

**$.park_meadow.kid[5][2]**

```text
>我在给云准备座位。
```

**$.park_meadow.kid[5][3]**

```text
它们坐得下吗？
```

**$.park_meadow.kid[5][4]**

```text
>坐不下可以站着喝一点风。
```

**$.park_meadow.kid[6][0]**

```text
饼干的座位
```

**$.park_meadow.kid[6][1].mm**

```text
{对方称呼}，你怎么把饼干摆成一个圈？
```

**$.park_meadow.kid[6][1].mf**

```text
你好，你怎么把饼干摆成一个圈？
```

**$.park_meadow.kid[6][1].fm**

```text
你好，{对方称呼}，你怎么把饼干摆成一个圈？
```

**$.park_meadow.kid[6][1].ff**

```text
打个招呼，你怎么把饼干摆成一个圈？
```

**$.park_meadow.kid[6][2].mm**

```text
>{主角称呼}，嗯，想让它们先坐好再吃。
```

**$.park_meadow.kid[6][2].mf**

```text
>{主角称呼}，说起来，想让它们先坐好再吃。
```

**$.park_meadow.kid[6][2].fm**

```text
>{主角称呼}，其实，想让它们先坐好再吃。
```

**$.park_meadow.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，想让它们先坐好再吃。
```

**$.park_meadow.kid[6][3]**

```text
等会儿会少很多客人。
```

**$.park_meadow.kid[6][4]**

```text
>那叫散会，不能说得太伤心。
```

**$.park_meadow.kid[7][0]**

```text
饭盒的名字
```

**$.park_meadow.kid[7][1].mm**

```text
{对方称呼}，这只饭盒有什么特别的吗？
```

**$.park_meadow.kid[7][1].mf**

```text
你好，这只饭盒有什么特别的吗？
```

**$.park_meadow.kid[7][1].fm**

```text
你好，{对方称呼}，这只饭盒有什么特别的吗？
```

**$.park_meadow.kid[7][1].ff**

```text
打个招呼，这只饭盒有什么特别的吗？
```

**$.park_meadow.kid[7][2].mm**

```text
>{主角称呼}，说起来，我给它起名叫今天有好吃的。
```

**$.park_meadow.kid[7][2].mf**

```text
>{主角称呼}，其实，我给它起名叫今天有好吃的。
```

**$.park_meadow.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，我给它起名叫今天有好吃的。
```

**$.park_meadow.kid[7][2].ff**

```text
>{主角称呼}，嗯，我给它起名叫今天有好吃的。
```

**$.park_meadow.kid[7][3]**

```text
名字很让人期待。
```

**$.park_meadow.kid[7][4]**

```text
>希望它每天都能对得起这个名字。
```

**$.park_meadow.kid[8][0]**

```text
云的午餐
```

**$.park_meadow.kid[8][1].mm**

```text
{对方称呼}，你觉得云会饿吗？
```

**$.park_meadow.kid[8][1].mf**

```text
你好，你觉得云会饿吗？
```

**$.park_meadow.kid[8][1].fm**

```text
你好，{对方称呼}，你觉得云会饿吗？
```

**$.park_meadow.kid[8][1].ff**

```text
打个招呼，你觉得云会饿吗？
```

**$.park_meadow.kid[8][2].mm**

```text
>{主角称呼}，其实，会吧，不然怎么一直飘来飘去。
```

**$.park_meadow.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，会吧，不然怎么一直飘来飘去。
```

**$.park_meadow.kid[8][2].fm**

```text
>{主角称呼}，嗯，会吧，不然怎么一直飘来飘去。
```

**$.park_meadow.kid[8][2].ff**

```text
>{主角称呼}，说起来，会吧，不然怎么一直飘来飘去。
```

**$.park_meadow.kid[8][3]**

```text
它在找什么吃的？
```

**$.park_meadow.kid[8][4]**

```text
>找一大碗风，可能还要续杯。
```

**$.park_meadow.kid[9][0]**

```text
纸巾的任务
```

**$.park_meadow.kid[9][1].mm**

```text
{对方称呼}，这张纸巾怎么还不肯用？
```

**$.park_meadow.kid[9][1].mf**

```text
你好，这张纸巾怎么还不肯用？
```

**$.park_meadow.kid[9][1].fm**

```text
你好，{对方称呼}，这张纸巾怎么还不肯用？
```

**$.park_meadow.kid[9][1].ff**

```text
打个招呼，这张纸巾怎么还不肯用？
```

**$.park_meadow.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，我想留着，等最重要的时候。
```

**$.park_meadow.kid[9][2].mf**

```text
>{主角称呼}，嗯，我想留着，等最重要的时候。
```

**$.park_meadow.kid[9][2].fm**

```text
>{主角称呼}，说起来，我想留着，等最重要的时候。
```

**$.park_meadow.kid[9][2].ff**

```text
>{主角称呼}，其实，我想留着，等最重要的时候。
```

**$.park_meadow.kid[9][3]**

```text
擦干净嘴也挺重要。
```

**$.park_meadow.kid[9][4]**

```text
>对，那它现在可以上场了。
```

**$.park_meadow.kid[10][0]**

```text
毯子边的提醒
```

**$.park_meadow.kid[10][1].mm**

```text
{对方称呼}，怎么忽然伸手拦了一下？
```

**$.park_meadow.kid[10][1].mf**

```text
你好，怎么忽然伸手拦了一下？
```

**$.park_meadow.kid[10][1].fm**

```text
你好，{对方称呼}，怎么忽然伸手拦了一下？
```

**$.park_meadow.kid[10][1].ff**

```text
打个招呼，怎么忽然伸手拦了一下？
```

**$.park_meadow.kid[10][2].mm**

```text
>{主角称呼}，嗯，那里有个小虫，我怕你踩到。
```

**$.park_meadow.kid[10][2].mf**

```text
>{主角称呼}，说起来，那里有个小虫，我怕你踩到。
```

**$.park_meadow.kid[10][2].fm**

```text
>{主角称呼}，其实，那里有个小虫，我怕你踩到。
```

**$.park_meadow.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，那里有个小虫，我怕你踩到。
```

**$.park_meadow.kid[10][3]**

```text
谢谢你提醒我。
```

**$.park_meadow.kid[10][4]**

```text
>不客气，它也刚好经过这里。
```

**$.park_meadow.kid[11][0]**

```text
带走好心情
```

**$.park_meadow.kid[11][1].mm**

```text
{对方称呼}，准备回去了吗？
```

**$.park_meadow.kid[11][1].mf**

```text
你好，准备回去了吗？
```

**$.park_meadow.kid[11][1].fm**

```text
你好，{对方称呼}，准备回去了吗？
```

**$.park_meadow.kid[11][1].ff**

```text
打个招呼，准备回去了吗？
```

**$.park_meadow.kid[11][2].mm**

```text
>{主角称呼}，说起来，嗯，我想把今天的开心也带上。
```

**$.park_meadow.kid[11][2].mf**

```text
>{主角称呼}，其实，嗯，我想把今天的开心也带上。
```

**$.park_meadow.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，嗯，我想把今天的开心也带上。
```

**$.park_meadow.kid[11][2].ff**

```text
>{主角称呼}，嗯，嗯，我想把今天的开心也带上。
```

**$.park_meadow.kid[11][3]**

```text
这个不占饭盒位置。
```

**$.park_meadow.kid[11][4]**

```text
>太好了，我还怕盖不上盖子。
```

**$.park_grove.adult[0][0]**

```text
樱花问候
```

**$.park_grove.adult[0][1]**

```text
这边花还挺多。
```

**$.park_grove.adult[0][2]**

```text
>嗯，刚拐进来就看见了。
```

**$.park_grove.adult[0][3]**

```text
刚才外面还没几棵。
```

**$.park_grove.adult[0][4]**

```text
>里面密一点，慢慢看吧。
```

**$.park_grove.adult[1][0]**

```text
小摊香味
```

**$.park_grove.adult[1][1]**

```text
一闻到小摊味儿就饿了。
```

**$.park_grove.adult[1][2]**

```text
>我也是，本来没打算吃。
```

**$.park_grove.adult[1][3]**

```text
现在有点想过去。
```

**$.park_grove.adult[1][4]**

```text
>去看看菜单吧。
```

**$.park_grove.adult[2][0]**

```text
花瓣落肩
```

**$.park_grove.adult[2][1]**

```text
你肩上有片花瓣。
```

**$.park_grove.adult[2][2]**

```text
>哪边？
```

**$.park_grove.adult[2][3]**

```text
这边，已经掉下去了。
```

**$.park_grove.adult[2][4]**

```text
>哦，谢谢，我刚没注意。
```

**$.park_grove.adult[3][0]**

```text
小摊的热气
```

**$.park_grove.adult[3][1]**

```text
看见锅里冒热气就想吃。
```

**$.park_grove.adult[3][2]**

```text
>走久了想吃点热的。
```

**$.park_grove.adult[3][3]**

```text
我去看看有些什么。
```

**$.park_grove.adult[3][4]**

```text
>嗯，别急着吃，小心烫。
```

**$.park_grove.adult[4][0]**

```text
樱花的误会
```

**$.park_grove.adult[4][1]**

```text
刚飘过去的是花瓣吗？
```

**$.park_grove.adult[4][2]**

```text
>好像是张小纸片。
```

**$.park_grove.adult[4][3]**

```text
还真是，我看错了。
```

**$.park_grove.adult[4][4]**

```text
>落那边了，等下捡起来吧。
```

**$.park_grove.adult[5][0]**

```text
选菜困难
```

**$.park_grove.adult[5][1]**

```text
你想好吃什么了吗？
```

**$.park_grove.adult[5][2]**

```text
>还没，每样都想尝点。
```

**$.park_grove.adult[5][3]**

```text
我也是，看半天了。
```

**$.park_grove.adult[5][4]**

```text
>先少点几样，不够再说。
```

**$.park_grove.adult[6][0]**

```text
花下慢走
```

**$.park_grove.adult[6][1]**

```text
这边慢慢走挺好。
```

**$.park_grove.adult[6][2]**

```text
>嗯，还能看看树。
```

**$.park_grove.adult[6][3]**

```text
刚才走太快，什么都没看。
```

**$.park_grove.adult[6][4]**

```text
>别光看头上，也看着点脚下。
```

**$.park_grove.adult[7][0]**

```text
借个鼻子
```

**$.park_grove.adult[7][1]**

```text
没看见摊子就闻到味了。
```

**$.park_grove.adult[7][2]**

```text
>在前面，树后面。
```

**$.park_grove.adult[7][3]**

```text
哦，藏这儿了。
```

**$.park_grove.adult[7][4]**

```text
>走近就能看见牌子。
```

**$.park_grove.adult[8][0]**

```text
留住花瓣
```

**$.park_grove.adult[8][1]**

```text
这花瓣能带回去吗？
```

**$.park_grove.adult[8][2]**

```text
>地上干净的捡一片吧。
```

**$.park_grove.adult[8][3]**

```text
回去压书里。
```

**$.park_grove.adult[8][4]**

```text
>拿轻点，别一捏就碎了。
```

**$.park_grove.adult[9][0]**

```text
摊前的位置
```

**$.park_grove.adult[9][1]**

```text
摊子这边人不少。
```

**$.park_grove.adult[9][2]**

```text
>有的在等吃的。
```

**$.park_grove.adult[9][3]**

```text
难怪，都往锅那边看。
```

**$.park_grove.adult[9][4]**

```text
>我也想看看还剩什么。
```

**$.park_grove.adult[10][0]**

```text
温热的晚饭
```

**$.park_grove.adult[10][1]**

```text
没想到还能在这儿吃顿热的。
```

**$.park_grove.adult[10][2]**

```text
>不用走回去了。
```

**$.park_grove.adult[10][3]**

```text
嗯，我先买一点。
```

**$.park_grove.adult[10][4]**

```text
>看着量点，别一次买多。
```

**$.park_grove.adult[11][0]**

```text
一树的名字
```

**$.park_grove.adult[11][1]**

```text
这些树你都叫得出名字吗？
```

**$.park_grove.adult[11][2]**

```text
>叫不全，就认识几种。
```

**$.park_grove.adult[11][3]**

```text
我也差不多。
```

**$.park_grove.adult[11][4]**

```text
>看看牌子，有的写着。
```

**$.park_grove.adult[12][0]**

```text
筷子的练习
```

**$.park_grove.adult[12][1]**

```text
你也有夹不住东西的时候？
```

**$.park_grove.adult[12][2]**

```text
>有啊，滑的特别难夹。
```

**$.park_grove.adult[12][3]**

```text
我刚夹起来又掉回去了。
```

**$.park_grove.adult[12][4]**

```text
>没掉外面就行，慢点。
```

**$.park_grove.adult[13][0]**

```text
花影的变化
```

**$.park_grove.adult[13][1]**

```text
刚才地上还有花影。
```

**$.park_grove.adult[13][2]**

```text
>云过去，把光挡住了。
```

**$.park_grove.adult[13][3]**

```text
怪不得一下暗了。
```

**$.park_grove.adult[13][4]**

```text
>等会儿应该还会出来。
```

**$.park_grove.adult[14][0]**

```text
看花和看锅
```

**$.park_grove.adult[14][1]**

```text
在这儿都不知道先看花还是吃东西。
```

**$.park_grove.adult[14][2]**

```text
>吃的买了没？
```

**$.park_grove.adult[14][3]**

```text
还没。
```

**$.park_grove.adult[14][4]**

```text
>那先看花呗，饿了再去。
```

**$.park_grove.adult[15][0]**

```text
带回家的香气
```

**$.park_grove.adult[15][1]**

```text
站小摊边上，衣服都沾味儿。
```

**$.park_grove.adult[15][2]**

```text
>回去挂着散散。
```

**$.park_grove.adult[15][3]**

```text
闻着倒挺香。
```

**$.park_grove.adult[15][4]**

```text
>现在香，回去就知道了。
```

**$.park_grove.adult[16][0]**

```text
樱花林的安静
```

**$.park_grove.adult[16][1]**

```text
有个摊子，倒也不太吵。
```

**$.park_grove.adult[16][2]**

```text
>嗯，说话不用喊。
```

**$.park_grove.adult[16][3]**

```text
大家都是坐着吃。
```

**$.park_grove.adult[16][4]**

```text
>这边也离主路远一点。
```

**$.park_grove.adult[17][0]**

```text
花瓣的方向
```

**$.park_grove.adult[17][1]**

```text
花瓣吹得到处都是。
```

**$.park_grove.adult[17][2]**

```text
>刚才我头发上也挂了一片。
```

**$.park_grove.adult[17][3]**

```text
现在还有吗？
```

**$.park_grove.adult[17][4]**

```text
>应该没有了，你帮我看一眼？
```

**$.park_grove.adult[18][0]**

```text
偶遇的晚饭
```

**$.park_grove.adult[18][1]**

```text
本来就散步，结果想吃晚饭了。
```

**$.park_grove.adult[18][2]**

```text
>这边味道挺香。
```

**$.park_grove.adult[18][3]**

```text
我看看有什么。
```

**$.park_grove.adult[18][4]**

```text
>先看量，别点多。
```

**$.park_grove.adult[19][0]**

```text
小碗的分量
```

**$.park_grove.adult[19][1]**

```text
这个碗看着不大。
```

**$.park_grove.adult[19][2]**

```text
>装满也挺多的。
```

**$.park_grove.adult[19][3]**

```text
我怕不够吃。
```

**$.park_grove.adult[19][4]**

```text
>先吃这个，不够再添。
```

**$.park_grove.adult[20][0]**

```text
熟悉的香味
```

**$.park_grove.adult[20][1]**

```text
这味道有点熟。
```

**$.park_grove.adult[20][2]**

```text
>像味噌汤吧。
```

**$.park_grove.adult[20][3]**

```text
对，刚才想不起名字。
```

**$.park_grove.adult[20][4]**

```text
>你问一下摊主就知道了。
```

**$.park_grove.adult[21][0]**

```text
被胃劝服
```

**$.park_grove.adult[21][1]**

```text
本来不饿，过来又想吃了。
```

**$.park_grove.adult[21][2]**

```text
>闻着就容易馋。
```

**$.park_grove.adult[21][3]**

```text
那少买一点？
```

**$.park_grove.adult[21][4]**

```text
>嗯，别等点完才嫌多。
```

**$.park_grove.adult[22][0]**

```text
花期以外
```

**$.park_grove.adult[22][1]**

```text
没开花的时候，这里人也多吗？
```

**$.park_grove.adult[22][2]**

```text
>摊子开着就有人来。
```

**$.park_grove.adult[22][3]**

```text
也是，还能吃东西。
```

**$.park_grove.adult[22][4]**

```text
>树也能看看，不一定非得开花。
```

**$.park_grove.adult[23][0]**

```text
下次的约定
```

**$.park_grove.adult[23][1]**

```text
下回还想来尝别的。
```

**$.park_grove.adult[23][2]**

```text
>那这次别吃太撑。
```

**$.park_grove.adult[23][3]**

```text
嗯，留两样。
```

**$.park_grove.adult[23][4]**

```text
>下回看看有没有。
```

**$.park_grove.adult[24][0]**

```text
树下的第一句
```

**$.park_grove.adult[24][1].mm**

```text
{对方称呼}，你好，小摊在前面吧？
```

**$.park_grove.adult[24][1].mf**

```text
你好，你好，小摊在前面吧？
```

**$.park_grove.adult[24][1].fm**

```text
你好，{对方称呼}，你好，小摊在前面吧？
```

**$.park_grove.adult[24][1].ff**

```text
你好，你好，小摊在前面吧？
```

**$.park_grove.adult[24][2].mm**

```text
>{主角称呼}，嗯，穿过树就能看见。
```

**$.park_grove.adult[24][2].mf**

```text
>嗯，穿过树就能看见。
```

**$.park_grove.adult[24][2].fm**

```text
>嗯，穿过树就能看见。
```

**$.park_grove.adult[24][2].ff**

```text
>{主角称呼}，嗯，穿过树就能看见。
```

**$.park_grove.adult[24][3]**

```text
我刚没看见牌子。
```

**$.park_grove.adult[24][4]**

```text
>树挡着一点，走近就好了。
```

**$.park_grove.adult[25][0]**

```text
小摊的方向感
```

**$.park_grove.adult[25][1].mm**

```text
{对方称呼}，闻香味比看路牌还快。
```

**$.park_grove.adult[25][1].mf**

```text
你好，闻香味比看路牌还快。
```

**$.park_grove.adult[25][1].fm**

```text
你好，{对方称呼}，闻香味比看路牌还快。
```

**$.park_grove.adult[25][1].ff**

```text
你好，闻香味比看路牌还快。
```

**$.park_grove.adult[25][2].mm**

```text
>{主角称呼}，往那边找就行。
```

**$.park_grove.adult[25][2].mf**

```text
>往那边找就行。
```

**$.park_grove.adult[25][2].fm**

```text
>往那边找就行。
```

**$.park_grove.adult[25][2].ff**

```text
>{主角称呼}，往那边找就行。
```

**$.park_grove.adult[25][3]**

```text
我刚差点走岔。
```

**$.park_grove.adult[25][4]**

```text
>别绕树后，路在这边。
```

**$.park_grove.adult[26][0]**

```text
树影里的热气
```

**$.park_grove.adult[26][1].mm**

```text
{对方称呼}，树影里那点热气挺明显。
```

**$.park_grove.adult[26][1].mf**

```text
你好，树影里那点热气挺明显。
```

**$.park_grove.adult[26][1].fm**

```text
你好，{对方称呼}，树影里那点热气挺明显。
```

**$.park_grove.adult[26][1].ff**

```text
你好，树影里那点热气挺明显。
```

**$.park_grove.adult[26][2].mm**

```text
>{主角称呼}，锅一直开着。
```

**$.park_grove.adult[26][2].mf**

```text
>锅一直开着。
```

**$.park_grove.adult[26][2].fm**

```text
>锅一直开着。
```

**$.park_grove.adult[26][2].ff**

```text
>{主角称呼}，锅一直开着。
```

**$.park_grove.adult[26][3]**

```text
站远也看得见。
```

**$.park_grove.adult[26][4]**

```text
>嗯，走近小心别撞着人。
```

**$.park_grove.adult[27][0]**

```text
碗边的期待
```

**$.park_grove.adult[27][1].mm**

```text
{对方称呼}，还没吃我就想再买一碗。
```

**$.park_grove.adult[27][1].mf**

```text
你好，还没吃我就想再买一碗。
```

**$.park_grove.adult[27][1].fm**

```text
你好，{对方称呼}，还没吃我就想再买一碗。
```

**$.park_grove.adult[27][1].ff**

```text
你好，还没吃我就想再买一碗。
```

**$.park_grove.adult[27][2].mm**

```text
>{主角称呼}，先吃完这碗。
```

**$.park_grove.adult[27][2].mf**

```text
>先吃完这碗。
```

**$.park_grove.adult[27][2].fm**

```text
>先吃完这碗。
```

**$.park_grove.adult[27][2].ff**

```text
>{主角称呼}，先吃完这碗。
```

**$.park_grove.adult[27][3]**

```text
你说得对。
```

**$.park_grove.adult[27][4]**

```text
>不够再来，别急。
```

**$.park_grove.adult[28][0]**

```text
先闻再决定
```

**$.park_grove.adult[28][1].mm**

```text
{对方称呼}，刚才还说自己不饿。
```

**$.park_grove.adult[28][1].mf**

```text
你好，刚才还说自己不饿。
```

**$.park_grove.adult[28][1].fm**

```text
你好，{对方称呼}，刚才还说自己不饿。
```

**$.park_grove.adult[28][1].ff**

```text
你好，刚才还说自己不饿。
```

**$.park_grove.adult[28][2].mm**

```text
>{主角称呼}，现在又想吃了？
```

**$.park_grove.adult[28][2].mf**

```text
>现在又想吃了？
```

**$.park_grove.adult[28][2].fm**

```text
>现在又想吃了？
```

**$.park_grove.adult[28][2].ff**

```text
>{主角称呼}，现在又想吃了？
```

**$.park_grove.adult[28][3]**

```text
嗯，闻到味了。
```

**$.park_grove.adult[28][4]**

```text
>那买一点试试。
```

**$.park_grove.adult[29][0]**

```text
小路的转弯
```

**$.park_grove.adult[29][1].mm**

```text
{对方称呼}，一拐进来就不一样了。
```

**$.park_grove.adult[29][1].mf**

```text
你好，一拐进来就不一样了。
```

**$.park_grove.adult[29][1].fm**

```text
你好，{对方称呼}，一拐进来就不一样了。
```

**$.park_grove.adult[29][1].ff**

```text
你好，一拐进来就不一样了。
```

**$.park_grove.adult[29][2].mm**

```text
>{主角称呼}，这边树多，摊子也在里面。
```

**$.park_grove.adult[29][2].mf**

```text
>这边树多，摊子也在里面。
```

**$.park_grove.adult[29][2].fm**

```text
>这边树多，摊子也在里面。
```

**$.park_grove.adult[29][2].ff**

```text
>{主角称呼}，这边树多，摊子也在里面。
```

**$.park_grove.adult[29][3]**

```text
刚还以为走错路。
```

**$.park_grove.adult[29][4]**

```text
>没错，顺着路来就好。
```

**$.park_grove.adult[30][0]**

```text
不烫的耐心
```

**$.park_grove.adult[30][1].mm**

```text
{对方称呼}，热的总想快点吃。
```

**$.park_grove.adult[30][1].mf**

```text
你好，热的总想快点吃。
```

**$.park_grove.adult[30][1].fm**

```text
你好，{对方称呼}，热的总想快点吃。
```

**$.park_grove.adult[30][1].ff**

```text
你好，热的总想快点吃。
```

**$.park_grove.adult[30][2].mm**

```text
>{主角称呼}，先吹一下，里面更烫。
```

**$.park_grove.adult[30][2].mf**

```text
>先吹一下，里面更烫。
```

**$.park_grove.adult[30][2].fm**

```text
>先吹一下，里面更烫。
```

**$.park_grove.adult[30][2].ff**

```text
>{主角称呼}，先吹一下，里面更烫。
```

**$.park_grove.adult[30][3]**

```text
我先试一小口。
```

**$.park_grove.adult[30][4]**

```text
>别一口咬中间。
```

**$.park_grove.adult[31][0]**

```text
路边的暖意
```

**$.park_grove.adult[31][1].mm**

```text
{对方称呼}，看摊子冒热气就暖和点。
```

**$.park_grove.adult[31][1].mf**

```text
你好，看摊子冒热气就暖和点。
```

**$.park_grove.adult[31][1].fm**

```text
你好，{对方称呼}，看摊子冒热气就暖和点。
```

**$.park_grove.adult[31][1].ff**

```text
你好，看摊子冒热气就暖和点。
```

**$.park_grove.adult[31][2].mm**

```text
>{主角称呼}，走累了能坐着吃。
```

**$.park_grove.adult[31][2].mf**

```text
>走累了能坐着吃。
```

**$.park_grove.adult[31][2].fm**

```text
>走累了能坐着吃。
```

**$.park_grove.adult[31][2].ff**

```text
>{主角称呼}，走累了能坐着吃。
```

**$.park_grove.adult[31][3]**

```text
嗯，我先看看有座没。
```

**$.park_grove.adult[31][4]**

```text
>那边好像刚空出来。
```

**$.park_grove.adult[32][0]**

```text
花期的想象
```

**$.park_grove.adult[32][1].mm**

```text
{对方称呼}，等开花了还想再来。
```

**$.park_grove.adult[32][1].mf**

```text
你好，等开花了还想再来。
```

**$.park_grove.adult[32][1].fm**

```text
你好，{对方称呼}，等开花了还想再来。
```

**$.park_grove.adult[32][1].ff**

```text
你好，等开花了还想再来。
```

**$.park_grove.adult[32][2].mm**

```text
>{主角称呼}，到时候人可能多。
```

**$.park_grove.adult[32][2].mf**

```text
>到时候人可能多。
```

**$.park_grove.adult[32][2].fm**

```text
>到时候人可能多。
```

**$.park_grove.adult[32][2].ff**

```text
>{主角称呼}，到时候人可能多。
```

**$.park_grove.adult[32][3]**

```text
早点来能好点吧？
```

**$.park_grove.adult[32][4]**

```text
>应该吧，别挤的时候来。
```

**$.park_grove.adult[33][0]**

```text
碗里的小选择
```

**$.park_grove.adult[33][1].mm**

```text
{对方称呼}，碗里先选哪样？
```

**$.park_grove.adult[33][1].mf**

```text
你好，碗里先选哪样？
```

**$.park_grove.adult[33][1].fm**

```text
你好，{对方称呼}，碗里先选哪样？
```

**$.park_grove.adult[33][1].ff**

```text
你好，碗里先选哪样？
```

**$.park_grove.adult[33][2].mm**

```text
>{主角称呼}，先吃小块的，凉得快。
```

**$.park_grove.adult[33][2].mf**

```text
>先吃小块的，凉得快。
```

**$.park_grove.adult[33][2].fm**

```text
>先吃小块的，凉得快。
```

**$.park_grove.adult[33][2].ff**

```text
>{主角称呼}，先吃小块的，凉得快。
```

**$.park_grove.adult[33][3]**

```text
这个呢？
```

**$.park_grove.adult[33][4]**

```text
>大块的再放一下。
```

**$.park_grove.adult[34][0]**

```text
树下的停靠
```

**$.park_grove.adult[34][1].mm**

```text
{对方称呼}，我在树下歇一会儿。
```

**$.park_grove.adult[34][1].mf**

```text
你好，我在树下歇一会儿。
```

**$.park_grove.adult[34][1].fm**

```text
你好，{对方称呼}，我在树下歇一会儿。
```

**$.park_grove.adult[34][1].ff**

```text
你好，我在树下歇一会儿。
```

**$.park_grove.adult[34][2].mm**

```text
>{主角称呼}，好，别挡着小路。
```

**$.park_grove.adult[34][2].mf**

```text
>好，别挡着小路。
```

**$.park_grove.adult[34][2].fm**

```text
>好，别挡着小路。
```

**$.park_grove.adult[34][2].ff**

```text
>{主角称呼}，好，别挡着小路。
```

**$.park_grove.adult[34][3]**

```text
我站边上。
```

**$.park_grove.adult[34][4]**

```text
>嗯，这儿不晒。
```

**$.park_grove.adult[35][0]**

```text
香味的边界
```

**$.park_grove.adult[35][1].mm**

```text
{对方称呼}，香味到这边又淡了。
```

**$.park_grove.adult[35][1].mf**

```text
你好，香味到这边又淡了。
```

**$.park_grove.adult[35][1].fm**

```text
你好，{对方称呼}，香味到这边又淡了。
```

**$.park_grove.adult[35][1].ff**

```text
你好，香味到这边又淡了。
```

**$.park_grove.adult[35][2].mm**

```text
>{主角称呼}，风换方向了吧。
```

**$.park_grove.adult[35][2].mf**

```text
>风换方向了吧。
```

**$.park_grove.adult[35][2].fm**

```text
>风换方向了吧。
```

**$.park_grove.adult[35][2].ff**

```text
>{主角称呼}，风换方向了吧。
```

**$.park_grove.adult[35][3]**

```text
刚在那边特别香。
```

**$.park_grove.adult[35][4]**

```text
>靠锅近也更明显。
```

**$.park_grove.adult[36][0]**

```text
吃饭前的闲聊
```

**$.park_grove.adult[36][1].mm**

```text
{对方称呼}，等饭的时候总想找人说两句。
```

**$.park_grove.adult[36][1].mf**

```text
你好，等饭的时候总想找人说两句。
```

**$.park_grove.adult[36][1].fm**

```text
你好，{对方称呼}，等饭的时候总想找人说两句。
```

**$.park_grove.adult[36][1].ff**

```text
你好，等饭的时候总想找人说两句。
```

**$.park_grove.adult[36][2].mm**

```text
>{主角称呼}，等多久了？
```

**$.park_grove.adult[36][2].mf**

```text
>等多久了？
```

**$.park_grove.adult[36][2].fm**

```text
>等多久了？
```

**$.park_grove.adult[36][2].ff**

```text
>{主角称呼}，等多久了？
```

**$.park_grove.adult[36][3]**

```text
刚点，没多久。
```

**$.park_grove.adult[36][4]**

```text
>那再等会儿，人也不太多。
```

**$.park_grove.adult[37][0]**

```text
不急着拍照
```

**$.park_grove.adult[37][1].mm**

```text
{对方称呼}，先吃还是先拍照？
```

**$.park_grove.adult[37][1].mf**

```text
你好，先吃还是先拍照？
```

**$.park_grove.adult[37][1].fm**

```text
你好，{对方称呼}，先吃还是先拍照？
```

**$.park_grove.adult[37][1].ff**

```text
你好，先吃还是先拍照？
```

**$.park_grove.adult[37][2].mm**

```text
>{主角称呼}，热的先吃吧。
```

**$.park_grove.adult[37][2].mf**

```text
>热的先吃吧。
```

**$.park_grove.adult[37][2].fm**

```text
>热的先吃吧。
```

**$.park_grove.adult[37][2].ff**

```text
>{主角称呼}，热的先吃吧。
```

**$.park_grove.adult[37][3]**

```text
也对，拍半天该凉了。
```

**$.park_grove.adult[37][4]**

```text
>等不烫嘴的时候拍一张就行。
```

**$.park_grove.adult[38][0]**

```text
树枝的空隙
```

**$.park_grove.adult[38][1].mm**

```text
{对方称呼}，从树枝空隙看见摊子了。
```

**$.park_grove.adult[38][1].mf**

```text
你好，从树枝空隙看见摊子了。
```

**$.park_grove.adult[38][1].fm**

```text
你好，{对方称呼}，从树枝空隙看见摊子了。
```

**$.park_grove.adult[38][1].ff**

```text
你好，从树枝空隙看见摊子了。
```

**$.park_grove.adult[38][2].mm**

```text
>{主角称呼}，是不是刚才没找着？
```

**$.park_grove.adult[38][2].mf**

```text
>是不是刚才没找着？
```

**$.park_grove.adult[38][2].fm**

```text
>是不是刚才没找着？
```

**$.park_grove.adult[38][2].ff**

```text
>{主角称呼}，是不是刚才没找着？
```

**$.park_grove.adult[38][3]**

```text
嗯，走太外面了。
```

**$.park_grove.adult[38][4]**

```text
>沿小路过去，不用从树间钻。
```

**$.park_grove.adult[39][0]**

```text
一口的踏实
```

**$.park_grove.adult[39][1].mm**

```text
{对方称呼}，吃点热的舒服多了。
```

**$.park_grove.adult[39][1].mf**

```text
你好，吃点热的舒服多了。
```

**$.park_grove.adult[39][1].fm**

```text
你好，{对方称呼}，吃点热的舒服多了。
```

**$.park_grove.adult[39][1].ff**

```text
你好，吃点热的舒服多了。
```

**$.park_grove.adult[39][2].mm**

```text
>{主角称呼}，刚是不是走饿了？
```

**$.park_grove.adult[39][2].mf**

```text
>刚是不是走饿了？
```

**$.park_grove.adult[39][2].fm**

```text
>刚是不是走饿了？
```

**$.park_grove.adult[39][2].ff**

```text
>{主角称呼}，刚是不是走饿了？
```

**$.park_grove.adult[39][3]**

```text
嗯，光顾着转。
```

**$.park_grove.adult[39][4]**

```text
>下回先吃饭再来。
```

**$.park_grove.adult[40][0]**

```text
小摊的声音
```

**$.park_grove.adult[40][1].mm**

```text
{对方称呼}，摊子那边有锅盖响。
```

**$.park_grove.adult[40][1].mf**

```text
你好，摊子那边有锅盖响。
```

**$.park_grove.adult[40][1].fm**

```text
你好，{对方称呼}，摊子那边有锅盖响。
```

**$.park_grove.adult[40][1].ff**

```text
你好，摊子那边有锅盖响。
```

**$.park_grove.adult[40][2].mm**

```text
>{主角称呼}，有人开锅了吧。
```

**$.park_grove.adult[40][2].mf**

```text
>有人开锅了吧。
```

**$.park_grove.adult[40][2].fm**

```text
>有人开锅了吧。
```

**$.park_grove.adult[40][2].ff**

```text
>{主角称呼}，有人开锅了吧。
```

**$.park_grove.adult[40][3]**

```text
还听见碗碰一起。
```

**$.park_grove.adult[40][4]**

```text
>忙着呢，先别过去挤。
```

**$.park_grove.adult[41][0]**

```text
回去以后的香
```

**$.park_grove.adult[41][1].mm**

```text
{对方称呼}，回家衣服上还有这个味。
```

**$.park_grove.adult[41][1].mf**

```text
你好，回家衣服上还有这个味。
```

**$.park_grove.adult[41][1].fm**

```text
你好，{对方称呼}，回家衣服上还有这个味。
```

**$.park_grove.adult[41][1].ff**

```text
你好，回家衣服上还有这个味。
```

**$.park_grove.adult[41][2].mm**

```text
>{主角称呼}，你在锅边站久了。
```

**$.park_grove.adult[41][2].mf**

```text
>你在锅边站久了。
```

**$.park_grove.adult[41][2].fm**

```text
>你在锅边站久了。
```

**$.park_grove.adult[41][2].ff**

```text
>{主角称呼}，你在锅边站久了。
```

**$.park_grove.adult[41][3]**

```text
嗯，等吃的时一直看。
```

**$.park_grove.adult[41][4]**

```text
>挂着散散，别闷柜子里。
```

**$.park_grove.adult[42][0]**

```text
安静地热闹
```

**$.park_grove.adult[42][1].mm**

```text
{对方称呼}，摊子旁边人不少，也没大声喊。
```

**$.park_grove.adult[42][1].mf**

```text
你好，摊子旁边人不少，也没大声喊。
```

**$.park_grove.adult[42][1].fm**

```text
你好，{对方称呼}，摊子旁边人不少，也没大声喊。
```

**$.park_grove.adult[42][1].ff**

```text
你好，摊子旁边人不少，也没大声喊。
```

**$.park_grove.adult[42][2].mm**

```text
>{主角称呼}，都在吃东西。
```

**$.park_grove.adult[42][2].mf**

```text
>都在吃东西。
```

**$.park_grove.adult[42][2].fm**

```text
>都在吃东西。
```

**$.park_grove.adult[42][2].ff**

```text
>{主角称呼}，都在吃东西。
```

**$.park_grove.adult[42][3]**

```text
聊几句又接着吃。
```

**$.park_grove.adult[42][4]**

```text
>嗯，这样挺好。
```

**$.park_grove.adult[43][0]**

```text
不用一次记住
```

**$.park_grove.adult[43][1].mm**

```text
{对方称呼}，菜单我看几回也记不住。
```

**$.park_grove.adult[43][1].mf**

```text
你好，菜单我看几回也记不住。
```

**$.park_grove.adult[43][1].fm**

```text
你好，{对方称呼}，菜单我看几回也记不住。
```

**$.park_grove.adult[43][1].ff**

```text
你好，菜单我看几回也记不住。
```

**$.park_grove.adult[43][2].mm**

```text
>{主角称呼}，想点时再看呗。
```

**$.park_grove.adult[43][2].mf**

```text
>想点时再看呗。
```

**$.park_grove.adult[43][2].fm**

```text
>想点时再看呗。
```

**$.park_grove.adult[43][2].ff**

```text
>{主角称呼}，想点时再看呗。
```

**$.park_grove.adult[43][3]**

```text
就是老忘上回吃了哪个。
```

**$.park_grove.adult[43][4]**

```text
>下回拍一下名字。
```

**$.park_grove.adult[44][0]**

```text
旁边的空位
```

**$.park_grove.adult[44][1].mm**

```text
{对方称呼}，旁边能坐吗？
```

**$.park_grove.adult[44][1].mf**

```text
你好，旁边能坐吗？
```

**$.park_grove.adult[44][1].fm**

```text
你好，{对方称呼}，旁边能坐吗？
```

**$.park_grove.adult[44][1].ff**

```text
你好，旁边能坐吗？
```

**$.park_grove.adult[44][2].mm**

```text
>{主角称呼}，没人，先看看干不干净。
```

**$.park_grove.adult[44][2].mf**

```text
>没人，先看看干不干净。
```

**$.park_grove.adult[44][2].fm**

```text
>没人，先看看干不干净。
```

**$.park_grove.adult[44][2].ff**

```text
>{主角称呼}，没人，先看看干不干净。
```

**$.park_grove.adult[44][3]**

```text
我擦一下。
```

**$.park_grove.adult[44][4]**

```text
>纸别落地上就行。
```

**$.park_grove.adult[45][0]**

```text
好吃的争论
```

**$.park_grove.adult[45][1].mm**

```text
{对方称呼}，你觉得哪样好吃？
```

**$.park_grove.adult[45][1].mf**

```text
你好，你觉得哪样好吃？
```

**$.park_grove.adult[45][1].fm**

```text
你好，{对方称呼}，你觉得哪样好吃？
```

**$.park_grove.adult[45][1].ff**

```text
你好，你觉得哪样好吃？
```

**$.park_grove.adult[45][2].mm**

```text
>{主角称呼}，我只吃过一点，不好比。
```

**$.park_grove.adult[45][2].mf**

```text
>我只吃过一点，不好比。
```

**$.park_grove.adult[45][2].fm**

```text
>我只吃过一点，不好比。
```

**$.park_grove.adult[45][2].ff**

```text
>{主角称呼}，我只吃过一点，不好比。
```

**$.park_grove.adult[45][3]**

```text
那先说吃过的。
```

**$.park_grove.adult[45][4]**

```text
>那个汤的还行，别的你自己尝尝。
```

**$.park_grove.adult[46][0]**

```text
今天的改变
```

**$.park_grove.adult[46][1].mm**

```text
{对方称呼}，今天换条路走，还真找到吃的了。
```

**$.park_grove.adult[46][1].mf**

```text
你好，今天换条路走，还真找到吃的了。
```

**$.park_grove.adult[46][1].fm**

```text
你好，{对方称呼}，今天换条路走，还真找到吃的了。
```

**$.park_grove.adult[46][1].ff**

```text
你好，今天换条路走，还真找到吃的了。
```

**$.park_grove.adult[46][2].mm**

```text
>{主角称呼}，以前没来过这边？
```

**$.park_grove.adult[46][2].mf**

```text
>以前没来过这边？
```

**$.park_grove.adult[46][2].fm**

```text
>以前没来过这边？
```

**$.park_grove.adult[46][2].ff**

```text
>{主角称呼}，以前没来过这边？
```

**$.park_grove.adult[46][3]**

```text
没，老在中间转。
```

**$.park_grove.adult[46][4]**

```text
>下回就认得了。
```

**$.park_grove.adult[47][0]**

```text
再来的理由
```

**$.park_grove.adult[47][1].mm**

```text
{对方称呼}，下回可能还会来。
```

**$.park_grove.adult[47][1].mf**

```text
你好，下回可能还会来。
```

**$.park_grove.adult[47][1].fm**

```text
你好，{对方称呼}，下回可能还会来。
```

**$.park_grove.adult[47][1].ff**

```text
你好，下回可能还会来。
```

**$.park_grove.adult[47][2].mm**

```text
>{主角称呼}，嗯，这边走走挺方便。
```

**$.park_grove.adult[47][2].mf**

```text
>嗯，这边走走挺方便。
```

**$.park_grove.adult[47][2].fm**

```text
>嗯，这边走走挺方便。
```

**$.park_grove.adult[47][2].ff**

```text
>{主角称呼}，嗯，这边走走挺方便。
```

**$.park_grove.adult[47][3]**

```text
碰上再打招呼。
```

**$.park_grove.adult[47][4]**

```text
>好，下回见。
```

**$.park_grove.kid[0][0]**

```text
花瓣帽子
```

**$.park_grove.kid[0][1]**

```text
头上落了一片花瓣，要帮你拿掉吗？
```

**$.park_grove.kid[0][2]**

```text
>先不用，我想戴一会儿免费的帽子。
```

**$.park_grove.kid[0][3]**

```text
它可能会被风借走。
```

**$.park_grove.kid[0][4]**

```text
>没关系，风也能戴一下。
```

**$.park_grove.kid[1][0]**

```text
热气云朵
```

**$.park_grove.kid[1][1]**

```text
你在追着看什么呀？
```

**$.park_grove.kid[1][2]**

```text
>锅上的小云，它们升起来就不见了。
```

**$.park_grove.kid[1][3]**

```text
也许去天上换班了。
```

**$.park_grove.kid[1][4]**

```text
>那今天的小摊很忙。
```

**$.park_grove.kid[2][0]**

```text
树的雪
```

**$.park_grove.kid[2][1]**

```text
你觉得这些花像什么？
```

**$.park_grove.kid[2][2]**

```text
>像不会把手冻红的雪。
```

**$.park_grove.kid[2][3]**

```text
这个比喻很暖和。
```

**$.park_grove.kid[2][4]**

```text
>而且落到鼻子上不会让我打喷嚏那么久。
```

**$.park_grove.kid[3][0]**

```text
筷子桥
```

**$.park_grove.kid[3][1]**

```text
你为什么把筷子摆在碗边？
```

**$.park_grove.kid[3][2]**

```text
>我在等食物过桥。
```

**$.park_grove.kid[3][3]**

```text
桥过了以后去哪儿？
```

**$.park_grove.kid[3][4]**

```text
>去肚子里，终点站很安全。
```

**$.park_grove.kid[4][0]**

```text
花瓣邮票
```

**$.park_grove.kid[4][1]**

```text
你手里那片花瓣要送给谁？
```

**$.park_grove.kid[4][2]**

```text
>我想当邮票，寄一封信给春天。
```

**$.park_grove.kid[4][3]**

```text
信里写什么？
```

**$.park_grove.kid[4][4]**

```text
>写下次也要记得开花。
```

**$.park_grove.kid[5][0]**

```text
小摊灯笼
```

**$.park_grove.kid[5][1]**

```text
你看灯笼看得好认真。
```

**$.park_grove.kid[5][2]**

```text
>它像一个不会烫嘴的大丸子。
```

**$.park_grove.kid[5][3]**

```text
可不能真的吃。
```

**$.park_grove.kid[5][4]**

```text
>我知道，我的想象先吃一口。
```

**$.park_grove.kid[6][0]**

```text
锅边的小云
```

**$.park_grove.kid[6][1].mm**

```text
{对方称呼}，你盯着那点热气看什么？
```

**$.park_grove.kid[6][1].mf**

```text
你好，你盯着那点热气看什么？
```

**$.park_grove.kid[6][1].fm**

```text
你好，{对方称呼}，你盯着那点热气看什么？
```

**$.park_grove.kid[6][1].ff**

```text
打个招呼，你盯着那点热气看什么？
```

**$.park_grove.kid[6][2].mm**

```text
>{主角称呼}，嗯，看它们谁先跑到树上去。
```

**$.park_grove.kid[6][2].mf**

```text
>{主角称呼}，说起来，看它们谁先跑到树上去。
```

**$.park_grove.kid[6][2].fm**

```text
>{主角称呼}，其实，看它们谁先跑到树上去。
```

**$.park_grove.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，看它们谁先跑到树上去。
```

**$.park_grove.kid[6][3]**

```text
最后谁赢了？
```

**$.park_grove.kid[6][4]**

```text
>都不见了，我判它们打平。
```

**$.park_grove.kid[7][0]**

```text
想象的丸子
```

**$.park_grove.kid[7][1].mm**

```text
{对方称呼}，你在空中比一个圆？
```

**$.park_grove.kid[7][1].mf**

```text
你好，你在空中比一个圆？
```

**$.park_grove.kid[7][1].fm**

```text
你好，{对方称呼}，你在空中比一个圆？
```

**$.park_grove.kid[7][1].ff**

```text
打个招呼，你在空中比一个圆？
```

**$.park_grove.kid[7][2].mm**

```text
>{主角称呼}，说起来，我觉得灯笼像特别大的丸子。
```

**$.park_grove.kid[7][2].mf**

```text
>{主角称呼}，其实，我觉得灯笼像特别大的丸子。
```

**$.park_grove.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，我觉得灯笼像特别大的丸子。
```

**$.park_grove.kid[7][2].ff**

```text
>{主角称呼}，嗯，我觉得灯笼像特别大的丸子。
```

**$.park_grove.kid[7][3]**

```text
这个只能看，不能夹。
```

**$.park_grove.kid[7][4]**

```text
>知道，我的筷子也够不到。
```

**$.park_grove.kid[8][0]**

```text
碗里的月亮
```

**$.park_grove.kid[8][1].mm**

```text
{对方称呼}，你说在碗里看见了月亮？
```

**$.park_grove.kid[8][1].mf**

```text
你好，你说在碗里看见了月亮？
```

**$.park_grove.kid[8][1].fm**

```text
你好，{对方称呼}，你说在碗里看见了月亮？
```

**$.park_grove.kid[8][1].ff**

```text
打个招呼，你说在碗里看见了月亮？
```

**$.park_grove.kid[8][2].mm**

```text
>{主角称呼}，其实，圆圆的那个很像。
```

**$.park_grove.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，圆圆的那个很像。
```

**$.park_grove.kid[8][2].fm**

```text
>{主角称呼}，嗯，圆圆的那个很像。
```

**$.park_grove.kid[8][2].ff**

```text
>{主角称呼}，说起来，圆圆的那个很像。
```

**$.park_grove.kid[8][3]**

```text
那要慢慢吃，可能有点烫。
```

**$.park_grove.kid[8][4]**

```text
>好，我让月亮先凉快一下。
```

**$.park_grove.kid[9][0]**

```text
树根的小门
```

**$.park_grove.kid[9][1].mm**

```text
{对方称呼}，为什么站在树边不走？
```

**$.park_grove.kid[9][1].mf**

```text
你好，为什么站在树边不走？
```

**$.park_grove.kid[9][1].fm**

```text
你好，{对方称呼}，为什么站在树边不走？
```

**$.park_grove.kid[9][1].ff**

```text
打个招呼，为什么站在树边不走？
```

**$.park_grove.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，我觉得这里像小虫的家门口。
```

**$.park_grove.kid[9][2].mf**

```text
>{主角称呼}，嗯，我觉得这里像小虫的家门口。
```

**$.park_grove.kid[9][2].fm**

```text
>{主角称呼}，说起来，我觉得这里像小虫的家门口。
```

**$.park_grove.kid[9][2].ff**

```text
>{主角称呼}，其实，我觉得这里像小虫的家门口。
```

**$.park_grove.kid[9][3]**

```text
那留条路给它们。
```

**$.park_grove.kid[9][4]**

```text
>嗯，我也不喜欢家门被挡着。
```

**$.park_grove.kid[10][0]**

```text
等饭的计时
```

**$.park_grove.kid[10][1].mm**

```text
{对方称呼}，你一直在数什么？
```

**$.park_grove.kid[10][1].mf**

```text
你好，你一直在数什么？
```

**$.park_grove.kid[10][1].fm**

```text
你好，{对方称呼}，你一直在数什么？
```

**$.park_grove.kid[10][1].ff**

```text
打个招呼，你一直在数什么？
```

**$.park_grove.kid[10][2].mm**

```text
>{主角称呼}，嗯，数闻到几次香味，饭就会到。
```

**$.park_grove.kid[10][2].mf**

```text
>{主角称呼}，说起来，数闻到几次香味，饭就会到。
```

**$.park_grove.kid[10][2].fm**

```text
>{主角称呼}，其实，数闻到几次香味，饭就会到。
```

**$.park_grove.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，数闻到几次香味，饭就会到。
```

**$.park_grove.kid[10][3]**

```text
这个时钟准吗？
```

**$.park_grove.kid[10][4]**

```text
>不太准，可是听起来很好吃。
```

**$.park_grove.kid[11][0]**

```text
小摊的下次
```

**$.park_grove.kid[11][1].mm**

```text
{对方称呼}，今天玩得开心吗？
```

**$.park_grove.kid[11][1].mf**

```text
你好，今天玩得开心吗？
```

**$.park_grove.kid[11][1].fm**

```text
你好，{对方称呼}，今天玩得开心吗？
```

**$.park_grove.kid[11][1].ff**

```text
打个招呼，今天玩得开心吗？
```

**$.park_grove.kid[11][2].mm**

```text
>{主角称呼}，说起来，开心，我已经在想下次吃什么。
```

**$.park_grove.kid[11][2].mf**

```text
>{主角称呼}，其实，开心，我已经在想下次吃什么。
```

**$.park_grove.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，开心，我已经在想下次吃什么。
```

**$.park_grove.kid[11][2].ff**

```text
>{主角称呼}，嗯，开心，我已经在想下次吃什么。
```

**$.park_grove.kid[11][3]**

```text
今天还没结束呢。
```

**$.park_grove.kid[11][4]**

```text
>那我先认真开心今天这一份。
```

**$.mall.adult[0][0]**

```text
只看不买
```

**$.mall.adult[0][1]**

```text
你也随便逛逛？
```

**$.mall.adult[0][2]**

```text
>嗯，暂时没想买什么。
```

**$.mall.adult[0][3]**

```text
我也是，先看看。
```

**$.mall.adult[0][4]**

```text
>那边几家刚换了东西。
```

**$.mall.adult[1][0]**

```text
橱窗的倒影
```

**$.mall.adult[1][1]**

```text
刚在玻璃里差点没认出自己。
```

**$.mall.adult[1][2]**

```text
>灯打得不一样吧。
```

**$.mall.adult[1][3]**

```text
还顺便整了下头发。
```

**$.mall.adult[1][4]**

```text
>我也经常拿橱窗当镜子。
```

**$.mall.adult[2][0]**

```text
商场的方向
```

**$.mall.adult[2][1]**

```text
往哪边比较好逛？
```

**$.mall.adult[2][2]**

```text
>我刚从那边过来，吃的多一点。
```

**$.mall.adult[2][3]**

```text
哦，我先往那边看看。
```

**$.mall.adult[2][4]**

```text
>嗯，沿着走就能看见。
```

**$.mall.adult[3][0]**

```text
购物清单
```

**$.mall.adult[3][1]**

```text
你买东西列清单吗？
```

**$.mall.adult[3][2]**

```text
>列，但经常忘看。
```

**$.mall.adult[3][3]**

```text
那跟没列差不多。
```

**$.mall.adult[3][4]**

```text
>买完才想起来少了最要紧的。
```

**$.mall.adult[4][0]**

```text
电梯的犹豫
```

**$.mall.adult[4][1]**

```text
刚电梯开了，我忘了去哪层。
```

**$.mall.adult[4][2]**

```text
>后来上去没？
```

**$.mall.adult[4][3]**

```text
没，在外面又看了一遍牌子。
```

**$.mall.adult[4][4]**

```text
>看清了再上，不然还得下来。
```

**$.mall.adult[5][0]**

```text
鞋子的建议
```

**$.mall.adult[5][1]**

```text
鞋舒不舒服得走久了才知道。
```

**$.mall.adult[5][2]**

```text
>你也磨脚？
```

**$.mall.adult[5][3]**

```text
有一点，试的时候没觉得。
```

**$.mall.adult[5][4]**

```text
>找个地方坐会儿吧。
```

**$.mall.adult[6][0]**

```text
奶茶的远方
```

**$.mall.adult[6][1]**

```text
那边是不是有奶茶？
```

**$.mall.adult[6][2]**

```text
>有，我刚看见招牌了。
```

**$.mall.adult[6][3]**

```text
我想过去看看。
```

**$.mall.adult[6][4]**

```text
>先看看排队长不长。
```

**$.mall.adult[7][0]**

```text
电影院海报
```

**$.mall.adult[7][1]**

```text
这张电影海报挺好看。
```

**$.mall.adult[7][2]**

```text
>嗯，不过我没听过这片。
```

**$.mall.adult[7][3]**

```text
我也没，先看看简介。
```

**$.mall.adult[7][4]**

```text
>别只看海报就买票了。
```

**$.mall.adult[8][0]**

```text
商场的音乐
```

**$.mall.adult[8][1]**

```text
这歌是不是放过一遍了？
```

**$.mall.adult[8][2]**

```text
>好像是，我也听着耳熟。
```

**$.mall.adult[8][3]**

```text
逛久了都能唱了。
```

**$.mall.adult[8][4]**

```text
>我刚差点跟着哼。
```

**$.mall.adult[9][0]**

```text
不消费的休息
```

**$.mall.adult[9][1]**

```text
我进来没买什么，就走走。
```

**$.mall.adult[9][2]**

```text
>里面温度合适。
```

**$.mall.adult[9][3]**

```text
对，还能找地方坐一下。
```

**$.mall.adult[9][4]**

```text
>那边好像有空位。
```

**$.mall.adult[10][0]**

```text
购物袋的分量
```

**$.mall.adult[10][1]**

```text
这袋子拎久了真重。
```

**$.mall.adult[10][2]**

```text
>换只手吧。
```

**$.mall.adult[10][3]**

```text
刚换过，另一只也酸。
```

**$.mall.adult[10][4]**

```text
>那先歇会儿，别一直拎着。
```

**$.mall.adult[11][0]**

```text
路过书店
```

**$.mall.adult[11][1]**

```text
路过书店总想进去。
```

**$.mall.adult[11][2]**

```text
>有想买的书？
```

**$.mall.adult[11][3]**

```text
没有，就翻翻。
```

**$.mall.adult[11][4]**

```text
>先看看也行，别又买一堆放着。
```

**$.mall.adult[12][0]**

```text
折扣的算术
```

**$.mall.adult[12][1]**

```text
这折扣我算半天。
```

**$.mall.adult[12][2]**

```text
>算明白了没？
```

**$.mall.adult[12][3]**

```text
算明白了，不买省最多。
```

**$.mall.adult[12][4]**

```text
>那先别买，真想要再来。
```

**$.mall.adult[13][0]**

```text
玻璃栏杆
```

**$.mall.adult[13][1]**

```text
从这儿往上看层数还挺多。
```

**$.mall.adult[13][2]**

```text
>走起来就更觉得了。
```

**$.mall.adult[13][3]**

```text
你逛完了吗？
```

**$.mall.adult[13][4]**

```text
>哪能啊，挑几家看看就行。
```

**$.mall.adult[14][0]**

```text
空白的计划
```

**$.mall.adult[14][1]**

```text
今天没打算买什么。
```

**$.mall.adult[14][2]**

```text
>我也是，出来转转。
```

**$.mall.adult[14][3]**

```text
有时候逛完也没买。
```

**$.mall.adult[14][4]**

```text
>嗯，不用非得带点什么回去。
```

**$.mall.adult[15][0]**

```text
跟着香味
```

**$.mall.adult[15][1]**

```text
你刚才怎么又回头了？
```

**$.mall.adult[15][2]**

```text
>闻着像面包，想看看哪儿卖的。
```

**$.mall.adult[15][3]**

```text
找到了？
```

**$.mall.adult[15][4]**

```text
>没，可能是有人拎着过去。
```

**$.mall.adult[16][0]**

```text
试衣的勇气
```

**$.mall.adult[16][1]**

```text
有些衣服好看，穿着不一定好看。
```

**$.mall.adult[16][2]**

```text
>试过才知道。
```

**$.mall.adult[16][3]**

```text
就怕试完人家一直劝买。
```

**$.mall.adult[16][4]**

```text
>不合适就说不合适，没事。
```

**$.mall.adult[17][0]**

```text
走反的路
```

**$.mall.adult[17][1]**

```text
这段路我好像又走回来了。
```

**$.mall.adult[17][2]**

```text
>看店名，刚才不是这几家吗。
```

**$.mall.adult[17][3]**

```text
还真是。
```

**$.mall.adult[17][4]**

```text
>那换边走吧，别再绕一圈。
```

**$.mall.adult[18][0]**

```text
饭点的讨论
```

**$.mall.adult[18][1]**

```text
饭点都不知道吃什么。
```

**$.mall.adult[18][2]**

```text
>楼里吃的倒不少。
```

**$.mall.adult[18][3]**

```text
越多越难选。
```

**$.mall.adult[18][4]**

```text
>先想要饭还是面，少看一半。
```

**$.mall.adult[19][0]**

```text
手空出来了
```

**$.mall.adult[19][1]**

```text
没提袋子，手轻松多了。
```

**$.mall.adult[19][2]**

```text
>刚才东西放哪儿了？
```

**$.mall.adult[19][3]**

```text
收包里了，就一点。
```

**$.mall.adult[19][4]**

```text
>那好，空个手方便。
```

**$.mall.adult[20][0]**

```text
热闹里的停顿
```

**$.mall.adult[20][1]**

```text
热闹地方走久了想坐下。
```

**$.mall.adult[20][2]**

```text
>前面有空位。
```

**$.mall.adult[20][3]**

```text
我去歇一下。
```

**$.mall.adult[20][4]**

```text
>嗯，别走到脚疼才停。
```

**$.mall.adult[21][0]**

```text
同款的巧合
```

**$.mall.adult[21][1]**

```text
刚才看到跟我同款的衣服。
```

**$.mall.adult[21][2]**

```text
>颜色也一样？
```

**$.mall.adult[21][3]**

```text
嗯，差点以为照镜子。
```

**$.mall.adult[21][4]**

```text
>那还挺巧。
```

**$.mall.adult[22][0]**

```text
收获一点
```

**$.mall.adult[22][1]**

```text
今天也算买到要用的了。
```

**$.mall.adult[22][2]**

```text
>什么东西？
```

**$.mall.adult[22][3]**

```text
小配件，不起眼但找好久。
```

**$.mall.adult[22][4]**

```text
>那就好，不用再跑一趟。
```

**$.mall.adult[23][0]**

```text
逛街的终点
```

**$.mall.adult[23][1]**

```text
逛完不知道从哪个出口走。
```

**$.mall.adult[23][2]**

```text
>你来的时候从哪进的？
```

**$.mall.adult[23][3]**

```text
我有点忘了。
```

**$.mall.adult[23][4]**

```text
>先看指示牌，别急着上楼。
```

**$.mall.adult[24][0]**

```text
先认识一个人
```

**$.mall.adult[24][1].mm**

```text
{对方称呼}，你好，刚看见你也在这边。
```

**$.mall.adult[24][1].mf**

```text
你好，你好，刚看见你也在这边。
```

**$.mall.adult[24][1].fm**

```text
你好，{对方称呼}，你好，刚看见你也在这边。
```

**$.mall.adult[24][1].ff**

```text
你好，你好，刚看见你也在这边。
```

**$.mall.adult[24][2].mm**

```text
>{主角称呼}，嗯，我在找店。
```

**$.mall.adult[24][2].mf**

```text
>嗯，我在找店。
```

**$.mall.adult[24][2].fm**

```text
>嗯，我在找店。
```

**$.mall.adult[24][2].ff**

```text
>{主角称呼}，嗯，我在找店。
```

**$.mall.adult[24][3]**

```text
找哪家？
```

**$.mall.adult[24][4]**

```text
>名字想不起来，得再看一眼。
```

**$.mall.adult[25][0]**

```text
清单外的相遇
```

**$.mall.adult[25][1].mm**

```text
{对方称呼}，没想到买个东西还能碰上你。
```

**$.mall.adult[25][1].mf**

```text
你好，没想到买个东西还能碰上你。
```

**$.mall.adult[25][1].fm**

```text
你好，{对方称呼}，没想到买个东西还能碰上你。
```

**$.mall.adult[25][1].ff**

```text
你好，没想到买个东西还能碰上你。
```

**$.mall.adult[25][2].mm**

```text
>{主角称呼}，你买到了没？
```

**$.mall.adult[25][2].mf**

```text
>你买到了没？
```

**$.mall.adult[25][2].fm**

```text
>你买到了没？
```

**$.mall.adult[25][2].ff**

```text
>{主角称呼}，你买到了没？
```

**$.mall.adult[25][3]**

```text
还差一样。
```

**$.mall.adult[25][4]**

```text
>我也再转一圈。
```

**$.mall.adult[26][0]**

```text
橱窗里的天气
```

**$.mall.adult[26][1].mm**

```text
{对方称呼}，橱窗里穿的都跟外面不一样。
```

**$.mall.adult[26][1].mf**

```text
你好，橱窗里穿的都跟外面不一样。
```

**$.mall.adult[26][1].fm**

```text
你好，{对方称呼}，橱窗里穿的都跟外面不一样。
```

**$.mall.adult[26][1].ff**

```text
你好，橱窗里穿的都跟外面不一样。
```

**$.mall.adult[26][2].mm**

```text
>{主角称呼}，上新快，提前摆。
```

**$.mall.adult[26][2].mf**

```text
>上新快，提前摆。
```

**$.mall.adult[26][2].fm**

```text
>上新快，提前摆。
```

**$.mall.adult[26][2].ff**

```text
>{主角称呼}，上新快，提前摆。
```

**$.mall.adult[26][3]**

```text
现在穿那件得冷吧。
```

**$.mall.adult[26][4]**

```text
>是，看看就好。
```

**$.mall.adult[27][0]**

```text
看得比买得多
```

**$.mall.adult[27][1].mm**

```text
{对方称呼}，今天看得比买得多。
```

**$.mall.adult[27][1].mf**

```text
你好，今天看得比买得多。
```

**$.mall.adult[27][1].fm**

```text
你好，{对方称呼}，今天看得比买得多。
```

**$.mall.adult[27][1].ff**

```text
你好，今天看得比买得多。
```

**$.mall.adult[27][2].mm**

```text
>{主角称呼}，逛街不都这样。
```

**$.mall.adult[27][2].mf**

```text
>逛街不都这样。
```

**$.mall.adult[27][2].fm**

```text
>逛街不都这样。
```

**$.mall.adult[27][2].ff**

```text
>{主角称呼}，逛街不都这样。
```

**$.mall.adult[27][3]**

```text
我有时候还觉得白跑。
```

**$.mall.adult[27][4]**

```text
>真没要用的就别买。
```

**$.mall.adult[28][0]**

```text
购物袋的影子
```

**$.mall.adult[28][1].mm**

```text
{对方称呼}，袋子影子都拉这么大了。
```

**$.mall.adult[28][1].mf**

```text
你好，袋子影子都拉这么大了。
```

**$.mall.adult[28][1].fm**

```text
你好，{对方称呼}，袋子影子都拉这么大了。
```

**$.mall.adult[28][1].ff**

```text
你好，袋子影子都拉这么大了。
```

**$.mall.adult[28][2].mm**

```text
>{主角称呼}，灯在你后面呢。
```

**$.mall.adult[28][2].mf**

```text
>灯在你后面呢。
```

**$.mall.adult[28][2].fm**

```text
>灯在你后面呢。
```

**$.mall.adult[28][2].ff**

```text
>{主角称呼}，灯在你后面呢。
```

**$.mall.adult[28][3]**

```text
还以为自己拎好多。
```

**$.mall.adult[28][4]**

```text
>要真这么大就拿不动了。
```

**$.mall.adult[29][0]**

```text
海报的下一步
```

**$.mall.adult[29][1].mm**

```text
{对方称呼}，海报看完又犹豫要不要看电影。
```

**$.mall.adult[29][1].mf**

```text
你好，海报看完又犹豫要不要看电影。
```

**$.mall.adult[29][1].fm**

```text
你好，{对方称呼}，海报看完又犹豫要不要看电影。
```

**$.mall.adult[29][1].ff**

```text
你好，海报看完又犹豫要不要看电影。
```

**$.mall.adult[29][2].mm**

```text
>{主角称呼}，先看看几点开场。
```

**$.mall.adult[29][2].mf**

```text
>先看看几点开场。
```

**$.mall.adult[29][2].fm**

```text
>先看看几点开场。
```

**$.mall.adult[29][2].ff**

```text
>{主角称呼}，先看看几点开场。
```

**$.mall.adult[29][3]**

```text
对，还没看时间。
```

**$.mall.adult[29][4]**

```text
>不合适就下回。
```

**$.mall.adult[30][0]**

```text
只逛一小会儿
```

**$.mall.adult[30][1].mm**

```text
{对方称呼}，说好只逛一会儿。
```

**$.mall.adult[30][1].mf**

```text
你好，说好只逛一会儿。
```

**$.mall.adult[30][1].fm**

```text
你好，{对方称呼}，说好只逛一会儿。
```

**$.mall.adult[30][1].ff**

```text
你好，说好只逛一会儿。
```

**$.mall.adult[30][2].mm**

```text
>{主角称呼}，结果又逛久了？
```

**$.mall.adult[30][2].mf**

```text
>结果又逛久了？
```

**$.mall.adult[30][2].fm**

```text
>结果又逛久了？
```

**$.mall.adult[30][2].ff**

```text
>{主角称呼}，结果又逛久了？
```

**$.mall.adult[30][3]**

```text
嗯，看了眼时间都愣了。
```

**$.mall.adult[30][4]**

```text
>那早点回，剩下再来。
```

**$.mall.adult[31][0]**

```text
店名记不住
```

**$.mall.adult[31][1].mm**

```text
{对方称呼}，店名我来几次都记不住。
```

**$.mall.adult[31][1].mf**

```text
你好，店名我来几次都记不住。
```

**$.mall.adult[31][1].fm**

```text
你好，{对方称呼}，店名我来几次都记不住。
```

**$.mall.adult[31][1].ff**

```text
你好，店名我来几次都记不住。
```

**$.mall.adult[31][2].mm**

```text
>{主角称呼}，我就记旁边那家卖什么。
```

**$.mall.adult[31][2].mf**

```text
>我就记旁边那家卖什么。
```

**$.mall.adult[31][2].fm**

```text
>我就记旁边那家卖什么。
```

**$.mall.adult[31][2].ff**

```text
>{主角称呼}，我就记旁边那家卖什么。
```

**$.mall.adult[31][3]**

```text
对，这个好认。
```

**$.mall.adult[31][4]**

```text
>下次从那儿找就行。
```

**$.mall.adult[32][0]**

```text
袋子别换错
```

**$.mall.adult[32][1].mm**

```text
{对方称呼}，刚差点拿错别人的袋子。
```

**$.mall.adult[32][1].mf**

```text
你好，刚差点拿错别人的袋子。
```

**$.mall.adult[32][1].fm**

```text
你好，{对方称呼}，刚差点拿错别人的袋子。
```

**$.mall.adult[32][1].ff**

```text
你好，刚差点拿错别人的袋子。
```

**$.mall.adult[32][2].mm**

```text
>{主角称呼}，没拿走吧？
```

**$.mall.adult[32][2].mf**

```text
>没拿走吧？
```

**$.mall.adult[32][2].fm**

```text
>没拿走吧？
```

**$.mall.adult[32][2].ff**

```text
>{主角称呼}，没拿走吧？
```

**$.mall.adult[32][3]**

```text
没有，提起来才发现不对。
```

**$.mall.adult[32][4]**

```text
>还好，赶紧放回去。
```

**$.mall.adult[33][0]**

```text
不追每个折扣
```

**$.mall.adult[33][1].mm**

```text
{对方称呼}，每个牌子都写着现在便宜。
```

**$.mall.adult[33][1].mf**

```text
你好，每个牌子都写着现在便宜。
```

**$.mall.adult[33][1].fm**

```text
你好，{对方称呼}，每个牌子都写着现在便宜。
```

**$.mall.adult[33][1].ff**

```text
你好，每个牌子都写着现在便宜。
```

**$.mall.adult[33][2].mm**

```text
>{主角称呼}，你原本要买吗？
```

**$.mall.adult[33][2].mf**

```text
>你原本要买吗？
```

**$.mall.adult[33][2].fm**

```text
>你原本要买吗？
```

**$.mall.adult[33][2].ff**

```text
>{主角称呼}，你原本要买吗？
```

**$.mall.adult[33][3]**

```text
不太需要，就是看着降价。
```

**$.mall.adult[33][4]**

```text
>那先别买，回去再想。
```

**$.mall.adult[34][0]**

```text
坐下再决定
```

**$.mall.adult[34][1].mm**

```text
{对方称呼}，越逛越不知道要什么。
```

**$.mall.adult[34][1].mf**

```text
你好，越逛越不知道要什么。
```

**$.mall.adult[34][1].fm**

```text
你好，{对方称呼}，越逛越不知道要什么。
```

**$.mall.adult[34][1].ff**

```text
你好，越逛越不知道要什么。
```

**$.mall.adult[34][2].mm**

```text
>{主角称呼}，是不是累了？
```

**$.mall.adult[34][2].mf**

```text
>是不是累了？
```

**$.mall.adult[34][2].fm**

```text
>是不是累了？
```

**$.mall.adult[34][2].ff**

```text
>{主角称呼}，是不是累了？
```

**$.mall.adult[34][3]**

```text
有点，也饿。
```

**$.mall.adult[34][4]**

```text
>先找个地方坐着吃点。
```

**$.mall.adult[35][0]**

```text
玻璃里的路人
```

**$.mall.adult[35][1].mm**

```text
{对方称呼}，玻璃里人好多，看着眼花。
```

**$.mall.adult[35][1].mf**

```text
你好，玻璃里人好多，看着眼花。
```

**$.mall.adult[35][1].fm**

```text
你好，{对方称呼}，玻璃里人好多，看着眼花。
```

**$.mall.adult[35][1].ff**

```text
你好，玻璃里人好多，看着眼花。
```

**$.mall.adult[35][2].mm**

```text
>{主角称呼}，反光把另一边也照进来了。
```

**$.mall.adult[35][2].mf**

```text
>反光把另一边也照进来了。
```

**$.mall.adult[35][2].fm**

```text
>反光把另一边也照进来了。
```

**$.mall.adult[35][2].ff**

```text
>{主角称呼}，反光把另一边也照进来了。
```

**$.mall.adult[35][3]**

```text
怪不得像多了一排。
```

**$.mall.adult[35][4]**

```text
>嗯，盯久了有点晕。
```

**$.mall.adult[36][0]**

```text
熟悉的副歌
```

**$.mall.adult[36][1].mm**

```text
{对方称呼}，这首副歌我怎么都会了。
```

**$.mall.adult[36][1].mf**

```text
你好，这首副歌我怎么都会了。
```

**$.mall.adult[36][1].fm**

```text
你好，{对方称呼}，这首副歌我怎么都会了。
```

**$.mall.adult[36][1].ff**

```text
你好，这首副歌我怎么都会了。
```

**$.mall.adult[36][2].mm**

```text
>{主角称呼}，听好几遍了吧。
```

**$.mall.adult[36][2].mf**

```text
>听好几遍了吧。
```

**$.mall.adult[36][2].fm**

```text
>听好几遍了吧。
```

**$.mall.adult[36][2].ff**

```text
>{主角称呼}，听好几遍了吧。
```

**$.mall.adult[36][3]**

```text
嗯，逛一圈就来一次。
```

**$.mall.adult[36][4]**

```text
>我刚也差点跟着唱。
```

**$.mall.adult[37][0]**

```text
钱包没发言
```

**$.mall.adult[37][1].mm**

```text
{对方称呼}，今天还没怎么花钱。
```

**$.mall.adult[37][1].mf**

```text
你好，今天还没怎么花钱。
```

**$.mall.adult[37][1].fm**

```text
你好，{对方称呼}，今天还没怎么花钱。
```

**$.mall.adult[37][1].ff**

```text
你好，今天还没怎么花钱。
```

**$.mall.adult[37][2].mm**

```text
>{主角称呼}，没看中想买的？
```

**$.mall.adult[37][2].mf**

```text
>没看中想买的？
```

**$.mall.adult[37][2].fm**

```text
>没看中想买的？
```

**$.mall.adult[37][2].ff**

```text
>{主角称呼}，没看中想买的？
```

**$.mall.adult[37][3]**

```text
嗯，先看看。
```

**$.mall.adult[37][4]**

```text
>别为了买而买就行。
```

**$.mall.adult[38][0]**

```text
饭香的拐弯
```

**$.mall.adult[38][1].mm**

```text
{对方称呼}，闻到香味就拐回来了。
```

**$.mall.adult[38][1].mf**

```text
你好，闻到香味就拐回来了。
```

**$.mall.adult[38][1].fm**

```text
你好，{对方称呼}，闻到香味就拐回来了。
```

**$.mall.adult[38][1].ff**

```text
你好，闻到香味就拐回来了。
```

**$.mall.adult[38][2].mm**

```text
>{主角称呼}，找到卖什么了？
```

**$.mall.adult[38][2].mf**

```text
>找到卖什么了？
```

**$.mall.adult[38][2].fm**

```text
>找到卖什么了？
```

**$.mall.adult[38][2].ff**

```text
>{主角称呼}，找到卖什么了？
```

**$.mall.adult[38][3]**

```text
还没有，看着像在前面。
```

**$.mall.adult[38][4]**

```text
>再看看牌子，别一圈圈绕。
```

**$.mall.adult[39][0]**

```text
鞋柜的警告
```

**$.mall.adult[39][1].mm**

```text
{对方称呼}，看见鞋就又想试。
```

**$.mall.adult[39][1].mf**

```text
你好，看见鞋就又想试。
```

**$.mall.adult[39][1].fm**

```text
你好，{对方称呼}，看见鞋就又想试。
```

**$.mall.adult[39][1].ff**

```text
你好，看见鞋就又想试。
```

**$.mall.adult[39][2].mm**

```text
>{主角称呼}，家里放得下吗？
```

**$.mall.adult[39][2].mf**

```text
>家里放得下吗？
```

**$.mall.adult[39][2].fm**

```text
>家里放得下吗？
```

**$.mall.adult[39][2].ff**

```text
>{主角称呼}，家里放得下吗？
```

**$.mall.adult[39][3]**

```text
快放不下了。
```

**$.mall.adult[39][4]**

```text
>那先把家里那几双穿起来吧。
```

**$.mall.adult[40][0]**

```text
空手的自由
```

**$.mall.adult[40][1].mm**

```text
{对方称呼}，空手逛街真轻松。
```

**$.mall.adult[40][1].mf**

```text
你好，空手逛街真轻松。
```

**$.mall.adult[40][1].fm**

```text
你好，{对方称呼}，空手逛街真轻松。
```

**$.mall.adult[40][1].ff**

```text
你好，空手逛街真轻松。
```

**$.mall.adult[40][2].mm**

```text
>{主角称呼}，回去也不勒手。
```

**$.mall.adult[40][2].mf**

```text
>回去也不勒手。
```

**$.mall.adult[40][2].fm**

```text
>回去也不勒手。
```

**$.mall.adult[40][2].ff**

```text
>{主角称呼}，回去也不勒手。
```

**$.mall.adult[40][3]**

```text
嗯，今天尽量不买了。
```

**$.mall.adult[40][4]**

```text
>先记着，真要用再来。
```

**$.mall.adult[41][0]**

```text
决定得慢一点
```

**$.mall.adult[41][1].mm**

```text
{对方称呼}，怕犹豫久了就卖完。
```

**$.mall.adult[41][1].mf**

```text
你好，怕犹豫久了就卖完。
```

**$.mall.adult[41][1].fm**

```text
你好，{对方称呼}，怕犹豫久了就卖完。
```

**$.mall.adult[41][1].ff**

```text
你好，怕犹豫久了就卖完。
```

**$.mall.adult[41][2].mm**

```text
>{主角称呼}，店里没别的码吗？
```

**$.mall.adult[41][2].mf**

```text
>店里没别的码吗？
```

**$.mall.adult[41][2].fm**

```text
>店里没别的码吗？
```

**$.mall.adult[41][2].ff**

```text
>{主角称呼}，店里没别的码吗？
```

**$.mall.adult[41][3]**

```text
有，就是活动快结束了。
```

**$.mall.adult[41][4]**

```text
>你先想清楚合不合适吧。
```

**$.mall.adult[42][0]**

```text
逛街的同伴
```

**$.mall.adult[42][1].mm**

```text
{对方称呼}，有人聊两句倒没那么累。
```

**$.mall.adult[42][1].mf**

```text
你好，有人聊两句倒没那么累。
```

**$.mall.adult[42][1].fm**

```text
你好，{对方称呼}，有人聊两句倒没那么累。
```

**$.mall.adult[42][1].ff**

```text
你好，有人聊两句倒没那么累。
```

**$.mall.adult[42][2].mm**

```text
>{主角称呼}，光看东西才容易走神。
```

**$.mall.adult[42][2].mf**

```text
>光看东西才容易走神。
```

**$.mall.adult[42][2].fm**

```text
>光看东西才容易走神。
```

**$.mall.adult[42][2].ff**

```text
>{主角称呼}，光看东西才容易走神。
```

**$.mall.adult[42][3]**

```text
嗯，刚那店都走过去了。
```

**$.mall.adult[42][4]**

```text
>那回头看看，别错过。
```

**$.mall.adult[43][0]**

```text
自己的尺寸
```

**$.mall.adult[43][1].mm**

```text
{对方称呼}，这件标的码怎么和平时不一样。
```

**$.mall.adult[43][1].mf**

```text
你好，这件标的码怎么和平时不一样。
```

**$.mall.adult[43][1].fm**

```text
你好，{对方称呼}，这件标的码怎么和平时不一样。
```

**$.mall.adult[43][1].ff**

```text
你好，这件标的码怎么和平时不一样。
```

**$.mall.adult[43][2].mm**

```text
>{主角称呼}，不同牌子有差别吧。
```

**$.mall.adult[43][2].mf**

```text
>不同牌子有差别吧。
```

**$.mall.adult[43][2].fm**

```text
>不同牌子有差别吧。
```

**$.mall.adult[43][2].ff**

```text
>{主角称呼}，不同牌子有差别吧。
```

**$.mall.adult[43][3]**

```text
我是不是得试一下。
```

**$.mall.adult[43][4]**

```text
>是，别光看标。
```

**$.mall.adult[44][0]**

```text
手机上的清单
```

**$.mall.adult[44][1].mm**

```text
{对方称呼}，清单写好了，找不到在哪个软件。
```

**$.mall.adult[44][1].mf**

```text
你好，清单写好了，找不到在哪个软件。
```

**$.mall.adult[44][1].fm**

```text
你好，{对方称呼}，清单写好了，找不到在哪个软件。
```

**$.mall.adult[44][1].ff**

```text
你好，清单写好了，找不到在哪个软件。
```

**$.mall.adult[44][2].mm**

```text
>{主角称呼}，便签里看看？
```

**$.mall.adult[44][2].mf**

```text
>便签里看看？
```

**$.mall.adult[44][2].fm**

```text
>便签里看看？
```

**$.mall.adult[44][2].ff**

```text
>{主角称呼}，便签里看看？
```

**$.mall.adult[44][3]**

```text
找到了，夹在别的下面。
```

**$.mall.adult[44][4]**

```text
>先置顶，省得又找。
```

**$.mall.adult[45][0]**

```text
逛完的纪念
```

**$.mall.adult[45][1].mm**

```text
{对方称呼}，这次逛完没带什么回去。
```

**$.mall.adult[45][1].mf**

```text
你好，这次逛完没带什么回去。
```

**$.mall.adult[45][1].fm**

```text
你好，{对方称呼}，这次逛完没带什么回去。
```

**$.mall.adult[45][1].ff**

```text
你好，这次逛完没带什么回去。
```

**$.mall.adult[45][2].mm**

```text
>{主角称呼}，要买的都没有？
```

**$.mall.adult[45][2].mf**

```text
>要买的都没有？
```

**$.mall.adult[45][2].fm**

```text
>要买的都没有？
```

**$.mall.adult[45][2].ff**

```text
>{主角称呼}，要买的都没有？
```

**$.mall.adult[45][3]**

```text
倒也不急着买。
```

**$.mall.adult[45][4]**

```text
>那就下次再看。
```

**$.mall.adult[46][0]**

```text
热闹的边上
```

**$.mall.adult[46][1].mm**

```text
{对方称呼}，热闹地方旁边站着舒服点。
```

**$.mall.adult[46][1].mf**

```text
你好，热闹地方旁边站着舒服点。
```

**$.mall.adult[46][1].fm**

```text
你好，{对方称呼}，热闹地方旁边站着舒服点。
```

**$.mall.adult[46][1].ff**

```text
你好，热闹地方旁边站着舒服点。
```

**$.mall.adult[46][2].mm**

```text
>{主角称呼}，人没那么挤。
```

**$.mall.adult[46][2].mf**

```text
>人没那么挤。
```

**$.mall.adult[46][2].fm**

```text
>人没那么挤。
```

**$.mall.adult[46][2].ff**

```text
>{主角称呼}，人没那么挤。
```

**$.mall.adult[46][3]**

```text
对，还看得见里面。
```

**$.mall.adult[46][4]**

```text
>想进去再进去就好。
```

**$.mall.adult[47][0]**

```text
收尾的办法
```

**$.mall.adult[47][1].mm**

```text
{对方称呼}，逛累了真该回去了。
```

**$.mall.adult[47][1].mf**

```text
你好，逛累了真该回去了。
```

**$.mall.adult[47][1].fm**

```text
你好，{对方称呼}，逛累了真该回去了。
```

**$.mall.adult[47][1].ff**

```text
你好，逛累了真该回去了。
```

**$.mall.adult[47][2].mm**

```text
>{主角称呼}，东西拿齐了没？
```

**$.mall.adult[47][2].mf**

```text
>东西拿齐了没？
```

**$.mall.adult[47][2].fm**

```text
>东西拿齐了没？
```

**$.mall.adult[47][2].ff**

```text
>{主角称呼}，东西拿齐了没？
```

**$.mall.adult[47][3]**

```text
我再看一眼包。
```

**$.mall.adult[47][4]**

```text
>看好就走，别又绕进店里。
```

**$.mall.kid[0][0]**

```text
地砖路线
```

**$.mall.kid[0][1]**

```text
你为什么只踩同一种颜色的地砖？
```

**$.mall.kid[0][2]**

```text
>我在走一条秘密路线。
```

**$.mall.kid[0][3]**

```text
路线的终点在哪里？
```

**$.mall.kid[0][4]**

```text
>还没决定，可能是吃饭的地方。
```

**$.mall.kid[1][0]**

```text
橱窗模特
```

**$.mall.kid[1][1]**

```text
你刚才在跟谁挥手？
```

**$.mall.kid[1][2]**

```text
>那个站得很直的人，可它一直不理我。
```

**$.mall.kid[1][3]**

```text
它是展示衣服的模特。
```

**$.mall.kid[1][4]**

```text
>那它工作的时候很认真。
```

**$.mall.kid[2][0]**

```text
电梯肚子
```

**$.mall.kid[2][1]**

```text
你在看电梯什么呀？
```

**$.mall.kid[2][2]**

```text
>人进去又出来，我觉得它像商场的大肚子。
```

**$.mall.kid[2][3]**

```text
这个肚子还会上下移动。
```

**$.mall.kid[2][4]**

```text
>难怪它总有点忙。
```

**$.mall.kid[3][0]**

```text
纸袋房子
```

**$.mall.kid[3][1]**

```text
这个纸袋为什么不舍得扔？
```

**$.mall.kid[3][2]**

```text
>它看起来能当玩具的小房子。
```

**$.mall.kid[3][3]**

```text
记得留个门给它们。
```

**$.mall.kid[3][4]**

```text
>已经留了，住进去要排队。
```

**$.mall.kid[4][0]**

```text
海报英雄
```

**$.mall.kid[4][1]**

```text
海报上这个人你认识吗？
```

**$.mall.kid[4][2]**

```text
>不认识，但他披风看着很有风。
```

**$.mall.kid[4][3]**

```text
你也想要一件？
```

**$.mall.kid[4][4]**

```text
>想，不过先问问会不会卡在门里。
```

**$.mall.kid[5][0]**

```text
鞋带提醒
```

**$.mall.kid[5][1]**

```text
鞋带有点松了，要停一下吗？
```

**$.mall.kid[5][2]**

```text
>要，它刚才一直拖着我走。
```

**$.mall.kid[5][3]**

```text
系好了再出发。
```

**$.mall.kid[5][4]**

```text
>谢谢，我不能让鞋先下班。
```

**$.mall.kid[6][0]**

```text
纸袋的翅膀
```

**$.mall.kid[6][1].mm**

```text
{对方称呼}，为什么一直提着空纸袋？
```

**$.mall.kid[6][1].mf**

```text
你好，为什么一直提着空纸袋？
```

**$.mall.kid[6][1].fm**

```text
你好，{对方称呼}，为什么一直提着空纸袋？
```

**$.mall.kid[6][1].ff**

```text
打个招呼，为什么一直提着空纸袋？
```

**$.mall.kid[6][2].mm**

```text
>{主角称呼}，嗯，它展开以后像一双小翅膀。
```

**$.mall.kid[6][2].mf**

```text
>{主角称呼}，说起来，它展开以后像一双小翅膀。
```

**$.mall.kid[6][2].fm**

```text
>{主角称呼}，其实，它展开以后像一双小翅膀。
```

**$.mall.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，它展开以后像一双小翅膀。
```

**$.mall.kid[6][3]**

```text
不过可不能真靠它飞。
```

**$.mall.kid[6][4]**

```text
>知道，我让想象先飞一会儿。
```

**$.mall.kid[7][0]**

```text
地砖的秘密
```

**$.mall.kid[7][1].mm**

```text
{对方称呼}，你是不是在躲开那些格子？
```

**$.mall.kid[7][1].mf**

```text
你好，你是不是在躲开那些格子？
```

**$.mall.kid[7][1].fm**

```text
你好，{对方称呼}，你是不是在躲开那些格子？
```

**$.mall.kid[7][1].ff**

```text
打个招呼，你是不是在躲开那些格子？
```

**$.mall.kid[7][2].mm**

```text
>{主角称呼}，说起来，我觉得有些格子是想象里的水坑。
```

**$.mall.kid[7][2].mf**

```text
>{主角称呼}，其实，我觉得有些格子是想象里的水坑。
```

**$.mall.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，我觉得有些格子是想象里的水坑。
```

**$.mall.kid[7][2].ff**

```text
>{主角称呼}，嗯，我觉得有些格子是想象里的水坑。
```

**$.mall.kid[7][3]**

```text
那慢慢走，别撞到人。
```

**$.mall.kid[7][4]**

```text
>好，游戏也得给别人留路。
```

**$.mall.kid[8][0]**

```text
海报的眼睛
```

**$.mall.kid[8][1].mm**

```text
{对方称呼}，你怎么又回来看海报？
```

**$.mall.kid[8][1].mf**

```text
你好，你怎么又回来看海报？
```

**$.mall.kid[8][1].fm**

```text
你好，{对方称呼}，你怎么又回来看海报？
```

**$.mall.kid[8][1].ff**

```text
打个招呼，你怎么又回来看海报？
```

**$.mall.kid[8][2].mm**

```text
>{主角称呼}，其实，它上面的人，好像一直看着我。
```

**$.mall.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，它上面的人，好像一直看着我。
```

**$.mall.kid[8][2].fm**

```text
>{主角称呼}，嗯，它上面的人，好像一直看着我。
```

**$.mall.kid[8][2].ff**

```text
>{主角称呼}，说起来，它上面的人，好像一直看着我。
```

**$.mall.kid[8][3]**

```text
那是画面的效果。
```

**$.mall.kid[8][4]**

```text
>我知道，我只是想礼貌地看回去。
```

**$.mall.kid[9][0]**

```text
电梯的假期
```

**$.mall.kid[9][1].mm**

```text
{对方称呼}，你在等谁出来？
```

**$.mall.kid[9][1].mf**

```text
你好，你在等谁出来？
```

**$.mall.kid[9][1].fm**

```text
你好，{对方称呼}，你在等谁出来？
```

**$.mall.kid[9][1].ff**

```text
打个招呼，你在等谁出来？
```

**$.mall.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，没有，我在想电梯会不会累。
```

**$.mall.kid[9][2].mf**

```text
>{主角称呼}，嗯，没有，我在想电梯会不会累。
```

**$.mall.kid[9][2].fm**

```text
>{主角称呼}，说起来，没有，我在想电梯会不会累。
```

**$.mall.kid[9][2].ff**

```text
>{主角称呼}，其实，没有，我在想电梯会不会累。
```

**$.mall.kid[9][3]**

```text
它也有人定期照顾。
```

**$.mall.kid[9][4]**

```text
>那就好，它每天搬那么多人。
```

**$.mall.kid[10][0]**

```text
鞋子的声音
```

**$.mall.kid[10][1].mm**

```text
{对方称呼}，你在听自己的脚步吗？
```

**$.mall.kid[10][1].mf**

```text
你好，你在听自己的脚步吗？
```

**$.mall.kid[10][1].fm**

```text
你好，{对方称呼}，你在听自己的脚步吗？
```

**$.mall.kid[10][1].ff**

```text
打个招呼，你在听自己的脚步吗？
```

**$.mall.kid[10][2].mm**

```text
>{主角称呼}，嗯，嗯，我想每一脚都落得轻一点。
```

**$.mall.kid[10][2].mf**

```text
>{主角称呼}，说起来，嗯，我想每一脚都落得轻一点。
```

**$.mall.kid[10][2].fm**

```text
>{主角称呼}，其实，嗯，我想每一脚都落得轻一点。
```

**$.mall.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，嗯，我想每一脚都落得轻一点。
```

**$.mall.kid[10][3]**

```text
挺好，也注意看前面。
```

**$.mall.kid[10][4]**

```text
>好，不能只让耳朵负责走路。
```

**$.mall.kid[11][0]**

```text
不一定要礼物
```

**$.mall.kid[11][1].mm**

```text
{对方称呼}，今天一定想买什么吗？
```

**$.mall.kid[11][1].mf**

```text
你好，今天一定想买什么吗？
```

**$.mall.kid[11][1].fm**

```text
你好，{对方称呼}，今天一定想买什么吗？
```

**$.mall.kid[11][1].ff**

```text
打个招呼，今天一定想买什么吗？
```

**$.mall.kid[11][2].mm**

```text
>{主角称呼}，说起来，不一定，出来看看也开心。
```

**$.mall.kid[11][2].mf**

```text
>{主角称呼}，其实，不一定，出来看看也开心。
```

**$.mall.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，不一定，出来看看也开心。
```

**$.mall.kid[11][2].ff**

```text
>{主角称呼}，嗯，不一定，出来看看也开心。
```

**$.mall.kid[11][3]**

```text
那这趟已经有收获了。
```

**$.mall.kid[11][4]**

```text
>还认识了一个会接我话的人。
```

**$.beach.adult[0][0]**

```text
码头的招呼
```

**$.beach.adult[0][1]**

```text
这边风比想象中大。
```

**$.beach.adult[0][2]**

```text
>嗯，刚走过来没觉得。
```

**$.beach.adult[0][3]**

```text
头发都吹眼睛里了。
```

**$.beach.adult[0][4]**

```text
>背着风理一下吧。
```

**$.beach.adult[1][0]**

```text
海鸥的评审
```

**$.beach.adult[1][1]**

```text
刚才海鸥是不是叫了一声？
```

**$.beach.adult[1][2]**

```text
>嗯，声音挺响的。
```

**$.beach.adult[1][3]**

```text
就在头上？
```

**$.beach.adult[1][4]**

```text
>飞过去了，现在在那边。
```

**$.beach.adult[2][0]**

```text
木板的声音
```

**$.beach.adult[2][1]**

```text
木板踩着会响。
```

**$.beach.adult[2][2]**

```text
>这几块踩着都这样。
```

**$.beach.adult[2][3]**

```text
有一块声音特别大。
```

**$.beach.adult[2][4]**

```text
>看着脚下，别踩缝里。
```

**$.beach.adult[3][0]**

```text
远处的船
```

**$.beach.adult[3][1]**

```text
那船好像没动。
```

**$.beach.adult[3][2]**

```text
>远了看着慢吧。
```

**$.beach.adult[3][3]**

```text
盯一会儿才看出来。
```

**$.beach.adult[3][4]**

```text
>嗯，跟刚才那根杆比就知道了。
```

**$.beach.adult[4][0]**

```text
浪的重复
```

**$.beach.adult[4][1]**

```text
看海浪来回倒不觉得烦。
```

**$.beach.adult[4][2]**

```text
>我有时候能看很久。
```

**$.beach.adult[4][3]**

```text
刚才那阵还大一点。
```

**$.beach.adult[4][4]**

```text
>你看，又过来了。
```

**$.beach.adult[5][0]**

```text
码头的空位
```

**$.beach.adult[5][1]**

```text
我站这儿挡着你了吗？
```

**$.beach.adult[5][2]**

```text
>没有，你站吧。
```

**$.beach.adult[5][3]**

```text
那我看一会儿。
```

**$.beach.adult[5][4]**

```text
>嗯，小心别靠太外面。
```

**$.beach.adult[6][0]**

```text
风里的消息
```

**$.beach.adult[6][1]**

```text
手机响了，我还以为鸟叫。
```

**$.beach.adult[6][2]**

```text
>铃声挺像？
```

**$.beach.adult[6][3]**

```text
有点，刚没反应过来。
```

**$.beach.adult[6][4]**

```text
>你先看看，万一有人找。
```

**$.beach.adult[7][0]**

```text
海面的光
```

**$.beach.adult[7][1]**

```text
水上那些亮点一直在动。
```

**$.beach.adult[7][2]**

```text
>浪一过来就换位置。
```

**$.beach.adult[7][3]**

```text
想拍还拍不清。
```

**$.beach.adult[7][4]**

```text
>镜头远了，就剩一片亮了。
```

**$.beach.adult[8][0]**

```text
望远的眼睛
```

**$.beach.adult[8][1]**

```text
看远处眼睛舒服点。
```

**$.beach.adult[8][2]**

```text
>平时看屏幕太多了。
```

**$.beach.adult[8][3]**

```text
对，老盯那么一点。
```

**$.beach.adult[8][4]**

```text
>那多看会儿，别又低头玩手机。
```

**$.beach.adult[9][0]**

```text
咸味的风
```

**$.beach.adult[9][1]**

```text
空气有点咸味。
```

**$.beach.adult[9][2]**

```text
>走近就闻得出来。
```

**$.beach.adult[9][3]**

```text
刚在外面路上没觉得。
```

**$.beach.adult[9][4]**

```text
>嗯，还夹着点海腥味。
```

**$.beach.adult[10][0]**

```text
码头栏杆
```

**$.beach.adult[10][1]**

```text
这栏杆挺稳的。
```

**$.beach.adult[10][2]**

```text
>扶一下可以，别翻过去。
```

**$.beach.adult[10][3]**

```text
我没想翻，就靠一下。
```

**$.beach.adult[10][4]**

```text
>嗯，脚下看着点。
```

**$.beach.adult[11][0]**

```text
潮水的耐心
```

**$.beach.adult[11][1]**

```text
水退回去了。
```

**$.beach.adult[11][2]**

```text
>下一阵又过来了。
```

**$.beach.adult[11][3]**

```text
边上那块石头一会儿露一会儿没。
```

**$.beach.adult[11][4]**

```text
>别下去站，水来得挺快。
```

**$.beach.adult[12][0]**

```text
想不到的话
```

**$.beach.adult[12][1]**

```text
到这儿反而不知道说什么了。
```

**$.beach.adult[12][2]**

```text
>那就看看呗。
```

**$.beach.adult[12][3]**

```text
嗯，先看会儿船。
```

**$.beach.adult[12][4]**

```text
>那艘刚开始转向了。
```

**$.beach.adult[13][0]**

```text
看错的海鸟
```

**$.beach.adult[13][1]**

```text
远处那个白点是船？
```

**$.beach.adult[13][2]**

```text
>好像是鸟，刚动了。
```

**$.beach.adult[13][3]**

```text
哦，我看它换方向了。
```

**$.beach.adult[13][4]**

```text
>远了就看不清。
```

**$.beach.adult[14][0]**

```text
木板上的影子
```

**$.beach.adult[14][1]**

```text
影子被木板缝切开了。
```

**$.beach.adult[14][2]**

```text
>你挪一步就变了。
```

**$.beach.adult[14][3]**

```text
还挺好玩。
```

**$.beach.adult[14][4]**

```text
>拍照也行，别一直低头走。
```

**$.beach.adult[15][0]**

```text
海边的愿望
```

**$.beach.adult[15][1]**

```text
你来海边会许愿吗？
```

**$.beach.adult[15][2]**

```text
>偶尔吧。
```

**$.beach.adult[15][3]**

```text
许什么？
```

**$.beach.adult[15][4]**

```text
>这个先不说，等成了再告诉你。
```

**$.beach.adult[16][0]**

```text
不捡的贝壳
```

**$.beach.adult[16][1]**

```text
今天没找到贝壳。
```

**$.beach.adult[16][2]**

```text
>这边本来就不多。
```

**$.beach.adult[16][3]**

```text
嗯，吹吹风也行。
```

**$.beach.adult[16][4]**

```text
>走的时候记着别落东西。
```

**$.beach.adult[17][0]**

```text
海浪的音量
```

**$.beach.adult[17][1]**

```text
浪声有时候盖过说话声。
```

**$.beach.adult[17][2]**

```text
>你刚说什么？
```

**$.beach.adult[17][3]**

```text
我说这里声音挺大的。
```

**$.beach.adult[17][4]**

```text
>哦，这回听见了。
```

**$.beach.adult[18][0]**

```text
船的目的地
```

**$.beach.adult[18][1]**

```text
那船要去哪儿啊？
```

**$.beach.adult[18][2]**

```text
>不知道，看方向要出去了。
```

**$.beach.adult[18][3]**

```text
挺想知道船上是干什么的。
```

**$.beach.adult[18][4]**

```text
>有机会看看船身写的字。
```

**$.beach.adult[19][0]**

```text
海风的提醒
```

**$.beach.adult[19][1]**

```text
站久了手有点凉。
```

**$.beach.adult[19][2]**

```text
>来这边，风小点。
```

**$.beach.adult[19][3]**

```text
嗯，再站刚才那里得冷了。
```

**$.beach.adult[19][4]**

```text
>冷了就别硬站。
```

**$.beach.adult[20][0]**

```text
码头的步数
```

**$.beach.adult[20][1]**

```text
码头没多长，我走了好久。
```

**$.beach.adult[20][2]**

```text
>走两步就停下来看看吧。
```

**$.beach.adult[20][3]**

```text
对，老回头看船。
```

**$.beach.adult[20][4]**

```text
>我也差不多。
```

**$.beach.adult[21][0]**

```text
风景的照片
```

**$.beach.adult[21][1]**

```text
拍出来的海小了一圈。
```

**$.beach.adult[21][2]**

```text
>镜头没那么宽。
```

**$.beach.adult[21][3]**

```text
看着不如现场。
```

**$.beach.adult[21][4]**

```text
>先看看吧，别一直盯手机。
```

**$.beach.adult[22][0]**

```text
和海打招呼
```

**$.beach.adult[22][1]**

```text
我刚差点对着海说你好。
```

**$.beach.adult[22][2]**

```text
>那说呗，没人管。
```

**$.beach.adult[22][3]**

```text
说出来又觉得怪。
```

**$.beach.adult[22][4]**

```text
>哈哈，那先不说。
```

**$.beach.adult[23][0]**

```text
回去的方向
```

**$.beach.adult[23][1]**

```text
看久了都有点不想转身。
```

**$.beach.adult[23][2]**

```text
>太阳快晃眼了吧。
```

**$.beach.adult[23][3]**

```text
是，我换个方向。
```

**$.beach.adult[23][4]**

```text
>回来这边还能看见岸上。
```

**$.beach.adult[24][0]**

```text
把你好送到海边
```

**$.beach.adult[24][1].mm**

```text
{对方称呼}，你好，你也在看那船？
```

**$.beach.adult[24][1].mf**

```text
你好，你好，你也在看那船？
```

**$.beach.adult[24][1].fm**

```text
你好，{对方称呼}，你好，你也在看那船？
```

**$.beach.adult[24][1].ff**

```text
你好，你好，你也在看那船？
```

**$.beach.adult[24][2].mm**

```text
>{主角称呼}，嗯，刚才看它慢慢拐。
```

**$.beach.adult[24][2].mf**

```text
>嗯，刚才看它慢慢拐。
```

**$.beach.adult[24][2].fm**

```text
>嗯，刚才看它慢慢拐。
```

**$.beach.adult[24][2].ff**

```text
>{主角称呼}，嗯，刚才看它慢慢拐。
```

**$.beach.adult[24][3]**

```text
我还以为停住了。
```

**$.beach.adult[24][4]**

```text
>远了看就很慢。
```

**$.beach.adult[25][0]**

```text
风把话吹近
```

**$.beach.adult[25][1].mm**

```text
{对方称呼}，刚才那句话没听清。
```

**$.beach.adult[25][1].mf**

```text
你好，刚才那句话没听清。
```

**$.beach.adult[25][1].fm**

```text
你好，{对方称呼}，刚才那句话没听清。
```

**$.beach.adult[25][1].ff**

```text
你好，刚才那句话没听清。
```

**$.beach.adult[25][2].mm**

```text
>{主角称呼}，风大，我再说一遍。
```

**$.beach.adult[25][2].mf**

```text
>风大，我再说一遍。
```

**$.beach.adult[25][2].fm**

```text
>风大，我再说一遍。
```

**$.beach.adult[25][2].ff**

```text
>{主角称呼}，风大，我再说一遍。
```

**$.beach.adult[25][3]**

```text
我靠近一点。
```

**$.beach.adult[25][4]**

```text
>好，这回听得到吗？
```

**$.beach.adult[26][0]**

```text
码头的慢镜头
```

**$.beach.adult[26][1].mm**

```text
{对方称呼}，远处那船像慢放一样。
```

**$.beach.adult[26][1].mf**

```text
你好，远处那船像慢放一样。
```

**$.beach.adult[26][1].fm**

```text
你好，{对方称呼}，远处那船像慢放一样。
```

**$.beach.adult[26][1].ff**

```text
你好，远处那船像慢放一样。
```

**$.beach.adult[26][2].mm**

```text
>{主角称呼}，太远了，不好看出在动。
```

**$.beach.adult[26][2].mf**

```text
>太远了，不好看出在动。
```

**$.beach.adult[26][2].fm**

```text
>太远了，不好看出在动。
```

**$.beach.adult[26][2].ff**

```text
>{主角称呼}，太远了，不好看出在动。
```

**$.beach.adult[26][3]**

```text
盯着那根杆就能看出来。
```

**$.beach.adult[26][4]**

```text
>嗯，已经偏过去一点了。
```

**$.beach.adult[27][0]**

```text
木板的条纹
```

**$.beach.adult[27][1].mm**

```text
{对方称呼}，木板条纹看久了眼花。
```

**$.beach.adult[27][1].mf**

```text
你好，木板条纹看久了眼花。
```

**$.beach.adult[27][1].fm**

```text
你好，{对方称呼}，木板条纹看久了眼花。
```

**$.beach.adult[27][1].ff**

```text
你好，木板条纹看久了眼花。
```

**$.beach.adult[27][2].mm**

```text
>{主角称呼}，别一直低头看。
```

**$.beach.adult[27][2].mf**

```text
>别一直低头看。
```

**$.beach.adult[27][2].fm**

```text
>别一直低头看。
```

**$.beach.adult[27][2].ff**

```text
>{主角称呼}，别一直低头看。
```

**$.beach.adult[27][3]**

```text
刚在数有多少块。
```

**$.beach.adult[27][4]**

```text
>数不完的，抬头歇一下。
```

**$.beach.adult[28][0]**

```text
海风的便签
```

**$.beach.adult[28][1].mm**

```text
{对方称呼}，想回去记一下今天的风。
```

**$.beach.adult[28][1].mf**

```text
你好，想回去记一下今天的风。
```

**$.beach.adult[28][1].fm**

```text
你好，{对方称呼}，想回去记一下今天的风。
```

**$.beach.adult[28][1].ff**

```text
你好，想回去记一下今天的风。
```

**$.beach.adult[28][2].mm**

```text
>{主角称呼}，怎么记？写几句？
```

**$.beach.adult[28][2].mf**

```text
>怎么记？写几句？
```

**$.beach.adult[28][2].fm**

```text
>怎么记？写几句？
```

**$.beach.adult[28][2].ff**

```text
>{主角称呼}，怎么记？写几句？
```

**$.beach.adult[28][3]**

```text
嗯，怕回去忘了。
```

**$.beach.adult[28][4]**

```text
>那现在随手记一下也行。
```

**$.beach.adult[29][0]**

```text
船还没走远
```

**$.beach.adult[29][1].mm**

```text
{对方称呼}，看半天船还没走多远。
```

**$.beach.adult[29][1].mf**

```text
你好，看半天船还没走多远。
```

**$.beach.adult[29][1].fm**

```text
你好，{对方称呼}，看半天船还没走多远。
```

**$.beach.adult[29][1].ff**

```text
你好，看半天船还没走多远。
```

**$.beach.adult[29][2].mm**

```text
>{主角称呼}，没准在等呢。
```

**$.beach.adult[29][2].mf**

```text
>没准在等呢。
```

**$.beach.adult[29][2].fm**

```text
>没准在等呢。
```

**$.beach.adult[29][2].ff**

```text
>{主角称呼}，没准在等呢。
```

**$.beach.adult[29][3]**

```text
我还以为已经开出去了。
```

**$.beach.adult[29][4]**

```text
>再看会儿吧。
```

**$.beach.adult[30][0]**

```text
不用问答案
```

**$.beach.adult[30][1].mm**

```text
{对方称呼}，在海边想事情好像不那么急。
```

**$.beach.adult[30][1].mf**

```text
你好，在海边想事情好像不那么急。
```

**$.beach.adult[30][1].fm**

```text
你好，{对方称呼}，在海边想事情好像不那么急。
```

**$.beach.adult[30][1].ff**

```text
你好，在海边想事情好像不那么急。
```

**$.beach.adult[30][2].mm**

```text
>{主角称呼}，先别忙着做决定。
```

**$.beach.adult[30][2].mf**

```text
>先别忙着做决定。
```

**$.beach.adult[30][2].fm**

```text
>先别忙着做决定。
```

**$.beach.adult[30][2].ff**

```text
>{主角称呼}，先别忙着做决定。
```

**$.beach.adult[30][3]**

```text
嗯，我再看看。
```

**$.beach.adult[30][4]**

```text
>有空再慢慢想。
```

**$.beach.adult[31][0]**

```text
栏杆边的空间
```

**$.beach.adult[31][1].mm**

```text
{对方称呼}，站这里挡不挡路？
```

**$.beach.adult[31][1].mf**

```text
你好，站这里挡不挡路？
```

**$.beach.adult[31][1].fm**

```text
你好，{对方称呼}，站这里挡不挡路？
```

**$.beach.adult[31][1].ff**

```text
你好，站这里挡不挡路？
```

**$.beach.adult[31][2].mm**

```text
>{主角称呼}，往栏杆边一点就不挡。
```

**$.beach.adult[31][2].mf**

```text
>往栏杆边一点就不挡。
```

**$.beach.adult[31][2].fm**

```text
>往栏杆边一点就不挡。
```

**$.beach.adult[31][2].ff**

```text
>{主角称呼}，往栏杆边一点就不挡。
```

**$.beach.adult[31][3]**

```text
这样呢？
```

**$.beach.adult[31][4]**

```text
>行，别往外探。
```

**$.beach.adult[32][0]**

```text
一朵浪花
```

**$.beach.adult[32][1].mm**

```text
{对方称呼}，刚那朵浪一下就没了。
```

**$.beach.adult[32][1].mf**

```text
你好，刚那朵浪一下就没了。
```

**$.beach.adult[32][1].fm**

```text
你好，{对方称呼}，刚那朵浪一下就没了。
```

**$.beach.adult[32][1].ff**

```text
你好，刚那朵浪一下就没了。
```

**$.beach.adult[32][2].mm**

```text
>{主角称呼}，撞石头上就散了。
```

**$.beach.adult[32][2].mf**

```text
>撞石头上就散了。
```

**$.beach.adult[32][2].fm**

```text
>撞石头上就散了。
```

**$.beach.adult[32][2].ff**

```text
>{主角称呼}，撞石头上就散了。
```

**$.beach.adult[32][3]**

```text
想拍都来不及。
```

**$.beach.adult[32][4]**

```text
>下一阵再试吧。
```

**$.beach.adult[33][0]**

```text
海鸟的路线
```

**$.beach.adult[33][1].mm**

```text
{对方称呼}，海鸟飞得好稳。
```

**$.beach.adult[33][1].mf**

```text
你好，海鸟飞得好稳。
```

**$.beach.adult[33][1].fm**

```text
你好，{对方称呼}，海鸟飞得好稳。
```

**$.beach.adult[33][1].ff**

```text
你好，海鸟飞得好稳。
```

**$.beach.adult[33][2].mm**

```text
>{主角称呼}，风大也没怎么晃。
```

**$.beach.adult[33][2].mf**

```text
>风大也没怎么晃。
```

**$.beach.adult[33][2].fm**

```text
>风大也没怎么晃。
```

**$.beach.adult[33][2].ff**

```text
>{主角称呼}，风大也没怎么晃。
```

**$.beach.adult[33][3]**

```text
它翅膀都没动几下。
```

**$.beach.adult[33][4]**

```text
>可能顺着风飞，省力一点。
```

**$.beach.adult[34][0]**

```text
不想一直拍
```

**$.beach.adult[34][1].mm**

```text
{对方称呼}，拍几张就想收手机了。
```

**$.beach.adult[34][1].mf**

```text
你好，拍几张就想收手机了。
```

**$.beach.adult[34][1].fm**

```text
你好，{对方称呼}，拍几张就想收手机了。
```

**$.beach.adult[34][1].ff**

```text
你好，拍几张就想收手机了。
```

**$.beach.adult[34][2].mm**

```text
>{主角称呼}，拿久了手也冷。
```

**$.beach.adult[34][2].mf**

```text
>拿久了手也冷。
```

**$.beach.adult[34][2].fm**

```text
>拿久了手也冷。
```

**$.beach.adult[34][2].ff**

```text
>{主角称呼}，拿久了手也冷。
```

**$.beach.adult[34][3]**

```text
嗯，眼睛看舒服点。
```

**$.beach.adult[34][4]**

```text
>那先看会儿。
```

**$.beach.adult[35][0]**

```text
手心的温度
```

**$.beach.adult[35][1].mm**

```text
{对方称呼}，手有点冷，手机都拿不稳。
```

**$.beach.adult[35][1].mf**

```text
你好，手有点冷，手机都拿不稳。
```

**$.beach.adult[35][1].fm**

```text
你好，{对方称呼}，手有点冷，手机都拿不稳。
```

**$.beach.adult[35][1].ff**

```text
你好，手有点冷，手机都拿不稳。
```

**$.beach.adult[35][2].mm**

```text
>{主角称呼}，先揣兜里。
```

**$.beach.adult[35][2].mf**

```text
>先揣兜里。
```

**$.beach.adult[35][2].fm**

```text
>先揣兜里。
```

**$.beach.adult[35][2].ff**

```text
>{主角称呼}，先揣兜里。
```

**$.beach.adult[35][3]**

```text
嗯，不拍了。
```

**$.beach.adult[35][4]**

```text
>回去暖一暖。
```

**$.beach.adult[36][0]**

```text
海面的标点
```

**$.beach.adult[36][1].mm**

```text
{对方称呼}，那些亮点看着一闪一闪的。
```

**$.beach.adult[36][1].mf**

```text
你好，那些亮点看着一闪一闪的。
```

**$.beach.adult[36][1].fm**

```text
你好，{对方称呼}，那些亮点看着一闪一闪的。
```

**$.beach.adult[36][1].ff**

```text
你好，那些亮点看着一闪一闪的。
```

**$.beach.adult[36][2].mm**

```text
>{主角称呼}，浪一动就这样。
```

**$.beach.adult[36][2].mf**

```text
>浪一动就这样。
```

**$.beach.adult[36][2].fm**

```text
>浪一动就这样。
```

**$.beach.adult[36][2].ff**

```text
>{主角称呼}，浪一动就这样。
```

**$.beach.adult[36][3]**

```text
凑一起又像一条线。
```

**$.beach.adult[36][4]**

```text
>嗯，有光那边特别明显。
```

**$.beach.adult[37][0]**

```text
站稳再看远
```

**$.beach.adult[37][1].mm**

```text
{对方称呼}，刚才光看远处，差点踩缝里。
```

**$.beach.adult[37][1].mf**

```text
你好，刚才光看远处，差点踩缝里。
```

**$.beach.adult[37][1].fm**

```text
你好，{对方称呼}，刚才光看远处，差点踩缝里。
```

**$.beach.adult[37][1].ff**

```text
你好，刚才光看远处，差点踩缝里。
```

**$.beach.adult[37][2].mm**

```text
>{主角称呼}，先站稳再看。
```

**$.beach.adult[37][2].mf**

```text
>先站稳再看。
```

**$.beach.adult[37][2].fm**

```text
>先站稳再看。
```

**$.beach.adult[37][2].ff**

```text
>{主角称呼}，先站稳再看。
```

**$.beach.adult[37][3]**

```text
好，吓我一下。
```

**$.beach.adult[37][4]**

```text
>木板有缝，小心一点。
```

**$.beach.adult[38][0]**

```text
浪声里的空白
```

**$.beach.adult[38][1].mm**

```text
{对方称呼}，浪声一大就听不见讲话。
```

**$.beach.adult[38][1].mf**

```text
你好，浪声一大就听不见讲话。
```

**$.beach.adult[38][1].fm**

```text
你好，{对方称呼}，浪声一大就听不见讲话。
```

**$.beach.adult[38][1].ff**

```text
你好，浪声一大就听不见讲话。
```

**$.beach.adult[38][2].mm**

```text
>{主角称呼}，你刚那句我就没听到。
```

**$.beach.adult[38][2].mf**

```text
>你刚那句我就没听到。
```

**$.beach.adult[38][2].fm**

```text
>你刚那句我就没听到。
```

**$.beach.adult[38][2].ff**

```text
>{主角称呼}，你刚那句我就没听到。
```

**$.beach.adult[38][3]**

```text
我说再站一会儿。
```

**$.beach.adult[38][4]**

```text
>哦，好，我也不急。
```

**$.beach.adult[39][0]**

```text
回头的风景
```

**$.beach.adult[39][1].mm**

```text
{对方称呼}，一直看海，忘了看看身后。
```

**$.beach.adult[39][1].mf**

```text
你好，一直看海，忘了看看身后。
```

**$.beach.adult[39][1].fm**

```text
你好，{对方称呼}，一直看海，忘了看看身后。
```

**$.beach.adult[39][1].ff**

```text
你好，一直看海，忘了看看身后。
```

**$.beach.adult[39][2].mm**

```text
>{主角称呼}，后面也挺开阔。
```

**$.beach.adult[39][2].mf**

```text
>后面也挺开阔。
```

**$.beach.adult[39][2].fm**

```text
>后面也挺开阔。
```

**$.beach.adult[39][2].ff**

```text
>{主角称呼}，后面也挺开阔。
```

**$.beach.adult[39][3]**

```text
嗯，来时没注意。
```

**$.beach.adult[39][4]**

```text
>回去慢慢看就行。
```

**$.beach.adult[40][0]**

```text
一点点的盐味
```

**$.beach.adult[40][1].mm**

```text
{对方称呼}，风里还真有点盐味。
```

**$.beach.adult[40][1].mf**

```text
你好，风里还真有点盐味。
```

**$.beach.adult[40][1].fm**

```text
你好，{对方称呼}，风里还真有点盐味。
```

**$.beach.adult[40][1].ff**

```text
你好，风里还真有点盐味。
```

**$.beach.adult[40][2].mm**

```text
>{主角称呼}，走近更明显。
```

**$.beach.adult[40][2].mf**

```text
>走近更明显。
```

**$.beach.adult[40][2].fm**

```text
>走近更明显。
```

**$.beach.adult[40][2].ff**

```text
>{主角称呼}，走近更明显。
```

**$.beach.adult[40][3]**

```text
刚开始以为是别的味。
```

**$.beach.adult[40][4]**

```text
>嗯，还得再闻一下才分得清。
```

**$.beach.adult[41][0]**

```text
留个好心情
```

**$.beach.adult[41][1].mm**

```text
{对方称呼}，今天也没想明白什么。
```

**$.beach.adult[41][1].mf**

```text
你好，今天也没想明白什么。
```

**$.beach.adult[41][1].fm**

```text
你好，{对方称呼}，今天也没想明白什么。
```

**$.beach.adult[41][1].ff**

```text
你好，今天也没想明白什么。
```

**$.beach.adult[41][2].mm**

```text
>{主角称呼}，你是专门来想事的？
```

**$.beach.adult[41][2].mf**

```text
>你是专门来想事的？
```

**$.beach.adult[41][2].fm**

```text
>你是专门来想事的？
```

**$.beach.adult[41][2].ff**

```text
>{主角称呼}，你是专门来想事的？
```

**$.beach.adult[41][3]**

```text
不是，就是出来走走。
```

**$.beach.adult[41][4]**

```text
>那走得舒服就行。
```

**$.beach.adult[42][0]**

```text
看错一艘船
```

**$.beach.adult[42][1].mm**

```text
{对方称呼}，刚盯着白点看了半天。
```

**$.beach.adult[42][1].mf**

```text
你好，刚盯着白点看了半天。
```

**$.beach.adult[42][1].fm**

```text
你好，{对方称呼}，刚盯着白点看了半天。
```

**$.beach.adult[42][1].ff**

```text
你好，刚盯着白点看了半天。
```

**$.beach.adult[42][2].mm**

```text
>{主角称呼}，船还是鸟？
```

**$.beach.adult[42][2].mf**

```text
>船还是鸟？
```

**$.beach.adult[42][2].fm**

```text
>船还是鸟？
```

**$.beach.adult[42][2].ff**

```text
>{主角称呼}，船还是鸟？
```

**$.beach.adult[42][3]**

```text
鸟，刚飞起来了。
```

**$.beach.adult[42][4]**

```text
>怪不得一下换了方向。
```

**$.beach.adult[43][0]**

```text
没追上的浪
```

**$.beach.adult[43][1].mm**

```text
{对方称呼}，刚才那浪没来得及拍。
```

**$.beach.adult[43][1].mf**

```text
你好，刚才那浪没来得及拍。
```

**$.beach.adult[43][1].fm**

```text
你好，{对方称呼}，刚才那浪没来得及拍。
```

**$.beach.adult[43][1].ff**

```text
你好，刚才那浪没来得及拍。
```

**$.beach.adult[43][2].mm**

```text
>{主角称呼}，手机刚拿出来？
```

**$.beach.adult[43][2].mf**

```text
>手机刚拿出来？
```

**$.beach.adult[43][2].fm**

```text
>手机刚拿出来？
```

**$.beach.adult[43][2].ff**

```text
>{主角称呼}，手机刚拿出来？
```

**$.beach.adult[43][3]**

```text
嗯，解锁就晚了。
```

**$.beach.adult[43][4]**

```text
>下一阵再试，先对好镜头。
```

**$.beach.adult[44][0]**

```text
耳朵的休息
```

**$.beach.adult[44][1].mm**

```text
{对方称呼}，浪声大，反而没那么烦。
```

**$.beach.adult[44][1].mf**

```text
你好，浪声大，反而没那么烦。
```

**$.beach.adult[44][1].fm**

```text
你好，{对方称呼}，浪声大，反而没那么烦。
```

**$.beach.adult[44][1].ff**

```text
你好，浪声大，反而没那么烦。
```

**$.beach.adult[44][2].mm**

```text
>{主角称呼}，不用听人说一堆话吧。
```

**$.beach.adult[44][2].mf**

```text
>不用听人说一堆话吧。
```

**$.beach.adult[44][2].fm**

```text
>不用听人说一堆话吧。
```

**$.beach.adult[44][2].ff**

```text
>{主角称呼}，不用听人说一堆话吧。
```

**$.beach.adult[44][3]**

```text
也有点这个意思。
```

**$.beach.adult[44][4]**

```text
>那先安静听听。
```

**$.beach.adult[45][0]**

```text
码头的问候
```

**$.beach.adult[45][1].mm**

```text
{对方称呼}，你好，这里风真大啊。
```

**$.beach.adult[45][1].mf**

```text
你好，你好，这里风真大啊。
```

**$.beach.adult[45][1].fm**

```text
你好，{对方称呼}，你好，这里风真大啊。
```

**$.beach.adult[45][1].ff**

```text
你好，你好，这里风真大啊。
```

**$.beach.adult[45][2].mm**

```text
>{主角称呼}，嗯，刚那阵更大。
```

**$.beach.adult[45][2].mf**

```text
>嗯，刚那阵更大。
```

**$.beach.adult[45][2].fm**

```text
>嗯，刚那阵更大。
```

**$.beach.adult[45][2].ff**

```text
>{主角称呼}，嗯，刚那阵更大。
```

**$.beach.adult[45][3]**

```text
我帽子都差点飞。
```

**$.beach.adult[45][4]**

```text
>拿稳，掉下去不好捡。
```

**$.beach.adult[46][0]**

```text
想说再说
```

**$.beach.adult[46][1].mm**

```text
{对方称呼}，我刚想搭话，又没想好说什么。
```

**$.beach.adult[46][1].mf**

```text
你好，我刚想搭话，又没想好说什么。
```

**$.beach.adult[46][1].fm**

```text
你好，{对方称呼}，我刚想搭话，又没想好说什么。
```

**$.beach.adult[46][1].ff**

```text
你好，我刚想搭话，又没想好说什么。
```

**$.beach.adult[46][2].mm**

```text
>{主角称呼}，问个好就行。
```

**$.beach.adult[46][2].mf**

```text
>问个好就行。
```

**$.beach.adult[46][2].fm**

```text
>问个好就行。
```

**$.beach.adult[46][2].ff**

```text
>{主角称呼}，问个好就行。
```

**$.beach.adult[46][3]**

```text
那你好。
```

**$.beach.adult[46][4]**

```text
>你好啊，你从哪边来的？
```

**$.beach.adult[47][0]**

```text
把脚步带回去
```

**$.beach.adult[47][1].mm**

```text
{对方称呼}，站够了，准备回去了。
```

**$.beach.adult[47][1].mf**

```text
你好，站够了，准备回去了。
```

**$.beach.adult[47][1].fm**

```text
你好，{对方称呼}，站够了，准备回去了。
```

**$.beach.adult[47][1].ff**

```text
你好，站够了，准备回去了。
```

**$.beach.adult[47][2].mm**

```text
>{主角称呼}，好，路上小心。
```

**$.beach.adult[47][2].mf**

```text
>好，路上小心。
```

**$.beach.adult[47][2].fm**

```text
>好，路上小心。
```

**$.beach.adult[47][2].ff**

```text
>{主角称呼}，好，路上小心。
```

**$.beach.adult[47][3]**

```text
回去先坐一会儿。
```

**$.beach.adult[47][4]**

```text
>嗯，别忘了拿东西。
```

**$.beach.kid[0][0]**

```text
海鸥点名
```

**$.beach.kid[0][1]**

```text
你刚才为什么抬头答了一声？
```

**$.beach.kid[0][2]**

```text
>我以为那只鸟在叫我的名字。
```

**$.beach.kid[0][3]**

```text
它的发音可能还需要练练。
```

**$.beach.kid[0][4]**

```text
>下次我慢一点教它。
```

**$.beach.kid[1][0]**

```text
大海的呼吸
```

**$.beach.kid[1][1]**

```text
海为什么一直一来一回？
```

**$.beach.kid[1][2]**

```text
>我觉得它在慢慢呼吸。
```

**$.beach.kid[1][3]**

```text
那我们也可以一起慢一点。
```

**$.beach.kid[1][4]**

```text
>好，不过我不想把鞋吸进去。
```

**$.beach.kid[2][0]**

```text
船的大小
```

**$.beach.kid[2][1]**

```text
远处的船为什么那么小？
```

**$.beach.kid[2][2]**

```text
>因为它站得远，不是吃得少。
```

**$.beach.kid[2][3]**

```text
你这个解释很清楚。
```

**$.beach.kid[2][4]**

```text
>所以不能给它丢饼干，它收不到。
```

**$.beach.kid[3][0]**

```text
风的口袋
```

**$.beach.kid[3][1]**

```text
你张开手在接什么？
```

**$.beach.kid[3][2]**

```text
>风呀，可我握住以后它就不见了。
```

**$.beach.kid[3][3]**

```text
也许它不喜欢被攥太紧。
```

**$.beach.kid[3][4]**

```text
>那我摊开手，让它多待一下。
```

**$.beach.kid[4][0]**

```text
木板格子
```

**$.beach.kid[4][1]**

```text
为什么一直低头数木板？
```

**$.beach.kid[4][2]**

```text
>我想知道码头用了多少片饼干。
```

**$.beach.kid[4][3]**

```text
这些饼干可不能咬。
```

**$.beach.kid[4][4]**

```text
>我知道，它们负责让我们站稳。
```

**$.beach.kid[5][0]**

```text
海水的颜色
```

**$.beach.kid[5][1]**

```text
你觉得海是什么颜色？
```

**$.beach.kid[5][2]**

```text
>好多种，我的画笔可能带少了。
```

**$.beach.kid[5][3]**

```text
可以先记住最喜欢的一种。
```

**$.beach.kid[5][4]**

```text
>那我选刚才闪了一下的那种。
```

**$.beach.kid[6][0]**

```text
浪的名字
```

**$.beach.kid[6][1].mm**

```text
{对方称呼}，每一道浪，是不是都该有名字？
```

**$.beach.kid[6][1].mf**

```text
你好，每一道浪，是不是都该有名字？
```

**$.beach.kid[6][1].fm**

```text
你好，{对方称呼}，每一道浪，是不是都该有名字？
```

**$.beach.kid[6][1].ff**

```text
打个招呼，每一道浪，是不是都该有名字？
```

**$.beach.kid[6][2].mm**

```text
>{主角称呼}，嗯，我刚起好一个，它就走了。
```

**$.beach.kid[6][2].mf**

```text
>{主角称呼}，说起来，我刚起好一个，它就走了。
```

**$.beach.kid[6][2].fm**

```text
>{主角称呼}，其实，我刚起好一个，它就走了。
```

**$.beach.kid[6][2].ff**

```text
>{主角称呼}，这个嘛，我刚起好一个，它就走了。
```

**$.beach.kid[6][3]**

```text
可以留给下一道。
```

**$.beach.kid[6][4]**

```text
>好，名字也不用浪费。
```

**$.beach.kid[7][0]**

```text
海风的信
```

**$.beach.kid[7][1].mm**

```text
{对方称呼}，你张着手在等什么？
```

**$.beach.kid[7][1].mf**

```text
你好，你张着手在等什么？
```

**$.beach.kid[7][1].fm**

```text
你好，{对方称呼}，你张着手在等什么？
```

**$.beach.kid[7][1].ff**

```text
打个招呼，你张着手在等什么？
```

**$.beach.kid[7][2].mm**

```text
>{主角称呼}，说起来，等风把一封信交给我。
```

**$.beach.kid[7][2].mf**

```text
>{主角称呼}，其实，等风把一封信交给我。
```

**$.beach.kid[7][2].fm**

```text
>{主角称呼}，这个嘛，等风把一封信交给我。
```

**$.beach.kid[7][2].ff**

```text
>{主角称呼}，嗯，等风把一封信交给我。
```

**$.beach.kid[7][3]**

```text
收到了什么内容？
```

**$.beach.kid[7][4]**

```text
>收到一头乱发，字有点多。
```

**$.beach.kid[8][0]**

```text
船上的想象
```

**$.beach.kid[8][1].mm**

```text
{对方称呼}，你觉得船上现在有人在做什么？
```

**$.beach.kid[8][1].mf**

```text
你好，你觉得船上现在有人在做什么？
```

**$.beach.kid[8][1].fm**

```text
你好，{对方称呼}，你觉得船上现在有人在做什么？
```

**$.beach.kid[8][1].ff**

```text
打个招呼，你觉得船上现在有人在做什么？
```

**$.beach.kid[8][2].mm**

```text
>{主角称呼}，其实，也许在吃饭，也许在找袜子。
```

**$.beach.kid[8][2].mf**

```text
>{主角称呼}，这个嘛，也许在吃饭，也许在找袜子。
```

**$.beach.kid[8][2].fm**

```text
>{主角称呼}，嗯，也许在吃饭，也许在找袜子。
```

**$.beach.kid[8][2].ff**

```text
>{主角称呼}，说起来，也许在吃饭，也许在找袜子。
```

**$.beach.kid[8][3]**

```text
这么想，远方也很日常。
```

**$.beach.kid[8][4]**

```text
>对，不一定一直都在冒险。
```

**$.beach.kid[9][0]**

```text
木板的节拍
```

**$.beach.kid[9][1].mm**

```text
{对方称呼}，你在跟着脚步哼歌？
```

**$.beach.kid[9][1].mf**

```text
你好，你在跟着脚步哼歌？
```

**$.beach.kid[9][1].fm**

```text
你好，{对方称呼}，你在跟着脚步哼歌？
```

**$.beach.kid[9][1].ff**

```text
打个招呼，你在跟着脚步哼歌？
```

**$.beach.kid[9][2].mm**

```text
>{主角称呼}，这个嘛，嗯，这条路给了我一个拍子。
```

**$.beach.kid[9][2].mf**

```text
>{主角称呼}，嗯，嗯，这条路给了我一个拍子。
```

**$.beach.kid[9][2].fm**

```text
>{主角称呼}，说起来，嗯，这条路给了我一个拍子。
```

**$.beach.kid[9][2].ff**

```text
>{主角称呼}，其实，嗯，这条路给了我一个拍子。
```

**$.beach.kid[9][3]**

```text
慢一点也能唱。
```

**$.beach.kid[9][4]**

```text
>好，我不想把鞋唱得太累。
```

**$.beach.kid[10][0]**

```text
一小片天空
```

**$.beach.kid[10][1].mm**

```text
{对方称呼}，手指圈起来是在看什么？
```

**$.beach.kid[10][1].mf**

```text
你好，手指圈起来是在看什么？
```

**$.beach.kid[10][1].fm**

```text
你好，{对方称呼}，手指圈起来是在看什么？
```

**$.beach.kid[10][1].ff**

```text
打个招呼，手指圈起来是在看什么？
```

**$.beach.kid[10][2].mm**

```text
>{主角称呼}，嗯，我想给自己留一小片天空。
```

**$.beach.kid[10][2].mf**

```text
>{主角称呼}，说起来，我想给自己留一小片天空。
```

**$.beach.kid[10][2].fm**

```text
>{主角称呼}，其实，我想给自己留一小片天空。
```

**$.beach.kid[10][2].ff**

```text
>{主角称呼}，这个嘛，我想给自己留一小片天空。
```

**$.beach.kid[10][3]**

```text
放下手，它也还在。
```

**$.beach.kid[10][4]**

```text
>那我可以放心把口袋留给钥匙。
```

**$.beach.kid[11][0]**

```text
好好的再见
```

**$.beach.kid[11][1].mm**

```text
{对方称呼}，你已经挥手两次了？
```

**$.beach.kid[11][1].mf**

```text
你好，你已经挥手两次了？
```

**$.beach.kid[11][1].fm**

```text
你好，{对方称呼}，你已经挥手两次了？
```

**$.beach.kid[11][1].ff**

```text
打个招呼，你已经挥手两次了？
```

**$.beach.kid[11][2].mm**

```text
>{主角称呼}，说起来，第一次给海，第二次给你。
```

**$.beach.kid[11][2].mf**

```text
>{主角称呼}，其实，第一次给海，第二次给你。
```

**$.beach.kid[11][2].fm**

```text
>{主角称呼}，这个嘛，第一次给海，第二次给你。
```

**$.beach.kid[11][2].ff**

```text
>{主角称呼}，嗯，第一次给海，第二次给你。
```

**$.beach.kid[11][3]**

```text
那我也认真回一次。
```

**$.beach.kid[11][4]**

```text
>好，下次我们都别装不认识。
```

**$.bar.adult[0][0]**

```text
吧台的招呼
```

**$.bar.adult[0][1]**

```text
这里说话是不是有点吵？
```

**$.bar.adult[0][2]**

```text
>靠近一点就听得见。
```

**$.bar.adult[0][3]**

```text
这样能听清吗？
```

**$.bar.adult[0][4]**

```text
>能，你不用喊。
```

**$.bar.adult[1][0]**

```text
杯里的冰
```

**$.bar.adult[1][1]**

```text
冰块响得还挺清楚。
```

**$.bar.adult[1][2]**

```text
>你一晃就碰杯壁。
```

**$.bar.adult[1][3]**

```text
刚才还没注意。
```

**$.bar.adult[1][4]**

```text
>歌停的时候更明显。
```

**$.bar.adult[2][0]**

```text
今晚的歌
```

**$.bar.adult[2][1]**

```text
这前奏我好像听过。
```

**$.bar.adult[2][2]**

```text
>我也耳熟，名字想不起来。
```

**$.bar.adult[2][3]**

```text
等唱到后面看看。
```

**$.bar.adult[2][4]**

```text
>嗯，副歌可能认得。
```

**$.bar.adult[3][0]**

```text
无酒精也好
```

**$.bar.adult[3][1]**

```text
只点无酒精的可以吧？
```

**$.bar.adult[3][2]**

```text
>可以啊，菜单上就有。
```

**$.bar.adult[3][3]**

```text
我今天不想喝酒。
```

**$.bar.adult[3][4]**

```text
>那看看果汁什么的。
```

**$.bar.adult[4][0]**

```text
杯垫的工作
```

**$.bar.adult[4][1]**

```text
这杯垫有点湿了。
```

**$.bar.adult[4][2]**

```text
>杯子外面都是水。
```

**$.bar.adult[4][3]**

```text
我翻个面。
```

**$.bar.adult[4][4]**

```text
>嗯，别把水弄桌边。
```

**$.bar.adult[5][0]**

```text
临窗的灯
```

**$.bar.adult[5][1]**

```text
窗边这个位置挺好。
```

**$.bar.adult[5][2]**

```text
>嗯，不用凑很近才看清。
```

**$.bar.adult[5][3]**

```text
也不晃眼。
```

**$.bar.adult[5][4]**

```text
>就是有人走过会挡一下。
```

**$.bar.adult[6][0]**

```text
音乐的间隙
```

**$.bar.adult[6][1]**

```text
刚才歌结束，大家都停了一下。
```

**$.bar.adult[6][2]**

```text
>后面那段确实好听。
```

**$.bar.adult[6][3]**

```text
我还以为要接下一首。
```

**$.bar.adult[6][4]**

```text
>可能歇一会儿吧。
```

**$.bar.adult[7][0]**

```text
加班的影子
```

**$.bar.adult[7][1]**

```text
坐下了还惦记着白天的事。
```

**$.bar.adult[7][2]**

```text
>还没忙完？
```

**$.bar.adult[7][3]**

```text
忙完了，就是老想起来。
```

**$.bar.adult[7][4]**

```text
>先喝点水，晚点再想吧。
```

**$.bar.adult[8][0]**

```text
酒单的犹豫
```

**$.bar.adult[8][1]**

```text
酒单看半天也没选好。
```

**$.bar.adult[8][2]**

```text
>想喝甜一点的还是清一点的？
```

**$.bar.adult[8][3]**

```text
不想太苦。
```

**$.bar.adult[8][4]**

```text
>那问问酒保，别光看名字。
```

**$.bar.adult[9][0]**

```text
轻轻碰杯
```

**$.bar.adult[9][1]**

```text
那边碰杯声音挺大。
```

**$.bar.adult[9][2]**

```text
>估计聊高兴了。
```

**$.bar.adult[9][3]**

```text
我刚还回头看一眼。
```

**$.bar.adult[9][4]**

```text
>咱们轻点碰就好。
```

**$.bar.adult[10][0]**

```text
舞台的认真
```

**$.bar.adult[10][1]**

```text
台上唱得挺认真。
```

**$.bar.adult[10][2]**

```text
>嗯，刚才那句都闭眼了。
```

**$.bar.adult[10][3]**

```text
声音也稳。
```

**$.bar.adult[10][4]**

```text
>先听完这首吧。
```

**$.bar.adult[11][0]**

```text
不会跳舞
```

**$.bar.adult[11][1]**

```text
听这个我都想跟着动两下。
```

**$.bar.adult[11][2]**

```text
>那就动啊。
```

**$.bar.adult[11][3]**

```text
我不会跳。
```

**$.bar.adult[11][4]**

```text
>坐着打打拍子也行。
```

**$.bar.adult[12][0]**

```text
菜单的小字
```

**$.bar.adult[12][1]**

```text
这描述我没看懂。
```

**$.bar.adult[12][2]**

```text
>想知道什么，直接问酒保吧。
```

**$.bar.adult[12][3]**

```text
嗯，问问酸不酸。
```

**$.bar.adult[12][4]**

```text
>比看名字猜省事。
```

**$.bar.adult[13][0]**

```text
夜里的空白
```

**$.bar.adult[13][1]**

```text
今天说太多话了，想歇会儿。
```

**$.bar.adult[13][2]**

```text
>那先听歌。
```

**$.bar.adult[13][3]**

```text
嗯，这首挺好听。
```

**$.bar.adult[13][4]**

```text
>我也听听。
```

**$.bar.adult[14][0]**

```text
一杯的时间
```

**$.bar.adult[14][1]**

```text
你一般坐多久？
```

**$.bar.adult[14][2]**

```text
>看情况，一杯喝完差不多。
```

**$.bar.adult[14][3]**

```text
不再坐会儿？
```

**$.bar.adult[14][4]**

```text
>要是聊得来就多坐一下。
```

**$.bar.adult[15][0]**

```text
玻璃的倒影
```

**$.bar.adult[15][1]**

```text
玻璃里看着自己不太一样。
```

**$.bar.adult[15][2]**

```text
>这儿光暗，脸都看不太清。
```

**$.bar.adult[15][3]**

```text
难怪，我还以为自己脸脏了。
```

**$.bar.adult[15][4]**

```text
>没有，就是影子。
```

**$.bar.adult[16][0]**

```text
听不清的歌词
```

**$.bar.adult[16][1]**

```text
有句歌词我老听错。
```

**$.bar.adult[16][2]**

```text
>听成什么？
```

**$.bar.adult[16][3]**

```text
明天不用起床。
```

**$.bar.adult[16][4]**

```text
>这句我也想信。
```

**$.bar.adult[17][0]**

```text
点头的默契
```

**$.bar.adult[17][1]**

```text
你也在跟着点头啊。
```

**$.bar.adult[17][2]**

```text
>嗯，这段节奏挺明显。
```

**$.bar.adult[17][3]**

```text
我都没发现自己在动。
```

**$.bar.adult[17][4]**

```text
>听着就跟上了。
```

**$.bar.adult[18][0]**

```text
陌生人的礼貌
```

**$.bar.adult[18][1]**

```text
谢谢，没打扰你就好。
```

**$.bar.adult[18][2]**

```text
>没有，我刚也在找人说话。
```

**$.bar.adult[18][3]**

```text
刚还怕你不方便。
```

**$.bar.adult[18][4]**

```text
>有事我会说的。
```

**$.bar.adult[19][0]**

```text
慢慢说的话
```

**$.bar.adult[19][1]**

```text
有些事当面反而好说一点。
```

**$.bar.adult[19][2]**

```text
>打字太长？
```

**$.bar.adult[19][3]**

```text
对，发出去还怕没说清。
```

**$.bar.adult[19][4]**

```text
>那你慢慢讲，我听着。
```

**$.bar.adult[20][0]**

```text
冰化以后
```

**$.bar.adult[20][1]**

```text
冰化了，味道淡一点了。
```

**$.bar.adult[20][2]**

```text
>放挺久了吧。
```

**$.bar.adult[20][3]**

```text
嗯，光顾着聊天。
```

**$.bar.adult[20][4]**

```text
>想换点冰就叫酒保。
```

**$.bar.adult[21][0]**

```text
窗外的路
```

**$.bar.adult[21][1]**

```text
看窗外人走来走去也挺有意思。
```

**$.bar.adult[21][2]**

```text
>有的进来，有的路过。
```

**$.bar.adult[21][3]**

```text
刚那人都走过两回了。
```

**$.bar.adult[21][4]**

```text
>可能在等人。
```

**$.bar.adult[22][0]**

```text
酒吧的钟
```

**$.bar.adult[22][1]**

```text
这边是不是有钟？
```

**$.bar.adult[22][2]**

```text
>那边，上面一点。
```

**$.bar.adult[22][3]**

```text
哦，看见了。
```

**$.bar.adult[22][4]**

```text
>坐这儿容易忘看时间。
```

**$.bar.adult[23][0]**

```text
演出前一拍
```

**$.bar.adult[23][1]**

```text
演出前那一下特别安静。
```

**$.bar.adult[23][2]**

```text
>都等着第一声呢。
```

**$.bar.adult[23][3]**

```text
我也跟着屏住气。
```

**$.bar.adult[23][4]**

```text
>开始了，先听吧。
```

**$.bar.adult[24][0]**

```text
清醒的聊天
```

**$.bar.adult[24][1]**

```text
清醒着聊天也挺好。
```

**$.bar.adult[24][2]**

```text
>是，至少话记得住。
```

**$.bar.adult[24][3]**

```text
我有次喝多了，第二天全忘。
```

**$.bar.adult[24][4]**

```text
>那今天慢点喝。
```

**$.bar.adult[25][0]**

```text
不硬撑的告别
```

**$.bar.adult[25][1]**

```text
聊得挺好，就是有点困了。
```

**$.bar.adult[25][2]**

```text
>那早点回去吧。
```

**$.bar.adult[25][3]**

```text
嗯，下次再接着说。
```

**$.bar.adult[25][4]**

```text
>行，别硬撑着。
```

**$.bar.adult[26][0]**

```text
小小的庆祝
```

**$.bar.adult[26][1]**

```text
今天想给自己买点好喝的。
```

**$.bar.adult[26][2]**

```text
>有什么高兴事？
```

**$.bar.adult[26][3]**

```text
也没，就是想喝。
```

**$.bar.adult[26][4]**

```text
>那看看菜单，挑喜欢的。
```

**$.bar.adult[27][0]**

```text
杯口的水珠
```

**$.bar.adult[27][1]**

```text
杯子下面一圈水。
```

**$.bar.adult[27][2]**

```text
>杯垫湿了，换张干的。
```

**$.bar.adult[27][3]**

```text
我翻个面先。
```

**$.bar.adult[27][4]**

```text
>嗯，别滴到袖子上。
```

**$.bar.adult[28][0]**

```text
多认识一点
```

**$.bar.adult[28][1]**

```text
刚才聊得比前面顺一点。
```

**$.bar.adult[28][2]**

```text
>你前面一直没出声。
```

**$.bar.adult[28][3]**

```text
刚没想好问什么。
```

**$.bar.adult[28][4]**

```text
>没事，随口说就行。
```

**$.bar.adult[29][0]**

```text
今晚的记忆
```

**$.bar.adult[29][1]**

```text
今天这首歌我回去得找找。
```

**$.bar.adult[29][2]**

```text
>你记住名字了吗？
```

**$.bar.adult[29][3]**

```text
没，准备问酒保。
```

**$.bar.adult[29][4]**

```text
>那先记一下，免得又忘。
```

**$.bar.adult[30][0]**

```text
夜里的新招呼
```

**$.bar.adult[30][1].mm**

```text
{对方称呼}，你好，你常来这儿吗？
```

**$.bar.adult[30][1].mf**

```text
你好，你好，你常来这儿吗？
```

**$.bar.adult[30][1].fm**

```text
你好，{对方称呼}，你好，你常来这儿吗？
```

**$.bar.adult[30][1].ff**

```text
你好，你好，你常来这儿吗？
```

**$.bar.adult[30][2].mm**

```text
>{主角称呼}，偶尔来，你呢？
```

**$.bar.adult[30][2].mf**

```text
>偶尔来，你呢？
```

**$.bar.adult[30][2].fm**

```text
>偶尔来，你呢？
```

**$.bar.adult[30][2].ff**

```text
>{主角称呼}，偶尔来，你呢？
```

**$.bar.adult[30][3]**

```text
我今天来坐坐。
```

**$.bar.adult[30][4]**

```text
>这边还行，声音没那么吵。
```

**$.bar.adult[31][0]**

```text
杯垫的小停顿
```

**$.bar.adult[31][1].mm**

```text
{对方称呼}，杯子放下，手总算能歇了。
```

**$.bar.adult[31][1].mf**

```text
你好，杯子放下，手总算能歇了。
```

**$.bar.adult[31][1].fm**

```text
你好，{对方称呼}，杯子放下，手总算能歇了。
```

**$.bar.adult[31][1].ff**

```text
你好，杯子放下，手总算能歇了。
```

**$.bar.adult[31][2].mm**

```text
>{主角称呼}，你一直端着干什么？
```

**$.bar.adult[31][2].mf**

```text
>你一直端着干什么？
```

**$.bar.adult[31][2].fm**

```text
>你一直端着干什么？
```

**$.bar.adult[31][2].ff**

```text
>{主角称呼}，你一直端着干什么？
```

**$.bar.adult[31][3]**

```text
忘了，边说边拿着。
```

**$.bar.adult[31][4]**

```text
>有杯垫，放着就好。
```

**$.bar.adult[32][0]**

```text
不必借口味
```

**$.bar.adult[32][1].mm**

```text
{对方称呼}，我还想找个懂酒的话题。
```

**$.bar.adult[32][1].mf**

```text
你好，我还想找个懂酒的话题。
```

**$.bar.adult[32][1].fm**

```text
你好，{对方称呼}，我还想找个懂酒的话题。
```

**$.bar.adult[32][1].ff**

```text
你好，我还想找个懂酒的话题。
```

**$.bar.adult[32][2].mm**

```text
>{主角称呼}，你不用问我，我也不懂。
```

**$.bar.adult[32][2].mf**

```text
>你不用问我，我也不懂。
```

**$.bar.adult[32][2].fm**

```text
>你不用问我，我也不懂。
```

**$.bar.adult[32][2].ff**

```text
>{主角称呼}，你不用问我，我也不懂。
```

**$.bar.adult[32][3]**

```text
那咱俩看菜单吧。
```

**$.bar.adult[32][4]**

```text
>行，先看口味。
```

**$.bar.adult[33][0]**

```text
听见同一拍
```

**$.bar.adult[33][1].mm**

```text
{对方称呼}，刚才那个拍子你也跟着点头？
```

**$.bar.adult[33][1].mf**

```text
你好，刚才那个拍子你也跟着点头？
```

**$.bar.adult[33][1].fm**

```text
你好，{对方称呼}，刚才那个拍子你也跟着点头？
```

**$.bar.adult[33][1].ff**

```text
你好，刚才那个拍子你也跟着点头？
```

**$.bar.adult[33][2].mm**

```text
>{主角称呼}，嗯，挺好跟的。
```

**$.bar.adult[33][2].mf**

```text
>嗯，挺好跟的。
```

**$.bar.adult[33][2].fm**

```text
>嗯，挺好跟的。
```

**$.bar.adult[33][2].ff**

```text
>{主角称呼}，嗯，挺好跟的。
```

**$.bar.adult[33][3]**

```text
我没听过这首。
```

**$.bar.adult[33][4]**

```text
>后面再听听，我也刚听。
```

**$.bar.adult[34][0]**

```text
慢一点的晚上
```

**$.bar.adult[34][1].mm**

```text
{对方称呼}，坐这儿才发现时间过挺快。
```

**$.bar.adult[34][1].mf**

```text
你好，坐这儿才发现时间过挺快。
```

**$.bar.adult[34][1].fm**

```text
你好，{对方称呼}，坐这儿才发现时间过挺快。
```

**$.bar.adult[34][1].ff**

```text
你好，坐这儿才发现时间过挺快。
```

**$.bar.adult[34][2].mm**

```text
>{主角称呼}，你几点得走？
```

**$.bar.adult[34][2].mf**

```text
>你几点得走？
```

**$.bar.adult[34][2].fm**

```text
>你几点得走？
```

**$.bar.adult[34][2].ff**

```text
>{主角称呼}，你几点得走？
```

**$.bar.adult[34][3]**

```text
还早，不赶。
```

**$.bar.adult[34][4]**

```text
>那再坐会儿。
```

**$.bar.adult[35][0]**

```text
玻璃边的亮点
```

**$.bar.adult[35][1].mm**

```text
{对方称呼}，杯沿反的光有点晃。
```

**$.bar.adult[35][1].mf**

```text
你好，杯沿反的光有点晃。
```

**$.bar.adult[35][1].fm**

```text
你好，{对方称呼}，杯沿反的光有点晃。
```

**$.bar.adult[35][1].ff**

```text
你好，杯沿反的光有点晃。
```

**$.bar.adult[35][2].mm**

```text
>{主角称呼}，换个位置放呢？
```

**$.bar.adult[35][2].mf**

```text
>换个位置放呢？
```

**$.bar.adult[35][2].fm**

```text
>换个位置放呢？
```

**$.bar.adult[35][2].ff**

```text
>{主角称呼}，换个位置放呢？
```

**$.bar.adult[35][3]**

```text
这边好点了。
```

**$.bar.adult[35][4]**

```text
>嗯，刚好避开灯。
```

**$.bar.adult[36][0]**

```text
说到一半也行
```

**$.bar.adult[36][1].mm**

```text
{对方称呼}，有件事还没想好怎么讲。
```

**$.bar.adult[36][1].mf**

```text
你好，有件事还没想好怎么讲。
```

**$.bar.adult[36][1].fm**

```text
你好，{对方称呼}，有件事还没想好怎么讲。
```

**$.bar.adult[36][1].ff**

```text
你好，有件事还没想好怎么讲。
```

**$.bar.adult[36][2].mm**

```text
>{主角称呼}，你先说个大概。
```

**$.bar.adult[36][2].mf**

```text
>你先说个大概。
```

**$.bar.adult[36][2].fm**

```text
>你先说个大概。
```

**$.bar.adult[36][2].ff**

```text
>{主角称呼}，你先说个大概。
```

**$.bar.adult[36][3]**

```text
挺小的，就是有点烦。
```

**$.bar.adult[36][4]**

```text
>那从头说，我听听。
```

**$.bar.adult[37][0]**

```text
音乐换一首
```

**$.bar.adult[37][1].mm**

```text
{对方称呼}，换歌了，我还想听前面那首。
```

**$.bar.adult[37][1].mf**

```text
你好，换歌了，我还想听前面那首。
```

**$.bar.adult[37][1].fm**

```text
你好，{对方称呼}，换歌了，我还想听前面那首。
```

**$.bar.adult[37][1].ff**

```text
你好，换歌了，我还想听前面那首。
```

**$.bar.adult[37][2].mm**

```text
>{主角称呼}，问问叫什么吧。
```

**$.bar.adult[37][2].mf**

```text
>问问叫什么吧。
```

**$.bar.adult[37][2].fm**

```text
>问问叫什么吧。
```

**$.bar.adult[37][2].ff**

```text
>{主角称呼}，问问叫什么吧。
```

**$.bar.adult[37][3]**

```text
嗯，回去找着听。
```

**$.bar.adult[37][4]**

```text
>应该能问到，刚才挺多人跟着哼。
```

**$.bar.adult[38][0]**

```text
一杯清醒
```

**$.bar.adult[38][1].mm**

```text
{对方称呼}，今天不想喝酒。
```

**$.bar.adult[38][1].mf**

```text
你好，今天不想喝酒。
```

**$.bar.adult[38][1].fm**

```text
你好，{对方称呼}，今天不想喝酒。
```

**$.bar.adult[38][1].ff**

```text
你好，今天不想喝酒。
```

**$.bar.adult[38][2].mm**

```text
>{主角称呼}，那点无酒精的。
```

**$.bar.adult[38][2].mf**

```text
>那点无酒精的。
```

**$.bar.adult[38][2].fm**

```text
>那点无酒精的。
```

**$.bar.adult[38][2].ff**

```text
>{主角称呼}，那点无酒精的。
```

**$.bar.adult[38][3]**

```text
我看这页有。
```

**$.bar.adult[38][4]**

```text
>对，果汁也有几种。
```

**$.bar.adult[39][0]**

```text
话不用太满
```

**$.bar.adult[39][1].mm**

```text
{对方称呼}，我是不是说太多了？
```

**$.bar.adult[39][1].mf**

```text
你好，我是不是说太多了？
```

**$.bar.adult[39][1].fm**

```text
你好，{对方称呼}，我是不是说太多了？
```

**$.bar.adult[39][1].ff**

```text
你好，我是不是说太多了？
```

**$.bar.adult[39][2].mm**

```text
>{主角称呼}，还好，就是刚没听清一句。
```

**$.bar.adult[39][2].mf**

```text
>还好，就是刚没听清一句。
```

**$.bar.adult[39][2].fm**

```text
>还好，就是刚没听清一句。
```

**$.bar.adult[39][2].ff**

```text
>{主角称呼}，还好，就是刚没听清一句。
```

**$.bar.adult[39][3]**

```text
哪句，我再说一遍。
```

**$.bar.adult[39][4]**

```text
>就前面你说去那儿之后呢？
```

**$.bar.adult[40][0]**

```text
杯里的倒影
```

**$.bar.adult[40][1].mm**

```text
{对方称呼}，杯子里照得脸有点变形。
```

**$.bar.adult[40][1].mf**

```text
你好，杯子里照得脸有点变形。
```

**$.bar.adult[40][1].fm**

```text
你好，{对方称呼}，杯子里照得脸有点变形。
```

**$.bar.adult[40][1].ff**

```text
你好，杯子里照得脸有点变形。
```

**$.bar.adult[40][2].mm**

```text
>{主角称呼}，玻璃弯的啊。
```

**$.bar.adult[40][2].mf**

```text
>玻璃弯的啊。
```

**$.bar.adult[40][2].fm**

```text
>玻璃弯的啊。
```

**$.bar.adult[40][2].ff**

```text
>{主角称呼}，玻璃弯的啊。
```

**$.bar.adult[40][3]**

```text
哦，我还盯着看半天。
```

**$.bar.adult[40][4]**

```text
>你用手机看看不就知道了。
```

**$.bar.adult[41][0]**

```text
不赶着喝完
```

**$.bar.adult[41][1].mm**

```text
{对方称呼}，我老是几口就喝完一杯。
```

**$.bar.adult[41][1].mf**

```text
你好，我老是几口就喝完一杯。
```

**$.bar.adult[41][1].fm**

```text
你好，{对方称呼}，我老是几口就喝完一杯。
```

**$.bar.adult[41][1].ff**

```text
你好，我老是几口就喝完一杯。
```

**$.bar.adult[41][2].mm**

```text
>{主角称呼}，这杯慢点吧，别呛着。
```

**$.bar.adult[41][2].mf**

```text
>这杯慢点吧，别呛着。
```

**$.bar.adult[41][2].fm**

```text
>这杯慢点吧，别呛着。
```

**$.bar.adult[41][2].ff**

```text
>{主角称呼}，这杯慢点吧，别呛着。
```

**$.bar.adult[41][3]**

```text
嗯，我先放下。
```

**$.bar.adult[41][4]**

```text
>说会儿话，一会儿再喝。
```

**$.bar.adult[42][0]**

```text
台上的准备
```

**$.bar.adult[42][1].mm**

```text
{对方称呼}，台上那个人刚才深呼吸了。
```

**$.bar.adult[42][1].mf**

```text
你好，台上那个人刚才深呼吸了。
```

**$.bar.adult[42][1].fm**

```text
你好，{对方称呼}，台上那个人刚才深呼吸了。
```

**$.bar.adult[42][1].ff**

```text
你好，台上那个人刚才深呼吸了。
```

**$.bar.adult[42][2].mm**

```text
>{主角称呼}，可能准备唱高音。
```

**$.bar.adult[42][2].mf**

```text
>可能准备唱高音。
```

**$.bar.adult[42][2].fm**

```text
>可能准备唱高音。
```

**$.bar.adult[42][2].ff**

```text
>{主角称呼}，可能准备唱高音。
```

**$.bar.adult[42][3]**

```text
这一段看着挺难。
```

**$.bar.adult[42][4]**

```text
>嗯，先听听。
```

**$.bar.adult[43][0]**

```text
没有大新闻
```

**$.bar.adult[43][1].mm**

```text
{对方称呼}，今天没什么新鲜事。
```

**$.bar.adult[43][1].mf**

```text
你好，今天没什么新鲜事。
```

**$.bar.adult[43][1].fm**

```text
你好，{对方称呼}，今天没什么新鲜事。
```

**$.bar.adult[43][1].ff**

```text
你好，今天没什么新鲜事。
```

**$.bar.adult[43][2].mm**

```text
>{主角称呼}，那就随便聊呗。
```

**$.bar.adult[43][2].mf**

```text
>那就随便聊呗。
```

**$.bar.adult[43][2].fm**

```text
>那就随便聊呗。
```

**$.bar.adult[43][2].ff**

```text
>{主角称呼}，那就随便聊呗。
```

**$.bar.adult[43][3]**

```text
我刚还差点走错门。
```

**$.bar.adult[43][4]**

```text
>怎么走的，说来听听。
```

**$.bar.adult[44][0]**

```text
笑得慢半拍
```

**$.bar.adult[44][1].mm**

```text
{对方称呼}，刚那个笑话我现在才懂。
```

**$.bar.adult[44][1].mf**

```text
你好，刚那个笑话我现在才懂。
```

**$.bar.adult[44][1].fm**

```text
你好，{对方称呼}，刚那个笑话我现在才懂。
```

**$.bar.adult[44][1].ff**

```text
你好，刚那个笑话我现在才懂。
```

**$.bar.adult[44][2].mm**

```text
>{主角称呼}，反应过来了？
```

**$.bar.adult[44][2].mf**

```text
>反应过来了？
```

**$.bar.adult[44][2].fm**

```text
>反应过来了？
```

**$.bar.adult[44][2].ff**

```text
>{主角称呼}，反应过来了？
```

**$.bar.adult[44][3]**

```text
嗯，越想越好笑。
```

**$.bar.adult[44][4]**

```text
>我还以为没讲清楚。
```

**$.bar.adult[45][0]**

```text
灯下的安静
```

**$.bar.adult[45][1].mm**

```text
{对方称呼}，灯没那么亮，坐着倒舒服。
```

**$.bar.adult[45][1].mf**

```text
你好，灯没那么亮，坐着倒舒服。
```

**$.bar.adult[45][1].fm**

```text
你好，{对方称呼}，灯没那么亮，坐着倒舒服。
```

**$.bar.adult[45][1].ff**

```text
你好，灯没那么亮，坐着倒舒服。
```

**$.bar.adult[45][2].mm**

```text
>{主角称呼}，菜单看得清吗？
```

**$.bar.adult[45][2].mf**

```text
>菜单看得清吗？
```

**$.bar.adult[45][2].fm**

```text
>菜单看得清吗？
```

**$.bar.adult[45][2].ff**

```text
>{主角称呼}，菜单看得清吗？
```

**$.bar.adult[45][3]**

```text
靠近点能看。
```

**$.bar.adult[45][4]**

```text
>那就行，要看字再拿近点。
```

**$.bar.adult[46][0]**

```text
留点精神回去
```

**$.bar.adult[46][1].mm**

```text
{对方称呼}，今天不想待太晚。
```

**$.bar.adult[46][1].mf**

```text
你好，今天不想待太晚。
```

**$.bar.adult[46][1].fm**

```text
你好，{对方称呼}，今天不想待太晚。
```

**$.bar.adult[46][1].ff**

```text
你好，今天不想待太晚。
```

**$.bar.adult[46][2].mm**

```text
>{主角称呼}，那看好回去的时间。
```

**$.bar.adult[46][2].mf**

```text
>那看好回去的时间。
```

**$.bar.adult[46][2].fm**

```text
>那看好回去的时间。
```

**$.bar.adult[46][2].ff**

```text
>{主角称呼}，那看好回去的时间。
```

**$.bar.adult[46][3]**

```text
嗯，再坐一会儿。
```

**$.bar.adult[46][4]**

```text
>东西先收好，走时不慌。
```

**$.bar.adult[47][0]**

```text
歌名没想起
```

**$.bar.adult[47][1].mm**

```text
{对方称呼}，旋律熟，名字想不起来。
```

**$.bar.adult[47][1].mf**

```text
你好，旋律熟，名字想不起来。
```

**$.bar.adult[47][1].fm**

```text
你好，{对方称呼}，旋律熟，名字想不起来。
```

**$.bar.adult[47][1].ff**

```text
你好，旋律熟，名字想不起来。
```

**$.bar.adult[47][2].mm**

```text
>{主角称呼}，等唱到副歌看看。
```

**$.bar.adult[47][2].mf**

```text
>等唱到副歌看看。
```

**$.bar.adult[47][2].fm**

```text
>等唱到副歌看看。
```

**$.bar.adult[47][2].ff**

```text
>{主角称呼}，等唱到副歌看看。
```

**$.bar.adult[47][3]**

```text
还真是，后面那句我会。
```

**$.bar.adult[47][4]**

```text
>一会儿问问歌名。
```

**$.bar.adult[48][0]**

```text
不需要表现懂
```

**$.bar.adult[48][1].mm**

```text
{对方称呼}，别人聊酒聊得好熟。
```

**$.bar.adult[48][1].mf**

```text
你好，别人聊酒聊得好熟。
```

**$.bar.adult[48][1].fm**

```text
你好，{对方称呼}，别人聊酒聊得好熟。
```

**$.bar.adult[48][1].ff**

```text
你好，别人聊酒聊得好熟。
```

**$.bar.adult[48][2].mm**

```text
>{主角称呼}，我也就认识菜单上几个。
```

**$.bar.adult[48][2].mf**

```text
>我也就认识菜单上几个。
```

**$.bar.adult[48][2].fm**

```text
>我也就认识菜单上几个。
```

**$.bar.adult[48][2].ff**

```text
>{主角称呼}，我也就认识菜单上几个。
```

**$.bar.adult[48][3]**

```text
那我就不装懂了。
```

**$.bar.adult[48][4]**

```text
>不懂就问一下呗。
```

**$.bar.adult[49][0]**

```text
桌边的问候
```

**$.bar.adult[49][1].mm**

```text
{对方称呼}，你好，这里没人坐吧？
```

**$.bar.adult[49][1].mf**

```text
你好，你好，这里没人坐吧？
```

**$.bar.adult[49][1].fm**

```text
你好，{对方称呼}，你好，这里没人坐吧？
```

**$.bar.adult[49][1].ff**

```text
你好，你好，这里没人坐吧？
```

**$.bar.adult[49][2].mm**

```text
>{主角称呼}，没人，你坐。
```

**$.bar.adult[49][2].mf**

```text
>没人，你坐。
```

**$.bar.adult[49][2].fm**

```text
>没人，你坐。
```

**$.bar.adult[49][2].ff**

```text
>{主角称呼}，没人，你坐。
```

**$.bar.adult[49][3]**

```text
好，谢谢。
```

**$.bar.adult[49][4]**

```text
>包放旁边也行。
```

**$.bar.adult[50][0]**

```text
慢慢认识
```

**$.bar.adult[50][1].mm**

```text
{对方称呼}，刚认识还真不知道聊什么。
```

**$.bar.adult[50][1].mf**

```text
你好，刚认识还真不知道聊什么。
```

**$.bar.adult[50][1].fm**

```text
你好，{对方称呼}，刚认识还真不知道聊什么。
```

**$.bar.adult[50][1].ff**

```text
你好，刚认识还真不知道聊什么。
```

**$.bar.adult[50][2].mm**

```text
>{主角称呼}，你从哪边过来的？
```

**$.bar.adult[50][2].mf**

```text
>你从哪边过来的？
```

**$.bar.adult[50][2].fm**

```text
>你从哪边过来的？
```

**$.bar.adult[50][2].ff**

```text
>{主角称呼}，你从哪边过来的？
```

**$.bar.adult[50][3]**

```text
刚在附近走了走。
```

**$.bar.adult[50][4]**

```text
>哦，我也是，顺路进来。
```

**$.bar.adult[51][0]**

```text
把声音收小
```

**$.bar.adult[51][1].mm**

```text
{对方称呼}，我刚说话是不是太大声？
```

**$.bar.adult[51][1].mf**

```text
你好，我刚说话是不是太大声？
```

**$.bar.adult[51][1].fm**

```text
你好，{对方称呼}，我刚说话是不是太大声？
```

**$.bar.adult[51][1].ff**

```text
你好，我刚说话是不是太大声？
```

**$.bar.adult[51][2].mm**

```text
>{主角称呼}，有一点，我都听清了。
```

**$.bar.adult[51][2].mf**

```text
>有一点，我都听清了。
```

**$.bar.adult[51][2].fm**

```text
>有一点，我都听清了。
```

**$.bar.adult[51][2].ff**

```text
>{主角称呼}，有一点，我都听清了。
```

**$.bar.adult[51][3]**

```text
好，我收点。
```

**$.bar.adult[51][4]**

```text
>嗯，不用喊那么大。
```

**$.bar.adult[52][0]**

```text
一点自己的时间
```

**$.bar.adult[52][1].mm**

```text
{对方称呼}，今天总算有点自己的时间。
```

**$.bar.adult[52][1].mf**

```text
你好，今天总算有点自己的时间。
```

**$.bar.adult[52][1].fm**

```text
你好，{对方称呼}，今天总算有点自己的时间。
```

**$.bar.adult[52][1].ff**

```text
你好，今天总算有点自己的时间。
```

**$.bar.adult[52][2].mm**

```text
>{主角称呼}，前面忙什么呢？
```

**$.bar.adult[52][2].mf**

```text
>前面忙什么呢？
```

**$.bar.adult[52][2].fm**

```text
>前面忙什么呢？
```

**$.bar.adult[52][2].ff**

```text
>{主角称呼}，前面忙什么呢？
```

**$.bar.adult[52][3]**

```text
都是零碎事，跑来跑去。
```

**$.bar.adult[52][4]**

```text
>那坐会儿，别再忙了。
```

**$.bar.adult[53][0]**

```text
演出以后的回味
```

**$.bar.adult[53][1].mm**

```text
{对方称呼}，上一首结束了还在脑子里响。
```

**$.bar.adult[53][1].mf**

```text
你好，上一首结束了还在脑子里响。
```

**$.bar.adult[53][1].fm**

```text
你好，{对方称呼}，上一首结束了还在脑子里响。
```

**$.bar.adult[53][1].ff**

```text
你好，上一首结束了还在脑子里响。
```

**$.bar.adult[53][2].mm**

```text
>{主角称呼}，我也是，老跟着哼。
```

**$.bar.adult[53][2].mf**

```text
>我也是，老跟着哼。
```

**$.bar.adult[53][2].fm**

```text
>我也是，老跟着哼。
```

**$.bar.adult[53][2].ff**

```text
>{主角称呼}，我也是，老跟着哼。
```

**$.bar.adult[53][3]**

```text
但歌词记不住。
```

**$.bar.adult[53][4]**

```text
>先把歌名找着吧。
```

**$.bar.adult[54][0]**

```text
没有急着回答
```

**$.bar.adult[54][1].mm**

```text
{对方称呼}，你刚半天没接话，我还以为没听清。
```

**$.bar.adult[54][1].mf**

```text
你好，你刚半天没接话，我还以为没听清。
```

**$.bar.adult[54][1].fm**

```text
你好，{对方称呼}，你刚半天没接话，我还以为没听清。
```

**$.bar.adult[54][1].ff**

```text
你好，你刚半天没接话，我还以为没听清。
```

**$.bar.adult[54][2].mm**

```text
>{主角称呼}，听着呢，想了一下。
```

**$.bar.adult[54][2].mf**

```text
>听着呢，想了一下。
```

**$.bar.adult[54][2].fm**

```text
>听着呢，想了一下。
```

**$.bar.adult[54][2].ff**

```text
>{主角称呼}，听着呢，想了一下。
```

**$.bar.adult[54][3]**

```text
哦，我还准备再讲一遍。
```

**$.bar.adult[54][4]**

```text
>不用，你接着说。
```

**$.bar.adult[55][0]**

```text
话题绕了点路
```

**$.bar.adult[55][1].mm**

```text
{对方称呼}，从歌聊到晚饭，也绕挺远。
```

**$.bar.adult[55][1].mf**

```text
你好，从歌聊到晚饭，也绕挺远。
```

**$.bar.adult[55][1].fm**

```text
你好，{对方称呼}，从歌聊到晚饭，也绕挺远。
```

**$.bar.adult[55][1].ff**

```text
你好，从歌聊到晚饭，也绕挺远。
```

**$.bar.adult[55][2].mm**

```text
>{主角称呼}，一说吃的就停不下来。
```

**$.bar.adult[55][2].mf**

```text
>一说吃的就停不下来。
```

**$.bar.adult[55][2].fm**

```text
>一说吃的就停不下来。
```

**$.bar.adult[55][2].ff**

```text
>{主角称呼}，一说吃的就停不下来。
```

**$.bar.adult[55][3]**

```text
我现在都有点饿了。
```

**$.bar.adult[55][4]**

```text
>先看看有没有小吃。
```

**$.bar.adult[56][0]**

```text
平常的一点庆祝
```

**$.bar.adult[56][1].mm**

```text
{对方称呼}，今天有件小事终于办好了。
```

**$.bar.adult[56][1].mf**

```text
你好，今天有件小事终于办好了。
```

**$.bar.adult[56][1].fm**

```text
你好，{对方称呼}，今天有件小事终于办好了。
```

**$.bar.adult[56][1].ff**

```text
你好，今天有件小事终于办好了。
```

**$.bar.adult[56][2].mm**

```text
>{主角称呼}，哪件啊？
```

**$.bar.adult[56][2].mf**

```text
>哪件啊？
```

**$.bar.adult[56][2].fm**

```text
>哪件啊？
```

**$.bar.adult[56][2].ff**

```text
>{主角称呼}，哪件啊？
```

**$.bar.adult[56][3]**

```text
拖了好几天那个。
```

**$.bar.adult[56][4]**

```text
>哦，总算不用再惦记了。
```

**$.bar.adult[57][0]**

```text
玻璃响了一声
```

**$.bar.adult[57][1].mm**

```text
{对方称呼}，刚才杯子响了一下。
```

**$.bar.adult[57][1].mf**

```text
你好，刚才杯子响了一下。
```

**$.bar.adult[57][1].fm**

```text
你好，{对方称呼}，刚才杯子响了一下。
```

**$.bar.adult[57][1].ff**

```text
你好，刚才杯子响了一下。
```

**$.bar.adult[57][2].mm**

```text
>{主角称呼}，你袖子碰到了。
```

**$.bar.adult[57][2].mf**

```text
>你袖子碰到了。
```

**$.bar.adult[57][2].fm**

```text
>你袖子碰到了。
```

**$.bar.adult[57][2].ff**

```text
>{主角称呼}，你袖子碰到了。
```

**$.bar.adult[57][3]**

```text
还好没倒。
```

**$.bar.adult[57][4]**

```text
>往里面挪一点吧。
```

**$.bar.adult[58][0]**

```text
不硬找共同点
```

**$.bar.adult[58][1].mm**

```text
{对方称呼}，咱俩喜欢的好像不太一样。
```

**$.bar.adult[58][1].mf**

```text
你好，咱俩喜欢的好像不太一样。
```

**$.bar.adult[58][1].fm**

```text
你好，{对方称呼}，咱俩喜欢的好像不太一样。
```

**$.bar.adult[58][1].ff**

```text
你好，咱俩喜欢的好像不太一样。
```

**$.bar.adult[58][2].mm**

```text
>{主角称呼}，没事，你说说你听什么。
```

**$.bar.adult[58][2].mf**

```text
>没事，你说说你听什么。
```

**$.bar.adult[58][2].fm**

```text
>没事，你说说你听什么。
```

**$.bar.adult[58][2].ff**

```text
>{主角称呼}，没事，你说说你听什么。
```

**$.bar.adult[58][3]**

```text
我找首给你看看。
```

**$.bar.adult[58][4]**

```text
>好，我也听听。
```

**$.bar.adult[59][0]**

```text
留一段下次
```

**$.bar.adult[59][1].mm**

```text
{对方称呼}，今天先聊到这儿？
```

**$.bar.adult[59][1].mf**

```text
你好，今天先聊到这儿？
```

**$.bar.adult[59][1].fm**

```text
你好，{对方称呼}，今天先聊到这儿？
```

**$.bar.adult[59][1].ff**

```text
你好，今天先聊到这儿？
```

**$.bar.adult[59][2].mm**

```text
>{主角称呼}，好，下回碰见再聊。
```

**$.bar.adult[59][2].mf**

```text
>好，下回碰见再聊。
```

**$.bar.adult[59][2].fm**

```text
>好，下回碰见再聊。
```

**$.bar.adult[59][2].ff**

```text
>{主角称呼}，好，下回碰见再聊。
```

**$.bar.adult[59][3]**

```text
我先走了。
```

**$.bar.adult[59][4]**

```text
>嗯，路上慢点。
```
