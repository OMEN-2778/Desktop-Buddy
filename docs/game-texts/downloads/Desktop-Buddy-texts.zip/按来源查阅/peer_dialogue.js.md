# prototype/demo/peer_dialogue.js

**L8**

```text
`与${contactName(c)}的友谊增加 ${Number(gain.toFixed(2))}`
```

**L16**

```text
对方
```

**L37**

```text
的对话
```

**L37**

```text
的头像
```
