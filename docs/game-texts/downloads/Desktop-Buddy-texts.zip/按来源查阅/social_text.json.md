# prototype/demo/social_text.json

**$.conversations.familiar[0][0]**

```text
再聊·初识·名字对上了
```

**$.conversations.familiar[0][1]**

```text
>你好，是刚才遇到的那位吗？
```

**$.conversations.familiar[0][2]**

```text
对，是我。
```

**$.conversations.familiar[0][3]**

```text
>好，没加错就行。
```

**$.conversations.familiar[0][4]**

```text
嗯，我也存上了。
```

**$.conversations.familiar[1][0]**

```text
再聊·初识·先留个备注
```

**$.conversations.familiar[1][1]**

```text
>我把你名字存上了。
```

**$.conversations.familiar[1][2]**

```text
我也刚存。
```

**$.conversations.familiar[1][3]**

```text
>好，下次找你就方便了。
```

**$.conversations.familiar[1][4]**

```text
嗯。
```

**$.conversations.familiar[2][0]**

```text
再聊·初识·不知道怎么开头
```

**$.conversations.familiar[2][1]**

```text
>你好啊。
```

**$.conversations.familiar[2][2]**

```text
你好。
```

**$.conversations.familiar[2][3]**

```text
>突然不知道说什么了。
```

**$.conversations.familiar[2][4]**

```text
哈哈，那先打个招呼。
```

**$.conversations.familiar[3][0]**

```text
再聊·初识·消息发出去
```

**$.conversations.familiar[3][1]**

```text
>刚那条是不是没发出去？
```

**$.conversations.familiar[3][2]**

```text
这条收到了。
```

**$.conversations.familiar[3][3]**

```text
>哦，我还以为网断了。
```

**$.conversations.familiar[3][4]**

```text
我刚没看手机。
```

**$.conversations.familiar[4][0]**

```text
再聊·初识·简单问声好
```

**$.conversations.familiar[4][1]**

```text
>在忙吗？
```

**$.conversations.familiar[4][2]**

```text
这会儿还好，你呢？
```

**$.conversations.familiar[4][3]**

```text
>也是，刚空下来。
```

**$.conversations.familiar[4][4]**

```text
哦，你说。
```

**$.conversations.familiar[5][0]**

```text
再聊·初识·不是群发
```

**$.conversations.familiar[5][1]**

```text
>你好，这条不是群发啊。
```

**$.conversations.familiar[5][2]**

```text
看出来了。
```

**$.conversations.familiar[5][3]**

```text
>开头打得跟通知似的。
```

**$.conversations.familiar[5][4]**

```text
哈哈，我差点回个收到。
```

**$.conversations.familiar[6][0]**

```text
再聊·初识·头像认人
```

**$.conversations.familiar[6][1]**

```text
>刚才差点没认出你头像。
```

**$.conversations.familiar[6][2]**

```text
和本人差挺多？
```

**$.conversations.familiar[6][3]**

```text
>有点，我又看了一眼名字。
```

**$.conversations.familiar[6][4]**

```text
那我备注写清楚点。
```

**$.conversations.familiar[7][0]**

```text
再聊·初识·字打慢一点
```

**$.conversations.familiar[7][1]**

```text
>我打字慢一点啊。
```

**$.conversations.familiar[7][2]**

```text
没事，不急。
```

**$.conversations.familiar[7][3]**

```text
>刚才老按错。
```

**$.conversations.familiar[7][4]**

```text
看得懂，你发吧。
```

**$.conversations.familiar[8][0]**

```text
再聊·初识·想起刚才
```

**$.conversations.familiar[8][1]**

```text
>刚说的那个地方叫什么来着？
```

**$.conversations.familiar[8][2]**

```text
我发你看看。
```

**$.conversations.familiar[8][3]**

```text
>谢谢，刚没记住。
```

**$.conversations.familiar[8][4]**

```text
不客气。
```

**$.conversations.familiar[9][0]**

```text
再聊·初识·不必立即回
```

**$.conversations.familiar[9][1]**

```text
>你忙的话晚点回。
```

**$.conversations.familiar[9][2]**

```text
好，我一会儿看。
```

**$.conversations.familiar[9][3]**

```text
>嗯，不是什么急事。
```

**$.conversations.familiar[9][4]**

```text
行。
```

**$.conversations.familiar[10][0]**

```text
再聊·初识·打错的字
```

**$.conversations.familiar[10][1]**

```text
>上面有个字打错了。
```

**$.conversations.familiar[10][2]**

```text
看懂了。
```

**$.conversations.familiar[10][3]**

```text
>好，懒得撤回了。
```

**$.conversations.familiar[10][4]**

```text
嗯，没事。
```

**$.conversations.familiar[11][0]**

```text
再聊·初识·谢谢提醒
```

**$.conversations.familiar[11][1]**

```text
>刚才谢谢你提醒。
```

**$.conversations.familiar[11][2]**

```text
没事，顺便的。
```

**$.conversations.familiar[11][3]**

```text
>不然我真没看见。
```

**$.conversations.familiar[11][4]**

```text
还好没掉。
```

**$.conversations.familiar[12][0]**

```text
再聊·初识·聊过一点点
```

**$.conversations.familiar[12][1]**

```text
>刚才都没顾上多说两句。
```

**$.conversations.familiar[12][2]**

```text
嗯，有点赶。
```

**$.conversations.familiar[12][3]**

```text
>下回碰见再聊。
```

**$.conversations.familiar[12][4]**

```text
好啊。
```

**$.conversations.familiar[13][0]**

```text
再聊·初识·表情的选择
```

**$.conversations.familiar[13][1]**

```text
>本来想发个表情，挑半天。
```

**$.conversations.familiar[13][2]**

```text
随便发一个就行。
```

**$.conversations.familiar[13][3]**

```text
>结果越挑越不知道发哪个。
```

**$.conversations.familiar[13][4]**

```text
哈哈，先不挑了。
```

**$.conversations.familiar[14][0]**

```text
再聊·初识·有没有打扰
```

**$.conversations.familiar[14][1]**

```text
>这会儿发消息没打扰吧？
```

**$.conversations.familiar[14][2]**

```text
没有，你说。
```

**$.conversations.familiar[14][3]**

```text
>好，我就问一下。
```

**$.conversations.familiar[14][4]**

```text
嗯。
```

**$.conversations.familiar[15][0]**

```text
再聊·初识·记性有限
```

**$.conversations.familiar[15][1]**

```text
>我认人不太行，下回别见怪。
```

**$.conversations.familiar[15][2]**

```text
没事，叫我一声就行。
```

**$.conversations.familiar[15][3]**

```text
>嗯，名字记着了。
```

**$.conversations.familiar[15][4]**

```text
好，下次见。
```

**$.conversations.friend[0][0]**

```text
自动续费侦探
```

**$.conversations.friend[0][1]**

```text
>我刚翻账单，发现有个会员一直在扣钱。
```

**$.conversations.friend[0][2]**

```text
哪个？
```

**$.conversations.friend[0][3]**

```text
>一个好久没打开的软件，连密码都忘了。
```

**$.conversations.friend[0][4]**

```text
赶紧关了吧。我也去看看我的。
```

**$.conversations.friend[1][0]**

```text
购物车减负
```

**$.conversations.friend[1][1]**

```text
>我把购物车删了一半。
```

**$.conversations.friend[1][2]**

```text
买完了？
```

**$.conversations.friend[1][3]**

```text
>没买，越看越觉得用不上。
```

**$.conversations.friend[1][4]**

```text
那挺好啊，省下钱吃顿好的。
```

**$.conversations.friend[2][0]**

```text
路边的空椅子
```

**$.conversations.friend[2][1]**

```text
>我路上找了张椅子坐，结果不太想起来了。
```

**$.conversations.friend[2][2]**

```text
累啦？
```

**$.conversations.friend[2][3]**

```text
>有点。本来还想去另一家店。
```

**$.conversations.friend[2][4]**

```text
下回再去呗，店又不跑。
```

**$.conversations.friend[3][0]**

```text
袋子里的袋子
```

**$.conversations.friend[3][1]**

```text
>我家怎么能翻出这么多袋子啊。
```

**$.conversations.friend[3][2]**

```text
我家也是，一抽屉。
```

**$.conversations.friend[3][3]**

```text
>这到底留到什么时候用？
```

**$.conversations.friend[3][4]**

```text
挑几个结实的，剩下的扔了吧。
```

**$.conversations.friend[4][0]**

```text
发错的语音
```

**$.conversations.friend[4][1]**

```text
>我给自己发了条语音。
```

**$.conversations.friend[4][2]**

```text
提醒自己拿钥匙？
```

**$.conversations.friend[4][3]**

```text
>对，结果听见自己的声音又不想点开。
```

**$.conversations.friend[4][4]**

```text
哈哈，钥匙拿了就行。
```

**$.conversations.friend[5][0]**

```text
冰箱磁铁
```

**$.conversations.friend[5][1]**

```text
>我贴了个少吃零食的冰箱贴。
```

**$.conversations.friend[5][2]**

```text
然后呢？
```

**$.conversations.friend[5][3]**

```text
>拿零食的时候顺手把它扶正了。
```

**$.conversations.friend[5][4]**

```text
你还挺照顾它面子的。
```

**$.conversations.friend[6][0]**

```text
导航的脾气
```

**$.conversations.friend[6][1]**

```text
>我没听导航的，多绕了好一段。
```

**$.conversations.friend[6][2]**

```text
又想抄近路？
```

**$.conversations.friend[6][3]**

```text
>嗯，觉得自己认得。
```

**$.conversations.friend[6][4]**

```text
下次先看看路，别光觉得。
```

**$.conversations.friend[7][0]**

```text
袜子失踪案
```

**$.conversations.friend[7][1]**

```text
>我一只袜子又找不着了。
```

**$.conversations.friend[7][2]**

```text
床底看了没？
```

**$.conversations.friend[7][3]**

```text
>看了，翻出另外两只。
```

**$.conversations.friend[7][4]**

```text
行，至少找袜子这事没白忙。
```

**$.conversations.friend[8][0]**

```text
安静的快递
```

**$.conversations.friend[8][1]**

```text
>买了一颗纽扣，寄来个挺大的盒子。
```

**$.conversations.friend[8][2]**

```text
里面垫满纸？
```

**$.conversations.friend[8][3]**

```text
>对，拆了好几层才看见。
```

**$.conversations.friend[8][4]**

```text
别顺手把纽扣和纸一起扔了啊。
```

**$.conversations.friend[9][0]**

```text
地图收藏夹
```

**$.conversations.friend[9][1]**

```text
>我收藏了好多店，基本没去过。
```

**$.conversations.friend[9][2]**

```text
挑一家近的先去啊。
```

**$.conversations.friend[9][3]**

```text
>看着都想去，就选不出来。
```

**$.conversations.friend[9][4]**

```text
先发两家给我，我帮你纠结。
```

**$.conversations.friend[10][0]**

```text
学会拒绝
```

**$.conversations.friend[10][1]**

```text
>有件事我不想帮，刚才终于说了。
```

**$.conversations.friend[10][2]**

```text
对方怎么回？
```

**$.conversations.friend[10][3]**

```text
>说没事，找别人了。
```

**$.conversations.friend[10][4]**

```text
那不挺好，我还以为要扯半天。
```

**$.conversations.friend[11][0]**

```text
盆栽新叶
```

**$.conversations.friend[11][1]**

```text
>我那盆绿植长新叶子了。
```

**$.conversations.friend[11][2]**

```text
拍我看看。
```

**$.conversations.friend[11][3]**

```text
>等会儿啊，挺小一片的。
```

**$.conversations.friend[11][4]**

```text
看见了，还真长出来了。
```

**$.conversations.friend[12][0]**

```text
相册清理
```

**$.conversations.friend[12][1]**

```text
>我本来想删照片，看着看着忘删了。
```

**$.conversations.friend[12][2]**

```text
又翻以前出去玩的照片了吧。
```

**$.conversations.friend[12][3]**

```text
>嗯，一下看了好久。
```

**$.conversations.friend[12][4]**

```text
那先留着呗，下次别拍那么多重样的。
```

**$.conversations.friend[13][0]**

```text
门口的鞋
```

**$.conversations.friend[13][1]**

```text
>我差点穿两只不一样的鞋出门。
```

**$.conversations.friend[13][2]**

```text
哈哈哈，真穿出去了？
```

**$.conversations.friend[13][3]**

```text
>走到门口才发现。
```

**$.conversations.friend[13][4]**

```text
还好，还来得及假装没这回事。
```

**$.conversations.friend[14][0]**

```text
纸质地图
```

**$.conversations.friend[14][1]**

```text
>我翻出张旧地图，好多地方都变了。
```

**$.conversations.friend[14][2]**

```text
哪里来的？
```

**$.conversations.friend[14][3]**

```text
>以前随手拿的，夹在一本书里。
```

**$.conversations.friend[14][4]**

```text
先别扔，拍张给我看看。
```

**$.conversations.friend[15][0]**

```text
新买的笔
```

**$.conversations.friend[15][1]**

```text
>我新买的笔还挺好写。
```

**$.conversations.friend[15][2]**

```text
什么笔？
```

**$.conversations.friend[15][3]**

```text
>一支普通的，就是不怎么断墨。
```

**$.conversations.friend[15][4]**

```text
链接发我，我那支写着写着就没了。
```

**$.conversations.close[0][0]**

```text
安静的快递
```

**$.conversations.close[0][1]**

```text
>买了一颗纽扣，寄来个挺大的盒子。
```

**$.conversations.close[0][2]**

```text
里面垫满纸？
```

**$.conversations.close[0][3]**

```text
>对，拆了好几层才看见。
```

**$.conversations.close[0][4]**

```text
别顺手把纽扣和纸一起扔了啊。
```

**$.conversations.close[1][0]**

```text
地图收藏夹
```

**$.conversations.close[1][1]**

```text
>我收藏了好多店，基本没去过。
```

**$.conversations.close[1][2]**

```text
挑一家近的先去啊。
```

**$.conversations.close[1][3]**

```text
>看着都想去，就选不出来。
```

**$.conversations.close[1][4]**

```text
先发两家给我，我帮你纠结。
```

**$.conversations.close[2][0]**

```text
学会拒绝
```

**$.conversations.close[2][1]**

```text
>有件事我不想帮，刚才终于说了。
```

**$.conversations.close[2][2]**

```text
对方怎么回？
```

**$.conversations.close[2][3]**

```text
>说没事，找别人了。
```

**$.conversations.close[2][4]**

```text
那不挺好，我还以为要扯半天。
```

**$.conversations.close[3][0]**

```text
盆栽新叶
```

**$.conversations.close[3][1]**

```text
>我那盆绿植长新叶子了。
```

**$.conversations.close[3][2]**

```text
拍我看看。
```

**$.conversations.close[3][3]**

```text
>等会儿啊，挺小一片的。
```

**$.conversations.close[3][4]**

```text
看见了，还真长出来了。
```

**$.conversations.close[4][0]**

```text
相册清理
```

**$.conversations.close[4][1]**

```text
>我本来想删照片，看着看着忘删了。
```

**$.conversations.close[4][2]**

```text
又翻以前出去玩的照片了吧。
```

**$.conversations.close[4][3]**

```text
>嗯，一下看了好久。
```

**$.conversations.close[4][4]**

```text
那先留着呗，下次别拍那么多重样的。
```

**$.conversations.close[5][0]**

```text
门口的鞋
```

**$.conversations.close[5][1]**

```text
>我差点穿两只不一样的鞋出门。
```

**$.conversations.close[5][2]**

```text
哈哈哈，真穿出去了？
```

**$.conversations.close[5][3]**

```text
>走到门口才发现。
```

**$.conversations.close[5][4]**

```text
还好，还来得及假装没这回事。
```

**$.conversations.close[6][0]**

```text
纸质地图
```

**$.conversations.close[6][1]**

```text
>我翻出张旧地图，好多地方都变了。
```

**$.conversations.close[6][2]**

```text
哪里来的？
```

**$.conversations.close[6][3]**

```text
>以前随手拿的，夹在一本书里。
```

**$.conversations.close[6][4]**

```text
先别扔，拍张给我看看。
```

**$.conversations.close[7][0]**

```text
新买的笔
```

**$.conversations.close[7][1]**

```text
>我新买的笔还挺好写。
```

**$.conversations.close[7][2]**

```text
什么笔？
```

**$.conversations.close[7][3]**

```text
>一支普通的，就是不怎么断墨。
```

**$.conversations.close[7][4]**

```text
链接发我，我那支写着写着就没了。
```

**$.conversations.close[8][0]**

```text
薄荷的野心
```

**$.conversations.close[8][1]**

```text
>我的薄荷快挤满花盆了。
```

**$.conversations.close[8][2]**

```text
那剪一点啊。
```

**$.conversations.close[8][3]**

```text
>怕我下手重了。
```

**$.conversations.close[8][4]**

```text
先剪一小撮，别整盆端走就行。
```

**$.conversations.close[9][0]**

```text
冷笑话存档
```

**$.conversations.close[9][1]**

```text
>你上次那个冷笑话，我后来讲给别人听了。
```

**$.conversations.close[9][2]**

```text
有人笑吗？
```

**$.conversations.close[9][3]**

```text
>有一个，说没听懂。
```

**$.conversations.close[9][4]**

```text
那跟你当时反应差不多。
```

**$.conversations.close[10][0]**

```text
数字断舍离
```

**$.conversations.close[10][1]**

```text
>我退了几个好久不说话的群。
```

**$.conversations.close[10][2]**

```text
是不是清净点了？
```

**$.conversations.close[10][3]**

```text
>嗯，不过有个群又把我拉回去了。
```

**$.conversations.close[10][4]**

```text
哈哈，看来他们还挺舍不得你。
```

**$.conversations.close[11][0]**

```text
透明手机壳
```

**$.conversations.close[11][1]**

```text
>我手机壳里那张票都褪色了。
```

**$.conversations.close[11][2]**

```text
还夹着啊？
```

**$.conversations.close[11][3]**

```text
>嗯，懒得换，看着也习惯了。
```

**$.conversations.close[11][4]**

```text
你先擦擦壳吧，边都发黄了。
```

**$.conversations.close[12][0]**

```text
电梯里的镜子
```

**$.conversations.close[12][1]**

```text
>我在电梯里才发现衣领翻着。
```

**$.conversations.close[12][2]**

```text
翻多久了？
```

**$.conversations.close[12][3]**

```text
>不知道，已经在外面走一圈了。
```

**$.conversations.close[12][4]**

```text
没事，应该没人盯着你衣领看。
```

**$.conversations.close[13][0]**

```text
旧书签
```

**$.conversations.close[13][1]**

```text
>书里掉出一张纸，写着下次从这里看。
```

**$.conversations.close[13][2]**

```text
然后你看过这页没？
```

**$.conversations.close[13][3]**

```text
>完全没印象。
```

**$.conversations.close[13][4]**

```text
行，那这回真从这里看。
```

**$.conversations.close[14][0]**

```text
存下的表情
```

**$.conversations.close[14][1]**

```text
>我存了个表情，但一直没机会发。
```

**$.conversations.close[14][2]**

```text
先发我看看。
```

**$.conversations.close[14][3]**

```text
>发了。
```

**$.conversations.close[14][4]**

```text
哈哈哈，这个你留着，下回肯定用得上。
```

**$.conversations.close[15][0]**

```text
剪胶带的技巧
```

**$.conversations.close[15][1]**

```text
>我终于想起用完胶带折个角了。
```

**$.conversations.close[15][2]**

```text
你以前是不是每次都找半天？
```

**$.conversations.close[15][3]**

```text
>对，抠得我手指疼。
```

**$.conversations.close[15][4]**

```text
我也老忘，得贴张纸提醒一下。
```

**$.conversations.best[0][0]**

```text
数字断舍离
```

**$.conversations.best[0][1]**

```text
>我退了几个好久不说话的群。
```

**$.conversations.best[0][2]**

```text
是不是清净点了？
```

**$.conversations.best[0][3]**

```text
>嗯，不过有个群又把我拉回去了。
```

**$.conversations.best[0][4]**

```text
哈哈，看来他们还挺舍不得你。
```

**$.conversations.best[1][0]**

```text
透明手机壳
```

**$.conversations.best[1][1]**

```text
>我手机壳里那张票都褪色了。
```

**$.conversations.best[1][2]**

```text
还夹着啊？
```

**$.conversations.best[1][3]**

```text
>嗯，懒得换，看着也习惯了。
```

**$.conversations.best[1][4]**

```text
你先擦擦壳吧，边都发黄了。
```

**$.conversations.best[2][0]**

```text
电梯里的镜子
```

**$.conversations.best[2][1]**

```text
>我在电梯里才发现衣领翻着。
```

**$.conversations.best[2][2]**

```text
翻多久了？
```

**$.conversations.best[2][3]**

```text
>不知道，已经在外面走一圈了。
```

**$.conversations.best[2][4]**

```text
没事，应该没人盯着你衣领看。
```

**$.conversations.best[3][0]**

```text
旧书签
```

**$.conversations.best[3][1]**

```text
>书里掉出一张纸，写着下次从这里看。
```

**$.conversations.best[3][2]**

```text
然后你看过这页没？
```

**$.conversations.best[3][3]**

```text
>完全没印象。
```

**$.conversations.best[3][4]**

```text
行，那这回真从这里看。
```

**$.conversations.best[4][0]**

```text
存下的表情
```

**$.conversations.best[4][1]**

```text
>我存了个表情，但一直没机会发。
```

**$.conversations.best[4][2]**

```text
先发我看看。
```

**$.conversations.best[4][3]**

```text
>发了。
```

**$.conversations.best[4][4]**

```text
哈哈哈，这个你留着，下回肯定用得上。
```

**$.conversations.best[5][0]**

```text
剪胶带的技巧
```

**$.conversations.best[5][1]**

```text
>我终于想起用完胶带折个角了。
```

**$.conversations.best[5][2]**

```text
你以前是不是每次都找半天？
```

**$.conversations.best[5][3]**

```text
>对，抠得我手指疼。
```

**$.conversations.best[5][4]**

```text
我也老忘，得贴张纸提醒一下。
```

**$.conversations.best[6][0]**

```text
耳机的左右
```

**$.conversations.best[6][1]**

```text
>我耳机好像一直戴反了。
```

**$.conversations.best[6][2]**

```text
你耳朵没觉得别扭？
```

**$.conversations.best[6][3]**

```text
>有一点，以为它就长这样。
```

**$.conversations.best[6][4]**

```text
你也太能凑合了吧。
```

**$.conversations.best[7][0]**

```text
忘带会员卡
```

**$.conversations.best[7][1]**

```text
>买完东西才想起能积分。
```

**$.conversations.best[7][2]**

```text
能补吗？
```

**$.conversations.best[7][3]**

```text
>问了，说下次记得。
```

**$.conversations.best[7][4]**

```text
那算了，别为了两分再跑回去。
```

**$.conversations.best[8][0]**

```text
一根充电线
```

**$.conversations.best[8][1]**

```text
>我找到那根能用的线了。
```

**$.conversations.best[8][2]**

```text
在哪儿？
```

**$.conversations.best[8][3]**

```text
>在一堆坏线里面。
```

**$.conversations.best[8][4]**

```text
坏的扔掉几根吧，不然还得再找。
```

**$.conversations.best[9][0]**

```text
自动更正
```

**$.conversations.best[9][1]**

```text
>输入法把我一句正经话改得乱七八糟。
```

**$.conversations.best[9][2]**

```text
发出去了？
```

**$.conversations.best[9][3]**

```text
>发了，对方回了我三个问号。
```

**$.conversations.best[9][4]**

```text
哈哈，先解释一下吧。
```

**$.conversations.best[10][0]**

```text
口袋里的硬币
```

**$.conversations.best[10][1]**

```text
>我口袋里摸出一块钱。
```

**$.conversations.best[10][2]**

```text
那你先收好。
```

**$.conversations.best[10][3]**

```text
>我还以为早就花了。
```

**$.conversations.best[10][4]**

```text
说不定你还有别的衣服没翻呢。
```

**$.conversations.best[11][0]**

```text
新鲜的夸奖
```

**$.conversations.best[11][1]**

```text
>有人夸我做得仔细，我一下不知道怎么回。
```

**$.conversations.best[11][2]**

```text
说谢谢啊。
```

**$.conversations.best[11][3]**

```text
>说了，但有点不习惯。
```

**$.conversations.best[11][4]**

```text
多收几次就习惯啦。
```

**$.conversations.best[12][0]**

```text
二手书的字
```

**$.conversations.best[12][1]**

```text
>我买的旧书上有人写批注。
```

**$.conversations.best[12][2]**

```text
写什么了？
```

**$.conversations.best[12][3]**

```text
>这一段没看懂。刚好，我也没懂。
```

**$.conversations.best[12][4]**

```text
哈哈，那你看看后面有没有答案。
```

**$.conversations.best[13][0]**

```text
小店的招牌
```

**$.conversations.best[13][1]**

```text
>路边那家店招牌有个字写歪了。
```

**$.conversations.best[13][2]**

```text
哪家？
```

**$.conversations.best[13][3]**

```text
>转角那家，小小的那个。
```

**$.conversations.best[13][4]**

```text
我下次路过也看看，我之前都没注意。
```

**$.conversations.best[14][0]**

```text
关掉的闹钟
```

**$.conversations.best[14][1]**

```text
>我删了一个早就不用的闹钟。
```

**$.conversations.best[14][2]**

```text
还一直响呢？
```

**$.conversations.best[14][3]**

```text
>没响，但老看见它就觉得有事。
```

**$.conversations.best[14][4]**

```text
删了好，真要用再定呗。
```

**$.conversations.best[15][0]**

```text
钥匙的标签
```

**$.conversations.best[15][1]**

```text
>我给钥匙贴标签，贴完还是分不清。
```

**$.conversations.best[15][2]**

```text
你写了啥？
```

**$.conversations.best[15][3]**

```text
>都写的家里。
```

**$.conversations.best[15][4]**

```text
你倒是写上开哪扇门啊。
```

**$.visitTalks[0][0]**

```text
玄关的鞋
```

**$.visitTalks[0][1]**

```text
>鞋放这儿对吗？
```

**$.visitTalks[0][2]**

```text
对，靠墙就好。
```

**$.visitTalks[0][3]**

```text
>我往里放一点。
```

**$.visitTalks[1][0]**

```text
第一次坐下
```

**$.visitTalks[1][1]**

```text
>坐这儿还能看见那棵树。
```

**$.visitTalks[1][2]**

```text
嗯，站门口反而看不全。
```

**$.visitTalks[1][3]**

```text
>怪不得你喜欢坐这儿。
```

**$.visitTalks[2][0]**

```text
杯子的选择
```

**$.visitTalks[2][1]**

```text
杯子不成套，随便拿一个。
```

**$.visitTalks[2][2]**

```text
>那我拿小的这个。
```

**$.visitTalks[2][3]**

```text
行，那个好拿。
```

**$.visitTalks[3][0]**

```text
窗边的风
```

**$.visitTalks[3][1]**

```text
>窗帘都吹起来了。
```

**$.visitTalks[3][2]**

```text
风有点大，要关小点吗？
```

**$.visitTalks[3][3]**

```text
>留条缝吧，还挺凉快。
```

**$.visitTalks[4][0]**

```text
分享点心
```

**$.visitTalks[4][1]**

```text
这份点心一人一半吧。
```

**$.visitTalks[4][2]**

```text
>我来掰，你先选。
```

**$.visitTalks[4][3]**

```text
行，别掉地上就好。
```

**$.visitTalks[5][0]**

```text
沙发的空位
```

**$.visitTalks[5][1]**

```text
>坐这边挡着你吗？
```

**$.visitTalks[5][2]**

```text
没有，你坐吧。
```

**$.visitTalks[5][3]**

```text
>好，我往后靠点。
```

**$.visitTalks[6][0]**

```text
随便聊聊
```

**$.visitTalks[6][1]**

```text
>今天没安排别的事。
```

**$.visitTalks[6][2]**

```text
那坐着聊会儿。
```

**$.visitTalks[6][3]**

```text
>行，我也不想再往外跑。
```

**$.visitTalks[7][0]**

```text
一起听雨
```

**$.visitTalks[7][1]**

```text
雨好像又大了。
```

**$.visitTalks[7][2]**

```text
>还好进屋了，刚才差点淋到。
```

**$.visitTalks[7][3]**

```text
等小一点再走吧。
```

**$.visitTalks[8][0]**

```text
电视的背景声
```

**$.visitTalks[8][1]**

```text
>刚才电视里说什么来着？
```

**$.visitTalks[8][2]**

```text
没听，我们光说话了。
```

**$.visitTalks[8][3]**

```text
>那我把声音调小点。
```

**$.visitTalks[9][0]**

```text
桌角的阳光
```

**$.visitTalks[9][1]**

```text
这块光每天下午都会照过来。
```

**$.visitTalks[9][2]**

```text
>晒在桌上会热吗？
```

**$.visitTalks[9][3]**

```text
会，所以杯子别放这儿太久。
```

**$.visitTalks[10][0]**

```text
不急着说话
```

**$.visitTalks[10][1]**

```text
>我刚才是不是半天没出声？
```

**$.visitTalks[10][2]**

```text
我也走神了。
```

**$.visitTalks[10][3]**

```text
>那先歇会儿。
```

**$.visitTalks[11][0]**

```text
一口热水
```

**$.visitTalks[11][1]**

```text
水烫，先别喝。
```

**$.visitTalks[11][2]**

```text
>我先捧着，手有点凉。
```

**$.visitTalks[11][3]**

```text
好，过会儿再喝。
```

**$.visitTalks[12][0]**

```text
门外的脚步
```

**$.visitTalks[12][1]**

```text
刚以为有人敲门。
```

**$.visitTalks[12][2]**

```text
>不是吗？
```

**$.visitTalks[12][3]**

```text
不是，脚步已经过去了。
```

**$.visitTalks[13][0]**

```text
光线变了
```

**$.visitTalks[13][1]**

```text
>是不是快到傍晚了？
```

**$.visitTalks[13][2]**

```text
嗯，我开灯吧。
```

**$.visitTalks[13][3]**

```text
>再坐一下我就该回去了。
```

**$.visitTalks[14][0]**

```text
熟悉的小屋
```

**$.visitTalks[14][1]**

```text
>你这屋坐着挺舒服。
```

**$.visitTalks[14][2]**

```text
就是有点挤，东西太多。
```

**$.visitTalks[14][3]**

```text
>还行，走路不碍事。
```

**$.visitTalks[15][0]**

```text
笑到忘词
```

**$.visitTalks[15][1]**

```text
我刚讲到哪儿了？
```

**$.visitTalks[15][2]**

```text
>讲到盐和糖放一起了。
```

**$.visitTalks[15][3]**

```text
哦对，后来就拿错了。
```

**$.visitTalks[16][0]**

```text
给植物打招呼
```

**$.visitTalks[16][1]**

```text
>这盆比上次精神点了。
```

**$.visitTalks[16][2]**

```text
最近没忘浇水。
```

**$.visitTalks[16][3]**

```text
>还真得记着，不然忙起来就忘。
```

**$.visitTalks[17][0]**

```text
窗外的小鸟
```

**$.visitTalks[17][1]**

```text
那鸟又落窗边了。
```

**$.visitTalks[17][2]**

```text
>我们动一下它就跑了吧。
```

**$.visitTalks[17][3]**

```text
先别动，看看它要干什么。
```

**$.visitTalks[18][0]**

```text
不一样的视角
```

**$.visitTalks[18][1]**

```text
>这幅画实物比照片好看。
```

**$.visitTalks[18][2]**

```text
我是不是拍糊了？
```

**$.visitTalks[18][3]**

```text
>有点，还有反光。
```

**$.visitTalks[19][0]**

```text
聊到饿了
```

**$.visitTalks[19][1]**

```text
说着说着饿了。
```

**$.visitTalks[19][2]**

```text
>你先吃饭，别等着陪我聊。
```

**$.visitTalks[19][3]**

```text
嗯，吃完接着说。
```

**$.visitTalks[20][0]**

```text
来的路上
```

**$.visitTalks[20][1]**

```text
>拐角那边影子挺好看。
```

**$.visitTalks[20][2]**

```text
树影？
```

**$.visitTalks[20][3]**

```text
>嗯，刚才想拍一张，没拍清。
```

**$.visitTalks[21][0]**

```text
帮忙收杯子
```

**$.visitTalks[21][1]**

```text
>空杯子我放这儿了。
```

**$.visitTalks[21][2]**

```text
好，一会儿收。
```

**$.visitTalks[21][3]**

```text
>要洗的时候叫我。
```

**$.visitTalks[22][0]**

```text
讲一个糗事
```

**$.visitTalks[22][1]**

```text
讲个糗事，你先别笑。
```

**$.visitTalks[22][2]**

```text
>你一说这个我就想笑。
```

**$.visitTalks[22][3]**

```text
我还没开始呢。
```

**$.visitTalks[23][0]**

```text
晚风进屋
```

**$.visitTalks[23][1]**

```text
>风凉了，要不要关小点？
```

**$.visitTalks[23][2]**

```text
好，留条缝就行。
```

**$.visitTalks[23][3]**

```text
>这样呢？
```

**$.visitTalks[24][0]**

```text
一起发呆
```

**$.visitTalks[24][1]**

```text
我刚才什么都没想。
```

**$.visitTalks[24][2]**

```text
>我也是，坐着就犯懒。
```

**$.visitTalks[24][3]**

```text
那再歇一会儿。
```

**$.visitTalks[25][0]**

```text
小小的默契
```

**$.visitTalks[25][1]**

```text
刚想问你要不要水。
```

**$.visitTalks[25][2]**

```text
>我正想递杯子呢。
```

**$.visitTalks[25][3]**

```text
来，我给你倒。
```

**$.visitTalks[26][0]**

```text
客人的客人
```

**$.visitTalks[26][1]**

```text
>窗台上有只小虫。
```

**$.visitTalks[26][2]**

```text
哪儿？
```

**$.visitTalks[26][3]**

```text
>边上那个，没进来。
```

**$.visitTalks[27][0]**

```text
下一次的约定
```

**$.visitTalks[27][1]**

```text
>下次带点东西来吃。
```

**$.visitTalks[27][2]**

```text
不用特意买。
```

**$.visitTalks[27][3]**

```text
>顺路买一点，不带多。
```

**$.visitTalks[28][0]**

```text
灯亮起来
```

**$.visitTalks[28][1]**

```text
天暗了，开灯吧。
```

**$.visitTalks[28][2]**

```text
>都这个点了？
```

**$.visitTalks[28][3]**

```text
是啊，刚才没看时间。
```

**$.visitTalks[29][0]**

```text
不用客气
```

**$.visitTalks[29][1]**

```text
>我待得是不是有点久了？
```

**$.visitTalks[29][2]**

```text
没事，你不急就再坐会儿。
```

**$.visitTalks[29][3]**

```text
>那我把这句话讲完。
```

**$.visitTalks[30][0]**

```text
靠垫的位置
```

**$.visitTalks[30][1]**

```text
靠枕给你。
```

**$.visitTalks[30][2]**

```text
>谢谢，刚想拿。
```

**$.visitTalks[30][3]**

```text
垫腰后面吧。
```

**$.visitTalks[31][0]**

```text
想起旧话题
```

**$.visitTalks[31][1]**

```text
>你上回那个事后来怎么样？
```

**$.visitTalks[31][2]**

```text
弄好了，总算。
```

**$.visitTalks[31][3]**

```text
>哦，那就好，我一直想问。
```

**$.visitTalks[32][0]**

```text
厨房的香气
```

**$.visitTalks[32][1]**

```text
>闻到饭香了。
```

**$.visitTalks[32][2]**

```text
嗯，快好了。
```

**$.visitTalks[32][3]**

```text
>那你先忙，别顾着回我。
```

**$.visitTalks[33][0]**

```text
没说完的句子
```

**$.visitTalks[33][1]**

```text
我又忘了刚才要说什么。
```

**$.visitTalks[33][2]**

```text
>往前想一下？
```

**$.visitTalks[33][3]**

```text
等会儿，好像跟买东西有关。
```

**$.visitTalks[34][0]**

```text
两个人的下午
```

**$.visitTalks[34][1]**

```text
平时家里没这么多人声。
```

**$.visitTalks[34][2]**

```text
>吵不吵？
```

**$.visitTalks[34][3]**

```text
不吵，你接着说。
```

**$.visitTalks[35][0]**

```text
告别前再坐会儿
```

**$.visitTalks[35][1]**

```text
>都准备走了，又想起个事。
```

**$.visitTalks[35][2]**

```text
那说完再走。
```

**$.visitTalks[35][3]**

```text
>好，这回真的就一件。
```

**$.visitTalks[36][0]**

```text
看见一颗星
```

**$.visitTalks[36][1]**

```text
>外面那个亮点是星星吗？
```

**$.visitTalks[36][2]**

```text
我也看不清。
```

**$.visitTalks[36][3]**

```text
>等会儿再看看，是不是飞机。
```

**$.visitTalks[37][0]**

```text
认真道谢
```

**$.visitTalks[37][1]**

```text
今天谢谢你过来。
```

**$.visitTalks[37][2]**

```text
>我也没什么事，刚好坐坐。
```

**$.visitTalks[37][3]**

```text
下次有空再来。
```

**$.visitTalks[38][0]**

```text
分享一段旋律
```

**$.visitTalks[38][1]**

```text
脑子里一直有个调。
```

**$.visitTalks[38][2]**

```text
>哼一下，我听听。
```

**$.visitTalks[38][3]**

```text
你先别笑，我可能哼不准。
```

**$.visitTalks[39][0]**

```text
平安到家
```

**$.visitTalks[39][1]**

```text
>到家给你发消息。
```

**$.visitTalks[39][2]**

```text
好，路上慢点。
```

**$.visitTalks[39][3]**

```text
>嗯，不急着走。
```

**$.visitEvents[0][0]**

```text
杯口的热气
```

**$.visitEvents[0][1]**

```text
{朋友}端着杯子吹气，后半句话没听清。
```

**$.visitEvents[0][2]**

```text
刚才说什么？喝完再说，不急。
```

**$.visitEvents[1][0]**

```text
歪掉的靠垫
```

**$.visitEvents[1][1]**

```text
靠垫滑到沙发边，{朋友}顺手扶了一下。
```

**$.visitEvents[1][2]**

```text
放后面吧，别掉地上。
```

**$.visitEvents[2][0]**

```text
窗边的鸟影
```

**$.visitEvents[2][1]**

```text
一只鸟从窗前飞过，两人同时转头看了看。
```

**$.visitEvents[2][2]**

```text
刚才那只挺大的，你看见没？
```

**$.visitEvents[3][0]**

```text
共用的笑点
```

**$.visitEvents[3][1]**

```text
一个词说岔了，两个人笑了好一会儿。
```

**$.visitEvents[3][2]**

```text
不行，你先别再说那两个字了。
```

**$.visitEvents[4][0]**

```text
片刻安静
```

**$.visitEvents[4][1]**

```text
话题停下来，两个人各自坐了一会儿。
```

**$.visitEvents[4][2]**

```text
我靠会儿，你想喝水自己倒啊。
```

**$.visitEvents[5][0]**

```text
阳光挪位
```

**$.visitEvents[5][1]**

```text
聊了会儿天，才发现阳光已经从桌子移到地上。
```

**$.visitEvents[5][2]**

```text
刚才还照在杯子上呢。
```

**$.visitEvents[6][0]**

```text
杯子碰响
```

**$.visitEvents[6][1]**

```text
两个杯子碰了一下，{朋友}连忙扶稳杯子。
```

**$.visitEvents[6][2]**

```text
轻点，水都快晃出来了。
```

**$.visitEvents[7][0]**

```text
想起前一句
```

**$.visitEvents[7][1]**

```text
{朋友}总算想起刚才没想起来的那个词。
```

**$.visitEvents[7][2]**

```text
对对，就是这个，我也想半天。
```

**$.visitEvents[8][0]**

```text
一阵晚风
```

**$.visitEvents[8][1]**

```text
一阵风把窗帘吹过来，两人往旁边让了一点。
```

**$.visitEvents[8][2]**

```text
要不把窗关小点？
```

**$.visitEvents[9][0]**

```text
讲到口渴
```

**$.visitEvents[9][1]**

```text
聊到一半，两个人都伸手去拿杯子。
```

**$.visitEvents[9][2]**

```text
你也渴了啊，刚说了好半天。
```

**$.visitEvents[10][0]**

```text
慢下来的下午
```

**$.visitEvents[10][1]**

```text
本来只想坐片刻，结果聊了大半个下午。
```

**$.visitEvents[10][2]**

```text
我都忘看时间了。
```

**$.visitEvents[11][0]**

```text
落在桌上的光
```

**$.visitEvents[11][1]**

```text
杯底在桌上留了一圈水印。
```

**$.visitEvents[11][2]**

```text
垫子呢？先擦一下。
```

**$.visitEvents[12][0]**

```text
不用解释的笑
```

**$.visitEvents[12][1]**

```text
{朋友}提起一件糗事，才说到一半两个人就笑了。
```

**$.visitEvents[12][2]**

```text
好了，知道你说哪件了。
```

**$.visitEvents[13][0]**

```text
门外经过的人
```

**$.visitEvents[13][1]**

```text
门外有脚步声，两人停了一下，又接着聊。
```

**$.visitEvents[13][2]**

```text
不是敲门。刚才说到哪儿了？
```

**$.visitEvents[14][0]**

```text
坐得更近一点
```

**$.visitEvents[14][1]**

```text
{朋友}声音有点小，两个人挪近了一点。
```

**$.visitEvents[14][2]**

```text
这回听得清了，你说吧。
```

**$.visitEvents[15][0]**

```text
找不到的词
```

**$.visitEvents[15][1]**

```text
一个词两人都想不起来，比画了半天才说明白。
```

**$.visitEvents[15][2]**

```text
哦，是那个！我知道你说什么了。
```

**$.visitEvents[16][0]**

```text
没有拍的照片
```

**$.visitEvents[16][1]**

```text
本来想拍照，两人聊着聊着忘了拿手机。
```

**$.visitEvents[16][2]**

```text
算了，下次再拍吧。
```

**$.visitEvents[17][0]**

```text
新的称呼
```

**$.visitEvents[17][1]**

```text
{朋友}换了个称呼叫人，主角愣了一下才应声。
```

**$.visitEvents[17][2]**

```text
哎，我还以为你叫别人呢。
```

**$.visitEvents[18][0]**

```text
电视里的巧合
```

**$.visitEvents[18][1]**

```text
电视里刚好出现聊天提到的地方，两人同时指了过去。
```

**$.visitEvents[18][2]**

```text
就这儿！刚才说的就是这儿。
```

**$.visitEvents[19][0]**

```text
柔软的停顿
```

**$.visitEvents[19][1]**

```text
{朋友}听主角说完，等了片刻才接话。
```

**$.visitEvents[19][2]**

```text
我说得有点乱，你听懂了吧？
```

**$.visitEvents[20][0]**

```text
被记住的小事
```

**$.visitEvents[20][1]**

```text
一件主角快忘了的小事，{朋友}倒记得清楚。
```

**$.visitEvents[20][2]**

```text
你还记着啊？我都快忘了。
```

**$.visitEvents[21][0]**

```text
重新热闹起来
```

**$.visitEvents[21][1]**

```text
话题刚停，一个人忽然想起另一件事，又说了起来。
```

**$.visitEvents[21][2]**

```text
你刚怎么不说，差点让你憋忘了。
```

**$.visitEvents[22][0]**

```text
舍不得结束
```

**$.visitEvents[22][1]**

```text
本来准备告别，两个人站在门口又聊起来。
```

**$.visitEvents[22][2]**

```text
再讲一句，说完你真得回去了。
```

**$.visitEvents[23][0]**

```text
今天的新回忆
```

**$.visitEvents[23][1]**

```text
送走{朋友}以后，主角才发现桌上的水还剩大半杯。
```

**$.visitEvents[23][2]**

```text
光顾着聊天，水都没喝完。
```

**$.visitReasons[0][0]**

```text
想来坐坐
```

**$.visitReasons[0][1]**

```text
今天在家吗？想过去坐会儿，没别的事。
```

**$.visitReasons[0][2]**

```text
来吧，正好有空
```

**$.visitReasons[0][3]**

```text
今天不方便，改天吧
```

**$.visitReasons[1][0]**

```text
带了点心
```

**$.visitReasons[1][1]**

```text
买了点心，吃不完。你在家的话，我带点过去？
```

**$.visitReasons[1][2]**

```text
来，我拿个盘子
```

**$.visitReasons[1][3]**

```text
今天不行，你先留着
```

**$.visitReasons[2][0]**

```text
想借一杯水
```

**$.visitReasons[2][1]**

```text
走到附近有点渴，方便去你家喝口水吗？
```

**$.visitReasons[2][2]**

```text
来吧，顺便歇会儿
```

**$.visitReasons[2][3]**

```text
我这会儿不方便
```

**$.visitReasons[3][0]**

```text
来认领充电器
```

**$.visitReasons[3][1]**

```text
手机快没电了，想去你家充一会儿，方便吗？
```

**$.visitReasons[3][2]**

```text
来吧，充电器在这儿
```

**$.visitReasons[3][3]**

```text
今天不方便，先找地方充上
```

**$.visitReasons[4][0]**

```text
想交换八卦
```

**$.visitReasons[4][1]**

```text
有个八卦，消息里一两句说不清。能过去跟你说吗？
```

**$.visitReasons[4][2]**

```text
来吧，慢慢说
```

**$.visitReasons[4][3]**

```text
今天没空，晚点发我
```

**$.visitReasons[5][0]**

```text
想躲一会儿雨
```

**$.visitReasons[5][1]**

```text
没带伞，想找个地方等雨小点。你家方便过去吗？
```

**$.visitReasons[5][2]**

```text
快来，进屋躲躲
```

**$.visitReasons[5][3]**

```text
今天不方便，先找地方避雨
```

**$.visitReasons[6][0]**

```text
来分享一首歌
```

**$.visitReasons[6][1]**

```text
找到首歌，想放给你听。能去坐会儿吗？
```

**$.visitReasons[6][2]**

```text
来吧，一起听
```

**$.visitReasons[6][3]**

```text
今天没空，先发给我吧
```

**$.visitReasons[7][0]**

```text
要讲一个冷笑话
```

**$.visitReasons[7][1]**

```text
学了个冷笑话，想找你试试好不好笑。你在家吗？
```

**$.visitReasons[7][2]**

```text
来，我听听
```

**$.visitReasons[7][3]**

```text
今天不行，下回讲
```

**$.visitReasons[8][0]**

```text
想晒晒太阳
```

**$.visitReasons[8][1]**

```text
想去你那儿坐会儿，窗边那个位置留着没？
```

**$.visitReasons[8][2]**

```text
留着呢，来吧
```

**$.visitReasons[8][3]**

```text
今天不太方便
```

**$.visitReasons[9][0]**

```text
来还一本书
```

**$.visitReasons[9][1]**

```text
书看完了，想给你送回去，顺便聊聊。
```

**$.visitReasons[9][2]**

```text
来吧，看到哪儿了？
```

**$.visitReasons[9][3]**

```text
不急着还，改天吧
```

**$.visitReasons[10][0]**

```text
想找人试新茶
```

**$.visitReasons[10][1]**

```text
买了点新茶，想带过去一起尝尝。不知道好不好喝。
```

**$.visitReasons[10][2]**

```text
带来试试
```

**$.visitReasons[10][3]**

```text
今天没空，你先尝
```

**$.visitReasons[11][0]**

```text
想展示新发型
```

**$.visitReasons[11][1]**

```text
刚剪了头发，想过去让你看看。理发师一直说好看，我有点不信。
```

**$.visitReasons[11][2]**

```text
来，我帮你看看
```

**$.visitReasons[11][3]**

```text
今天不行，先拍张给我
```

**$.visitReasons[12][0]**

```text
来求植物急救
```

**$.visitReasons[12][1]**

```text
我养的那盆又蔫了，想过去问问你怎么养的。
```

**$.visitReasons[12][2]**

```text
来吧，照片也带上
```

**$.visitReasons[12][3]**

```text
今天不便，先发照片看看
```

**$.visitReasons[13][0]**

```text
想吃个橘子
```

**$.visitReasons[13][1]**

```text
买了橘子，想分你几个。今天能过去吗？
```

**$.visitReasons[13][2]**

```text
来，尝尝甜不甜
```

**$.visitReasons[13][3]**

```text
今天不行，你先吃
```

**$.visitReasons[14][0]**

```text
想聊聊奇怪的梦
```

**$.visitReasons[14][1]**

```text
做了个怪梦，梦见开冰箱去上班。想当面讲，打字太费劲。
```

**$.visitReasons[14][2]**

```text
来，我听听怎么开的
```

**$.visitReasons[14][3]**

```text
今天没空，留着下次讲
```

**$.visitReasons[15][0]**

```text
来练习道歉
```

**$.visitReasons[15][1]**

```text
刚出门就被自动门夹了下包，人倒是没事。想去你家坐会儿，缓缓。
```

**$.visitReasons[15][2]**

```text
来吧，包也带上
```

**$.visitReasons[15][3]**

```text
今天不行，先看看包坏没坏
```

**$.visitReasons[16][0]**

```text
来开五分钟小会
```

**$.visitReasons[16][1]**

```text
想去你家坐五分钟，可能也不止五分钟。今天方便吗？
```

**$.visitReasons[16][2]**

```text
方便，过来吧
```

**$.visitReasons[16][3]**

```text
今天没空，改天坐
```

**$.visitReasons[17][0]**

```text
想分享路边趣事
```

**$.visitReasons[17][1]**

```text
看见只猫把纸箱坐塌了，还一脸没事。想当面学给你看。
```

**$.visitReasons[17][2]**

```text
来，别忘了那个表情
```

**$.visitReasons[17][3]**

```text
今天没空，记着下次讲
```

**$.visitReasons[18][0]**

```text
来蹭一点安静
```

**$.visitReasons[18][1]**

```text
今天有点累，不想说太多话。能去你那儿坐一会儿吗？
```

**$.visitReasons[18][2]**

```text
来吧，不想说就歇着
```

**$.visitReasons[18][3]**

```text
今天不方便，你先好好歇歇
```

**$.visitReasons[19][0]**

```text
想给你看张照片
```

**$.visitReasons[19][1]**

```text
刚拍到朵像小狗的云，想拿过去给你看。你在家吗？
```

**$.visitReasons[19][2]**

```text
来吧，我看看
```

**$.visitReasons[19][3]**

```text
今天没空，先发我看看
```

**$.visitReasons[20][0]**

```text
想来交换零食
```

**$.visitReasons[20][1]**

```text
带了点咸口零食，想过去边吃边聊。
```

**$.visitReasons[20][2]**

```text
来，我找点喝的
```

**$.visitReasons[20][3]**

```text
今天不行，改天一起吃
```

**$.visitReasons[21][0]**

```text
来讨论晚饭难题
```

**$.visitReasons[21][1]**

```text
晚饭想了半天还没决定。能过去跟你商量一下吗？
```

**$.visitReasons[21][2]**

```text
来，一起想想
```

**$.visitReasons[21][3]**

```text
今天没空，你先吃吧
```

**$.visitReasons[22][0]**

```text
想找人吐槽闹钟
```

**$.visitReasons[22][1]**

```text
想找你吐槽一下闹钟，怎么每天都那么响。方便去坐坐吗？
```

**$.visitReasons[22][2]**

```text
来吧，我也没睡醒过
```

**$.visitReasons[22][3]**

```text
今天不行，下次听你说
```

**$.visitReasons[23][0]**

```text
来研究购物清单
```

**$.visitReasons[23][1]**

```text
本来只想买三样，结果购物车塞满了。想过去给你看看哪些能删。
```

**$.visitReasons[23][2]**

```text
来，先别结账
```

**$.visitReasons[23][3]**

```text
今天没空，先把购物车放着
```

**$.visitReasons[24][0]**

```text
想送你一朵小花
```

**$.visitReasons[24][1]**

```text
路过花店买了一朵花，想带给你。没什么日子，就是看着好看。
```

**$.visitReasons[24][2]**

```text
来，谢谢你啊
```

**$.visitReasons[24][3]**

```text
今天不方便，花你先养着吧
```

**$.visitReasons[25][0]**

```text
来练习夸人
```

**$.visitReasons[25][1]**

```text
有件事一直想当面夸你，又怕说得太认真。能过去坐会儿吗？
```

**$.visitReasons[25][2]**

```text
来吧，我先听听
```

**$.visitReasons[25][3]**

```text
今天不方便，下次说
```

**$.visitReasons[26][0]**

```text
想检查沙发舒适度
```

**$.visitReasons[26][1]**

```text
惦记你家沙发了。方便让我过去靠一会儿吗？
```

**$.visitReasons[26][2]**

```text
来，靠枕也给你留着
```

**$.visitReasons[26][3]**

```text
今天不方便，改天来
```

**$.visitReasons[27][0]**

```text
来展示神奇石头
```

**$.visitReasons[27][1]**

```text
捡了颗像土豆的石头，想带给你看。拍照总拍不像。
```

**$.visitReasons[27][2]**

```text
来，让我看看多像
```

**$.visitReasons[27][3]**

```text
今天不行，下次带来
```

**$.visitReasons[28][0]**

```text
想聊聊旧事
```

**$.visitReasons[28][1]**

```text
想起上回那件事，又笑了半天。想过去跟你对一下是不是记错了。
```

**$.visitReasons[28][2]**

```text
来，你先别忘了
```

**$.visitReasons[28][3]**

```text
今天没空，下回聊
```

**$.visitReasons[29][0]**

```text
来做天气观察员
```

**$.visitReasons[29][1]**

```text
想去你家坐会儿，吹吹风。窗边那个位置还空着吧？
```

**$.visitReasons[29][2]**

```text
空着，来吧
```

**$.visitReasons[29][3]**

```text
今天不方便
```

**$.visitReasons[30][0]**

```text
想借一点勇气
```

**$.visitReasons[30][1]**

```text
有件事一直没敢动手，想先找你聊两句。你现在方便吗？
```

**$.visitReasons[30][2]**

```text
来吧，慢慢说
```

**$.visitReasons[30][3]**

```text
今天不方便，晚点联系
```

**$.visitReasons[31][0]**

```text
来传授省钱妙招
```

**$.visitReasons[31][1]**

```text
今天不想逛店了，怕又乱买。能去你那儿坐会儿吗？
```

**$.visitReasons[31][2]**

```text
来吧，不用买东西
```

**$.visitReasons[31][3]**

```text
今天没空，先回家歇歇吧
```

**$.visitReasons[32][0]**

```text
想分享好消息
```

**$.visitReasons[32][1]**

```text
有个好消息，想当面告诉你。你在家吗？
```

**$.visitReasons[32][2]**

```text
在呢，过来说
```

**$.visitReasons[32][3]**

```text
今天不方便，先在这儿说？
```

**$.visitReasons[33][0]**

```text
来交换今日糗事
```

**$.visitReasons[33][1]**

```text
今天跟人挥手才发现认错了，想去你家把这事讲完。
```

**$.visitReasons[33][2]**

```text
来，我听听
```

**$.visitReasons[33][3]**

```text
今天没空，改天讲
```

**$.visitReasons[34][0]**

```text
想带个谜语来
```

**$.visitReasons[34][1]**

```text
有个谜语，答案我也没弄明白。想过去一起猜猜。
```

**$.visitReasons[34][2]**

```text
来，我也试试
```

**$.visitReasons[34][3]**

```text
今天不行，先发给我
```

**$.visitReasons[35][0]**

```text
来给生活按暂停
```

**$.visitReasons[35][1]**

```text
今天一直赶来赶去，想去你家歇会儿。可以吗？
```

**$.visitReasons[35][2]**

```text
来吧，坐会儿
```

**$.visitReasons[35][3]**

```text
今天不方便，你先歇着
```

**$.visitReasons[36][0]**

```text
想听听你的近况
```

**$.visitReasons[36][1]**

```text
最近怎么样？想过去看看你，坐着聊两句。
```

**$.visitReasons[36][2]**

```text
来吧，刚好有空
```

**$.visitReasons[36][3]**

```text
今天不方便，改天联系
```

**$.visitReasons[37][0]**

```text
来分享打折情报
```

**$.visitReasons[37][1]**

```text
看到家店打折，想去你那儿一起看看是不是真划算。
```

**$.visitReasons[37][2]**

```text
来，先别急着买
```

**$.visitReasons[37][3]**

```text
今天没空，链接发我吧
```

**$.visitReasons[38][0]**

```text
想来做表情练习
```

**$.visitReasons[38][1]**

```text
我学了个表情，自己看着挺怪。想过去给你看一眼。
```

**$.visitReasons[38][2]**

```text
来，我看看
```

**$.visitReasons[38][3]**

```text
今天不方便，下次给我看
```

**$.visitReasons[39][0]**

```text
来一起什么也不干
```

**$.visitReasons[39][1]**

```text
今天什么也不想干。能去你那儿一起待会儿吗？
```

**$.visitReasons[39][2]**

```text
来吧，坐着也行
```

**$.visitReasons[39][3]**

```text
今天不方便，改天吧
```
