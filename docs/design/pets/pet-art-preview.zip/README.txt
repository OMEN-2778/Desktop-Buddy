双击 pet-preview.html 查看全部品种和动作，无需联网。
assets 中是透明 PNG 动作图集和 manifest.json。
这只是素材试作，不含领养、需求或宠物 AI。
